definition(
    name:        "Local Air Pressure Server",
    namespace:   "local v. 1.2",
    author:      "John Land and Claude AI",
    description: "Averages local pressure sensors; serves result to ESP32 displays via HTTP GET",
    category:    "Utility",
    iconUrl:      "", 
    iconX2Url:    "",
    oauth: true
)

preferences {
    section("") {
        input "pressureSensors", "capability.pressureMeasurement",
              title: "Select pressure sensors",
              multiple: true, required: true, submitOnChange: true
    }
    section("") {
        input "updateIntervalMinutes", "number",
              title: "<b>Schedule:</b> Recompute average every X minutes",
              defaultValue: 5, required: true
    }
    section("") {
        input "maxAgeMinutes", "number",
              title: "<b>Staleness:</b> Ignore readings older than X minutes",
              defaultValue: 35, required: true
    }
    section {
        input "btnRefresh", "button", title: "Refresh"

        if (state.lastReadings) {
            String table = "<table style='width:100%'>" +
                           "<tr><th style='text-align:left'>Sensor</th>" +
                           "<th style='text-align:right'>hPa</th>" +
                           "<th style='text-align:right'>Status</th></tr>"
            state.lastReadings.each { r ->
                String hpaStr    = r.hpa != null ? "${r.hpa}" : "—"
                String statusStr = r.status == "ok"               ? "✓" :
                                   r.status == "offline"          ? "Offline" :
                                   r.status == "stale"            ? "Stale (${r.age_minutes?.toLong()}m)" :
                                   r.status == "out_of_range"     ? "Out of range" :
                                   r.status == "no_value"         ? "No value" :
                                   r.status == "no_pressure_attr" ? "No pressure attribute" : r.status
                String color     = r.status == "ok"               ? "green" : "red"
                table += "<tr>" +
                         "<td>${r.name}</td>" +
                         "<td style='text-align:right'>${hpaStr}</td>" +
                         "<td style='text-align:right;color:${color}'>${statusStr}</td>" +
                         "</tr>"
            }
            table += "</table>"
            paragraph table
        } else {
            paragraph "No readings yet — click Refresh or wait for the next scheduled run."
        }

        if (state.avgPressureHpa) {
            long ageSeconds = state.lastUpdated ? (now() - state.lastUpdated) / 1000 : -1
            String ageStr   = ageSeconds < 0    ? "unknown" :
                              ageSeconds < 60   ? "${ageSeconds}s ago" :
                              ageSeconds < 3600 ? "${(ageSeconds / 60).toLong()}m ago" :
                                                  "${(ageSeconds / 3600).toLong()}h ago"
            paragraph "<b>Average: ${state.avgPressureHpa} hPa</b>  " +
                      "(${state.validCount} valid of ${state.sensorCount} selected sensor${state.sensorCount == 1 ? '' : 's'}, " +
                      "computed ${ageStr})"
        }
    }
    section("") {
        if (state.accessToken) {
            paragraph "Copy this ESP32 Access URL into secrets.h:\n\n" +
                      "http://${location.hub.localIP}/apps/api/${app.id}/pressure" +
                      "?access_token=${state.accessToken}"
        } else {
            paragraph "Click Done once to generate the access token, then re-open this app to see the URL."
        }
    }
}

def appButtonHandler(btn) {
    if (btn == "btnRefresh") {
        computeAverage()
    }
}

mappings {
    path("/pressure") {
        action: [ GET: "handleGet" ]
    }
}

def handleGet() {
    def avg      = state.avgPressureHpa ?: 0
    int cnt      = state.sensorCount    ?: 0
    int valid    = state.validCount     ?: 0
    long age     = state.lastUpdated    ? (now() - state.lastUpdated) / 1000 : -1
    def readings = state.lastReadings   ?: []

    return render(
        contentType: "application/json",
        data: groovy.json.JsonOutput.toJson([
            hpa           : avg,
            sensors       : cnt,
            sensors_valid : valid,
            age_seconds   : age,
            readings      : readings
        ])
    )
}

def installed()  { initialize() }
def updated()    { unschedule(); initialize() }
def uninstalled(){ unschedule() }

def initialize() {
    if (!state.accessToken) {
        try {
            createAccessToken()
            log.info "Local Pressure Server: access token created"
        } catch (e) {
            log.error "Local Pressure Server: could not create access token — make sure OAuth is enabled in Apps Code: ${e}"
        }
    }

    log.info "Local Pressure Server URL: " +
             "http://${location.hub.localIP}/apps/api/${app.id}/pressure" +
             "?access_token=${state.accessToken}"

    int interval = Math.min(Math.max((updateIntervalMinutes ?: 5).toInteger(), 1), 59)
    switch (interval) {
        case  1: runEvery1Minute("computeAverage");   break
        case  5: runEvery5Minutes("computeAverage");  break
        case 10: runEvery10Minutes("computeAverage"); break
        case 15: runEvery15Minutes("computeAverage"); break
        case 30: runEvery30Minutes("computeAverage"); break
        default: schedule("0 */${interval} * * * ?", "computeAverage")
    }
    computeAverage()
}

def computeAverage() {
    long nowMs           = now()
    long maxAgeMs        = (maxAgeMinutes ?: 35).toLong() * 60000L
    int  totalSelected   = pressureSensors ? pressureSensors.size() : 0
    List<Float> readings = []
    List<Map>   details  = []

    pressureSensors.each { dev ->
        // Skip devices that don't expose a pressure attribute at all.
        // This lets the dropdown use capability.* while still filtering at runtime.
        if (dev.currentValue("pressure") == null && !dev.hasAttribute("pressure")) {
            log.debug "${dev.displayName}: no pressure attribute, skipping"
            details << [name: dev.displayName, hpa: null, status: "no_pressure_attr"]
            return
        }

        String health = dev.currentValue("healthStatus")
        if (health != null && health != "online") {
            log.debug "${dev.displayName}: offline, skipping"
            details << [name: dev.displayName, hpa: null, status: "offline"]
            return
        }
        Long lastActivity = dev.getLastActivity()?.getTime()
        if (lastActivity != null && (nowMs - lastActivity) > maxAgeMs) {
            log.debug "${dev.displayName}: stale (${(nowMs-lastActivity)/60000} min), skipping"
            details << [name: dev.displayName, hpa: null, status: "stale",
                        age_minutes: (nowMs - lastActivity) / 60000]
            return
        }
        def raw = dev.currentValue("pressure")
        if (raw == null) {
            details << [name: dev.displayName, hpa: null, status: "no_value"]
            return
        }
        float hpa = raw.toFloat()
        if (hpa < 800 || hpa > 1100) {
            details << [name: dev.displayName, hpa: hpa, status: "out_of_range"]
            return
        }
        log.debug "${dev.displayName}: ${hpa} hPa"
        readings << hpa
        details  << [name: dev.displayName, hpa: hpa.round(1), status: "ok"]
    }

    if (readings) {
        // Denominator is valid sensors only — offline/stale devices are excluded
        // so a spontaneously unavailable sensor doesn't skew the average.
        float avg            = readings.sum() / readings.size()
        state.avgPressureHpa = avg.round(1)
        state.sensorCount    = totalSelected
        state.validCount     = readings.size()
        state.lastUpdated    = nowMs
        state.lastReadings   = details
        log.info "Local Pressure Server: avg=${state.avgPressureHpa} hPa " +
                 "(${readings.size()} valid / ${totalSelected} selected)"
    } else {
        state.sensorCount    = totalSelected
        state.validCount     = 0
        state.lastReadings   = details
        log.warn "Local Pressure Server: no valid readings this cycle"
    }
}
