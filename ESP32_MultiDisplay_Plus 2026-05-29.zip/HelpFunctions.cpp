/*
  HelpFunctions.cpp
  
  Helper functions including NTP, font management, color parsing,
  JSON/GET parameter parsing, and text positioning
  
  Requires: ArduinoJson v7.x (tested with 7.4.2)
 */

#include "User_Setup.h"     //MUST be first - provides DEFAULT_ROTATION and other defaults
#include "HelpFunctions.h"
#include "WebDebugLog.h"    //For DEBUG_PRINT/PRINTLN/PRINTF macros
#include "secrets.h"
#include <WiFi.h>
#include <time.h>
#include "HTML.h"
#include "RobotoFonts.h"

//Note: DEBUG_PRINT, DEBUG_PRINTLN, DEBUG_PRINTF macros are provided by WebDebugLog.h
//(included via HelpFunctions.h). These macros automatically handle both Serial and web logging
//(web logging only when ENABLE_WEB_LOGGING is true in User_Setup.h).

//=============================================================
//External References from main sketch
//=============================================================
extern int  sunriseHour;
extern int  sunriseMinute;
extern int  sunsetHour;
extern int  sunsetMinute;
extern bool sunTimesValid;
extern String deviceName;
extern const char* Version;
extern void setBrightness(uint8_t brightness);

//=============================================================
//NTP Server Configuration
//=============================================================
static const char* ntpServer1   = "pool.ntp.org";
static const char* ntpServer2   = "time.google.com";
static const char* ntpServer3   = "time.windows.com";
static const char* ntpServer4   = "time.nist.gov";
static const char* ntpServers[] = { ntpServer1, ntpServer2, ntpServer3, ntpServer4 };
static const int numServers     = sizeof(ntpServers) / sizeof(ntpServers[0]);

//=============================================================
//NTP Initialization
//=============================================================
void NTP_Init() {
  struct tm timeinfo;
  bool timeSuccess            = false;
  const int maxAttemptsTotal  = 3;

  DEBUG_PRINTLN("\nInitializing NTP time synchronization...");
  DEBUG_PRINTF("  Timezone: %s\n", weatherTzString.c_str());

  for (int sweep = 1; sweep <= maxAttemptsTotal && !timeSuccess; sweep++) {
    DEBUG_PRINTF("  Time Synchronization Sweep %d of %d...\n", sweep, maxAttemptsTotal);

    for (int serverIndex = 0; serverIndex < numServers && !timeSuccess; serverIndex++) {
      //3-server window starting at serverIndex
      const char* s1 = ntpServers[serverIndex % numServers];
      const char* s2 = ntpServers[(serverIndex + 1) % numServers];
      const char* s3 = ntpServers[(serverIndex + 2) % numServers];

      DEBUG_PRINTF("\tAttempt %d/%d: NTP servers = %s, %s, %s\n", 
                    serverIndex + 1, numServers, s1, s2, s3);

      //weatherTzString handles DST automatically
      static int lastStartIndex = -999;
      if (lastStartIndex != serverIndex) {
        configTzTime(weatherTzString.c_str(), s1, s2, s3);
        lastStartIndex = serverIndex;
      }

      bool currentServerSuccess = getLocalTime(&timeinfo, 5000);

      if (currentServerSuccess) {
        DEBUG_PRINTLN("✓ Time synchronized successfully");
        DEBUG_PRINT("► Current time: ");
        char timeStr[32];
        strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %I:%M:%S %p", &timeinfo);
        DEBUG_PRINTLN(timeStr);
        timeSuccess = true;
      } else {
        DEBUG_PRINTLN("  Failed to obtain time from this attempt");
        if (serverIndex < numServers - 1) {
          DEBUG_PRINTLN("  Moving to next server in 1 second...");
          delay(1000);
        }
      }
    }

    if (!timeSuccess && sweep < maxAttemptsTotal) {
      DEBUG_PRINTLN("  Sweep failed. Trying next sweep in 2 seconds...");
      delay(2000);
    }
  }

  if (!timeSuccess) {
    DEBUG_PRINTLN("⚠ Failed to sync time after all attempts. Will retry in background.");
  }
}

//=============================================================
//Background NTP Sync Check
//=============================================================
void NTP_CheckSync() {
  static unsigned long lastSyncAttempt = 0;
  static bool lastSyncFailed = false;

  const unsigned long SYNC_INTERVAL  = 3600000UL;  //1 hour
  const unsigned long RETRY_INTERVAL = 60000UL;    //1 minute
  unsigned long interval = lastSyncFailed ? RETRY_INTERVAL : SYNC_INTERVAL;

  if (millis() - lastSyncAttempt < interval) return;
  lastSyncAttempt = millis();

  struct tm timeinfo;
  if (getLocalTime(&timeinfo)) {
    lastSyncFailed = false;
    return; //time is good; nothing to do
  }

  DEBUG_PRINTLN("\nTime not synced. Attempting NTP sync...");
  NTP_Init();  //Re-do robust round-robin sweeps
  lastSyncFailed = !getLocalTime(&timeinfo);
  if (lastSyncFailed) {
    DEBUG_PRINTLN("NTP sync still failed. Will retry in 1 minute.");
  } else {
    DEBUG_PRINTLN("NTP time sync successful!");
  }
}

void flushDisplay() {
  gfx->flush();
}

//=============================================================
//Device Identification
//=============================================================
String getDeviceID() {
  uint64_t chipId = ESP.getEfuseMac();
  char idStr[18];
  snprintf(idStr, sizeof(idStr), "%012llX", chipId);
  return String(idStr);
}

//=======================================================================
//Function to map device ID as reported by each board to a 
//user-friendly but unique board name used, e.g., in the mDNS setup
//           ******* The lookup table is in secrets.h ******* 
//=======================================================================

String getDeviceName() {
  uint64_t chipId = ESP.getEfuseMac();   
  //Default naming if not in table
  String devName = "Display-"   + String((uint16_t)(chipId & 0xFFFF), HEX);

  //Look up chipId in secrets.h mapping table to get the corresponding device name
  for (int i = 0; i < sizeof(deviceMappings) / sizeof(deviceMappings[0]); i++) {
    if (deviceMappings[i].chipId == chipId) {
      devName = String(deviceMappings[i].name);
      DEBUG_PRINTF("Device Name : %s\n", devName.c_str());  //Print board name
    }
  }  

  DEBUG_PRINTF("Device ID   : 0x%012llX\n", chipId);              //Print as hex without colons
  //Get 64-bit "MAC"; byte order is reversed from standard MAC
  DEBUG_PRINTF("MAC Address : %02X:%02X:%02X:%02X:%02X:%02X\n",   //Print with colons (standard MAC format)
    (uint8_t)(chipId >> 0),   //Least significant byte first
    (uint8_t)(chipId >> 8),
    (uint8_t)(chipId >> 16),
    (uint8_t)(chipId >> 24),
    (uint8_t)(chipId >> 32),
    (uint8_t)(chipId >> 40)   //Most significant byte last
  );

  return (devName);
}

//=============================================================
//Time Formatting Functions
//=============================================================
bool isTimeSynced() {
  struct tm timeinfo;
  return getLocalTime(&timeinfo);
}

String getTimeString() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return "No time";
  
  char timeStr[20];
  strftime(timeStr, sizeof(timeStr), "%H:%M:%S", &timeinfo);
  return String(timeStr);
}

String getFormattedTime(const char* format) {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return "No time";
  
  char buffer[128];
  strftime(buffer, sizeof(buffer), format, &timeinfo);
  String result = String(buffer);
  result.trim();
  return result;
}

//=============================================================
//Sunrise/Sunset Management
//=============================================================
void updateSunTimes(int newSunriseHour, int newSunriseMinute,
                    int newSunsetHour, int newSunsetMinute) {
  sunriseHour   = newSunriseHour;
  sunriseMinute = newSunriseMinute;
  sunsetHour    = newSunsetHour;
  sunsetMinute  = newSunsetMinute;
  sunTimesValid = true;
}

//=============================================================
//Font Selection System
//=============================================================
bool isSupportedRobotoFontCode(int fontNum) {
  switch (fontNum) {
    case 6: case 8: case 10: case 12: case 14: case 16: case 18: case 20: case 22: case 24:
    case 26: case 28: case 30: case 32: case 34: case 36: case 38: case 40: case 42: case 44:
    case 46: case 48:
      return true;
    default:
      return false;
  }
}

int validateRobotoFontCode(int fontNum) {
  if (isSupportedRobotoFontCode(fontNum)) return fontNum;
  if (fontNum <= 6)  return 6;
  if (fontNum >= 48) return 48;

  // Supported sizes are every 2 points from 6 to 48; round odd sizes up to the next available font
  if (fontNum & 1) fontNum++;
  if (fontNum < 6)  fontNum = 6;
  if (fontNum > 48) fontNum = 48;
  return fontNum;
}

void setSmartFont(int fontNum) {
  //Font code = point size (e.g. 16 = 16pt Roboto Regular)
  fontNum = validateRobotoFontCode(fontNum);

  switch (fontNum) {
    case  6:  gfx->setFont(&Roboto_Regular6pt8b);  break;
    case  8:  gfx->setFont(&Roboto_Regular8pt8b);  break;
    case 10:  gfx->setFont(&Roboto_Regular10pt8b); break;
    case 12:  gfx->setFont(&Roboto_Regular12pt8b); break;
    case 14:  gfx->setFont(&Roboto_Regular14pt8b); break;
    case 16:  gfx->setFont(&Roboto_Regular16pt8b); break;
    case 18:  gfx->setFont(&Roboto_Regular18pt8b); break;
    case 20:  gfx->setFont(&Roboto_Regular20pt8b); break;
    case 22:  gfx->setFont(&Roboto_Regular22pt8b); break;
    case 24:  gfx->setFont(&Roboto_Regular24pt8b); break;
    case 26:  gfx->setFont(&Roboto_Regular26pt8b); break;
    case 28:  gfx->setFont(&Roboto_Regular28pt8b); break;
    case 30:  gfx->setFont(&Roboto_Regular30pt8b); break;
    case 32:  gfx->setFont(&Roboto_Regular32pt8b); break;
    case 34:  gfx->setFont(&Roboto_Regular34pt8b); break;
    case 36:  gfx->setFont(&Roboto_Regular36pt8b); break;
    case 38:  gfx->setFont(&Roboto_Regular38pt8b); break;
    case 40:  gfx->setFont(&Roboto_Regular40pt8b); break;
    case 42:  gfx->setFont(&Roboto_Regular42pt8b); break;
    case 44:  gfx->setFont(&Roboto_Regular44pt8b); break;
    case 46:  gfx->setFont(&Roboto_Regular46pt8b); break;
    case 48:  gfx->setFont(&Roboto_Regular48pt8b); break;
    default:
      gfx->setFont(&Roboto_Regular16pt8b);  //Default fallback (16pt)
      break;
  }
}

//=============================================================
//Color Parsing
//=============================================================
uint16_t parseColor(String colorStr) {
  colorStr.toLowerCase();
  colorStr.trim();
  
  //Named colors
  if (colorStr == "black")    return COLOR_BLACK;
  if (colorStr == "white")    return COLOR_WHITE;
  if (colorStr == "red")      return COLOR_RED;
  if (colorStr == "green")    return COLOR_GREEN;
  if (colorStr == "blue")     return COLOR_BLUE;
  if (colorStr == "cyan")     return COLOR_CYAN;
  if (colorStr == "yellow")   return COLOR_YELLOW;
  if (colorStr == "magenta")  return COLOR_MAGENTA;
  if (colorStr == "orange")   return COLOR_ORANGE;
  if (colorStr == "purple")   return COLOR_PURPLE;
  if (colorStr == "pink")     return COLOR_PINK;
  if (colorStr == "brown")    return COLOR_BROWN;
  if (colorStr == "lightgray"  || colorStr == "lightgrey")  return COLOR_LIGHTGRAY;
  if (colorStr == "gray"       || colorStr == "grey")       return COLOR_GRAY;
  if (colorStr == "mediumgray" || colorStr == "mediumgrey") return COLOR_GRAY;
  if (colorStr == "darkgray"   || colorStr == "darkgrey")   return COLOR_DARKGRAY;
  if (colorStr == "gray10"     || colorStr == "grey10")     return COLOR_GRAY10;
  if (colorStr == "gray20"     || colorStr == "grey20")     return COLOR_GRAY20;
  if (colorStr == "gray30"     || colorStr == "grey30")     return COLOR_GRAY30;
  if (colorStr == "gray40"     || colorStr == "grey40")     return COLOR_GRAY40;
  if (colorStr == "gray50"     || colorStr == "grey50")     return COLOR_GRAY50;
  if (colorStr == "gray60"     || colorStr == "grey60")     return COLOR_GRAY60;
  if (colorStr == "gray70"     || colorStr == "grey70")     return COLOR_GRAY70;
  if (colorStr == "gray80"     || colorStr == "grey80")     return COLOR_GRAY80;
  if (colorStr == "gray90"     || colorStr == "grey90")     return COLOR_GRAY90;

  //Hex color parsing (#RRGGBB or #RGB)
  if (colorStr.startsWith("#")) {
    colorStr.remove(0, 1);
    long rgb = strtol(colorStr.c_str(), NULL, 16);

    if (colorStr.length() == 6) {  //Full 24-bit color (#RRGGBB)
      uint8_t r = (rgb >> 16) & 0xFF;
      uint8_t g = (rgb >> 8) & 0xFF;
      uint8_t b = rgb & 0xFF;
      //Convert RGB888 to RGB565
      return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
    } else if (colorStr.length() == 3) {  //Short form (#RGB)
      uint8_t r = ((rgb >> 8) & 0xF) * 17;
      uint8_t g = ((rgb >> 4) & 0xF) * 17;
      uint8_t b = (rgb & 0xF) * 17;
      return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
    }
  }

  return COLOR_WHITE;  //Default fallback
}

// getTextBoundsHF — calls gfx->getTextBounds from HelpFunctions.cpp.
// This works around an Arduino_GFX 1.6.5 issue where getTextBounds crashes
// when called from the main .ino translation unit after certain state changes.
void getTextBoundsHF(const char* str, int16_t x, int16_t y,
                     int16_t* x1, int16_t* y1, uint16_t* w, uint16_t* h) {
  gfx->getTextBounds(str, x, y, x1, y1, w, h);
}

// printHF — calls gfx->print from HelpFunctions.cpp translation unit.
// Same workaround as getTextBoundsHF: Arduino_GFX 1.6.5 font PROGMEM
// access works correctly from HF but corrupts heap when called from .ino.
void printHF(const char* str) {
  int16_t cy = gfx->getCursorY();
  //Guard against writing above the framebuffer (crashes) or
  //fully below it (wastes time). Top-edge is the dangerous one:
  //drawChar writes to framebuffer[y*w+x] with no top-clipping.
  if (cy < 0)               gfx->setCursor(gfx->getCursorX(), 0);
  if (cy >= DISPLAY_SHORT)  return;  //entirely off-screen, skip
  gfx->print(str);
}

String colorToHex(uint16_t color) {
  uint8_t r5 = (color >> 11) & 0x1F;
  uint8_t g6 = (color >> 5)  & 0x3F;
  uint8_t b5 =  color        & 0x1F;

  //Expand to 8-bit with bit replication (gives true #FFFFFF for 0xFFFF)
  uint8_t r = (r5 << 3) | (r5 >> 2);
  uint8_t g = (g6 << 2) | (g6 >> 4);
  uint8_t b = (b5 << 3) | (b5 >> 2);

  char hexColor[8];
  sprintf(hexColor, "#%02X%02X%02X", r, g, b);
  return String(hexColor);
}

//=============================================================
//Convert RGB565 Color to String (for web display)
//=============================================================
String colorToString(uint16_t color) {
  //Convert RGB565 Color to String (for web display)
  //Prefer named colors when possible; otherwise fall back to #RRGGBB.
  if (color == COLOR_BLACK)      return "Black";
  if (color == COLOR_WHITE)      return "White";
  if (color == COLOR_RED)        return "Red";
  if (color == COLOR_GREEN)      return "Green";
  if (color == COLOR_BLUE)       return "Blue";
  if (color == COLOR_CYAN)       return "Cyan";
  if (color == COLOR_YELLOW)     return "Yellow";
  if (color == COLOR_MAGENTA)    return "Magenta";
  if (color == COLOR_ORANGE)     return "Orange";
  if (color == COLOR_PURPLE)     return "Purple";
  if (color == COLOR_PINK)       return "Pink";
  if (color == COLOR_BROWN)      return "Brown";
  if (color == COLOR_LIGHTGRAY)  return "LightGray";
  if (color == COLOR_GRAY)       return "Gray";
  if (color == COLOR_DARKGRAY)   return "DarkGray";
  if (color == COLOR_GRAY10)     return "Gray10";
  if (color == COLOR_GRAY20)     return "Gray20";
  if (color == COLOR_GRAY30)     return "Gray30";
  if (color == COLOR_GRAY40)     return "Gray40";
  if (color == COLOR_GRAY60)     return "Gray60";
  if (color == COLOR_GRAY70)     return "Gray70";
  if (color == COLOR_GRAY80)     return "Gray80";
  if (color == COLOR_GRAY90)     return "Gray90";
  //Convert unknown colors to hex format
  uint8_t r = ((color >> 11) & 0x1F) << 3;  //5 bits to 8 bits
  uint8_t g = ((color >> 5) & 0x3F) << 2;   //6 bits to 8 bits
  uint8_t b = (color & 0x1F) << 3;          //5 bits to 8 bits
  
  char hexStr[8];
  sprintf(hexStr, "#%02X%02X%02X", r, g, b);
  return String(hexStr);
}

//=============================================================
// Normalize display text encoding
// Replaces common UTF-8 multibyte sequences with single-byte
// Latin-1 equivalents that the Roboto GFX font tables include.
// Call before passing user-supplied or API strings to printHF().
//=============================================================
String normalizeDisplayTextEncoding(String s) {
  // Degree sign: UTF-8 0xC2 0xB0 → Latin-1 0xB0
  s.replace("\xC2\xB0", "\xB0");
  // Left double angle «: UTF-8 0xC2 0xAB → Latin-1 0xAB
  s.replace("\xC2\xAB", "\xAB");
  // Right double angle »: UTF-8 0xC2 0xBB → Latin-1 0xBB
  s.replace("\xC2\xBB", "\xBB");
  // En dash –: UTF-8 0xE2 0x80 0x93 → hyphen-minus
  s.replace("\xE2\x80\x93", "-");
  // Em dash —: UTF-8 0xE2 0x80 0x94 → hyphen-minus
  s.replace("\xE2\x80\x94", "-");
  // Left single curly quote ': UTF-8 0xE2 0x80 0x98 → apostrophe
  s.replace("\xE2\x80\x98", "'");
  // Right single curly quote ': UTF-8 0xE2 0x80 0x99 → apostrophe
  s.replace("\xE2\x80\x99", "'");
  return s;
}

//=============================================================
//Rotation Conversion
//=============================================================
int getRotationIndex(int rotationDeg) {
  switch (rotationDeg) {
    case   0: return 0;
    case  90: return 1;
    case 180: return 2;
    case 270: return 3;
    default:  return 3;  //Default to 270° (landscape-flipped)
  }
}
//=============================================================
//Case-Insensitive Key Finding for JSON (ArduinoJson v7)
//=============================================================
const char* findKeyIgnoreCase(const JsonDocument& doc, const char* key) {
  //ArduinoJson v7: Use as<JsonObjectConst>() for const iteration
  if (!doc.is<JsonObjectConst>()) {
    return nullptr;
  }

  JsonObjectConst obj = doc.as<JsonObjectConst>();
  for (JsonPairConst kv : obj) {
    String jsonKey = String(kv.key().c_str());
    String searchKey = String(key);
    jsonKey.toLowerCase();
    searchKey.toLowerCase();
    if (jsonKey == searchKey) {
      return kv.key().c_str();
    }
  }
  return nullptr;
}

//=============================================================
//JSON Parameter Extraction Helpers
//=============================================================
bool getJSON_String(const JsonDocument& doc, const char* key, String& outValue, const char* debugLabel) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<String>()) {
    outValue = doc[actualKey].as<String>();
    if (outValue.length() == 0) outValue = "none";
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + outValue);
    return true;
  }
  return false;
}

bool getJSON_Color(const JsonDocument& doc, const char* key, uint16_t& outValue, const char* debugLabel) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<String>()) {
    String colorStr = doc[actualKey].as<String>();
    outValue = parseColor(colorStr);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + colorStr);
    return true;
  }
  return false;
}

bool getJSON_Int(const JsonDocument& doc, const char* key, int& outValue, int minVal, int maxVal,
                 const char* debugLabel, const char* suffix) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<int>()) {
    outValue = constrain(doc[actualKey].as<int>(), minVal, maxVal);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + suffix);
    return true;
  }
  return false;
}

bool getJSON_UInt(const JsonDocument& doc, const char* key, uint8_t& outValue, int minVal, int maxVal,
                  const char* debugLabel, const char* suffix) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<int>()) {
    outValue = constrain(doc[actualKey].as<int>(), minVal, maxVal);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + suffix);
    return true;
  }
  return false;
}

bool getJSON_ULong(const JsonDocument& doc, const char* key, unsigned long& outValue,
                   unsigned long minVal, unsigned long maxVal,
                   const char* debugLabel, const char* suffix) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<int>()) {
    outValue = constrain(doc[actualKey].as<unsigned long>(), minVal, maxVal);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + suffix);
    return true;
  }
  return false;
}

bool getJSON_Bool(const JsonDocument& doc, const char* key, bool& outValue, const char* debugLabel) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<bool>()) {
    outValue = doc[actualKey].as<bool>();
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue ? "True" : "False"));
    return true;
  }
  return false;
}

bool getJSON_Rotation(const JsonDocument& doc, const char* key, int& outValue, const char* debugLabel) {
  const char* actualKey = findKeyIgnoreCase(doc, key);
  if (actualKey && doc[actualKey].is<int>()) {
    int rotation = doc[actualKey].as<int>();
    //Constrain to allowed degrees: 0, 90, 180, 270
    if (rotation != 0 && rotation != 90 && rotation != 180 && rotation != 270) {
      rotation = DEFAULT_ROTATION;
    }
    outValue = rotation;
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + "°");
    return true;
  }
  return false;
}

//=============================================================
//GET Parameter Extraction Helpers
//=============================================================
int findArgIndexIgnoreCase(const char* key) {
  for (int i = 0; i < server.args(); i++) {
    String argName = server.argName(i);
    String searchKey = String(key);
    argName.toLowerCase();
    searchKey.toLowerCase();
    if (argName == searchKey) {
      return i;
    }
  }
  return -1;
}

bool hasArgIgnoreCase(const char* key) {
  return findArgIndexIgnoreCase(key) >= 0;
}

String getArgIgnoreCase(const char* key) {
  int index = findArgIndexIgnoreCase(key);
  if (index >= 0) {
    return server.arg(index);
  }
  return "";
}

bool getGET_String(const char* key, String& outValue, const char* debugLabel, bool& configChanged) {
  if (hasArgIgnoreCase(key)) {
    outValue = getArgIgnoreCase(key);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + outValue);
    configChanged = true;
    return true;
  }
  return false;
}

bool getGET_Color(const char* key, uint16_t& outValue, const char* debugLabel, bool& configChanged) {
  if (hasArgIgnoreCase(key)) {
    String colorStr = getArgIgnoreCase(key);
    outValue = parseColor(colorStr);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + colorStr);
    configChanged = true;
    return true;
  }
  return false;
}

bool getGET_Int(const char* key, int& outValue, int minVal, int maxVal, const char* debugLabel, 
                bool& configChanged, const char* suffix) {
  if (hasArgIgnoreCase(key)) {
    outValue = constrain(getArgIgnoreCase(key).toInt(), minVal, maxVal);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + suffix);
    configChanged = true;
    return true;
  }
  return false;
}

bool getGET_UInt(const char* key, uint8_t& outValue, int minVal, int maxVal, 
                 const char* debugLabel, bool& configChanged) {
  if (hasArgIgnoreCase(key)) {
    outValue = constrain(getArgIgnoreCase(key).toInt(), minVal, maxVal);
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue));
    configChanged = true;
    return true;
  }
  return false;
}

bool getGET_Bool(const char* key, bool& outValue, const char* debugLabel, bool& configChanged) {
  if (hasArgIgnoreCase(key)) {
    String value = getArgIgnoreCase(key);
    value.toLowerCase();
    outValue = (value == "true" || value == "1");
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue ? "True" : "False"));
    configChanged = true;
    return true;
  }
  return false;
}

bool getGET_Rotation(const char* key, int& outValue, const char* debugLabel, bool& configChanged) {
  if (hasArgIgnoreCase(key)) {
    int rotation = getArgIgnoreCase(key).toInt();
    if (rotation != 0 && rotation != 90 && rotation != 180 && rotation != 270) {
      rotation = DEFAULT_ROTATION;
    }
    outValue = rotation;
    if (debugLabel) DEBUG_PRINTLN(String(debugLabel) + ": " + String(outValue) + "°");
    configChanged = true;
    return true;
  }
  return false;
}

//=============================================================
//Text Positioning Helper
//=============================================================
TextPosition calculateTextPosition(
  int16_t screenW, int16_t screenH,
  uint16_t textW, uint16_t textH,
  int16_t textY1,   //y1 from getTextBounds (negative = above baseline)
  String hAlign, String vAlign,
  int16_t marginX,
  int16_t marginY
) {
  TextPosition pos;

  //Horizontal alignment
  hAlign.toLowerCase();
  if (hAlign == "center" || hAlign == "centre") {
    pos.x = (screenW - (int16_t)textW) / 2;
  } else if (hAlign == "right") {
    pos.x = screenW - (int16_t)textW - marginX;
  } else {
    pos.x = marginX;
  }
  if (pos.x < marginX) pos.x = marginX;

  //Vertical alignment — pos.y is the GFX baseline (setCursor Y).
  //textY1 is from getTextBounds: negative offset from baseline to glyph top.
  //  topOfGlyph = baseline + textY1  (textY1 < 0)
  //  bottomOfGlyph = baseline + textY1 + textH
  vAlign.toLowerCase();
  if (vAlign == "middle" || vAlign == "center" || vAlign == "centre") {
    //Center the glyph block vertically: topOfGlyph = (screenH - textH) / 2
    int16_t topOfGlyph = (screenH - (int16_t)textH) / 2;
    pos.y = topOfGlyph - textY1;  //baseline = top - y1 (y1 is negative)
  } else if (vAlign == "bottom") {
    //Bottom of glyph at screenH - marginY
    pos.y = screenH - marginY - (int16_t)textH - textY1;
  } else {
    //Top: top of glyph at marginY
    pos.y = marginY - textY1;  //baseline = marginY - y1
  }

  return pos;
}

//=============================================================
//POST JSON Helper Functions for /control endpoint
//=============================================================

//Parse JSON boolean value flexibly
//Accepts: true/false, 1/0, "true"/"false", "on"/"off", "yes"/"no", "toggle" or "t"
bool parseJsonBoolKey(JsonDocument &doc, const char * key, bool &outValue, bool &outFound, const bool currentValue) {
  const char * k = findKeyIgnoreCase(doc, key);
  if (!k) return true;  //"not present" is not an error
  
  //Native JSON bool
  if (doc[k].is<bool>()) {
    outValue = doc[k].as<bool>();
    outFound = true;
    return true;
  }
  
  //JSON number 0/1
  if (doc[k].is<int>() || doc[k].is<long>() || doc[k].is<float>() || doc[k].is<double>()) {
    double n = doc[k].as<double>();
    if (n == 0.0) { outValue = false; outFound = true; return true; }
    if (n == 1.0) { outValue = true;  outFound = true; return true; }
  }
  
  //JSON string
  if (doc[k].is<const char*>()) {
    String s = String(doc[k].as<const char*>());
    s.trim();
    s.toLowerCase();
    
    //Toggle support
    if (s == "toggle" || s == "flip" || s == "invert" || s == "t") {
      outValue = !currentValue;
      outFound = true;
      return true;
    }
    
    //Standard boolean strings
    if (s == "true" || s == "on" || s == "yes" || s == "1") {
      outValue = true;
      outFound = true;
      return true;
    }
    if (s == "false" || s == "off" || s == "no" || s == "0") {
      outValue = false;
      outFound = true;
      return true;
    }
  }
  
  //Invalid value
  DEBUG_PRINTLN(String("Invalid ") + key + " value (use true/false, 1/0, on/off, yes/no, or toggle)");
  return false;
}

//Send a simple JSON message response
void sendJsonMessage(int code, const String& message) {
  JsonDocument doc;
  doc["message"] = message;
  String output;
  serializeJson(doc, output);
  server.send(code, "application/json", output);
}

//=============================================================
//Calendar Date Math (pure utilities, no sketch globals)
//=============================================================

int getDaysInMonth(int month, int year) {
  //Month is 0-11
  if (month == 1) {  //February
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) return 29;
    return 28;
  }
  if (month == 3 || month == 5 || month == 8 || month == 10) return 30;
  return 31;
}

int getFirstDayOfMonth(int month, int year) {
  //Zeller's congruence; returns 0=Sunday .. 6=Saturday
  int m = month + 1;  //convert 0-11 to 1-12
  int y = year;
  if (m < 3) { m += 12; y -= 1; }
  int k = y % 100;
  int j = y / 100;
  int h = (1 + (13 * (m + 1)) / 5 + k + k/4 + j/4 - 2*j) % 7;
  return (h + 6) % 7;  //convert to 0=Sunday
}

String getMonthName(int month) {
  const char* months[] = {
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
  };
  if (month >= 0 && month < 12) return String(months[month]);
  return "Unknown";
}

//RF Signal Quality Helper
//=============================================================
const char* snrLabel(int snr) {
  if (snr >= 40) return "Excellent";
  if (snr >= 25) return "Good";
  if (snr >= 15) return "Fair";
  return "Poor";
}

//=============================================================
// buildTimestamp()
//  Parses the compiler-supplied date and time strings — passed in
//  from setup() via __DATE__ and __TIME__ so they are evaluated in
//  the always-recompiled .ino translation unit, not here.
//
//  Background: __DATE__/__TIME__ expand to the compile time of the
//  translation unit they appear in.  .cpp files are cached by the
//  Arduino IDE and only recompiled when the source changes, so if
//  these macros lived here they would freeze at the last time this
//  file was edited — not the current build time.  Passing them as
//  parameters from setup() (in the .ino TU, always rebuilt) ensures
//  Timestamp[] always reflects the true firmware build date.
//
//  date  — __DATE__ string: "Mmm DD YYYY"
//  time  — __TIME__ string: "HH:MM:SS"
//  Result stored in global Timestamp[] as "YYYY-MM-DD_HH:MM".
//=============================================================
extern char Timestamp[20];  //Declared in main .ino

void buildTimestamp(const char* date, const char* time) {
  const char* d = date;
  const char* t = time;
  const char* months = "JanFebMarAprMayJunJulAugSepOctNovDec";
  char mon3[4] = {d[0], d[1], d[2], '\0'};
  int mon = 1;
  for (int i = 0; i < 12; i++) {
    if (strncmp(mon3, months + i * 3, 3) == 0) { mon = i + 1; break; }
  }
  int day  = (d[4] == ' ') ? (d[5] - '0') : ((d[4] - '0') * 10 + (d[5] - '0'));
  int year = (d[7]-'0')*1000 + (d[8]-'0')*100 + (d[9]-'0')*10 + (d[10]-'0');
  snprintf(Timestamp, sizeof(Timestamp), "%04d-%02d-%02d_%c%c:%c%c",
           year, mon, day, t[0], t[1], t[3], t[4]);
}
