//=============================================================
// MQTTClient.ino  —  MQTT subscription client for CYD devices
//
// Subscribes to retained topics published by the Elecrow
// MQTT broker:
//
//   multidisplay/weather          — current conditions + daily forecast
//   multidisplay/pressure         — latest local air-pressure reading
//   multidisplay/pressure/history/0 … /3
//                                 — 24-hour pressure history (4 chunks,
//                                   up to 25 readings each)
//   multidisplay/time             — UTC epoch + POSIX TZ string
//
// NOTE: MQTT_MAX_PACKET_SIZE is defined in User_Setup.h (must be
// set there, before the Arduino IDE can hoist the PubSubClient
// #include ahead of any tab-level #defines).
//=============================================================

#include <PubSubClient.h>

//-------------------------------------------------------------
// Externs — globals owned by ESP32_MultiDisplay_Plus.ino
//-------------------------------------------------------------
extern float localWindDeg;
extern float localTemp;
extern float localHumidity;

//-------------------------------------------------------------
// History-chunk topic prefix & count (must match broker)
//-------------------------------------------------------------
#define MQTT_TOPIC_PRESSURE_HISTORY_PFX  "multidisplay/pressure/history/"
#define MQTT_PRESSURE_HISTORY_CHUNKS      4

//-------------------------------------------------------------
// Module state
//-------------------------------------------------------------
static WiFiClient   _mqttWiFiClient;
static PubSubClient _mqttClient(_mqttWiFiClient);
static ulong        _lastReconnectAttempt = 0;
static bool         _everConnected        = false;
static bool         _enabled              = false;

// Track which history chunks have been received so we only
// import each retained snapshot once per connection.
static bool _historyChunkReceived[MQTT_PRESSURE_HISTORY_CHUNKS] = {};

// Set true when all 4 chunks have been ingested but the weather
// screen was not active at that moment — cleared once the redraw fires.
static bool _historyRedrawPending = false;

//-------------------------------------------------------------
// mqttIngestHistoryChunk()
//
// Parses one history chunk payload and feeds all valid readings
// into pressureBufInsertRaw(), preserving original timestamps.
// Broker history is authoritative — no timestamp dedup is applied;
// the circular buffer naturally evicts the oldest entries on overflow.
//-------------------------------------------------------------
static void mqttIngestHistoryChunk(const String& payloadStr) {
  JsonDocument doc;
  if (deserializeJson(doc, payloadStr)) {
    DEBUG_PRINTLN("MQTT client: history chunk JSON parse error");
    return;
  }

  int total = doc["total"] | 0;
  if (total == 0) return;   // empty marker from broker

  JsonArray readings = doc["readings"];
  if (readings.isNull()) return;

  int imported = 0;
  for (JsonObject obj : readings) {
    uint32_t ts  = (uint32_t)(long)obj["ts"];
    float    hpa = obj["h"] | 0.0f;
    float    w   = obj["w"] | (float)NAN;
    float    t   = obj["t"] | (float)NAN;
    float    u   = obj["u"] | (float)NAN;

    if (hpa < 800.0f || hpa > 1200.0f) continue;  // sanity check
    // No timestamp dedup — broker history is authoritative.
    // The circular buffer naturally evicts the oldest entries on overflow.
    pressureBufInsertRaw(ts, hpa, w, t, u);
    imported++;
  }

  if (imported > 0) {
    DEBUG_PRINTF("MQTT: history chunk imported %d readings\n", imported);
    // Note: savePressureBuffer() requires LittleFS to be mounted.
    // It is called once after all chunks are ingested (see mqttCallback).
  }
}

// Returns true once all history chunk topics have been ingested this session.
bool mqttHistoryComplete() {
  for (int i = 0; i < MQTT_PRESSURE_HISTORY_CHUNKS; i++)
    if (!_historyChunkReceived[i]) return false;
  return true;
}

//-------------------------------------------------------------
// mqttCheckHistoryRedraw()
//
// Called from loop() — fires the deferred weather-screen redraw
// once the weather screen becomes active after a late history ingest.
// Safe to call every loop iteration; clears the flag on first fire.
//-------------------------------------------------------------
void mqttCheckHistoryRedraw() {
  if (!_historyRedrawPending) return;
  if (currentScreen != SCREEN_WEATHER) return;
  _historyRedrawPending = false;
  DEBUG_PRINTLN("MQTT: deferred history redraw — refreshing weather screen");
  displayWeather();
}

//-------------------------------------------------------------
// mqttCallback()
// Handles incoming retained topic payloads from the broker.
//-------------------------------------------------------------
static void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String topicStr(topic);

  String payloadStr;
  payloadStr.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++)
    payloadStr += (char)payload[i];

  //── Weather ────────────────────────────────────────────────────────────────
  if (topicStr == MQTT_TOPIC_WEATHER) {

    JsonDocument doc;
    if (deserializeJson(doc, payloadStr)) {
      DEBUG_PRINTF("MQTT client: JSON parse error on topic %s\n", topic);
      return;
    }

    // Reject if temperature unit mismatches — values would display with wrong label
    bool brokerCelsius = doc["celsius"] | tempCelsius;
    if (brokerCelsius != tempCelsius) {
      DEBUG_PRINTLN("MQTT client: weather unit mismatch — deferring to HTTP fetch");
      return;
    }

    weatherTemp           = doc["temp"]        | weatherTemp;
    weatherApparentTemp   = doc["apparent"]    | weatherApparentTemp;
    weatherHumidity       = doc["humidity"]    | weatherHumidity;
    weatherPressure       = doc["pressure"]    | weatherPressure;
    weatherIsDay          = (bool)(doc["is_day"] | (int)weatherIsDay);
    weatherCode           = doc["code"]        | weatherCode;
    dailyTempMax          = doc["hi"]          | dailyTempMax;
    dailyApparentTempMax  = doc["ahi"]         | dailyApparentTempMax;
    dailyTempMin          = doc["lo"]          | dailyTempMin;
    dailyApparentTempMin  = doc["alo"]         | dailyApparentTempMin;
    dailyPrecipitationSum = doc["precip"]      | dailyPrecipitationSum;
    dailyPrecipProbMax    = doc["precip_prob"] | dailyPrecipProbMax;
    weatherDescription    = getWeatherDescription(weatherCode);

    struct tm timeinfo;
    if (getLocalTime(&timeinfo)) {
      char buf[32];
      strftime(buf, sizeof(buf), DEFAULT_CLOCK_TIME_FORMAT, &timeinfo);
      weatherLastUpdate = String(buf);
    }

    lastWeatherFetch = millis();   // resets HTTP fallback timer

    DEBUG_PRINTF("MQTT: weather rx — %.1f%s, code %d\n",
                 weatherTemp, tempCelsius ? "°C" : "°F", weatherCode);

    if (currentScreen == SCREEN_WEATHER) displayWeather();
  }

  //── Pressure (single latest reading) ───────────────────────────────────────
  else if (topicStr == MQTT_TOPIC_PRESSURE) {

    JsonDocument doc;
    if (deserializeJson(doc, payloadStr)) {
      DEBUG_PRINTF("MQTT client: JSON parse error on topic %s\n", topic);
      return;
    }

    float hpa     = doc["hpa"]     | 0.0f;
    float windDeg = doc["wind"]    | (float)NAN;
    float temp    = doc["temp"]    | (float)NAN;
    float humid   = doc["humidity"]| (float)NAN;

    if (hpa >= 800.0f && hpa <= 1200.0f) {
      localPressureHpa          = hpa;
      localPressureValid        = true;
      lastLocalPressureReceived = millis();
      lastLocalPressureFetch    = millis();   // resets HTTP backup timer

      localWindDeg  = isnan(windDeg) ? localWindDeg : windDeg;
      localTemp     = isnan(temp)    ? localTemp    : temp;
      localHumidity = isnan(humid)   ? localHumidity: humid;

      // Feed pressure history buffer with the current live reading
      addPressureReading(hpa, localWindDeg, localTemp, localHumidity);

      DEBUG_PRINTF("MQTT: pressure rx — %.1f hPa  wind=%.0f°  temp=%.1f  hum=%.0f%%\n",
                   hpa, localWindDeg, localTemp, localHumidity);

      if (currentScreen == SCREEN_WEATHER &&
          (!apAlternate || apAlternateShowLocal))
        displayWeather();
    } else {
      DEBUG_PRINTF("MQTT: pressure %.1f out of range — ignored\n", hpa);
    }
  }

  //── Pressure history chunk ─────────────────────────────────────────────────
  else if (topicStr.startsWith(MQTT_TOPIC_PRESSURE_HISTORY_PFX)) {
    // Extract chunk index from topic suffix
    String suffix  = topicStr.substring(strlen(MQTT_TOPIC_PRESSURE_HISTORY_PFX));
    int    chunkIdx = suffix.toInt();

    if (chunkIdx < 0 || chunkIdx >= MQTT_PRESSURE_HISTORY_CHUNKS) {
      DEBUG_PRINTF("MQTT: unexpected history chunk index %d — ignored\n", chunkIdx);
      return;
    }
    if (_historyChunkReceived[chunkIdx]) return;  // already ingested this session

    DEBUG_PRINTF("MQTT: pressure history chunk %d rx (%u bytes)\n", chunkIdx, length);
    mqttIngestHistoryChunk(payloadStr);
    _historyChunkReceived[chunkIdx] = true;

    // Check if all chunks have now arrived
    bool allDone = true;
    for (int i = 0; i < MQTT_PRESSURE_HISTORY_CHUNKS; i++)
      if (!_historyChunkReceived[i]) { allDone = false; break; }

    if (allDone) {
      DEBUG_PRINTF("MQTT: all history chunks received — buffer has %d readings\n",
                   pressureBufSize());
      // Sort the buffer by timestamp so pressureChangeOverWindow() gets a
      // correctly ordered sequence regardless of chunk arrival order.
      pressureBufSortByTimestamp();
      savePressureBuffer();   // persist the complete imported history
      if (currentScreen == SCREEN_WEATHER) {
        displayWeather();     // on screen now — redraw immediately
      } else {
        _historyRedrawPending = true;   // deferred — redraw when screen next shown
        DEBUG_PRINTLN("MQTT: history complete (screen not active — redraw deferred)");
      }
    }
  }

  //── Time ───────────────────────────────────────────────────────────────────
  else if (topicStr == MQTT_TOPIC_TIME) {

    JsonDocument doc;
    if (deserializeJson(doc, payloadStr)) {
      DEBUG_PRINTF("MQTT client: JSON parse error on topic %s\n", topic);
      return;
    }

    long epoch = doc["epoch"] | 0L;
    const char* tz = doc["tz"] | (const char*)nullptr;

    if (epoch > 1000000L) {
      time_t currentEpoch = time(nullptr);
      long   drift        = labs((long)(epoch - currentEpoch));
      if (currentEpoch < 1000000L || drift > 60) {
        struct timeval tv = { (time_t)epoch, 0 };
        settimeofday(&tv, nullptr);
        DEBUG_PRINTF("MQTT: time set from broker (drift was %ld s)\n", drift);
      }
    }

    if (tz && tz[0] != '\0') {
      weatherTzString = String(tz);
      setenv("TZ", tz, 1);
      tzset();
    }
  }
}

//-------------------------------------------------------------
// Internal: connect to broker and subscribe to all topics
//-------------------------------------------------------------
static bool mqttClientConnect() {
  String clientId = "CYD-" + deviceID;
  if (_mqttClient.connect(clientId.c_str())) {
    _mqttClient.subscribe(MQTT_TOPIC_WEATHER);
    _mqttClient.subscribe(MQTT_TOPIC_PRESSURE);
    _mqttClient.subscribe(MQTT_TOPIC_TIME);

    // Subscribe to all history chunk topics
    for (int i = 0; i < MQTT_PRESSURE_HISTORY_CHUNKS; i++) {
      char htopic[48];
      snprintf(htopic, sizeof(htopic), "%s%d",
               MQTT_TOPIC_PRESSURE_HISTORY_PFX, i);
      _mqttClient.subscribe(htopic);
    }

    // Reset flags so retained payloads are re-ingested on reconnect
    memset(_historyChunkReceived, 0, sizeof(_historyChunkReceived));
    _historyRedrawPending = false;

    _everConnected = true;
    DEBUG_PRINTF("MQTT client: connected to %s — subscribed (incl. history)\n",
                 MQTT_BROKER_IP);
    return true;
  }
  DEBUG_PRINTF("MQTT client: connect failed (state %d) — retry in 30 s\n",
               _mqttClient.state());
  return false;
}

//=============================================================
// Public API  —  called from ESP32_MultiDisplay_Plus.ino
//=============================================================

void mqttClientSetup() {
  if (strlen(MQTT_BROKER_IP) == 0) {
    DEBUG_PRINTLN("MQTT client: MQTT_BROKER_IP not set — disabled");
    return;
  }
  _enabled = true;
  _mqttClient.setServer(MQTT_BROKER_IP, MQTT_BROKER_PORT);
  _mqttClient.setCallback(mqttCallback);
  _mqttClient.setBufferSize(MQTT_MAX_PACKET_SIZE);
  DEBUG_PRINTF("MQTT client: connecting to broker at %s:%d\n",
               MQTT_BROKER_IP, MQTT_BROKER_PORT);
  mqttClientConnect();
}

void mqttClientLoop() {
  if (!_enabled) return;
  if (_mqttClient.connected()) {
    _mqttClient.loop();
  } else {
    ulong now = millis();
    if (now - _lastReconnectAttempt >= MQTT_RECONNECT_INTERVAL_MS) {
      _lastReconnectAttempt = now;
      mqttClientConnect();
    }
  }
}

bool mqttClientIsConnected()  { return _mqttClient.connected(); }
bool mqttClientEverConnected(){ return _everConnected; }
