//=============================================================
// Network.ino — WiFi connection and health watchdog
//
//  connectWiFi()      — initial join at startup; reboots on failure.
//
//  checkWiFiHealth()  — periodic watchdog; call from loop().
//                       Two-stage response to degraded signal:
//
//    Stage 1 — Soft reconnect
//      Triggered when:
//        a) WiFi.status() != WL_CONNECTED  (always, immediately), OR
//        b) SNR has been below WIFI_SNR_RECONNECT_THRESHOLD for
//           WIFI_SNR_FAIL_COUNT consecutive 2-minute checks
//           (~6 min of sustained poor signal by default).
//      Action: WiFi.disconnect() + WiFi.begin() + wait up to
//              WIFI_RECONNECT_TIMEOUT_MS.
//      Note:   blocks loop() briefly (0–20 s max).  The display holds
//              its last frame; touch is unresponsive during this window.
//
//    Stage 2 — Hard reboot
//      Triggered when the soft reconnect itself fails to restore
//      WL_CONNECTED, OR when WIFI_MAX_RECONNECTS soft-reconnect
//      attempts have occurred this session.
//
//  rom_check_noise_floor() note:
//    This ESP32-S3 ROM function returns noise floor in 1/4-dBm units
//    but its sign bit is unreliable — it can return +88 when the true
//    value is -88 dBm.  The fix used throughout this sketch (HTML.cpp,
//    WeatherCalendar.ino) is:  if (nf > 0) nf = -nf;
//    Applied here in both checkWiFiHealth() and wifiSoftReconnect().
//
//  All tuning constants live in User_Setup.h.
//=============================================================

//=============================================================
// Session-scoped watchdog state  (static = persists across calls)
//=============================================================
static ulong _wifiLastHealthCheck = 0;   //millis() of last check
static int   _wifiSnrFailCount    = 0;   //consecutive below-threshold readings
static int   _wifiReconnectCount  = 0;   //total soft-reconnect attempts this session

//=============================================================
// wifiSoftReconnect()  —  internal helper
//  Disconnects cleanly, then rejoins using the credentials from
//  secrets.h.  Returns true if WL_CONNECTED within timeout.
//  Blocks the caller for up to WIFI_RECONNECT_TIMEOUT_MS.
//=============================================================
static bool wifiSoftReconnect() {
  DEBUG_PRINTLN("WiFi watchdog: starting soft reconnect...");

  WiFi.disconnect(false);   //false = do not erase stored credentials in stack
  delay(500);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - start < WIFI_RECONNECT_TIMEOUT_MS) {
    delay(500);
    DEBUG_PRINT(".");
  }
  DEBUG_PRINTLN();

  if (WiFi.status() == WL_CONNECTED) {
    int rssi  = WiFi.RSSI();
    int nf    = rom_check_noise_floor() / 4;
    if (nf > 0) nf = -nf;   //ROM sign-bit fix: noise floor is always ≤ 0 dBm
    int snr   = rssi - nf;
    DEBUG_PRINTF("WiFi watchdog: reconnected — RSSI=%d dBm, SNR=%d dB (%s)\n",
                 rssi, snr, snrLabel(snr));
    return true;
  }

  DEBUG_PRINTLN("WiFi watchdog: soft reconnect timed out");
  return false;
}

//=============================================================
// checkWiFiHealth()  —  call from loop()
//  Rate-limited to once per WIFI_HEALTH_CHECK_INTERVAL.
//=============================================================
void checkWiFiHealth() {
  if (millis() - _wifiLastHealthCheck < WIFI_HEALTH_CHECK_INTERVAL) return;
  _wifiLastHealthCheck = millis();

  // ── Disconnected: act immediately ─────────────────────────────────
  if (WiFi.status() != WL_CONNECTED) {
    DEBUG_PRINTLN("WiFi watchdog: not connected — attempting soft reconnect");
    _wifiReconnectCount++;
    DEBUG_PRINTF("WiFi watchdog: reconnect attempt %d of %d\n",
                 _wifiReconnectCount, WIFI_MAX_RECONNECTS);

    if (_wifiReconnectCount > WIFI_MAX_RECONNECTS || !wifiSoftReconnect()) {
      DEBUG_PRINTLN("WiFi watchdog: *** rebooting (limit reached or reconnect failed) ***");
      delay(500);
      ESP.restart();
    }
    _wifiSnrFailCount = 0;
    return;
  }

  // ── Connected: measure SNR ─────────────────────────────────────────
  int rssi = WiFi.RSSI();
  int nf   = rom_check_noise_floor() / 4;
  if (nf > 0) nf = -nf;   //ROM sign-bit fix: noise floor is always ≤ 0 dBm
  int snr  = rssi - nf;

  DEBUG_PRINTF("WiFi watchdog: RSSI=%d dBm, NF=%d dBm, SNR=%d dB (%s)\n",
               rssi, nf, snr, snrLabel(snr));

  if (snr < WIFI_SNR_RECONNECT_THRESHOLD) {
    _wifiSnrFailCount++;
    DEBUG_PRINTF("WiFi watchdog: below threshold (%d dB < %d dB), count %d/%d\n",
                 snr, WIFI_SNR_RECONNECT_THRESHOLD,
                 _wifiSnrFailCount, WIFI_SNR_FAIL_COUNT);

    if (_wifiSnrFailCount >= WIFI_SNR_FAIL_COUNT) {
      _wifiSnrFailCount = 0;
      _wifiReconnectCount++;
      DEBUG_PRINTF("WiFi watchdog: sustained poor SNR — soft reconnect #%d of %d\n",
                   _wifiReconnectCount, WIFI_MAX_RECONNECTS);

      if (_wifiReconnectCount > WIFI_MAX_RECONNECTS || !wifiSoftReconnect()) {
        DEBUG_PRINTLN("WiFi watchdog: *** rebooting (limit reached or reconnect failed) ***");
        delay(500);
        ESP.restart();
      }
    }
  } else {
    // SNR is acceptable — reset per-episode fail counter only.
    // _wifiReconnectCount is a session guard and is intentionally not reset here.
    if (_wifiSnrFailCount > 0) {
      DEBUG_PRINTF("WiFi watchdog: SNR recovered to %d dB — resetting fail counter\n", snr);
      _wifiSnrFailCount = 0;
    }
  }
}

//=============================================================
// connectWiFi()  —  called once from setup()
//=============================================================
void connectWiFi() {
  DEBUG_PRINTF("\nConnecting to %s WiFi...\n", WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  const uint32_t WIFI_TIMEOUT_MS = 30UL * 1000UL;
  uint32_t start = millis();

  while (WiFi.status() != WL_CONNECTED && (millis() - start) < WIFI_TIMEOUT_MS) {
    delay(500);
    DEBUG_PRINT(".");
  }

  if (WiFi.status() != WL_CONNECTED) {
    DEBUG_PRINTLN("\n⚠ WiFi connection failed! Rebooting...");
    delay(1000);
    ESP.restart();
  }

  DEBUG_PRINTLN("\n✓ Successfully connected to WiFi");
  DEBUG_PRINTF("  IP address : %s\n", WiFi.localIP().toString().c_str());
  DEBUG_PRINTF("  Signal     : %d dBm\n", WiFi.RSSI());
}
