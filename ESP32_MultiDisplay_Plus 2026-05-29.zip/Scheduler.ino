//=============================================================
// Scheduler.ino  —  scheduled actions, message profiles,
//                    and scheduler web endpoint
//=============================================================

void checkScheduledActions() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return;  //Can't get time
  }

  int currentMinute = timeinfo.tm_hour * 60 + timeinfo.tm_min;

  //Only check once per minute
  if (currentMinute == lastCheckedMinute) {
    return;
  }
  lastCheckedMinute = currentMinute;

  //Check each schedule
  for (int i = 0; i < MAX_SCHEDULES; i++) {
    if (!schedules[i].enabled) continue;

    int targetHour = 0;
    int targetMinute = 0;

    //Calculate target time based on mode
    if (schedules[i].mode == "absolute" || schedules[i].mode == "") {
      //Direct time
      targetHour   = schedules[i].hour;
      targetMinute = schedules[i].minute;
    } else if (schedules[i].mode == "relative") {
      //Relative to sunrise/sunset
      if (!sunTimesValid) {
        DEBUG_PRINTF("Warning: Sun times not available for schedule %d\n", i);
        continue;
      }

      int baseMinutes = 0;
      if (schedules[i].reference == "sunrise") {
        baseMinutes = sunriseHour * 60 + sunriseMinute;
      } else if (schedules[i].reference == "sunset") {
        baseMinutes = sunsetHour * 60 + sunsetMinute;
      } else {
        continue;
      }

      //Add offset
      int totalMinutes = baseMinutes + schedules[i].offset;

      //Handle wraparound
      if (totalMinutes < 0) totalMinutes += 1440;
      if (totalMinutes >= 1440) totalMinutes -= 1440;

      targetHour   = totalMinutes / 60;
      targetMinute = totalMinutes % 60;
    }

    //Check if this is the scheduled time
    if (timeinfo.tm_hour == targetHour && timeinfo.tm_min == targetMinute && !schedules[i].triggered) {

      DEBUG_PRINTF("Executing schedule %d: %s at %02d:%02d\n",
                    i, schedules[i].action.c_str(), targetHour, targetMinute);

      //Execute the action
      if (schedules[i].action == "brightness") {
        scheduledBrightness     = schedules[i].brightness;
        setBrightness(scheduledBrightness);
        actualCurrentBrightness = scheduledBrightness;
        //If night mode is off, let the schedule own the clock brightness too;
        //if night mode is on, leave screenBrightness alone so night mode stays in charge.
        if (!nightModeActive) {
          screenBrightness = scheduledBrightness;
        }
        DEBUG_PRINTF("✓ Set brightness to %d (screen %s)\n",
                     scheduledBrightness,
                     nightModeActive ? "exempt (night mode active)" : "updated");
      } else if (schedules[i].action == "clock") {
        changeScreen(SCREEN_CLOCK);
        DEBUG_PRINTLN("✓ Showing clock");
      } else if (schedules[i].action == "weather") {
        changeScreen(SCREEN_WEATHER);
        DEBUG_PRINTLN("✓ Showing weather");
      } else if (schedules[i].action == "calendar") {
        changeScreen(SCREEN_CALENDAR);
        DEBUG_PRINTLN("✓ Showing calendar");
      } else if (schedules[i].action == "message") {
        if (schedules[i].message.length() > 0) {
          DEBUG_PRINTLN("✓ Displaying scheduled message: " + schedules[i].message);

          //Use the full message display system with defaults
          //Set expiration to 0 so message persists until manually dismissed
          messageActive           = true;
          messageDisplayStartTime = millis();
          messagePriority         = "normal";
          messageExpirationTime   = 0;  //No expiration - persist until dismissed

          //Start with defaults; apply msgProfile if set
          uint16_t bg  = DEFAULT_BG_COLOR;
          uint16_t fg  = DEFAULT_TEXT_COLOR;
          int      fn  = DEFAULT_FONT;
          int      rot = currentRotation;
          String   ha  = "center";
          String   va  = "middle";
          bool     wr  = true;
          String   sd  = "none";
          uint8_t  ss  = DEFAULT_SCROLL_SPEED;
          uint8_t  br  = currentBrightness;
          bool     fl  = false;
          ulong    fi  = DEFAULT_FLASH_INTERVAL;
          bool     pu  = false;
          ulong    pd  = DEFAULT_PULSE_DURATION;

          if (schedules[i].msgProfileIdx >= 0 &&
              schedules[i].msgProfileIdx < MAX_MSG_PROFILES &&
              msgProfiles[schedules[i].msgProfileIdx].saved) {
            applyMsgProfile(schedules[i].msgProfileIdx, bg, fg, fn, rot, ha, va, wr, sd, ss, br, fl, fi, pu, pd,
                            messagePriority, messageExpirationTime);
            DEBUG_PRINTF("  Applied msgProfile %d for scheduled message\n", schedules[i].msgProfileIdx);
          }

          displayMessage(schedules[i].message, bg, fg, fn, rot, ha, va, wr, sd, ss, br, fl, fi, pu, pd);
        }
      } else if (schedules[i].action == "reboot") {
        DEBUG_PRINTLN("✓ Scheduled reboot triggered – restarting...");
        schedules[i].triggered = true;
        saveSchedules();
        delay(200);
        ESP.restart();
      }

      schedules[i].triggered = true;
    }
  }

  //Reset all triggers at midnight
  if (timeinfo.tm_hour == 0 && timeinfo.tm_min == 0) {
    for (int i = 0; i < MAX_SCHEDULES; i++) {
      schedules[i].triggered = false;
    }
    DEBUG_PRINTLN("Reset all schedule triggers for new day");
  }
}

void applyMsgProfile(int idx, uint16_t &bgColor, uint16_t &textColor, int &font, int &rotation,
                     String &hAlign, String &vAlign, bool &wrap, String &scrollDir,
                     uint8_t &scrollSpeed, uint8_t &brightness, bool &flash,
                     ulong &flashInterval, bool &pulse, ulong &pulseDuration,
                     String &priority, int &expirationTime) {
  if (idx < 0 || idx >= MAX_MSG_PROFILES || !msgProfiles[idx].saved) return;
  bgColor        = msgProfiles[idx].bgColor;
  textColor      = msgProfiles[idx].textColor;
  font           = msgProfiles[idx].font;
  rotation       = msgProfiles[idx].rotation;
  hAlign         = msgProfiles[idx].hAlign;
  vAlign         = msgProfiles[idx].vAlign;
  wrap           = msgProfiles[idx].wrap;
  scrollDir      = msgProfiles[idx].scrollDir;
  scrollSpeed    = msgProfiles[idx].scrollSpeed;
  brightness     = msgProfiles[idx].brightness;
  flash          = msgProfiles[idx].flash;
  flashInterval  = msgProfiles[idx].flashInterval;
  pulse          = msgProfiles[idx].pulse;
  pulseDuration  = msgProfiles[idx].pulseDuration;
  priority       = msgProfiles[idx].priority;
  expirationTime = msgProfiles[idx].expirationTime;
}

void saveMsgProfiles() {
  preferences.begin(PREFERENCES_NAMESPACE, false);
  for (int i = 0; i < MAX_MSG_PROFILES; i++) {
    String p = "p" + String(i);
    preferences.putBool(  (p + "sv").c_str(), msgProfiles[i].saved);
    if (!msgProfiles[i].saved) continue;
    preferences.putUShort((p + "bg").c_str(), msgProfiles[i].bgColor);
    preferences.putUShort((p + "tc").c_str(), msgProfiles[i].textColor);
    preferences.putChar(  (p + "fn").c_str(), (int8_t)msgProfiles[i].font);
    preferences.putShort( (p + "rot").c_str(),(int16_t)msgProfiles[i].rotation);
    preferences.putString((p + "ha").c_str(), msgProfiles[i].hAlign);
    preferences.putString((p + "va").c_str(), msgProfiles[i].vAlign);
    preferences.putBool(  (p + "wr").c_str(), msgProfiles[i].wrap);
    preferences.putString((p + "sd").c_str(), msgProfiles[i].scrollDir);
    preferences.putUChar( (p + "ss").c_str(), msgProfiles[i].scrollSpeed);
    preferences.putUChar( (p + "br").c_str(), msgProfiles[i].brightness);
    preferences.putBool(  (p + "fl").c_str(), msgProfiles[i].flash);
    preferences.putULong( (p + "fi").c_str(), msgProfiles[i].flashInterval);
    preferences.putBool(  (p + "pu").c_str(), msgProfiles[i].pulse);
    preferences.putULong( (p + "pd").c_str(), msgProfiles[i].pulseDuration);
    preferences.putString((p + "pr").c_str(), msgProfiles[i].priority);
    preferences.putInt(   (p + "et").c_str(), msgProfiles[i].expirationTime);
  }
  preferences.end();
  DEBUG_PRINTLN("\nMessage profiles saved to NVS");
}

void loadMsgProfiles() {
  preferences.begin(PREFERENCES_NAMESPACE, true);
  DEBUG_PRINTLN("\n=== Loading Message Profiles ===");
  int savedCount = 0;
  for (int i = 0; i < MAX_MSG_PROFILES; i++) {
    String p = "p" + String(i);
    msgProfiles[i].saved = preferences.getBool((p + "sv").c_str(), false);
    if (!msgProfiles[i].saved) continue;
    savedCount++;
    msgProfiles[i].bgColor       = preferences.getUShort((p + "bg").c_str(),  DEFAULT_BG_COLOR);
    msgProfiles[i].textColor     = preferences.getUShort((p + "tc").c_str(),  DEFAULT_TEXT_COLOR);
    msgProfiles[i].font          = validateRobotoFontCode(preferences.getChar((p + "fn").c_str(), DEFAULT_FONT));
    msgProfiles[i].rotation      = preferences.getShort( (p + "rot").c_str(), DEFAULT_ROTATION);
    msgProfiles[i].hAlign        = preferences.getString((p + "ha").c_str(),  DEFAULT_H_ALIGN);
    msgProfiles[i].vAlign        = preferences.getString((p + "va").c_str(),  DEFAULT_V_ALIGN);
    msgProfiles[i].wrap          = preferences.getBool(  (p + "wr").c_str(),  DEFAULT_WRAP);
    msgProfiles[i].scrollDir     = preferences.getString((p + "sd").c_str(),  DEFAULT_SCROLL_DIRECTION);
    msgProfiles[i].scrollSpeed   = preferences.getUChar( (p + "ss").c_str(),  DEFAULT_SCROLL_SPEED);
    msgProfiles[i].brightness    = preferences.getUChar( (p + "br").c_str(),  DEFAULT_BRIGHTNESS);
    msgProfiles[i].flash         = preferences.getBool(  (p + "fl").c_str(),  DEFAULT_FLASH);
    msgProfiles[i].flashInterval = preferences.getULong( (p + "fi").c_str(),  DEFAULT_FLASH_INTERVAL);
    msgProfiles[i].pulse         = preferences.getBool(  (p + "pu").c_str(),  DEFAULT_PULSE);
    msgProfiles[i].pulseDuration = preferences.getULong( (p + "pd").c_str(),  DEFAULT_PULSE_DURATION);
    msgProfiles[i].priority      = preferences.getString((p + "pr").c_str(),  DEFAULT_PRIORITY);
    msgProfiles[i].expirationTime= preferences.getInt(   (p + "et").c_str(),  DEFAULT_EXPIRATION_TIME);
    DEBUG_PRINTF("  Profile %d: loaded\n", i);
  }
  preferences.end();
  DEBUG_PRINTF("Loaded %d message profiles\n\n", savedCount);
}

void saveSchedules() {
  preferences.begin(PREFERENCES_NAMESPACE, false);

  for (int i = 0; i < MAX_SCHEDULES; i++) {
    String prefix = "sched" + String(i) + "_";

    preferences.putBool((prefix + "en").c_str(),      schedules[i].enabled);
    preferences.putString((prefix + "mode").c_str(),  schedules[i].mode);
    preferences.putUChar((prefix + "h").c_str(),      schedules[i].hour);
    preferences.putUChar((prefix + "m").c_str(),      schedules[i].minute);
    preferences.putString((prefix + "ref").c_str(),   schedules[i].reference);
    preferences.putShort((prefix + "off").c_str(),    schedules[i].offset);
    preferences.putString((prefix + "act").c_str(),   schedules[i].action);
    preferences.putUChar((prefix + "br").c_str(),     schedules[i].brightness);
    preferences.putString((prefix + "msg").c_str(),   schedules[i].message);
    preferences.putChar((prefix + "mpi").c_str(),     schedules[i].msgProfileIdx);
  }

  preferences.end();
  DEBUG_PRINTLN("Schedules saved to NVS");
}

void loadSchedules() {
  preferences.begin(PREFERENCES_NAMESPACE, true);  //Read-only

  DEBUG_PRINTLN("\n=== Loading Schedules ===");

  int enabledCount = 0;

  for (int i = 0; i < MAX_SCHEDULES; i++) {
    String prefix = "sched" + String(i) + "_";

    schedules[i].enabled       = preferences.getBool((prefix + "en").c_str(), false);
    schedules[i].mode          = preferences.getString((prefix + "mode").c_str(), "absolute");
    schedules[i].hour          = preferences.getUChar((prefix + "h").c_str(), 0);
    schedules[i].minute        = preferences.getUChar((prefix + "m").c_str(), 0);
    schedules[i].reference     = preferences.getString((prefix + "ref").c_str(), "sunset");
    schedules[i].offset        = preferences.getShort((prefix + "off").c_str(), 0);
    schedules[i].action        = preferences.getString((prefix + "act").c_str(), "brightness");
    schedules[i].brightness    = preferences.getUChar((prefix + "br").c_str(), 128);
    schedules[i].message       = preferences.getString((prefix + "msg").c_str(), "");
    schedules[i].msgProfileIdx = preferences.getChar((prefix + "mpi").c_str(), -1);
    schedules[i].triggered     = false;

    if (schedules[i].enabled) {
      enabledCount++;
      DEBUG_PRINTF("Schedule %d: ENABLED - %s\n", i, schedules[i].action.c_str());
    }
  }

  preferences.end();
  DEBUG_PRINTF("Loaded %d enabled schedules\n", enabledCount);
}

void handleSchedulerConfig() {
  if (server.method() == HTTP_GET) {
    handleSchedulerConfigPage();
  } else if (server.method() == HTTP_POST) {

    //Check if this is JSON or form data
    String contentType = server.header("Content-Type");
    contentType.toLowerCase();

    if (contentType.indexOf("application/json") >= 0) {
      //===================================================================
      //JSON POST - For Hubitat Rule Machine and automation
      //===================================================================
      StaticJsonDocument<2048> doc;
      DeserializationError error = deserializeJson(doc, server.arg("plain"));

      if (error) {
        DEBUG_PRINTLN("JSON parse error in /schedules");
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
      }

      int updatedCount = 0;

      //Check if this is array format or single schedule
      if (doc.containsKey("schedules")) {
        //------------------------------------------------------------
        //Array of schedules format:
        //{
        //"schedules": [
        //{"index": 0, "enabled": true, ...},
        //{"index": 1, "enabled": true, ...}
        //]
        //}
        //------------------------------------------------------------
        JsonArray schedulesArray = doc["schedules"].as<JsonArray>();
        for (JsonObject sched : schedulesArray) {
          if (!sched.containsKey("index")) continue;

          int idx = sched["index"];
          if (idx < 0 || idx >= MAX_SCHEDULES) continue;

          //Update schedule fields (only if present in JSON)
          if (sched.containsKey("enabled"))    schedules[idx].enabled       = sched["enabled"];
          if (sched.containsKey("mode"))       schedules[idx].mode          = sched["mode"].as<String>();
          if (sched.containsKey("hour"))       schedules[idx].hour          = sched["hour"];
          if (sched.containsKey("minute"))     schedules[idx].minute        = sched["minute"];
          if (sched.containsKey("reference"))  schedules[idx].reference     = sched["reference"].as<String>();
          if (sched.containsKey("offset"))     schedules[idx].offset        = sched["offset"];
          if (sched.containsKey("action"))     schedules[idx].action        = sched["action"].as<String>();
          if (sched.containsKey("brightness")) schedules[idx].brightness    = sched["brightness"];
          if (sched.containsKey("message"))    schedules[idx].message       = sched["message"].as<String>();
          if (sched.containsKey("msgprofile")) schedules[idx].msgProfileIdx = (int8_t)(int)sched["msgprofile"];

          //Reset triggered flag when schedule is updated
          schedules[idx].triggered = false;
          updatedCount++;

          DEBUG_PRINTF("Updated schedule %d: %s at %02d:%02d\n",
                       idx, schedules[idx].action.c_str(), schedules[idx].hour, schedules[idx].minute);
        }

      } else if (doc.containsKey("index")) {
        //------------------------------------------------------------
        //Single schedule format:
        //{
        //"index": 0,
        //"enabled": true,
        //"mode": "absolute",
        //"hour": 7,
        //"minute": 0,
        //"action": "weather"
        //}
        //------------------------------------------------------------
        int idx = doc["index"];
        if (idx >= 0 && idx < MAX_SCHEDULES) {
          //Update schedule fields (only if present in JSON)
          if (doc.containsKey("enabled"))    schedules[idx].enabled       = doc["enabled"];
          if (doc.containsKey("mode"))       schedules[idx].mode          = doc["mode"].as<String>();
          if (doc.containsKey("hour"))       schedules[idx].hour          = doc["hour"];
          if (doc.containsKey("minute"))     schedules[idx].minute        = doc["minute"];
          if (doc.containsKey("reference"))  schedules[idx].reference     = doc["reference"].as<String>();
          if (doc.containsKey("offset"))     schedules[idx].offset        = doc["offset"];
          if (doc.containsKey("action"))     schedules[idx].action        = doc["action"].as<String>();
          if (doc.containsKey("brightness")) schedules[idx].brightness    = doc["brightness"];
          if (doc.containsKey("message"))    schedules[idx].message       = doc["message"].as<String>();
          if (doc.containsKey("msgprofile")) schedules[idx].msgProfileIdx = (int8_t)(int)doc["msgprofile"];

          //Reset triggered flag when schedule is updated
          schedules[idx].triggered = false;
          updatedCount = 1;

          DEBUG_PRINTF("Updated schedule %d: %s at %02d:%02d\n",
                       idx, schedules[idx].action.c_str(), schedules[idx].hour, schedules[idx].minute);
        }
      } else {
        server.send(400, "application/json", "{\"error\":\"Missing 'index' or 'schedules' key\"}");
        return;
      }

      //Save all schedules to flash
      saveSchedules();

      //Send JSON response
      String response = "{\"message\":\"Schedules updated\",\"count\":" + String(updatedCount) + "}";
      server.send(200, "application/json", response);
      DEBUG_PRINTF("Schedules saved: %d updated\n", updatedCount);

    } else {
      //===================================================================
      //FORM POST - For web interface (existing functionality)
      //===================================================================
      for (int i = 0; i < MAX_SCHEDULES; i++) {
        String prefix = "sched" + String(i) + "_";

        schedules[i].enabled = server.hasArg(prefix + "enabled");

        //--- mode: whitelist-checked ---
        if (server.hasArg(prefix + "mode")) {
          String m = server.arg(prefix + "mode");
          if (m == "fixed" || m == "sunrise" || m == "sunset")
            schedules[i].mode = m;
        }
        //--- hour/minute: range-clamped ---
        if (server.hasArg(prefix + "hour"))
          schedules[i].hour   = constrain(server.arg(prefix + "hour").toInt(), 0, 23);
        if (server.hasArg(prefix + "minute"))
          schedules[i].minute = constrain(server.arg(prefix + "minute").toInt(), 0, 59);
        //--- reference: whitelist-checked ---
        if (server.hasArg(prefix + "reference")) {
          String r = server.arg(prefix + "reference");
          if (r == "fixed" || r == "sunrise" || r == "sunset")
            schedules[i].reference = r;
        }
        //--- offset: any signed int (sunrise/sunset relative minutes — no practical clamp needed) ---
        if (server.hasArg(prefix + "offset"))
          schedules[i].offset = server.arg(prefix + "offset").toInt();
        //--- action: whitelist-checked ---
        if (server.hasArg(prefix + "action")) {
          String a = server.arg(prefix + "action");
          if (a == "brightness" || a == "clock" || a == "weather" ||
              a == "calendar"   || a == "message" || a == "reboot")
            schedules[i].action = a;
        }
        //--- brightness: clamped to valid backlight range 0-255 ---
        if (server.hasArg(prefix + "brightness"))
          schedules[i].brightness = constrain(server.arg(prefix + "brightness").toInt(), 0, 255);
        if (server.hasArg(prefix + "message"))    schedules[i].message    = server.arg(prefix + "message");
        //msgProfileIdx: -1 means "none", 0-9 means use that profile
        if (server.hasArg(prefix + "msgprofile")) {
          schedules[i].msgProfileIdx = (int8_t)constrain(server.arg(prefix + "msgprofile").toInt(), -1, MAX_MSG_PROFILES - 1);
        } else {
          schedules[i].msgProfileIdx = -1;
        }

        //Reset triggered flag
        schedules[i].triggered = false;
      }

      saveSchedules();

      //Redirect back to config page
      server.sendHeader("Location", "/schedules");
      server.send(303);
      DEBUG_PRINTLN("Schedules saved from web form");
    }
  }
}
