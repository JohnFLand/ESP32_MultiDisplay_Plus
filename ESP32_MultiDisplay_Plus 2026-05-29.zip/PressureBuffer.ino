//=============================================================
// PressureBuffer.ino
//
// Rolling buffer of local sensor readings (pressure, wind
// direction, temperature, humidity), 3-hour and 24-hour trend
// computation, sea-level pressure correction, and a matrix-
// based weather forecast.
//
// Forecast algorithm: pressure-level × trend-rate matrix with
// humidity and wind-direction modifiers.
// Ported from WeatherPredictor Groovy app (Hubitat).
//
// Timestamps are UTC epoch seconds (from time()), NOT millis().
// This means the buffer survives reboots: it is saved to
// LittleFS on every new reading and restored at boot.
//
// struct PressureReading and struct LocalForecast are defined
// in User_Setup.h so Arduino's auto-prototype generator sees
// them before it emits forward declarations for these functions.
//=============================================================

#include <LittleFS.h>

// ── Circular buffer state ─────────────────────────────────────────────────
static PressureReading pressureBuf[PRESSURE_BUF_SIZE];
static int  pressureBufHead  = 0;
static int  pressureBufCount = 0;

// Oldest valid slot index
static int pressureBufOldestIdx() {
    return (pressureBufCount < PRESSURE_BUF_SIZE) ? 0 : pressureBufHead;
}

// ── LittleFS persistence ──────────────────────────────────────────────────
// File layout: 4-byte magic | 4-byte head | 4-byte count | raw array

static const uint32_t PBF_MAGIC = 0x50424632UL;  // "PBF2"

void savePressureBuffer() {
    File f = LittleFS.open(PRESSURE_BUF_FILE, "w");
    if (!f) {
        DEBUG_PRINTLN("PressureBuf: save failed (LittleFS open error)");
        return;
    }
    f.write((const uint8_t*)&PBF_MAGIC,          sizeof(PBF_MAGIC));
    f.write((const uint8_t*)&pressureBufHead,     sizeof(pressureBufHead));
    f.write((const uint8_t*)&pressureBufCount,    sizeof(pressureBufCount));
    f.write((const uint8_t*)pressureBuf,          sizeof(pressureBuf));
    f.close();
    DEBUG_PRINTF("PressureBuf: saved %d readings\n", pressureBufCount);
}

void loadPressureBuffer() {
    DEBUG_PRINTLN("");
    if (!LittleFS.exists(PRESSURE_BUF_FILE)) {
        DEBUG_PRINTLN("PressureBuf: no saved file — starting fresh");
        return;
    }
    File f = LittleFS.open(PRESSURE_BUF_FILE, "r");
    if (!f) {
        DEBUG_PRINTLN("PressureBuf: load failed (open error)");
        return;
    }

    uint32_t magic = 0;
    f.read((uint8_t*)&magic, sizeof(magic));
    if (magic != PBF_MAGIC) {
        DEBUG_PRINTLN("PressureBuf: stale/incompatible file — discarding");
        f.close();
        LittleFS.remove(PRESSURE_BUF_FILE);
        return;
    }

    int savedHead = 0, savedCount = 0;
    f.read((uint8_t*)&savedHead,  sizeof(savedHead));
    f.read((uint8_t*)&savedCount, sizeof(savedCount));

    // Read the full array into a static temporary to avoid a 1.9 KB stack frame
    static PressureReading loadBuf[PRESSURE_BUF_SIZE];
    f.read((uint8_t*)loadBuf, sizeof(loadBuf));
    f.close();

    // Validate against current time — drop readings older than 25 hours
    // or with future timestamps (clock drift / wrong RTC)
    time_t now = time(nullptr);
    if (now < 1000000L) {
        DEBUG_PRINTLN("PressureBuf: no valid time at load — discarding stored buffer");
        return;
    }

    const uint32_t maxAgeS = 25UL * 3600UL;
    int oldestIdx = (savedCount < PRESSURE_BUF_SIZE) ? 0 : savedHead;

    // Rebuild the live buffer linearly, keeping only valid entries.
    // This normalises the circular layout and discards expired readings.
    pressureBufHead  = 0;
    pressureBufCount = 0;
    int dropped = 0;

    for (int i = 0; i < savedCount; i++) {
        PressureReading& r = loadBuf[(oldestIdx + i) % PRESSURE_BUF_SIZE];
        if (r.ts > (uint32_t)(now + 120))       { dropped++; continue; } // future (+2 min tolerance)
        if ((uint32_t)now - r.ts > maxAgeS)     { dropped++; continue; } // too old
        pressureBuf[pressureBufHead] = r;
        pressureBufHead = (pressureBufHead + 1) % PRESSURE_BUF_SIZE;
        if (pressureBufCount < PRESSURE_BUF_SIZE) pressureBufCount++;
    }

    DEBUG_PRINTF("PressureBuf: restored %d readings (%d expired/invalid dropped)\n",
                 pressureBufCount, dropped);
}

// ── Public buffer API ─────────────────────────────────────────────────────

// Append a new reading. Skips silently if NTP not yet synced.
// windDeg, temp, humidity may be NAN if unavailable.
void addPressureReading(float hpa, float windDeg, float temp, float humidity) {
    time_t now = time(nullptr);
    if (now < 1000000L) {
        DEBUG_PRINTLN("PressureBuf: skipped (NTP not synced yet)");
        return;
    }
    pressureBuf[pressureBufHead] = { (uint32_t)now, hpa, windDeg, temp, humidity };
    pressureBufHead  = (pressureBufHead + 1) % PRESSURE_BUF_SIZE;
    if (pressureBufCount < PRESSURE_BUF_SIZE) pressureBufCount++;
    DEBUG_PRINTF("PressureBuf: %.1f hPa  wind=%.0f°  temp=%.1f  hum=%.0f%%  (%d readings)\n",
                 hpa, windDeg, temp, humidity, pressureBufCount);
    savePressureBuffer();
}

// ── Raw insert for history replay (explicit timestamp, no NTP guard) ──────
// Used by MQTTClient.ino when ingesting the broker's pressure history.
// Caller is responsible for timestamp validation and duplicate checking.
// Does NOT call savePressureBuffer() — caller must do so after bulk insert.
void pressureBufInsertRaw(uint32_t ts, float hpa,
                          float windDeg, float temp, float humidity) {
    pressureBuf[pressureBufHead] = { ts, hpa, windDeg, temp, humidity };
    pressureBufHead  = (pressureBufHead + 1) % PRESSURE_BUF_SIZE;
    if (pressureBufCount < PRESSURE_BUF_SIZE) pressureBufCount++;
}

// Sort the live buffer entries by ascending timestamp.
// Called after bulk history ingest (MQTT chunks) to ensure
// pressureChangeOverWindow() sees a correctly ordered sequence.
// Uses insertion sort — buffer is typically nearly-sorted already
// (chunks arrive close to timestamp order), so O(n) in practice.
void pressureBufSortByTimestamp() {
    if (pressureBufCount < 2) return;

    // Linearise the circular buffer into a flat scratch array,
    // sort it, then write it back as a linear (non-wrapped) buffer.
    // This also resets pressureBufHead to pressureBufCount % PRESSURE_BUF_SIZE.
    static PressureReading scratch[PRESSURE_BUF_SIZE];
    int oldest = pressureBufOldestIdx();
    for (int i = 0; i < pressureBufCount; i++)
        scratch[i] = pressureBuf[(oldest + i) % PRESSURE_BUF_SIZE];

    // Insertion sort by ts (ascending)
    for (int i = 1; i < pressureBufCount; i++) {
        PressureReading key = scratch[i];
        int j = i - 1;
        while (j >= 0 && scratch[j].ts > key.ts) {
            scratch[j + 1] = scratch[j];
            j--;
        }
        scratch[j + 1] = key;
    }

    // Write back as a fresh linear buffer
    for (int i = 0; i < pressureBufCount; i++)
        pressureBuf[i] = scratch[i];
    pressureBufHead = pressureBufCount % PRESSURE_BUF_SIZE;

    DEBUG_PRINTF("PressureBuf: sorted %d readings by timestamp\n", pressureBufCount);
}

// Number of valid entries
int pressureBufSize() { return pressureBufCount; }

// Read entry by age-order index (0 = oldest, count-1 = newest)
bool pressureBufEntry(int ageIdx, PressureReading& out) {
    if (ageIdx < 0 || ageIdx >= pressureBufCount) return false;
    int idx = (pressureBufOldestIdx() + ageIdx) % PRESSURE_BUF_SIZE;
    out = pressureBuf[idx];
    return true;
}

// ── Sea-level pressure correction ─────────────────────────────────────────
// Formula used by Groovy app: P_sl = P_raw × (1 + 2.26e-5 × h)^5.257
float seaLevelPressure(float rawHpa, float altMetres) {
    if (altMetres < 0.5f) return rawHpa;
    return rawHpa * powf(1.0f + 2.26e-5f * altMetres, 5.257f);
}

// ── Pressure-change helper (window in seconds) ────────────────────────────
static float pressureChangeOverWindow(uint32_t windowSec) {
    if (pressureBufCount < 2) return 0.0f;
    PressureReading newest;
    pressureBufEntry(pressureBufCount - 1, newest);

    uint32_t halfWin = windowSec / 2;
    PressureReading reference;
    pressureBufEntry(0, reference);

    for (int i = 0; i < pressureBufCount - 1; i++) {
        PressureReading r;
        pressureBufEntry(i, r);
        if (newest.ts >= r.ts && (newest.ts - r.ts) >= halfWin)
            reference = r;
        else
            break;
    }
    return newest.hpa - reference.hpa;
}

float pressureChangeHpa()   { return pressureChangeOverWindow(PRESSURE_TREND_3H_S);  }
float pressureChange24Hpa() { return pressureChangeOverWindow(PRESSURE_TREND_24H_S); }

// Buffer span in seconds
uint32_t pressureBufSpanSec() {
    if (pressureBufCount < 2) return 0;
    PressureReading oldest, newest;
    pressureBufEntry(0, oldest);
    pressureBufEntry(pressureBufCount - 1, newest);
    return newest.ts - oldest.ts;
}

// Trend code: +1 rising, -1 falling, 0 steady (3-hour window)
int pressureTrend() {
    float d = pressureChangeHpa();
    if (d >  PRESSURE_TREND_THRESHOLD) return  1;
    if (d < -PRESSURE_TREND_THRESHOLD) return -1;
    return 0;
}

// ── Compass conversion ────────────────────────────────────────────────────
static String degreesToCompass(float deg) {
    while (deg <    0) deg += 360.0f;
    while (deg >= 360) deg -= 360.0f;
    static const char* pts[] = {
        "N","NNE","NE","ENE","E","ESE","SE","SSE",
        "S","SSW","SW","WSW","W","WNW","NW","NNW"
    };
    int idx = (int)((deg + 11.25f) / 22.5f) % 16;
    return String(pts[idx]);
}

// ── Matrix forecast ───────────────────────────────────────────────────────
LocalForecast buildLocalForecast() {
    LocalForecast fc;
    fc.summary[0] = '\0';
    strncpy(fc.confidence, "Low", sizeof(fc.confidence));

    if (pressureBufCount < 2 || !localPressureValid) {
        strncpy(fc.summary, "Collecting pressure data...", sizeof(fc.summary));
        return fc;
    }

    float altM = atof(weatherAltitude.c_str());
    float slp  = seaLevelPressure(localPressureHpa, altM);

    const char* pCat;
    if      (slp > 1022) pCat = "HIGH";
    else if (slp > 1009) pCat = "NORMAL";
    else if (slp > 990)  pCat = "LOW";
    else                 pCat = "VERY_LOW";

    float c3 = pressureChangeHpa();
    const char* tCat;
    if      (c3 >  6.0f) tCat = "RAPID_RISE";
    else if (c3 >  3.0f) tCat = "FAST_RISE";
    else if (c3 >  1.0f) tCat = "SLOW_RISE";
    else if (c3 > -1.0f) tCat = "STEADY";
    else if (c3 > -3.0f) tCat = "SLOW_FALL";
    else if (c3 > -6.0f) tCat = "FAST_FALL";
    else                 tCat = "RAPID_FALL";

    PressureReading latest;
    pressureBufEntry(pressureBufCount - 1, latest);
    float hum = !isnan(latest.humidity) ? latest.humidity : (float)weatherHumidity;

    char humMod[64] = "";
    if      (hum >= 80.0f) strncpy(humMod, " High humidity supports rain.",          sizeof(humMod));
    else if (hum <= 40.0f) strncpy(humMod, " Low humidity suggests dry conditions.", sizeof(humMod));

    char windMod[64] = "";
    if (!isnan(latest.windDeg)) {
        String cp  = degreesToCompass(latest.windDeg);
        bool hasSW = (cp.indexOf("SW") >= 0);
        bool hasS  = (cp.indexOf('S')  >= 0);
        bool hasNW = (cp.indexOf("NW") >= 0);
        bool hasN  = (cp.indexOf('N')  >= 0);
        bool hasE  = (cp.indexOf('E')  >= 0);
        if      (hasSW || hasS) strncpy(windMod, " Southerly winds support incoming moisture.",       sizeof(windMod));
        else if (hasNW || hasN) strncpy(windMod, " Northerly winds suggest clearing, cooler air.",    sizeof(windMod));
        else if (hasE)          strncpy(windMod, " Easterly winds can signal an approaching system.", sizeof(windMod));
    }

    char key[32];
    snprintf(key, sizeof(key), "%s_%s", pCat, tCat);

    const char* base = nullptr;
    const char* conf = "Low";

    #define FC(k, s, c) if (strcmp(key, k) == 0) { base = s; conf = c; } else
    FC("HIGH_RAPID_RISE",     "Fair and settled. Rapid rise may be short-lived.",                         "Medium")
    FC("HIGH_FAST_RISE",      "Clearing and fair. Good conditions likely 12-24 hours.",                   "High")
    FC("HIGH_SLOW_RISE",      "Clearing and fair. Good conditions likely 12-24 hours.",                   "High")
    FC("HIGH_STEADY",         "Stable fair weather. Current conditions expected to persist.",             "High")
    FC("HIGH_SLOW_FALL",      "Fair now, but a change is coming in the next 12-24 hours.",                "Medium")
    FC("HIGH_FAST_FALL",      "Deteriorating. Clouds and rain likely within 6-12 hours.",                 "High")
    FC("HIGH_RAPID_FALL",     "Rapid deterioration. Significant weather event approaching.",              "High")
    FC("NORMAL_RAPID_RISE",   "Conditions improving quickly. Clearing expected, watch for instability.",  "Medium")
    FC("NORMAL_FAST_RISE",    "Improving. Expect clearing over the next several hours.",                  "Medium")
    FC("NORMAL_SLOW_RISE",    "Improving. Expect clearing over the next several hours.",                  "Medium")
    FC("NORMAL_STEADY",       "Settled and variable. No significant change expected soon.",               "Medium")
    FC("NORMAL_SLOW_FALL",    "Slight deterioration underway. Rain possible in 12-24 hours.",             "Medium")
    FC("NORMAL_FAST_FALL",    "Weather deteriorating. Rain or strong winds likely 6-12 hours.",           "High")
    FC("NORMAL_RAPID_FALL",   "Rapid fall — storm conditions likely within a few hours.",                 "High")
    FC("LOW_RAPID_RISE",      "Improving from disturbed conditions. Gradual clearing expected.",          "Medium")
    FC("LOW_FAST_RISE",       "Improving from disturbed conditions. Gradual clearing expected.",          "Medium")
    FC("LOW_SLOW_RISE",       "Improving from disturbed conditions. Gradual clearing expected.",          "Medium")
    FC("LOW_STEADY",          "Unsettled and overcast. Rain or showers likely to continue.",              "Medium")
    FC("LOW_SLOW_FALL",       "Worsening low pressure. Continued rain and wind expected.",                "High")
    FC("LOW_FAST_FALL",       "Deepening low — storm or severe weather conditions developing.",           "High")
    FC("LOW_RAPID_FALL",      "Deepening low — storm or severe weather conditions developing.",           "High")
    FC("VERY_LOW_STEADY",     "Deep low pressure. Severe weather in progress or imminent.",               "High")
    FC("VERY_LOW_SLOW_FALL",  "Deep low pressure. Severe weather in progress or imminent.",               "High")
    FC("VERY_LOW_FAST_FALL",  "Deep low pressure. Severe weather in progress or imminent.",               "High")
    FC("VERY_LOW_RAPID_FALL", "Deep low pressure. Severe weather in progress or imminent.",               "High")
    FC("VERY_LOW_SLOW_RISE",  "Recovering from severe conditions. Gradual improvement ahead.",            "Medium")
    FC("VERY_LOW_FAST_RISE",  "Recovering from severe conditions. Gradual improvement ahead.",            "Medium")
    FC("VERY_LOW_RAPID_RISE", "Recovering from severe conditions. Gradual improvement ahead.",            "Medium")
    { base = "Conditions unclear — continue monitoring."; conf = "Low"; }
    #undef FC

    snprintf(fc.summary, sizeof(fc.summary), "%s%s%s", base, humMod, windMod);
    strncpy(fc.confidence, conf, sizeof(fc.confidence));
    return fc;
}

LocalForecast getLocalForecast() { return buildLocalForecast(); }
