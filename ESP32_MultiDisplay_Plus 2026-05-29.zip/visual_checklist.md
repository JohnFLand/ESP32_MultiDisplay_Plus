# MultiDisplay — Visual Verification Checklist
**Version:** 2.0.2  
**Purpose:** Manual display verification after firmware changes.  
Mark each item ✅ pass, ❌ fail (with notes), or ⏭ skip (with reason).

---

## Before You Start

- [ ] Device is fully booted and connected to WiFi
- [ ] You have the IP address and can reach `http://YOUR_IP/`
- [ ] Serial monitor is open (optional, but helpful for confirming state changes)
- [ ] You have a way to send HTTP requests (curl, browser, Hubitat, or the test script)

---

## 1. Clock Screen

### 1.1 Basic Display
| # | Check | Notes |
|---|-------|-------|
| 1 | Clock displays correct time and date | |
| 2 | Time and date are legible at default brightness | |
| 3 | No text clipping at screen edges | |
| 4 | Background fills the entire screen | |

### 1.2 Color Themes
Send `GET /control?clockdark=true`, then `GET /control?clockdark=false`.

| # | Check | Notes |
|---|-------|-------|
| 5 | Dark mode: dark background, light text visible | |
| 6 | Light mode: light background, dark text visible | |
| 7 | Colors switch without partial redraws or artifacts | |
| 8 | Reset to dark: `POST /control {"clockresetcolors":"dark"}` — colors snap to defaults | |

### 1.3 Sun & Moon Times Display
Enable via `/clockconfig` → "Show Sunrise/Sunset" checkbox. Computed times from local astronomical calculations (not Open-Meteo).

| # | Check | Notes |
|---|-------|-------|
| 9 | Sun and moon time lines appear below the date when enabled | |
| 10 | Line 1 shows a sun event label ("Sunrise" or "Sunset") with time, followed by a moon event ("Moonrise" or "Moonset") with time | |
| 11 | Line 2 shows the next sun event and moon event in the same format | |
| 12 | Times match the values shown on the Astro Times Sun and Moon screens | |
| 13 | Lines disappear when display is disabled | |
| 14 | Correct contextual pair of times is shown for time of day (see note below) | |
| 15 | If no moonrise or moonset occurs today, the moon portion of that line is omitted gracefully | |
| 16 | The time values on line 1 and line 2 are vertically aligned (Sunrise/Sunset times line up; Moonrise/Moonset times line up) | |

> **Note (item 14):** Before sunrise → today's Sunrise + Moonrise (line 1), today's Sunset + Moonset (line 2).  
> After sunrise, before sunset → today's Sunset + Moonset (line 1), tomorrow's Sunrise + Moonrise (line 2).  
> After sunset → tomorrow's Sunrise + Moonrise (line 1), tomorrow's Sunset + Moonset (line 2).

### 1.4 Rotation
Send a message at each rotation, then `/clear`.

| # | Rotation | Check | Notes |
|---|----------|-------|-------|
| 16 | 0° | Clock renders upright in portrait | |
| 17 | 90° | Clock renders landscape (rotated 90°) | |
| 18 | 180° | Clock renders upside-down portrait | |
| 19 | 270° | Clock renders landscape-flipped | |

### 1.5 Pixel Shift
Enable via `/control?pixelshift=true`. Observe over 5–10 minutes.

| # | Check | Notes |
|---|-------|-------|
| 20 | Clock position shifts slightly between cycles | |
| 21 | Shift does not cause text to clip at screen edge | |
| 22 | Disabling pixel shift (`pixelshift=false`) stops movement | |

---

## 2. Messages

### 2.1 Basic Display
| # | Check | Notes |
|---|-------|-------|
| 23 | Short message displays at expected position | |
| 24 | Long message without wrap clips as expected (single line, no wrap) | |
| 25 | Long message with `wrap:true` word-wraps correctly | |
| 26 | Wrapped message respects all 9 alignment combinations (3H × 3V) | |
| 27 | No residual text from previous message after clear | |

### 2.2 Fonts
Send a test message with each of the 10 fonts (1–10).

| # | Font | Check |
|---|------|-------|
| 28 | 1 (smallest) | Readable, not distorted |
| 29 | 5 (medium) | Readable, not distorted |
| 30 | 8 (large) | Readable, fills appropriate screen space |
| 31 | 10 (largest) | Readable, single letter may fill screen |

### 2.3 Colors
| # | Check | Notes |
|---|-------|-------|
| 32 | Named color "red" → visibly red background | |
| 33 | Named color "navy" → visibly dark blue | |
| 34 | Hex color "#FF6600" → visibly orange | |
| 35 | White text on black background: good contrast | |
| 36 | Black text on white background: good contrast | |

### 2.4 Expiration
Send a message with `"expirationtime": 5` (5 seconds).

| # | Check | Notes |
|---|-------|-------|
| 37 | Message displays, then clock returns automatically after ~5 seconds | |
| 38 | No ghost of message visible after return to clock | |

### 2.5 Effects

**Flash:**
| # | Check | Notes |
|---|-------|-------|
| 39 | `flash:true` — colors visibly swap at the configured interval | |
| 40 | Flash stops cleanly when cleared | |
| 41 | `flashinterval:500` vs `flashinterval:2000` — visibly different speeds | |

**Pulse:**
| # | Check | Notes |
|---|-------|-------|
| 42 | `pulse:true` — brightness visibly rises and falls smoothly | |
| 43 | No abrupt jumps in brightness | |
| 44 | Pulse stops cleanly when cleared | |

**Scroll:**
| # | Direction | Check | Notes |
|---|-----------|-------|-------|
| 45 | left | Text scrolls from right to left, loops cleanly | |
| 46 | right | Text scrolls from left to right, loops cleanly | |
| 47 | up | Text scrolls from bottom to top, loops cleanly | |
| 48 | down | Text scrolls from top to bottom, loops cleanly | |
| 49 | any | `scrollspeed:1` visibly slower than `scrollspeed:9` | |
| 50 | any | No tearing or double-draw artifact between loop cycles | |

### 2.6 Priority
| # | Check | Notes |
|---|-------|-------|
| 51 | High-priority message stays on screen after normal message sent | |
| 52 | Two high-priority messages alternate on screen (wait ~10 seconds) | |
| 53 | Normal message with `normaloverride` enabled interrupts high priority briefly, then high priority returns | |
| 54 | Clearing all messages with `/clear` removes high priority | |

### 2.7 Message History
Send several messages, then open History from the Menu.

| # | Check | Notes |
|---|-------|-------|
| 55 | History screen shows list of recent messages | |
| 56 | Swipe up/down navigates through messages correctly | |
| 57 | Red ✕ button is visible when history is non-empty | |
| 58 | Holding ✕ (1–2 s) clears history; screen updates | |
| 59 | Long press (2 s) exits history to clock | |
| 60 | `/status` page message count matches displayed history | |

---

## 3. Weather Screen

| # | Check | Notes |
|---|-------|-------|
| 61 | `GET /weather` navigates to weather screen | |
| 62 | Weather icon renders correctly (not corrupted or blank) | |
| 63 | Temperature and humidity values are displayed | |
| 64 | Weather description text is readable | |
| 65 | "Last update" timestamp is shown | |
| 66 | Sun and moon times appear below the weather data, formatted like the clock screen | |
| 67 | Sun/moon times are consistent with what is shown on the clock and Astro screens | |
| 68 | The time values on line 1 and line 2 are vertically aligned (same as clock screen) | |
| 69 | Dark mode: `GET /control?weatherdark=true` — visible theme change, takes effect immediately | |
| 70 | Light mode: `GET /control?weatherdark=false` — visible theme change, takes effect immediately | |

---

## 4. Calendar Screen

| # | Check | Notes |
|---|-------|-------|
| 70 | `GET /calendar` navigates to calendar | |
| 71 | Month/year header shows correct month | |
| 72 | Day-of-week row (Su Mo Tu We Th Fr Sa) is correct | |
| 73 | Today's date is highlighted (circled) | |
| 74 | Previous/next month overflow days appear dimmed | |
| 75 | Calendar grid is complete (no missing rows) | |
| 76 | Dark mode: `GET /control?calendardark=true` — visible theme change, takes effect immediately | |
| 77 | Tap ◄ (left header) → previous month; tap ► (right header) → next month | |
| 78 | Tap the month/year label → returns to today's month | |
| 79 | Tap anywhere below the header → returns to clock | |

---

## 5. Astro Times Screen

Access via Menu → **Astro Times** button.

### 5.1 Sun Page
| # | Check | Notes |
|---|-------|-------|
| 80 | Screen title "Sun" and today's date appear in the header row | |
| 81 | Both `<` (left) and `>` (right) arrows are visible in the header row | |
| 82 | All nine time rows appear in chronological order: Astro. Dawn, Nautical Dawn, Civil Dawn, Sunrise, Solar Noon, Sunset, Civil Dusk, Nautical Dusk, Astro. Dusk | |
| 83 | Day Length row appears after a separator below Astro. Dusk | |
| 84 | All times use the configured clock time format (12 hr or 24 hr) | |
| 85 | Times are plausible for your location and date (cross-check against timeanddate.com) | |
| 86 | Solar noon is approximately midway between sunrise and sunset | |
| 87 | Twilight events are in the correct order (astro < nautical < civil < sunrise) | |
| 88 | Footer text "Tap here for Moon" is visible at the bottom of the screen | |

### 5.2 Moon Page
Tap the footer on the Sun page to switch to the Moon page.

| # | Check | Notes |
|---|-------|-------|
| 89 | Screen title "Moon" and today's date appear in the header row | |
| 90 | Both `<` (left) and `>` (right) arrows are visible in the header row | |
| 91 | Moonrise and Moonset times are shown (or "No rise" / "No set" / "Always up" if applicable) | |
| 92 | Illumination percentage is shown (0–100%) | |
| 93 | Phase Angle is shown (0–360°) | |
| 94 | Phase disc graphic renders and is consistent with the phase angle (e.g., right half lit for waxing crescent, fully lit for full moon) | |
| 95 | Phase name below the graphic matches the phase angle (e.g., "Waxing Crescent" at ~45°) | |
| 96 | Footer text "Tap here for Sun" is visible at the bottom of the screen | |
| 97 | Moon times are consistent with those shown on the Clock and Weather screens | |

### 5.3 Astro Screen Dark Mode
| # | Check | Notes |
|---|-------|-------|
| 98 | `GET /control?astrodark=false` — light theme applies **immediately** without leaving the screen | |
| 99 | `GET /control?astrodark=true` — dark theme applies **immediately** without leaving the screen | |
| 100 | Colors are correct: title in cyan/magenta, labels in white/black, values in yellow/orange | |
| 101 | Toggling astro dark mode does not affect any other screen's colors | |

### 5.4 Astro Touch Navigation
| # | Check | Notes |
|---|-------|-------|
| 102 | Tap `>` (right arrow) on either page → date advances one day; header date and all data update | |
| 103 | Tap `<` (left arrow) on either page → date goes back one day; header date and all data update | |
| 104 | Tap the title ("Sun" or "Moon") while viewing a non-today date → resets to today; header date updates | |
| 105 | Tap the title while already on today's date → stays on today (no visible change other than redraw) | |
| 106 | Tap the footer ("Tap here for Moon") on the Sun page → switches to Moon page (stays on same date) | |
| 107 | Tap the footer ("Tap here for Sun") on the Moon page → switches to Sun page (stays on same date) | |
| 108 | Tap the data area (below header, above footer) on either page → returns to Clock | |
| 109 | Entering the Astro screen always resets to today's date regardless of the last-viewed date | |
| 110 | When night mode is active and screen is dimmed: first tap brightens display, does NOT navigate | |
| 111 | Second tap while screen is brightened performs the normal navigation action | |

---

## 6. Menu Screen

| # | Check | Notes |
|---|-------|-------|
| 112 | Tapping the clock screen opens the menu | |
| 113 | Menu shows 6 buttons in a 2-column, 3-row layout: Clock / Weather / Calendar (left column) and Astro Times / History / About (right column) | |
| 114 | All 6 buttons are correctly labeled and their colors are distinct | |
| 115 | Tapping each button navigates to the correct screen | |
| 116 | Unread message count badge appears on the History button when there are unread messages | |
| 117 | Dark mode: `GET /control?menudark=true` — visible theme change, takes effect immediately | |
| 118 | When night mode is active and screen is dimmed: first tap brightens without opening the menu | |

---

## 7. Night Mode

> These tests require configuring night mode in `/clockconfig`.  
> To verify efficiently, use the `/testinject` endpoint (ENABLE_TEST_MODE build)
> to inject artificial sun times and force an immediate night mode check.

### 7.1 Night Mode Activation
Set `nightmodeenable=true`, `nightbrightness=20`, `daybrightness=200`.

| # | Check | Notes |
|---|-------|-------|
| 119 | During night hours: display brightness visibly drops to night level | |
| 120 | Clock switches to night color profile (dimmer colors) | |
| 121 | Sun/moon time text shows in night color (not day color) | |
| 122 | `/status` page shows "Night Mode: Active" | |

### 7.2 Day Mode Restoration
| # | Check | Notes |
|---|-------|-------|
| 123 | After sunrise: brightness restores to day level | |
| 124 | Clock switches back to day color profile | |
| 125 | Transition is clean (no flicker or partial repaint) | |

### 7.3 Touch Wake During Night Mode — All Screens
Night mode wake behavior should now apply consistently on all screens, not just the clock.

| # | Screen | Check | Notes |
|---|--------|-------|-------|
| 126 | Clock | First touch brightens display; second touch opens menu | |
| 127 | Menu | First touch brightens display; second touch activates a button | |
| 128 | Weather | First touch brightens display; second touch returns to clock | |
| 129 | Calendar | First touch brightens display; second touch performs normal navigation | |
| 130 | Astro Times | First touch brightens display; second touch performs normal navigation | |
| 131 | Message History | First touch brightens display; second touch performs swipe/navigation | |
| 132 | Any screen | After wake duration expires, display returns to night brightness automatically | |
| 133 | Any screen | Clock stays in night color profile during touch wake (brightness only, not colors) | |

### 7.4 Sunset/Sunrise Offsets
Use `/testinject` or wait for real transitions.

| # | Check | Notes |
|---|-------|-------|
| 134 | `sunsetoffset=+120`: night mode activates 2 hours after raw sunset | |
| 135 | `sunriseoffset=-60`: night mode ends 1 hour before raw sunrise | |
| 136 | Large offset crossing midnight: handled without display glitch | |

---

## 8. Screensaver

Set `screensavertimeout` to a short value (e.g., 30 seconds) for testing.

| # | Check | Notes |
|---|-------|-------|
| 137 | After inactivity: screen dims to screensaver level | |
| 138 | Brightness reduction is the expected percentage (e.g., 30%) | |
| 139 | Single touch wakes screensaver without processing as a gesture | |
| 140 | After wake: full brightness restores | |
| 141 | Screensaver does not activate on message, weather, or calendar screens | |

---

## 9. Auto-Cycle (Weather & Calendar)

Enable both cycles in `/clockconfig`.

| # | Check | Notes |
|---|-------|-------|
| 142 | Weather screen auto-appears after configured interval | |
| 143 | Weather screen returns to clock after configured show duration | |
| 144 | Calendar screen auto-appears after configured interval | |
| 145 | Calendar returns to clock after configured show duration | |
| 146 | With both enabled: weather and calendar alternate (not always the same one) | |
| 147 | Disabling cycles (`weathercycle=false`) stops auto-appear | |

---

## 10. Schedules

Configure a test schedule to fire 1–2 minutes in the future.

| # | Check | Notes |
|---|-------|-------|
| 148 | Absolute schedule fires at configured HH:MM | |
| 149 | Action=brightness: brightness changes at scheduled time | |
| 150 | Action=clock: display switches to clock screen at scheduled time | |
| 151 | Action=weather: display switches to weather screen at scheduled time | |
| 152 | Action=message: message appears at scheduled time with configured text | |
| 153 | Relative schedule (mode=relative, reference=sunset, offset=+5): fires ~5 min after sunset | |
| 154 | Disabled schedule does not fire | |

> **Note:** Relative schedules now use locally-computed sun times (from `AstroCalc`) rather than Open-Meteo data. Verify that the computed sunset/sunrise used for scheduling matches the times shown on the Astro Times Sun screen.

---

## 11. Dark / Light Mode Consistency

Each screen should respect its individual dark mode flag and update **immediately** when the flag is changed while that screen is visible.

| # | Check | Notes |
|---|-------|-------|
| 155 | Clock dark vs. light: clearly different appearance | |
| 156 | Weather dark vs. light: clearly different appearance, updates immediately | |
| 157 | Calendar dark vs. light: clearly different appearance, updates immediately | |
| 158 | History dark vs. light: clearly different appearance, updates immediately | |
| 159 | Menu dark vs. light: clearly different appearance, updates immediately | |
| 160 | Astro Times dark vs. light: clearly different appearance, updates immediately | |
| 161 | Toggling one screen's dark mode does not affect another screen's colors | |

---

## 12. Astronomical Accuracy

Cross-check a selection of computed times against a reference site such as timeanddate.com for your location and today's date.

| # | Check | Notes |
|---|-------|-------|
| 162 | Sunrise time on Astro Sun screen is within 2–3 minutes of reference | |
| 163 | Sunset time on Astro Sun screen is within 2–3 minutes of reference | |
| 164 | Solar noon is within 2–3 minutes of reference | |
| 165 | Civil dawn/dusk times are within 2–3 minutes of reference | |
| 166 | Moon phase name and illumination % are consistent with reference | |
| 167 | Moon times match those shown on Clock and Weather screens | |
| 168 | Night mode activation time (at sunset) is consistent with the sunset shown on the Astro screen | |
| 169 | Relative schedule firing time is consistent with the sunset/sunrise on the Astro screen | |
| 170 | After midnight: sun/moon times update to the new calendar day (cache refreshes) | |
| 171 | Browse to a future date via `>` on the Astro screen: times shown match reference for that date | |

---

## 13. OTA Update (Optional — perform only when needed)

| # | Check | Notes |
|---|-------|-------|
| 172 | Navigate to `/update` — update page loads | |
| 173 | Enter OTA password and select .bin file | |
| 174 | Progress bar appears during upload | |
| 175 | Device reboots and resumes normal operation after update | |
| 176 | Settings are preserved after update (not cleared) | |

---

## 14. Persistence Across Reboot

Configure a non-default setting (e.g., custom color, offset, schedule), then reboot via `/reboot`.

| # | Check | Notes |
|---|-------|-------|
| 177 | Custom clock colors survive reboot | |
| 178 | Night mode settings survive reboot | |
| 179 | Sunset/sunrise offsets survive reboot | |
| 180 | Schedules survive reboot | |
| 181 | Message profiles survive reboot | |
| 182 | All dark mode flags survive reboot (including `astrodark`) | |
| 183 | Astro screen font settings survive reboot | |

---

## 15. About Screen

Open Menu → **About**.

| # | Check | Notes |
|---|-------|-------|
| 184 | Device name is correct | |
| 185 | Firmware version matches expected (v2.0.1) | |
| 186 | WiFi IP address matches the IP you're using | |
| 187 | Flash/PSRAM sizes are reasonable (16MB / 8MB) | |
| 188 | Free heap shows a sane positive value | |

---

## Sign-Off

| Field | Value |
|-------|-------|
| Tester | |
| Date | |
| Firmware version | |
| Build timestamp | |
| Device IP | |
| Total: Pass | |
| Total: Fail | |
| Total: Skip | |
| Notes | |
