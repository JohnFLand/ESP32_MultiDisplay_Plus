//=============================================================
// AdminHandlers.ino  —  OTA updates, device reboot/reset,
//                        and OTA password management.
// Note: OTA security/upload functions consolidated here from
//       HelpFunctions.cpp where they did not logically belong.
//=============================================================

#if ENABLE_ARDUINO_OTA
  #include <ArduinoOTA.h>
#endif
#include <Update.h>

//=============================================================
//OTA Configuration
//=============================================================
extern String otaPassword;\
extern const unsigned long OTA_LOCKOUT_TIME = 300000;
extern const int MAX_OTA_ATTEMPTS           = 5;
unsigned long lastFailedOTAAttempt          = 0;
int failedOTAAttempts                       = 0;
bool otaAuthenticationFailed                = false;
bool otaUpdateSuccessful                    = false;

//=============================================================
//Check OTA Security (Password + Rate Limiting)
//=============================================================
bool checkOtaSecurity() {
  //Check rate limiting
  if (failedOTAAttempts >= MAX_OTA_ATTEMPTS) {
    if (millis() - lastFailedOTAAttempt < OTA_LOCKOUT_TIME) {
      unsigned long remaining = (OTA_LOCKOUT_TIME - (millis() - lastFailedOTAAttempt)) / 1000;
      DEBUG_PRINTF("OTA: Rate limit exceeded. %lu seconds remaining\n", remaining);
      otaAuthenticationFailed = true;
      return false;
    } else {
      //Lockout expired, reset counter
      failedOTAAttempts = 0;
    }
  }
  
  //Check password
  String submittedPassword = server.arg("password");
  
  if (submittedPassword != otaPassword) {
    DEBUG_PRINTLN("OTA: Authentication failed - incorrect password");
    failedOTAAttempts++;
    lastFailedOTAAttempt = millis();
    otaAuthenticationFailed = true;
    return false;
  }
  
  //Success!
  DEBUG_PRINTLN("OTA: Authentication successful");
  failedOTAAttempts = 0;  //Reset on success
  otaAuthenticationFailed = false;
  return true;
}

//=============================================================
//Setup OTA Endpoints
//=============================================================
void setupOTAEndpoints() {
  //Web OTA form
  server.on("/update", HTTP_GET, handleOTAUpdateForm);
  
  //OTA upload handler - capture external variables with [&]
  server.on("/doupdate", HTTP_POST, [&]() {
    server.sendHeader("Connection", "close");
    
    if (otaAuthenticationFailed) {
      if (failedOTAAttempts >= MAX_OTA_ATTEMPTS) {
        unsigned long remaining = (OTA_LOCKOUT_TIME - (millis() - lastFailedOTAAttempt)) / 1000;
        server.send(429, "text/plain", "Too many failed attempts. Try again in " + String(remaining) + " seconds");
      } else {
        server.send(401, "text/plain", "Authentication failed");
      }
      return;
    }
    
    if (otaUpdateSuccessful) {
      server.send(200, "text/plain", "Update successful! Rebooting...");
      delay(100);
      ESP.restart();
      return;
    }
    
    if (Update.hasError()) {
      server.send(500, "text/plain", "Update failed: " + String(Update.errorString()));
    } else {
      server.send(200, "text/plain", "Update successful! Rebooting...");
      delay(100);
      ESP.restart();
    }
  }, handleOTAUpload);
  
  #if ENABLE_ARDUINO_OTA
    //Set ArduinoOTA password
    if (otaPassword.length() > 0) {
      ArduinoOTA.setPassword(otaPassword.c_str());
      DEBUG_PRINTF("\n✓ OTA password configured (%d chars)\n", otaPassword.length());
    } else {
      DEBUG_PRINTLN("\n⚠️  WARNING: OTA password not set!");
    }

    //ArduinoOTA callbacks
    ArduinoOTA.onStart([]() {
      DEBUG_PRINTLN("\nArduino OTA: Update starting");
    });

    ArduinoOTA.onEnd([]() {
      DEBUG_PRINTLN("\nArduino OTA: Update complete");
    });

    ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
      DEBUG_PRINTF("Arduino OTA Progress: %u%%\r", (progress / (total / 100)));
    });

    ArduinoOTA.onError([](ota_error_t error) {
      DEBUG_PRINTF("Arduino OTA Error[%u]: ", error);
      if      (error == OTA_AUTH_ERROR)    DEBUG_PRINTLN("Auth Failed");
      else if (error == OTA_BEGIN_ERROR)   DEBUG_PRINTLN("Begin Failed");
      else if (error == OTA_CONNECT_ERROR) DEBUG_PRINTLN("Connect Failed");
      else if (error == OTA_RECEIVE_ERROR) DEBUG_PRINTLN("Receive Failed");
      else if (error == OTA_END_ERROR)     DEBUG_PRINTLN("End Failed");
    });
  #endif  //#if ENABLE_ARDUINO_OTA
}

//=============================================================
//Handle OTA Upload
//=============================================================
void handleOTAUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    if (!checkOtaSecurity()) {
      return;  //Security check failed
    }
    
    DEBUG_PRINTF("\n=== OTA Upload Started ===\n");
    DEBUG_PRINTF("File: %s (%u bytes)\n", upload.filename.c_str(), upload.totalSize);
    
    //Display OTA message on screen
    setBrightness(255);   //Brighten the screen all the way - Updates are notable
    gfx->fillScreen(COLOR_BLACK);
    gfx->setTextColor(COLOR_YELLOW);
    
    setSmartFont(26);  //Large font
    int16_t x1, y1;
    uint16_t w, h;
    getTextBoundsHF("OTA UPDATE", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 100);
    printHF("OTA UPDATE");
    
    setSmartFont(20);
    gfx->setTextColor(COLOR_WHITE);
    getTextBoundsHF("Uploading firmware...", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 140);
    printHF("Uploading firmware...");
    
    flushDisplay();
    
    //Start OTA update
    size_t imageSize = (upload.totalSize == 0) ? UPDATE_SIZE_UNKNOWN : upload.totalSize;
    
    if (!Update.begin(imageSize, U_FLASH)) {
      Update.printError(Serial);
      DEBUG_PRINTF("OTA: Failed to begin. Error: %u\n", Update.getError());
    }
  }
  else if (upload.status == UPLOAD_FILE_WRITE) {
    if (!Update.isRunning()) {
      Update.abort();
      return;
    }
    
    //Write firmware data
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      Update.printError(Serial);
    }
    
    //Show progress on display
    static unsigned long lastUpdate = 0;
    if (millis() - lastUpdate > 250) {  //Update every 250ms; keeps display responsive without overloading CPU
      if (Update.size() > 0) {
        int progress = (Update.progress() * 100) / Update.size();
        
        //Draw progress bar
        int barWidth  = 400;
        int barHeight = 30;
        int barX      = (DISPLAY_LONG - barWidth) / 2;
        int barY      = 180;
        
        gfx->fillRect(barX, barY, barWidth, barHeight, COLOR_DARKGRAY);
        int fillWidth = (barWidth * progress) / 100;
        gfx->fillRect(barX, barY, fillWidth, barHeight, COLOR_GREEN);
        gfx->drawRect(barX - 1, barY - 1, barWidth + 2, barHeight + 2, COLOR_WHITE);
        
        //Progress text — positioned below the bar
        String progressText = String(progress) + "%";
        setSmartFont(20);
        gfx->setTextColor(COLOR_WHITE);
        int16_t x1, y1;
        uint16_t w, h;
        getTextBoundsHF(progressText.c_str(), 0, 0, &x1, &y1, &w, &h);
        
        int textX = (DISPLAY_LONG - w) / 2;
        int textY = barY + barHeight + 40;  //baseline; 40px gap keeps text clear of bar border

        //Clear text area using y1 (the actual bounding-box top offset for GFX fonts,
        //not -h, which overshoots upward and can clip the bar border)
        gfx->fillRect(textX + x1 - 5, textY + y1 - 5, w + 10, h + 10, COLOR_BLACK);
        
        gfx->setCursor(textX, textY);
        printHF(progressText.c_str());
        
        flushDisplay();
        lastUpdate = millis();
        
        //Serial progress
        static int lastProgress = -1;
        if (progress != lastProgress && progress % 10 == 0) {
          DEBUG_PRINTF("Progress: %d%%\n", progress);
          lastProgress = progress;
        }
      }
    }
  }
  else if (upload.status == UPLOAD_FILE_END) {
    if (Update.end(true)) {
      otaUpdateSuccessful = true;
      DEBUG_PRINTF("\n=== OTA Complete ===\n");
      DEBUG_PRINTF("Bytes written: %u\n", upload.totalSize);
      
      //Success message
      gfx->fillScreen(COLOR_BLACK);
      gfx->setTextColor(COLOR_GREEN);
      setSmartFont(26);
      int16_t x1, y1;
      uint16_t w, h;
      getTextBoundsHF("SUCCESS!", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 140);
      printHF("SUCCESS!");
      
      setSmartFont(20);
      gfx->setTextColor(COLOR_WHITE);
      getTextBoundsHF("Rebooting...", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 180);
      printHF("Rebooting...");
      
      flushDisplay();
    } else {
      Update.printError(Serial);
      DEBUG_PRINTF("OTA: Update failed\n");
    }
  }
}

//=============================================================
//POST JSON Helper Functions for /control endpoint
//=============================================================

//Parse JSON boolean value flexibly
//Accepts: true/false, 1/0, "true"/"false", "on"/"off", "yes"/"no", "toggle" or "t"

void handleOTAPasswordPost() {
  String newPass = server.hasArg("otapassword") ? server.arg("otapassword") : "";
  newPass.trim();
  if (newPass.length() < 3) {
    server.send(400, "text/plain", "Password too short");
    return;
  }

  //Persist
  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.putString("otaPass", newPass);
  preferences.end();

  otaPassword = newPass;

  //Refresh ArduinoOTA password (if OTA enabled)
  #if ENABLE_ARDUINO_OTA
    ArduinoOTA.setPassword(otaPassword.c_str());
  #endif

  //Redirect back
  server.sendHeader("Location", "/otapassword");
  server.send(303, "text/plain", "Saved");
}

void handleResetSettingsPost() {
  bool keepProfiles = server.hasArg("keepprofiles") && server.arg("keepprofiles") == "true";

  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();
  preferences.end();

  // msgProfiles[] is still intact in RAM — re-persist them before rebooting
  if (keepProfiles) {
    saveMsgProfiles();
  }

  String msg = keepProfiles ? "Settings cleared (profiles kept). Rebooting..."
                            : "Settings cleared. Rebooting...";
  server.send(200, "text/plain", msg);
  delay(250);
  ESP.restart();
}

void handleDeviceReboot() {
  //Respond first so the caller gets an acknowledgement
  String acceptHeader = server.header("Accept");
  acceptHeader.toLowerCase();

  if (acceptHeader.indexOf("application/json") >= 0) {
    server.send(200, "application/json", "{\"message\":\"Rebooting\"}");
  } else {
    server.send(200, "text/plain", "Rebooting...");
  }

  delay(250);       //Give the HTTP stack a moment to flush
  ESP.restart();
}

void handleDeviceFullReset() {
  //Clear saved settings
  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();
  preferences.end();

  //Respond first so the caller gets an acknowledgement
  String acceptHeader = server.header("Accept");
  acceptHeader.toLowerCase();

  if (acceptHeader.indexOf("application/json") >= 0) {
    server.send(200, "application/json", "{\"message\":\"Settings cleared; rebooting\"}");
  } else {
    server.send(200, "text/plain", "Settings cleared. Rebooting...");
  }

  delay(250);
  ESP.restart();
}

#if ENABLE_TEST_MODE
  void handleTestInject() {
    //── GET: return current state ────────────────────────────────
    if (server.method() == HTTP_GET) {
      String json = "{";
      json += "\"nightModeActive\":"          + String(nightModeActive     ? "true" : "false") + ",";
      json += "\"nightModeEnabled\":"         + String(nightModeEnabled    ? "true" : "false") + ",";
      json += "\"nightModeWakeActive\":"      + String(nightModeWakeActive ? "true" : "false") + ",";
      json += "\"nightModeBrightness\":"      + String(nightModeBrightness)  + ",";
      json += "\"nightModeWakeBrightness\":"  + String(nightModeWakeBrightness) + ",";
      json += "\"screenBrightness\":"         + String(screenBrightness)     + ",";
      json += "\"sunsetOffset\":"             + String(sunsetOffset)         + ",";
      json += "\"sunriseOffset\":"            + String(sunriseOffset)        + ",";
      json += "\"sunriseHour\":"              + String(sunriseHour)          + ",";
      json += "\"sunriseMinute\":"            + String(sunriseMinute)        + ",";
      json += "\"sunsetHour\":"               + String(sunsetHour)           + ",";
      json += "\"sunsetMinute\":"             + String(sunsetMinute)         + ",";
      json += "\"sunTimesValid\":"            + String(sunTimesValid       ? "true" : "false") + ",";
      json += "\"currentScreen\":"            + String((int)currentScreen);
      json += "}";
      server.send(200, "application/json", json);
      return;
    }

    //── POST: inject values and/or force a state check for testing purposes ───────────
    if (server.method() == HTTP_POST && server.hasArg("plain")) {
      String body = server.arg("plain");
      JsonDocument doc;
      DeserializationError error = deserializeJson(doc, body);

      if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
      }

      //Override sun times
      if (doc.containsKey("sunsethour"))    sunsetHour    = (int)doc["sunsethour"];
      if (doc.containsKey("sunsetminute"))  sunsetMinute  = (int)doc["sunsetminute"];
      if (doc.containsKey("sunrisehour"))   sunriseHour   = (int)doc["sunrisehour"];
      if (doc.containsKey("sunriseminute")) sunriseMinute = (int)doc["sunriseminute"];

      //Tomorrow's sun times (used by getSunDisplayStrings / night mode after midnight)
      if (doc.containsKey("sunrisehourtomorrow"))   tomorrowSunriseHour   = (int)doc["sunrisehourtomorrow"];
      if (doc.containsKey("sunriseminutetomorrow")) tomorrowSunriseMinute = (int)doc["sunriseminutetomorrow"];

      //Validity flag
      if (doc.containsKey("setsuntimesvalid")) {
        sunTimesValid = (bool)doc["setsuntimesvalid"];
      } else {
        //Default: mark as valid when any sun time is injected
        if (doc.containsKey("sunsethour") || doc.containsKey("sunrisehour")) {
          sunTimesValid = true;
        }
      }

      //Force an immediate night-mode evaluation
      if (doc.containsKey("forcenightcheck") && (bool)doc["forcenightcheck"]) {
        lastNightModeCheck = 0;   //reset debounce timer
        updateNightMode();        //evaluate now
      }

      // Local air pressure pushed from Hubitat
      if (doc.containsKey("local_pressure")) {
        int incomingHpa = (int)doc["local_pressure"];
        if (incomingHpa > 800 && incomingHpa < 1100) {   // sanity-check reasonable hPa range
          localPressureHpa       = incomingHpa;
          localPressureValid     = true;
          lastLocalPressureReceived = millis();
        }
      }
      
      server.send(200, "application/json", "{\"message\":\"Injected\"}");
      return;
    }

    server.send(405, "application/json", "{\"error\":\"Method not allowed\"}");
  }
#endif  

//=============================================================
// startWebServer()
//  Registers every HTTP route, starts the WebServer, enables web
//  logging (if configured), and initialises ArduinoOTA.
//
//  Moved here from main .ino — all HTTP handler
//  registrations belong alongside the handlers themselves.
//  Called once from setup().
//=============================================================
void startWebServer() {
  server.on("/",               HTTP_GET,  handleRoot);                 //HTML UI for controlling the device
  server.on("/message",        HTTP_ANY,  handleDisplayMessage);       //Main message endpoint
  server.on("/msg",            HTTP_GET,  handleSimpleMessage);        //Simple compatibility endpoint
  server.on("/clear",          HTTP_ANY,  handleClear);                //Clears display, returns to Clock
  server.on("/time",           HTTP_GET,  handleTimeInfo);             //Just returns the time for diagnostic purposes
  server.on("/clock",          HTTP_ANY,  handleClockPage);            //Shows the Clock screen
  server.on("/clockconfig",    HTTP_GET,  handleClockConfigPage);
  server.on("/clockconfig",    HTTP_POST, handleClockConfig);
  server.on("/locationconfig", HTTP_GET,  handleLocationConfigPage);
  server.on("/locationconfig", HTTP_POST, handleLocationConfig);
  server.on("/weather",        HTTP_ANY,  handleWeatherPage);          //Shows the Weather screen
  server.on("/calendar",       HTTP_ANY,  handleCalendarPage);         //Shows the Calendar screen
  server.on("/astro",          HTTP_ANY,  handleAstroPage);            //Shows the Astro screen (Sun page)
  server.on("/schedules",      HTTP_ANY,  handleSchedulerConfig);
  server.on("/status",         HTTP_GET,  handleStatusPage);
  server.on("/status.json",    HTTP_GET,  handleStatusJson);
  server.on("/otapassword",    HTTP_GET,  handleOTAPasswordPage);
  server.on("/otapassword",    HTTP_POST, handleOTAPasswordPost);
  server.on("/reboot",         HTTP_ANY,  handleDeviceReboot);         //Immediate reboot (for automation)
  server.on("/resetdevice",    HTTP_ANY,  handleDeviceFullReset);      //Clear Preferences + reboot
  server.on("/resetsettings",  HTTP_GET,  handleResetSettingsPage);
  server.on("/resetsettings",  HTTP_POST, handleResetSettingsPost);
  server.on("/control",        HTTP_ANY,  handleControl);              //Multi-function endpoint, see README.md
  #if ENABLE_TEST_MODE
    server.on("/testinject",   HTTP_ANY,  handleTestInject);
  #endif

  const char* headerKeys[] = {"Content-Type", "Accept"};
  server.collectHeaders(headerKeys, 2);

  server.begin();

  #if ENABLE_WEB_LOGGING
    webLogSetup();
    DEBUG_PRINTLN("\n✓ Web debug logging enabled");
    DEBUG_PRINTLN("  Access logs at: http://" + WiFi.localIP().toString() + "/logs");
  #endif

  DEBUG_PRINTLN("\n✓ Web server started");
  DEBUG_PRINTF("  Send messages to: http://%s/message\n", WiFi.localIP().toString().c_str());

  //Setup OTA updates
  setupOTAEndpoints();
  #if ENABLE_ARDUINO_OTA
    ArduinoOTA.setHostname(deviceName.c_str());  //Name the OTA access point before beginning the OTA ability
    ArduinoOTA.begin();
    DEBUG_PRINTLN("\n✓ Arduino OTA enabled");
    DEBUG_PRINTLN("  via Arduino IDE: Select '" + String(deviceName) + "' as port");
  #endif
  DEBUG_PRINTLN("  via Web UI: http://" + WiFi.localIP().toString() + "/update");
}
