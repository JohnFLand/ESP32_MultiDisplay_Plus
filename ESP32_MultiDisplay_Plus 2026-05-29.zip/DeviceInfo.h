#include <Arduino.h>
#include <esp_chip_info.h>
#include <esp_mac.h>
#include <esp_partition.h>
#include <esp_sleep.h>
#include <esp_system.h>
#include <esp_ota_ops.h>

#if __has_include("esp_app_desc.h")
  #include <esp_app_desc.h>
  #define META_HAVE_APP_DESC 1
#else
  #define META_HAVE_APP_DESC 0
#endif

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------

static const char* metaResetReasonToStr(esp_reset_reason_t r) {
  switch (r) {
    case ESP_RST_UNKNOWN:   return "Unknown";
    case ESP_RST_POWERON:   return "Power-on";
    case ESP_RST_EXT:       return "External pin";
    case ESP_RST_SW:        return "Software restart";
    case ESP_RST_PANIC:     return "Exception / panic";
    case ESP_RST_INT_WDT:   return "Interrupt watchdog";
    case ESP_RST_TASK_WDT:  return "Task watchdog";
    case ESP_RST_WDT:       return "Other watchdog";
    case ESP_RST_DEEPSLEEP: return "Wake from deep sleep";
    case ESP_RST_BROWNOUT:  return "Brownout";
    case ESP_RST_SDIO:      return "SDIO";
    default:                return "Other / unrecognized";
  }
}

static const char* metaWakeupCauseToStr(esp_sleep_wakeup_cause_t c) {
  switch (c) {
    case ESP_SLEEP_WAKEUP_UNDEFINED: return "Not a deep-sleep wake";
    case ESP_SLEEP_WAKEUP_EXT0:      return "EXT0";
    case ESP_SLEEP_WAKEUP_EXT1:      return "EXT1";
    case ESP_SLEEP_WAKEUP_TIMER:     return "Timer";
    case ESP_SLEEP_WAKEUP_TOUCHPAD:  return "Touchpad";
    case ESP_SLEEP_WAKEUP_ULP:       return "ULP";
    case ESP_SLEEP_WAKEUP_GPIO:      return "GPIO";
    case ESP_SLEEP_WAKEUP_UART:      return "UART";
    default:                         return "Other / unrecognized";
  }
}

static const char* metaFlashModeToStr(FlashMode_t m) {
  switch (m) {
    case FM_QIO:       return "QIO";
    case FM_QOUT:      return "QOUT";
    case FM_DIO:       return "DIO";
    case FM_DOUT:      return "DOUT";
    case FM_FAST_READ: return "FAST_READ";
    case FM_SLOW_READ: return "SLOW_READ";
    case FM_UNKNOWN:   return "UNKNOWN";
    default:           return "Other / unrecognized";
  }
}

static void metaFormatMac(const uint8_t mac[6], char* out, size_t outLen) {
  snprintf(out, outLen, "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static String metaFormatBytes(uint64_t bytes) {
  char buf[64];
  if (bytes >= 1024ULL * 1024ULL) {
    snprintf(buf, sizeof(buf), "%llu bytes (%.2f MiB)",
             (unsigned long long)bytes,
             (double)bytes / 1048576.0);
  } else if (bytes >= 1024ULL) {
    snprintf(buf, sizeof(buf), "%llu bytes (%.2f KiB)",
             (unsigned long long)bytes,
             (double)bytes / 1024.0);
  } else {
    snprintf(buf, sizeof(buf), "%llu bytes",
             (unsigned long long)bytes);
  }
  return String(buf);
}

static void metaPrintKV(Print& out, const char* label, const String& value) {
  out.printf("  %-24s : %s\n", label, value.c_str());
}

static void metaPrintKV(Print& out, const char* label, const char* value) {
  out.printf("  %-24s : %s\n", label, value ? value : "(null)");
}

static String metaChipFeaturesToStr(uint32_t f) {
  String s;

#ifdef CHIP_FEATURE_WIFI_BGN
  if (f & CHIP_FEATURE_WIFI_BGN) s += "WiFi ";
#endif
#ifdef CHIP_FEATURE_BLE
  if (f & CHIP_FEATURE_BLE)      s += "BLE ";
#endif
#ifdef CHIP_FEATURE_BT
  if (f & CHIP_FEATURE_BT)       s += "BT ";
#endif
#ifdef CHIP_FEATURE_EMB_FLASH
  if (f & CHIP_FEATURE_EMB_FLASH) s += "EmbeddedFlash ";
#endif
#ifdef CHIP_FEATURE_EMB_PSRAM
  if (f & CHIP_FEATURE_EMB_PSRAM) s += "EmbeddedPSRAM ";
#endif

  s.trim();
  if (!s.length()) s = "(none decoded)";

  char raw[20];
  snprintf(raw, sizeof(raw), " [0x%08lX]", (unsigned long)f);
  s += raw;
  return s;
}

static String metaPartitionTypeToStr(const esp_partition_t* p) {
  if (!p) return "(null)";
  switch (p->type) {
    case ESP_PARTITION_TYPE_APP:  return "app";
    case ESP_PARTITION_TYPE_DATA: return "data";
    default: {
      char buf[12];
      snprintf(buf, sizeof(buf), "0x%02X", p->type);
      return String(buf);
    }
  }
}

static String metaPartitionSubtypeToStr(const esp_partition_t* p) {
  if (!p) return "(null)";

  if (p->type == ESP_PARTITION_TYPE_APP) {
    if (p->subtype == ESP_PARTITION_SUBTYPE_APP_FACTORY) return "factory";
    if (p->subtype == ESP_PARTITION_SUBTYPE_APP_TEST)    return "test";
    if (p->subtype >= ESP_PARTITION_SUBTYPE_APP_OTA_MIN &&
        p->subtype <= ESP_PARTITION_SUBTYPE_APP_OTA_MAX) {
      return String("ota_") + String((int)(p->subtype - ESP_PARTITION_SUBTYPE_APP_OTA_MIN));
    }
  }

  if (p->type == ESP_PARTITION_TYPE_DATA) {
    switch (p->subtype) {
      case ESP_PARTITION_SUBTYPE_DATA_OTA:      return "ota";
      case ESP_PARTITION_SUBTYPE_DATA_PHY:      return "phy";
      case ESP_PARTITION_SUBTYPE_DATA_NVS:      return "nvs";
      case ESP_PARTITION_SUBTYPE_DATA_COREDUMP: return "coredump";
      case ESP_PARTITION_SUBTYPE_DATA_NVS_KEYS: return "nvs_keys";
#ifdef ESP_PARTITION_SUBTYPE_DATA_EFUSE_EM
      case ESP_PARTITION_SUBTYPE_DATA_EFUSE_EM: return "efuse_em";
#endif
#ifdef ESP_PARTITION_SUBTYPE_DATA_ESPHTTPD
      case ESP_PARTITION_SUBTYPE_DATA_ESPHTTPD: return "esphttpd";
#endif
#ifdef ESP_PARTITION_SUBTYPE_DATA_FAT
      case ESP_PARTITION_SUBTYPE_DATA_FAT:      return "fat";
#endif
#ifdef ESP_PARTITION_SUBTYPE_DATA_SPIFFS
      case ESP_PARTITION_SUBTYPE_DATA_SPIFFS:   return "spiffs";
#endif
#ifdef ESP_PARTITION_SUBTYPE_DATA_LITTLEFS
      case ESP_PARTITION_SUBTYPE_DATA_LITTLEFS: return "littlefs";
#endif
      default: break;
    }
  }

  char buf[12];
  snprintf(buf, sizeof(buf), "0x%02X", p->subtype);
  return String(buf);
}

static void metaReadMacOrNA(esp_mac_type_t type, char* out, size_t outLen) {
  uint8_t mac[6];
  if (esp_read_mac(mac, type) == ESP_OK) {
    metaFormatMac(mac, out, outLen);
  } else {
    snprintf(out, outLen, "n/a");
  }
}

static void metaPrintPartitionRef(Print& out, const char* title, const esp_partition_t* p) {
  if (!p) {
    out.printf("  %-24s : (none)\n", title);
    return;
  }

  String typeStr = metaPartitionTypeToStr(p);
  String subStr  = metaPartitionSubtypeToStr(p);
  String sizeStr = metaFormatBytes(p->size);

  out.printf("  %-24s : %s / %s / label=\"%s\" / addr=0x%06lX / size=%s%s\n",
             title,
             typeStr.c_str(),
             subStr.c_str(),
             p->label,
             (unsigned long)p->address,
             sizeStr.c_str(),
             p->encrypted ? " / encrypted" : "");
}

static void metaPrintAppDescForPartition(Print& out, const esp_partition_t* p) {
  if (!p || p->type != ESP_PARTITION_TYPE_APP) return;

  esp_app_desc_t desc;
  memset(&desc, 0, sizeof(desc));

  if (esp_ota_get_partition_description(p, &desc) == ESP_OK) {
    out.printf("    %-22s project=%s | ver=%s | built=%s %s | secure=%u\n",
               "",
               desc.project_name,
               desc.version,
               desc.date,
               desc.time,
               (unsigned)desc.secure_version);
  }
}

// -----------------------------------------------------------------------------
// Main entry point
// -----------------------------------------------------------------------------

void dumpEsp32Metadata(Print& out = Serial) {
  esp_chip_info_t chipInfo;
  esp_chip_info(&chipInfo);

  const esp_partition_t* running = esp_ota_get_running_partition();
  const esp_partition_t* boot    = esp_ota_get_boot_partition();
  const esp_partition_t* nextUpd = esp_ota_get_next_update_partition(nullptr);

  char efuseMacRaw[20];
  snprintf(efuseMacRaw, sizeof(efuseMacRaw), "%012llX",
           (unsigned long long)(ESP.getEfuseMac() & 0xFFFFFFFFFFFFULL));

  char macSta[18], macAp[18], macBt[18], macEth[18];
  metaReadMacOrNA(ESP_MAC_WIFI_STA,    macSta, sizeof(macSta));
  metaReadMacOrNA(ESP_MAC_WIFI_SOFTAP, macAp,  sizeof(macAp));
  metaReadMacOrNA(ESP_MAC_BT,          macBt,  sizeof(macBt));
  metaReadMacOrNA(ESP_MAC_ETH,         macEth, sizeof(macEth));

#if META_HAVE_APP_DESC
  const esp_app_desc_t* appDesc = esp_app_get_description();
  char elfSha[65] = {0};
  esp_app_get_elf_sha256(elfSha, sizeof(elfSha));
#else
  const esp_app_desc_t* appDesc = esp_ota_get_app_description();
  char elfSha[65] = {0};
  esp_ota_get_app_elf_sha256(elfSha, sizeof(elfSha));
#endif

  out.println();
  out.println(F("======================================================================"));
  out.println(F("ESP32 Metadata Report"));
  out.println(F("======================================================================"));

  out.println(F("\n[Chip / Runtime]"));
  metaPrintKV(out, "Uptime", String(millis()) + " ms");
  metaPrintKV(out, "Chip model", ESP.getChipModel());
  metaPrintKV(out, "Chip revision", String((unsigned)ESP.getChipRevision()));
  metaPrintKV(out, "CPU cores", String((unsigned)ESP.getChipCores()));
  metaPrintKV(out, "CPU frequency", String((unsigned)ESP.getCpuFreqMHz()) + " MHz");
  metaPrintKV(out, "Chip features", metaChipFeaturesToStr(chipInfo.features));
  metaPrintKV(out, "Reset reason", metaResetReasonToStr(esp_reset_reason()));
  metaPrintKV(out, "Wakeup cause", metaWakeupCauseToStr(esp_sleep_get_wakeup_cause()));

  out.println(F("\n[Software / Build]"));
  metaPrintKV(out, "Arduino core version", ESP.getCoreVersion());
  metaPrintKV(out, "ESP-IDF version", ESP.getSdkVersion());
  if (appDesc) {
    metaPrintKV(out, "Project name", appDesc->project_name);
    metaPrintKV(out, "App version", appDesc->version);
    metaPrintKV(out, "Build date/time", String(appDesc->date) + " " + appDesc->time);
    metaPrintKV(out, "App secure version", String((unsigned)appDesc->secure_version));
    metaPrintKV(out, "App IDF version", appDesc->idf_ver);
  }
  metaPrintKV(out, "ELF SHA-256", elfSha[0] ? elfSha : "(not available)");
  metaPrintKV(out, "Sketch MD5", ESP.getSketchMD5().c_str());

  out.println(F("\n[Identity / MAC]"));
  metaPrintKV(out, "eFuse MAC (raw)", efuseMacRaw);
  metaPrintKV(out, "WiFi STA MAC", macSta);
  metaPrintKV(out, "WiFi AP MAC", macAp);
  metaPrintKV(out, "BT MAC (derived)", macBt);
  metaPrintKV(out, "ETH MAC (derived)", macEth);

  out.println(F("\n[Flash / Image]"));
  metaPrintKV(out, "Flash size", metaFormatBytes(ESP.getFlashChipSize()));
  metaPrintKV(out, "Flash speed", String((unsigned long)(ESP.getFlashChipSpeed() / 1000000UL)) + " MHz");
  metaPrintKV(out, "Flash mode", metaFlashModeToStr(ESP.getFlashChipMode()));
  metaPrintKV(out, "Flash source freq", String((unsigned)ESP.getFlashSourceFrequencyMHz()) + " MHz");
  metaPrintKV(out, "Flash divider", String((unsigned)ESP.getFlashClockDivider()));
  metaPrintKV(out, "Flash runtime freq", String((unsigned)ESP.getFlashFrequencyMHz()) + " MHz");
  metaPrintKV(out, "Sketch size", metaFormatBytes(ESP.getSketchSize()));
  metaPrintKV(out, "Free OTA space", metaFormatBytes(ESP.getFreeSketchSpace()));

  out.println(F("\n[Memory]"));
  metaPrintKV(out, "Heap total", metaFormatBytes(ESP.getHeapSize()));
  metaPrintKV(out, "Heap free", metaFormatBytes(ESP.getFreeHeap()));
  metaPrintKV(out, "Heap min free", metaFormatBytes(ESP.getMinFreeHeap()));
  metaPrintKV(out, "Heap max alloc", metaFormatBytes(ESP.getMaxAllocHeap()));

  if (ESP.getPsramSize() > 0) {
    metaPrintKV(out, "PSRAM total", metaFormatBytes(ESP.getPsramSize()));
    metaPrintKV(out, "PSRAM free", metaFormatBytes(ESP.getFreePsram()));
    metaPrintKV(out, "PSRAM min free", metaFormatBytes(ESP.getMinFreePsram()));
    metaPrintKV(out, "PSRAM max alloc", metaFormatBytes(ESP.getMaxAllocPsram()));
  } else {
    metaPrintKV(out, "PSRAM", "Not present / not enabled");
  }

  out.println(F("\n[Boot / OTA Partitions]"));
  metaPrintPartitionRef(out, "Boot partition", boot);
  metaPrintAppDescForPartition(out, boot);

  metaPrintPartitionRef(out, "Running partition", running);
  metaPrintAppDescForPartition(out, running);

  metaPrintPartitionRef(out, "Next OTA partition", nextUpd);
  metaPrintAppDescForPartition(out, nextUpd);

  metaPrintKV(out, "Running == Boot", (running == boot) ? "Yes" : "No");

  out.println(F("\n[Partition Table]"));
  esp_partition_iterator_t it =
      esp_partition_find(ESP_PARTITION_TYPE_ANY, ESP_PARTITION_SUBTYPE_ANY, nullptr);

  if (!it) {
    out.println(F("  (No partitions found)"));
  } else {
    int idx = 0;
    while (it != nullptr) {
      const esp_partition_t* p = esp_partition_get(it);

      String typeStr = metaPartitionTypeToStr(p);
      String subStr  = metaPartitionSubtypeToStr(p);
      String sizeStr = metaFormatBytes(p->size);
      String tags;

      if (p == boot)    tags += " [boot]";
      if (p == running) tags += " [running]";
      if (p == nextUpd) tags += " [nextOTA]";

      out.printf("  [%02d] %-4s %-10s %-16s addr=0x%06lX size=0x%06lX (%s)%s%s\n",
                 idx,
                 typeStr.c_str(),
                 subStr.c_str(),
                 p->label,
                 (unsigned long)p->address,
                 (unsigned long)p->size,
                 sizeStr.c_str(),
                 p->encrypted ? " encrypted" : "",
                 tags.c_str());

      metaPrintAppDescForPartition(out, p);

      it = esp_partition_next(it);
      ++idx;
    }
  }

  out.println(F("======================================================================"));
  out.println();
}