//=============================================================
// MessageEngine.ino  —  message display, effects, priority queue,
//                        history, and web message endpoints
//=============================================================

void checkMessageExpiration() {
  //Only check if a message is active and has an expiration time
  if (messageActive && messageExpirationTime > 0) {
    ulong elapsed = (millis() - messageDisplayStartTime) / 1000;  //seconds

    if (elapsed >= (ulong)messageExpirationTime) {
      DEBUG_PRINTF("Message expired after %d seconds\n", messageExpirationTime);

      //If a HIGH message expired, retire the current slot (so it doesn't immediately re-appear)
      if (messagePriority == "high") {
        if (currentHighPriorityIndex >= 0 && currentHighPriorityIndex < MAX_HIGH_PRIORITY_MESSAGES) {
          if (highPriorityMessages[currentHighPriorityIndex].active) {
            highPriorityMessages[currentHighPriorityIndex].active = false;
          }
        }
        pruneAndCountHighPriority();

        //If any other high-priority messages remain, immediately show the next one
        if (highPriorityMessageCount > 0 && !inNormalOverride) {
          int nextIdx = findNextActiveHighPriority(currentHighPriorityIndex);
          if (nextIdx >= 0) {
            activateHighPriorityIndex(nextIdx);
            return;
          }
        }

        //Otherwise, show the next queued normal message (if any)
        if (tryShowNextQueuedNormal()) {
          return;
        }
      }

      //Default: end message and return to the previous UI state
      messageActive = false;
      messageExpirationTime = 0;
      messagePriority       = "normal";   //Reset so a subsequent normal message isn't misidentified as blocked
      resetMessageRuntimeState();

      //Return to the UI state (screen + rotation) that was active before the message took over.
      uiReturnReturnOr(SCREEN_CLOCK);
    }
  }
}

void stopAllEffects() {
  isFlashing = false;
  isPulsing = false;
  currentScrollDirection = "";
  scrollOffset = 0;
  flashSwapState = false;

  //Reset brightness to message brightness
  setBrightness(currentBrightness);
  actualCurrentBrightness = currentBrightness;
}

void handleFlashing() {
  if (!isFlashing) return;

  if (millis() - lastFlashTime >= currentFlashInterval) {
    flashSwapState = !flashSwapState;
    lastFlashTime = millis();

    //Swap colors and redraw
    int rotIdx = getRotationIndex(currentRotation);
    gfx->setRotation(rotIdx);

    normalizeGfxState(false);

    if (flashSwapState) {
      //Swapped: text color becomes background, background becomes text color
      gfx->fillScreen(currentTextColor);
      gfx->setTextColor(currentBgColor);
    } else {
      //Normal: original colors
      gfx->fillScreen(currentBgColor);
      gfx->setTextColor(currentTextColor);
    }

    setSmartFont(currentFont);

    //Get screen dimensions
    int16_t screenW = gfx->width();
    int16_t screenH = gfx->height();

    //Calculate text bounds
    int16_t x1, y1;
    uint16_t textW, textH;
    getTextBoundsHF(currentMessage.c_str(), 0, 0, &x1, &y1, &textW, &textH);

    //Calculate position
    TextPosition pos = calculateTextPosition(screenW, screenH, textW, textH,
                                             y1, currentHAlign, currentVAlign, 10, 10);

    //Draw the message
    gfx->setCursor(pos.x, pos.y);
    printHF(currentMessage.c_str());
    flushDisplay();
  }
}

void handlePulsing() {
  if (!isPulsing) return;

  ulong currentTime = millis();

  //Calculate the fraction of the way through the pulse cycle (0.0 to 1.0)
  float phase = (float)(currentTime - pulseStartTime) / currentPulseDuration;

  //Use a sine wave for smooth pulse: sin(2*PI*phase) oscillates between -1.0 and 1.0
  float sinValue = sin(2 * PI * phase);

  //Map sine wave (-1 to 1) to brightness range (pulseMinBrightness to pulseMaxBrightness)
  uint8_t newBrightness = (uint8_t)round(
    (pulseMaxBrightness - pulseMinBrightness) / 2.0 * sinValue + (pulseMaxBrightness + pulseMinBrightness) / 2.0);

  //Apply the calculated brightness only if it changes
  if (newBrightness != actualCurrentBrightness) {
    setBrightness(newBrightness);
    actualCurrentBrightness = newBrightness;
  }

  //Loop the pulse continuously
  if (phase >= 1.0) {
    pulseStartTime = currentTime;
  }
}

void handleScrolling() {
  if (currentScrollDirection == "" || currentScrollDirection == "none") return;

  //Throttle (50ms)
  if (millis() - lastScrollUpdate < 50) return;
  lastScrollUpdate = millis();

  int rotIdx = getRotationIndex(currentRotation);
  gfx->setRotation(rotIdx);
  gfx->setTextWrap(false);

  int16_t screenW = gfx->width();
  int16_t screenH = gfx->height();

  setSmartFont(currentFont);

  //============================================================
  //VERTICAL SCROLLING (dirty-rect + flash disabled for scrolling)
  //============================================================
  if (currentScrollDirection == "up" || currentScrollDirection == "down") {
    static bool    vHasPrev = false;
    static int16_t vPrevX   = 0, vPrevY = 0;
    static int16_t vPrevW   = 0, vPrevH = 0;

    int16_t x1, y1;
    uint16_t textW, textH;
    getTextBoundsHF(currentMessage.c_str(), 0, 0, &x1, &y1, &textW, &textH);
    if (textW == 0 || textH == 0) return;

    //Update scroll offset
    if (currentScrollDirection == "up") {
      scrollOffset -= currentScrollSpeed;
      if (scrollOffset < 0) scrollOffset = screenH;
    } else {
      scrollOffset += currentScrollSpeed;
      if (scrollOffset > screenH + (int)textH) scrollOffset = 0;
    }

    //Erase previous rect only
    if (vHasPrev && vPrevW > 0 && vPrevH > 0) {
      int16_t ex = vPrevX, ey = vPrevY, ew = vPrevW, eh = vPrevH;
      //clip to screen
      if (ex < 0) { ew += ex; ex = 0; }
      if (ey < 0) { eh += ey; ey = 0; }
      if (ex + ew > screenW) ew = screenW - ex;
      if (ey + eh > screenH) eh = screenH - ey;
      if (ew > 0 && eh > 0) gfx->fillRect(ex, ey, ew, eh, currentBgColor);
    }

    //Draw new (flash disabled during scrolling)
    gfx->setTextColor(currentTextColor, currentBgColor);
    setSmartFont(currentFont);

    int drawX = (screenW - (int)textW) / 2;

    bool willDraw = (scrollOffset >= 0 && scrollOffset < screenH + (int)textH);
    if (willDraw) {
      gfx->setCursor(drawX, scrollOffset);
      printHF(currentMessage.c_str());

      //Compute new dirty rect from bounds (cursor origin is drawX/scrollOffset)
      int16_t rectX = drawX + x1;
      int16_t rectY = (int16_t)scrollOffset + y1;
      int16_t rectW = (int16_t)textW;
      int16_t rectH = (int16_t)textH;

      vPrevX = rectX; vPrevY = rectY; vPrevW = rectW; vPrevH = rectH;
      vHasPrev = true;
    } else {
      vHasPrev = false;
    }

    flushDisplay();
    return;
  }

  //============================================================
  //HORIZONTAL SCROLL (dirty-rect + flash disabled for scrolling)
  //============================================================
  static String lastMsg    = "";
  static int lastFont      = -1;
  static int lastRot       = -1;
  static String lastDir    = "";
  static int16_t y1_cached = 0;
  static int textW_px      = 0;
  static int textH_px      = 0;
  int effectiveFont        = currentFont;

  //--- time-based position in fixed-point (Q8 = 1/256 px) ---
  static int32_t  scrollPosQ8  = 0;
  static uint32_t lastScrollMs = 0;

  //--- dirty-rect cache for horizontal ---
  static bool    hHasPrev = false;
  static int16_t hPrevX   = 0, hPrevY = 0;
  static int16_t hPrevW   = 0, hPrevH = 0;

  const uint32_t frameIntervalMs = 50;

  uint32_t nowMs = millis();
  if (lastScrollMs != 0 && (nowMs - lastScrollMs) < frameIntervalMs) return;

  //Speed mapping 1-9 -> px/sec
  int s = (int)currentScrollSpeed;
  if (s < 1) s = 1;
  if (s > 9) s = 9;
  int32_t speedPxPerSec = 15 * s;

  //Gap control
  int gapPx = speedPxPerSec / 4;
  if (gapPx < 10) gapPx = 10;
  int maxGapPxByTime = (int)(speedPxPerSec * 2);
  if (gapPx > maxGapPxByTime) gapPx = maxGapPxByTime;
  if (gapPx > 120) gapPx = 120;

  //Measure once per change (message/font/rotation/direction)
  bool changed = (currentMessage != lastMsg ||
                  effectiveFont != lastFont ||
                  rotIdx != lastRot ||
                  currentScrollDirection != lastDir);

  if (changed) {
    //Clear old dirty region (just in case) then full clear once on change
    hHasPrev = false;
    gfx->fillScreen(currentBgColor);

    setSmartFont(effectiveFont);
    int16_t x1, y1; uint16_t w, h;
    getTextBoundsHF(currentMessage.c_str(), 0, 0, &x1, &y1, &w, &h);
    textW_px  = (int)w;
    textH_px  = (int)h;
    y1_cached = y1;

    //Initialize position at entering edge
    if (currentScrollDirection == "left") {
      scrollPosQ8 = ((int32_t)screenW) << 8;
    } else { //right
      scrollPosQ8 = (-(int32_t)textW_px) << 8;
    }

    lastMsg  = currentMessage;
    lastFont = effectiveFont;
    lastRot  = rotIdx;
    lastDir  = currentScrollDirection;

    lastScrollMs = nowMs;
  }

  if (textW_px <= 0 || textH_px <= 0) {
    lastScrollMs = nowMs;
    return;
  }

  //dt for time-based motion
  uint32_t prevMs = lastScrollMs;
  lastScrollMs = nowMs;
  uint32_t dtMs = (prevMs == 0) ? frameIntervalMs : (nowMs - prevMs);
  if (dtMs > 150) dtMs = 150;

  //vAlign-aware topY
  int topY = (screenH - textH_px) / 2;
  String v = currentVAlign; v.toLowerCase();
  if (v == "top") {
    topY = 0;
  } else if (v == "bottom") {
    topY = screenH - textH_px;
  }
  int baselineY = topY - (int)y1_cached;

  //1) Erase previous rect only
  if (hHasPrev && hPrevW > 0 && hPrevH > 0) {
    int16_t ex = hPrevX, ey = hPrevY, ew = hPrevW, eh = hPrevH;
    //clip to screen
    if (ex < 0) { ew += ex; ex = 0; }
    if (ey < 0) { eh += ey; ey = 0; }
    if (ex + ew > screenW) ew = screenW - ex;
    if (ey + eh > screenH) eh = screenH - ey;
    if (ew > 0 && eh > 0) gfx->fillRect(ex, ey, ew, eh, currentBgColor);
  }
  hHasPrev = false; //will be set true if we draw this frame

  //2) Draw new text (flash disabled during scrolling)
  gfx->setTextColor(currentTextColor, currentBgColor);
  setSmartFont(effectiveFont);

  int x = (int)(scrollPosQ8 >> 8);
  bool overlaps = (x < screenW) && (x + textW_px > 0);

  if (overlaps) {
    //Canvas-safe: never setCursor with negative x.
    String sText  = currentMessage;
    int drawX = x;

    if (drawX < 0) {
      while (sText.length() > 0 && drawX < 0) {
        String ch = sText.substring(0, 1);
        int16_t cx1, cy1; uint16_t cw, chh;
        getTextBoundsHF(ch.c_str(), 0, 0, &cx1, &cy1, &cw, &chh);
        drawX += (int)cw;
        sText.remove(0, 1);
      }
      if (drawX < 0) drawX = 0;
    }

    if (drawX >= 0 && drawX < screenW && sText.length() > 0) {
      gfx->setTextWrap(false);
      gfx->setCursor(drawX, baselineY);
      printHF(sText.c_str());

      //Compute dirty rect for what we actually printed
      int16_t sx1, sy1; uint16_t sw, sh;
      getTextBoundsHF(sText.c_str(), 0, 0, &sx1, &sy1, &sw, &sh);

      int16_t rectX = (int16_t)(drawX + sx1);
      int16_t rectY = (int16_t)(baselineY + sy1);
      int16_t rectW = (int16_t)sw;
      int16_t rectH = (int16_t)sh;

      hPrevX = rectX; hPrevY = rectY; hPrevW = rectW; hPrevH = rectH;
      hHasPrev = true;
    }
  }

  flushDisplay();

  //3) Advance + wrap (in Q8)
  int32_t deltaQ8 = (int32_t)(speedPxPerSec * (int32_t)dtMs);
  deltaQ8 = (deltaQ8 << 8) / 1000;

  if (currentScrollDirection == "left") {
    scrollPosQ8 -= deltaQ8;
    int32_t wrapThreshQ8 = -((int32_t)(textW_px + gapPx) << 8);
    if (scrollPosQ8 <= wrapThreshQ8) {
      scrollPosQ8 = ((int32_t)screenW) << 8;
    }
  } else { //right
    scrollPosQ8 += deltaQ8;
    int32_t wrapThreshQ8 = ((int32_t)(screenW + gapPx) << 8);
    if (scrollPosQ8 >= wrapThreshQ8) {
      scrollPosQ8 = (-(int32_t)textW_px) << 8;
    }
  }
}

void checkHighPriorityAlternation() {
  //Only alternate if:
  //1. Current message is high priority
  //2. Not in normal override
  //3. Have multiple high priority messages
  if (messagePriority != "high" || inNormalOverride || highPriorityMessageCount <= 1) {
    return;
  }

  //Check if it's time to alternate
  if (millis() - lastHighPriorityAlternateTime < highPriorityAlternateInterval) {
    return;
  }

  //Check for expired high priority messages and remove them
  for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
    if (highPriorityMessages[i].active) {
      ulong messageAge = (millis() - highPriorityMessages[i].startTime) / 1000;
      if (highPriorityMessages[i].expirationTime > 0 && messageAge >= highPriorityMessages[i].expirationTime) {
        highPriorityMessages[i].active = false;
        highPriorityMessageCount--;
        DEBUG_PRINTF("High priority message %d expired\n", i);
      }
    }
  }

  //If only one or zero messages left, don't alternate
  if (highPriorityMessageCount <= 1) {
    return;
  }

  //Find next active high priority message
  int startIndex = currentHighPriorityIndex;
  int nextIndex = (currentHighPriorityIndex + 1) % MAX_HIGH_PRIORITY_MESSAGES;

  while (nextIndex != startIndex) {
    if (highPriorityMessages[nextIndex].active) {
      //Check if this message is expired
      ulong messageAge = (millis() - highPriorityMessages[nextIndex].startTime) / 1000;
      if (highPriorityMessages[nextIndex].expirationTime == 0 || messageAge < highPriorityMessages[nextIndex].expirationTime) {
        //Display this message
        currentHighPriorityIndex = nextIndex;
        lastHighPriorityAlternateTime = millis();

        HighPriorityMessage* msg = &highPriorityMessages[nextIndex];

        DEBUG_PRINTF("Alternating to high priority message %d\n", nextIndex);

        //Stop current effects
        stopAllEffects();

        //Update current message parameters
        currentMessage          = msg->message;
        currentBgColor          = msg->bgColor;
        currentTextColor        = msg->textColor;
        currentFont             = msg->font;
        currentRotation         = msg->rotation;
        currentHAlign           = msg->hAlign;
        currentVAlign           = msg->vAlign;
        currentWrap             = msg->wrap;
        currentScrollDirection  = msg->scrollDir;
        currentScrollSpeed      = msg->scrollSpeed;
        currentBrightness       = msg->brightness;
        currentFlash            = msg->flash;
        currentFlashInterval    = msg->flashInterval;
        currentPulse            = msg->pulse;
        currentPulseDuration    = msg->pulseDuration;

        //Initialize effects
        isFlashing = msg->flash;
        flashSwapState = false;
        lastFlashTime = millis();

        isPulsing = msg->pulse;
        pulseStartTime = millis();

        if (msg->scrollDir != "" && msg->scrollDir != "none") {
          int16_t screenW = gfx->width();
          int16_t screenH = gfx->height();

          //Calculate text dimensions for accurate scroll positioning
          setSmartFont(msg->font);
          int16_t x1, y1;
          uint16_t textW, textH;
          getTextBoundsHF(msg->message.c_str(), 0, 0, &x1, &y1, &textW, &textH);

          //SAFE coordinate limits (matching handleScrolling)
          const int16_t SAFE_X_MIN = 0;
          const int16_t SAFE_X_MAX = screenW + 40;
          const int16_t SAFE_Y_MIN = -40;
          const int16_t SAFE_Y_MAX = screenH + 40;

          //Set initial scroll offset with SAFE starting positions
          if (msg->scrollDir == "left") {
            scrollOffset = SAFE_X_MAX;  //← SAFE!
          } else if (msg->scrollDir == "right") {
            scrollOffset = SAFE_X_MIN - textW;  //← SAFE!
          } else if (msg->scrollDir == "up") {
            scrollOffset = SAFE_Y_MAX;  //← SAFE!
          } else if (msg->scrollDir == "down") {
            scrollOffset = SAFE_Y_MIN - textH;  //← SAFE!
          } else {
            scrollOffset = 0;
          }
        }

        //Display the message
        displayMessage(msg->message, msg->bgColor, msg->textColor, msg->font,
                       msg->rotation, msg->hAlign, msg->vAlign, msg->wrap,
                       msg->scrollDir, msg->scrollSpeed, msg->brightness,
                       msg->flash, msg->flashInterval, msg->pulse, msg->pulseDuration);

        return;
      }
    }
    nextIndex = (nextIndex + 1) % MAX_HIGH_PRIORITY_MESSAGES;
  }
}

void enqueueNormalMessage(const String& msg,
                         uint16_t bg, uint16_t fg, int font, int rotation,
                         const String& hAlign, const String& vAlign, bool wrap,
                         const String& scrollDir, uint8_t scrollSpeed, uint8_t brightness,
                         bool flash, ulong flashInterval, bool pulse, ulong pulseDuration,
                         int expirationTime) {

  //If full, drop the oldest
  if (normalQueueCount >= MAX_NORMAL_QUEUED_MESSAGES) {
    normalQueueHead = (normalQueueHead + 1) % MAX_NORMAL_QUEUED_MESSAGES;
    normalQueueCount--;
    DEBUG_PRINTLN("Normal queue full - dropped oldest queued message");
  }

  QueuedNormalMessage* q = &normalMessageQueue[normalQueueTail];
  q->message        = msg;
  q->bgColor        = bg;
  q->textColor      = fg;
  q->font           = font;
  q->rotation       = rotation;
  q->hAlign         = hAlign;
  q->vAlign         = vAlign;
  q->wrap           = wrap;
  q->scrollDir      = normalizeScrollDir(scrollDir);
  q->scrollSpeed    = scrollSpeed;
  q->brightness     = brightness;
  q->flash          = flash;
  q->flashInterval  = flashInterval;
  q->pulse          = pulse;
  q->pulseDuration  = pulseDuration;
  q->expirationTime = expirationTime;
  q->queuedTime     = millis();

  normalQueueTail = (normalQueueTail + 1) % MAX_NORMAL_QUEUED_MESSAGES;
  normalQueueCount++;

  DEBUG_PRINTF("Queued normal message (count: %d)\n", normalQueueCount);
}

bool dequeueNormalMessage(QueuedNormalMessage& out) {
  if (normalQueueCount <= 0) return false;

  out = normalMessageQueue[normalQueueHead];
  normalQueueHead = (normalQueueHead + 1) % MAX_NORMAL_QUEUED_MESSAGES;
  normalQueueCount--;
  return true;
}

int pruneAndCountHighPriority() {
  int count = 0;
  for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
    if (highPriorityMessages[i].active) {
      ulong ageSec = (millis() - highPriorityMessages[i].startTime) / 1000;
      if (highPriorityMessages[i].expirationTime > 0 && ageSec >= (ulong)highPriorityMessages[i].expirationTime) {
        highPriorityMessages[i].active = false;
      } else {
        count++;
      }
    }
  }
  highPriorityMessageCount = count;
  return count;
}

int findNextActiveHighPriority(int startIndex) {
  if (pruneAndCountHighPriority() <= 0) return -1;

  int idx = startIndex;
  for (int tries = 0; tries < MAX_HIGH_PRIORITY_MESSAGES; tries++) {
    idx = (idx + 1) % MAX_HIGH_PRIORITY_MESSAGES;
    if (highPriorityMessages[idx].active) return idx;
  }
  return -1;
}

void activateHighPriorityIndex(int idx) {
  if (idx < 0 || idx >= MAX_HIGH_PRIORITY_MESSAGES) return;
  if (!highPriorityMessages[idx].active) return;

  HighPriorityMessage* msg = &highPriorityMessages[idx];

  //Stop any currently running effects
  stopAllEffects();

  deactivateScreensaver();
  showClock = false;

  if (currentScreen != SCREEN_MESSAGE) {
    uiReturnPushCurrentIfEntering(SCREEN_MESSAGE);
  }
  currentScreen = SCREEN_MESSAGE;

  //These globals drive drawing + runtime behavior
  messageActive                 = true;
  messagePriority               = "high";
  messageExpirationTime         = msg->expirationTime;
  messageDisplayStartTime       = millis();
  lastHighPriorityAlternateTime = millis();

  //Store advanced parameters + draw
  displayMessage(msg->message,
                 msg->bgColor, msg->textColor, msg->font, msg->rotation,
                 msg->hAlign, msg->vAlign, msg->wrap,
                 msg->scrollDir, msg->scrollSpeed, msg->brightness,
                 msg->flash, msg->flashInterval, msg->pulse, msg->pulseDuration);

  //Ensure effects flags match this message
  isFlashing = msg->flash;
  flashSwapState = false;
  lastFlashTime = millis();

  isPulsing = msg->pulse;
  pulseStartTime = millis();

  currentHighPriorityIndex = idx;
}

bool tryShowNextQueuedNormal() {
  if (normalQueueCount <= 0) return false;

  QueuedNormalMessage q;
  if (!dequeueNormalMessage(q)) return false;

  stopAllEffects();

  deactivateScreensaver();
  showClock = false;

  if (currentScreen != SCREEN_MESSAGE) {
    uiReturnPushCurrentIfEntering(SCREEN_MESSAGE);
  }
  currentScreen = SCREEN_MESSAGE;

  messageActive           = true;
  messagePriority         = "normal";
  messageExpirationTime   = q.expirationTime;
  messageDisplayStartTime = millis();

  displayMessage(q.message,
                 q.bgColor, q.textColor, q.font, q.rotation,
                 q.hAlign, q.vAlign, q.wrap,
                 q.scrollDir, q.scrollSpeed, q.brightness,
                 q.flash, q.flashInterval, q.pulse, q.pulseDuration);

  return true;
}

void checkTempAlternation() {
  if (!tempAlternate) return;
  if (millis() - lastTempAlternation >= (ulong)DEFAULT_TEMP_ALTERNATION_TIME * 1000UL) {
    tempAlternateShowActual = !tempAlternateShowActual;
    lastTempAlternation = millis();
    if (currentScreen == SCREEN_WEATHER) {
      displayWeather();
    }
  }
}

void checkAPAlternation() { //check air pressure alternation
  if (!apAlternate) return;
  bool localFresh = localPressureValid &&
                    (millis() - lastLocalPressureReceived < LOCAL_PRESSURE_STALE_MS);
  if (!localFresh) return;   //nothing to alternate with; keep showing open-meteo value

  if (millis() - lastApAlternation >= (ulong)DEFAULT_AP_ALTERNATION_TIME * 1000UL) {
    apAlternateShowLocal = !apAlternateShowLocal;
    lastApAlternation    = millis();
    if (currentScreen == SCREEN_WEATHER) {
      displayWeather();
    }
  }
}

void checkNormalOverride() {
  if (!inNormalOverride) return;

  //Check if override duration has elapsed
  ulong elapsed = (millis() - normalOverrideStartTime) / 1000;  //seconds

  if (elapsed >= normalOverrideDuration) {
    DEBUG_PRINTLN("Normal override duration elapsed - returning to high priority");
    inNormalOverride = false;

    //Return to the saved high priority message if still active
    if (savedHighPriorityIndex >= 0 && savedHighPriorityIndex < MAX_HIGH_PRIORITY_MESSAGES && highPriorityMessages[savedHighPriorityIndex].active) {

      currentHighPriorityIndex      = savedHighPriorityIndex;
      lastHighPriorityAlternateTime = millis();
      HighPriorityMessage* msg      = &highPriorityMessages[savedHighPriorityIndex];

      //Stop current effects
      stopAllEffects();

      //Restore high priority message
      messagePriority = "high";

      //Display the high priority message
      displayMessage(msg->message, msg->bgColor, msg->textColor, msg->font,
                     msg->rotation, msg->hAlign, msg->vAlign, msg->wrap,
                     msg->scrollDir, msg->scrollSpeed, msg->brightness,
                     msg->flash, msg->flashInterval, msg->pulse, msg->pulseDuration);

      //Restore effects
      currentScrollDirection = msg->scrollDir;
      currentScrollSpeed     = msg->scrollSpeed;
      isFlashing             = msg->flash;
      isPulsing              = msg->pulse;
      currentFlashInterval   = msg->flashInterval;
      currentPulseDuration   = msg->pulseDuration;
    }

    savedHighPriorityIndex = -1;
  }
}

static void drawWrappedMessageAligned(const String& msg,
                                     int16_t screenW, int16_t screenH,
                                     const String& hAlign, const String& vAlign,
                                     int marginX, int marginY) {
  //Safety
  if (screenW <= 0 || screenH <= 0) return;

  const int maxWidth = max(1, (int)screenW - (2 * marginX));
  const int maxLines = 20;          //hard cap (prevents runaway)
  const int lineGap  = 4;           //pixels between lines (tweak if desired)

  String lines[maxLines];
  int lineCount = 0;

  int16_t x1, y1; uint16_t w, h;

  //Build word-wrapped lines
  String currentLine = "";
  int i = 0;
  while (i < (int)msg.length() && lineCount < maxLines) {
    int nextSpace = msg.indexOf(' ', i);
    if (nextSpace < 0) nextSpace = msg.length();

    String word = msg.substring(i, nextSpace);

    String testLine = currentLine;
    if (testLine.length() > 0) testLine += " ";
    testLine += word;

    getTextBoundsHF(testLine.c_str(), 0, 0, &x1, &y1, &w, &h);

    if ((int)w > maxWidth && currentLine.length() > 0) {
      lines[lineCount++] = currentLine;
      currentLine = word;
    } else {
      currentLine = testLine;
    }

    i = nextSpace + 1;
  }
  if (lineCount < maxLines && currentLine.length() > 0) {
    lines[lineCount++] = currentLine;
  }

  if (lineCount == 0) return;

  //Measure total block height using per-line bounds (baseline-aware)
  int totalH = 0;
  int lineHeights[maxLines];
  int y1s[maxLines];

  for (int li = 0; li < lineCount; li++) {
    getTextBoundsHF(lines[li].c_str(), 0, 0, &x1, &y1, &w, &h);
    lineHeights[li] = (int)h;
    y1s[li] = (int)y1;
    totalH += (int)h;
    if (li < lineCount - 1) totalH += lineGap;
  }

  //vAlign -> top of block
  String v = vAlign; v.toLowerCase(); v.trim();
  int topY;
  if (v == "top") {
    topY = marginY;
  } else if (v == "bottom") {
    topY = screenH - marginY - totalH;
  } else { //middle/center/default
    topY = (screenH - totalH) / 2;
  }
  if (topY < marginY) topY = marginY;

  //Draw lines with hAlign
  String ha = hAlign; ha.toLowerCase(); ha.trim();
  int yCursorTop = topY;

  //We control wrapping ourselves
  gfx->setTextWrap(false);
  g_textWrapState = false;

  for (int li = 0; li < lineCount; li++) {
    getTextBoundsHF(lines[li].c_str(), 0, 0, &x1, &y1, &w, &h);

    int x;
    if (ha == "right") {
      x = screenW - marginX - (int)w;
    } else if (ha == "center") {
      x = (screenW - (int)w) / 2;
    } else { //left/default
      x = marginX;
    }
    if (x < marginX) x = marginX;

    //Convert top-of-line to baseline using y1
    int baselineY = yCursorTop - (int)y1;
    gfx->setCursor(x, baselineY);
    printHF(lines[li].c_str());

    yCursorTop += lineHeights[li] + lineGap;
    if (yCursorTop > screenH) break;
  }
}

String normalizeScrollDir (String dir) { //Normalize scroll direction
  dir.trim();
  dir.toLowerCase();
  if (dir.length() == 0 || dir == "none") {
    dir = DEFAULT_SCROLL_DIRECTION;   //which is "none"
  }
  return dir;
}

void displayMessage(String msg, uint16_t bg, uint16_t fg, int font, int rotation,
                    String hAlign, String vAlign, bool wrap,
                    String scrollDir, uint8_t scrollSpeed, uint8_t brightness,
                    bool flash, ulong flashInterval, bool pulse, ulong pulseDuration) {

  //Store current message parameters
  currentMessage         = msg;
  currentBgColor         = bg;
  currentTextColor       = fg;
  currentFont            = font;
  currentRotation        = rotation;
  currentHAlign          = hAlign;
  currentVAlign          = vAlign;
  currentWrap            = wrap;
  currentScrollDirection = normalizeScrollDir(scrollDir);
  currentScrollSpeed     = scrollSpeed;
  currentBrightness      = brightness;
  currentFlash           = flash;
  currentFlashInterval   = flashInterval;
  currentPulse           = pulse;
  currentPulseDuration   = pulseDuration;

  //Set rotation
  int rotIdx = getRotationIndex(rotation);
  gfx->setRotation(rotIdx);

  //Clear screen with background color
  gfx->fillScreen(bg);

  //Set font and color
  setSmartFont(font);
  gfx->setTextColor(fg);

  //Set brightness
  setBrightness(brightness);

  //Get screen dimensions (based on rotation)
  int16_t screenW = gfx->width();
  int16_t screenH = gfx->height();

  //Calculate text bounds
  int16_t x1, y1;
  uint16_t textW, textH;
  getTextBoundsHF(msg.c_str(), 0, 0, &x1, &y1, &textW, &textH);

  //Normalize scroll direction for checking
  String scrollCheck = scrollDir;
  scrollCheck.toLowerCase();
  scrollCheck.trim();
  #if DEEP_DEBUG
    DEBUG_PRINTLN("After normalization: '" + scrollCheck + "'");
    DEBUG_PRINTLN("Will draw: " + String((scrollCheck.length() == 0 || scrollCheck == "none") ? "YES" : "NO"));
  #endif

  //Draw the message ONLY if NOT scrolling
  //Check by length (empty or "none")
  bool isScrolling = (scrollCheck != "" && scrollCheck != "none");

  if (!isScrolling) {       //If scrolling, handleScrolling() will draw the text
    //Rules:
    //- If not scrolling and wrap==false: draw single line (may overflow screen width)
    //- If not scrolling and wrap==true : word-wrap with H/V alignment
    if (currentWrap) {
      //Word-wrap (NOT character-wrap) and honor alignment
      drawWrappedMessageAligned(msg, screenW, screenH, hAlign, vAlign, 10, 10);
    } else {
      //Single-line draw (no wrap)
      gfx->setTextWrap(false);
      g_textWrapState = false;

      //Recalculate bounds for the single line (already computed above, but safe)
      TextPosition pos = calculateTextPosition(screenW, screenH, textW, textH,
                                               y1, hAlign, vAlign, 10, 10);
      gfx->setCursor(pos.x, pos.y);
      printHF(msg.c_str());
    }
    flushDisplay();
  }

  DEBUG_PRINTLN("\nMessage and message parameter values:");
  DEBUG_PRINTLN("  Message          : " + String(currentMessage));
  DEBUG_PRINTLN("  Background Color : " + String(currentBgColor));
  DEBUG_PRINTLN("  Text color       : " + String(currentTextColor));
  DEBUG_PRINTLN("  Font             : " + String(currentFont));
  DEBUG_PRINTLN("  Rotation         : " + String(currentRotation) + "°");
  DEBUG_PRINTLN("  H. Alignment     : " + String(currentHAlign));
  DEBUG_PRINTLN("  V. Alignment     : " + String(currentVAlign));
  DEBUG_PRINTLN("  Wrap             : " + String(currentWrap ? "True" : "False"));
  DEBUG_PRINTLN("  Scroll Direction : " + String(currentScrollDirection));
  DEBUG_PRINTLN("  Scroll Speed     : " + String(currentScrollSpeed));
  DEBUG_PRINTLN("  Brightness       : " + String(currentBrightness));
  DEBUG_PRINTLN("  Flash On         : " + String(currentFlash ? "True" : "False"));
  DEBUG_PRINTLN("  Flash Interval   : " + String(currentFlashInterval) + " ms");
  DEBUG_PRINTLN("  Pulse On         : " + String(currentPulse ? "True" : "False"));
  DEBUG_PRINTLN("  Pulse Duration   : " + String(currentPulseDuration) + " ms");
  DEBUG_PRINTLN("  Priority         : " + String(messagePriority));
  DEBUG_PRINTLN("  Expiration       : " + String(messageExpirationTime) + " sec\n");

  #if EXTENDED_DEBUG
    DEBUG_PRINTLN("\n  Is Scrolling     : " + String(isScrolling ? "YES - skipped draw" : "NO - drew static"));
    if (!isScrolling) {
      TextPosition pos = calculateTextPosition(screenW, screenH, textW, textH, y1, hAlign, vAlign, 10, 10);
      DEBUG_PRINTF("  Alignment        : %s/%s\n", hAlign.c_str(), vAlign.c_str());
      DEBUG_PRINTF("  Position         : %d,%d\n", pos.x, pos.y);
    }
    getTextBoundsHF(msg.c_str(), 0, 0, &x1, &y1, &textW, &textH);
    DEBUG_PRINTF("  Screen           : %dx%d\n", screenW, screenH);
    DEBUG_PRINTF("  Text             : %dx%d\n", textW, textH);
  #endif
}

void purgeOldMessages() {
  if (maxMsgAge <= 0) return;  //Feature disabled — 0 means "never purge by age"

  time_t now = time(nullptr);
  if (now < 1000000L) return;  //NTP not yet synced — epoch is implausible, skip

  const time_t maxAgeSeconds = (time_t)maxMsgAge * 3600L;
  int newCount  = 0;
  int purged    = 0;

  for (int i = 0; i < messageCount; i++) {
    bool keep = (messages[i].timestamp == 0) ||                   //timestamp unknown — keep
                ((now - messages[i].timestamp) < maxAgeSeconds);  //within age limit
    if (keep) {
      if (newCount != i) {
        messages[newCount] = std::move(messages[i]);
      }
      newCount++;
    } else {
      if (messages[i].unread && unreadCount > 0) unreadCount--;
      purged++;
    }
  }

  messageCount = newCount;

  if (purged > 0) {
    DEBUG_PRINTF("Purged %d message(s) older than %d hours\n", purged, maxMsgAge);
  }
}

void addToHistory(String msg) {

  purgeOldMessages();  //Garbage-collect stale messages before adding a new one

  if (messageCount >= MAX_MESSAGES) {   //Shift messages down
    if (messages[0].unread && unreadCount > 0) unreadCount--;  //Evicted message was unread
    for (size_t i = 1; i < MAX_MESSAGES; ++i) {
      messages[i - 1] = std::move(messages[i]);
    }
    messageCount = MAX_MESSAGES - 1;
  }

  messages[messageCount].text      = msg;
  messages[messageCount].time      = getTimeString();
  messages[messageCount].timestamp = time(nullptr);   //Unix epoch for age-based purging
  messages[messageCount].unread    = true;
  messageCount++;
  unreadCount++;
}

void setBrightness(uint8_t brightness) {
  analogWrite(GFX_BL, brightness);
  actualCurrentBrightness = brightness;  //Keep status page in sync
}

void handleDisplayMessage() {
  //Default values
  String message          = DEFAULT_MESSAGE;
  uint16_t bgColor        = DEFAULT_BG_COLOR;
  uint16_t textColor      = DEFAULT_TEXT_COLOR;
  int font                = DEFAULT_FONT;
  int rotation            = DEFAULT_ROTATION;
  String hAlign           = DEFAULT_H_ALIGN;
  String vAlign           = DEFAULT_V_ALIGN;
  bool wrap               = DEFAULT_WRAP;
  String scrollDirection  = normalizeScrollDir(DEFAULT_SCROLL_DIRECTION);
  uint8_t scrollSpeed     = DEFAULT_SCROLL_SPEED;
  uint8_t brightness      = DEFAULT_BRIGHTNESS;
  bool flash              = DEFAULT_FLASH;
  ulong flashInterval     = DEFAULT_FLASH_INTERVAL;
  bool pulse              = DEFAULT_PULSE;
  ulong pulseDuration     = DEFAULT_PULSE_DURATION;
  String priority         = DEFAULT_PRIORITY;
  int expirationTime      = DEFAULT_EXPIRATION_TIME;
  bool isJson             = false;

  //Check for JSON POST
  if (server.method() == HTTP_POST && server.hasArg("plain")) {
    String body = server.arg("plain");
    DEBUG_PRINTLN("\n=== Received POST (JSON) ===");
    DEBUG_PRINTLN(body);

    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, body);

    if (!error) {
      isJson = true;
      DEBUG_PRINTLN("JSON parsed successfully");

      //Apply a saved message profile first (explicit params below will override)
      if (doc.containsKey("retrieveprofile")) {
        int pidx = (int)doc["retrieveprofile"];
        DEBUG_PRINTF("  Retrieve msgProfile  : %d\n", pidx);
        if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
          DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
        } else if (!msgProfiles[pidx].saved) {
          DEBUG_PRINTF("  ✗ Profile %d is empty (not saved)\n", pidx);
        } else {
          applyMsgProfile(pidx, bgColor, textColor, font, rotation,
                          hAlign, vAlign, wrap, scrollDirection,
                          scrollSpeed, brightness, flash, flashInterval, pulse, pulseDuration,
                          priority, expirationTime);
          DEBUG_PRINTF("  ✓ Applied msgProfile %d\n", pidx);
        }
      }

      //Extract parameters using helper functions; pad 4th argument to get nice printout
      getJSON_String(doc,   "text", message,                             "  Message          ");
      getJSON_Color(doc,    "bgcolor", bgColor,                          "  BG Color         ");
      getJSON_Color(doc,    "textcolor", textColor,                      "  Text Color       ");
      getJSON_Int(doc,      "font", font, 6, 48,                         "  Font             ");
      font = validateRobotoFontCode(font);
      getJSON_Rotation(doc, "rotation", rotation,                        "  Rotation         ");
      getJSON_String(doc,   "halign", hAlign,                            "  H-Align          ");
      getJSON_String(doc,   "valign", vAlign,                            "  V-Align          ");
      getJSON_Bool(doc,     "wrap", wrap,                                "  Wrap Text        ");
      getJSON_String(doc,   "scrolldir", scrollDirection,                "  Scroll Direction ");
      getJSON_UInt(doc,     "scrollspeed", scrollSpeed, 1, 9,            "  Scroll Speed     ");
      getJSON_UInt(doc,     "brightness", brightness, 0, 255,              "  Brightness       ");
      getJSON_Bool(doc,     "flash", flash,                              "  Flash Effect     ");
      getJSON_ULong(doc,    "flashinterval", flashInterval, 500, 60000,  "  Flash Interval   ", " ms");
      getJSON_Bool(doc,     "pulse", pulse,                              "  Pulse Effect     ");
      getJSON_ULong(doc,    "pulseduration", pulseDuration, 500, 600000, "  Pulse Duration   ", " ms");
      getJSON_String(doc,   "priority", priority,                        "  Priority         ");
      getJSON_Int(doc,      "expirationtime", expirationTime, 0, 86400,  "  Expiration       ", " sec");

      //Save profile if requested (after all params resolved, so saved values reflect final attrs)
      if (doc.containsKey("saveprofile")) {
        int pidx = (int)doc["saveprofile"];
        if (pidx >= 0 && pidx < MAX_MSG_PROFILES) {
          msgProfiles[pidx].saved          = true;
          msgProfiles[pidx].bgColor        = bgColor;
          msgProfiles[pidx].textColor      = textColor;
          msgProfiles[pidx].font           = font;
          msgProfiles[pidx].rotation       = rotation;
          msgProfiles[pidx].hAlign         = hAlign;
          msgProfiles[pidx].vAlign         = vAlign;
          msgProfiles[pidx].wrap           = wrap;
          msgProfiles[pidx].scrollDir      = scrollDirection;
          msgProfiles[pidx].scrollSpeed    = scrollSpeed;
          msgProfiles[pidx].brightness     = brightness;
          msgProfiles[pidx].flash          = flash;
          msgProfiles[pidx].flashInterval  = flashInterval;
          msgProfiles[pidx].pulse          = pulse;
          msgProfiles[pidx].pulseDuration  = pulseDuration;
          msgProfiles[pidx].priority       = priority;
          msgProfiles[pidx].expirationTime = expirationTime;
          saveMsgProfiles();
          DEBUG_PRINTF("  Saved msgProfile %d\n", pidx);
          //If no message text, just save and return
          if (message.length() == 0) {
            server.send(200, "application/json", "{\"message\":\"Profile saved\"}");
            return;
          }
        }
      }

      if (doc.containsKey("clearprofile")) {
        int pidx = (int)doc["clearprofile"];
        DEBUG_PRINTF("  Clear msgProfile  : %d\n", pidx);
        if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
          DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
        } else {
          msgProfiles[pidx].saved = false;
          saveMsgProfiles();
          DEBUG_PRINTF("  ✓ Cleared msgProfile %d\n", pidx);
        }
        server.send(200, "application/json", "{\"message\":\"Profile cleared\",\"profile\":" + String(pidx) + "}");
        return;
      }
    }    else {
      DEBUG_PRINTLN("JSON parsing failed - treating as plain text");
      message = body;
    }

    //If NOT JSON, parse query/form fields (Display32-style)
    if (!isJson) {
      //Apply profile first (explicit params below will override)
      if (server.hasArg("retrieveprofile")) {
        int pidx = server.arg("retrieveprofile").toInt();
        DEBUG_PRINTF("  Retrieve msgProfile  : %d\n", pidx);
        if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
          DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
        } else if (!msgProfiles[pidx].saved) {
          DEBUG_PRINTF("  ✗ Profile %d is empty (not saved)\n", pidx);
        } else {
          applyMsgProfile(pidx, bgColor, textColor, font, rotation,
                          hAlign, vAlign, wrap, scrollDirection,
                          scrollSpeed, brightness, flash, flashInterval, pulse, pulseDuration,
                          priority, expirationTime);
          DEBUG_PRINTF("  ✓ Applied msgProfile %d\n", pidx);
        }
      }

      if (server.hasArg("text"))           message        = server.arg("text");
      if (server.hasArg("bgcolor"))        bgColor        = parseColor(server.arg("bgcolor"));
      if (server.hasArg("textcolor"))      textColor      = parseColor(server.arg("textcolor"));
      if (server.hasArg("font"))           font           = server.arg("font").toInt();
      if (server.hasArg("rotation"))       rotation       = server.arg("rotation").toInt();
      if (server.hasArg("halign"))         hAlign         = server.arg("halign");
      if (server.hasArg("valign"))         vAlign         = server.arg("valign");
      if (server.hasArg("brightness"))     brightness     = (uint8_t)constrain(server.arg("brightness").toInt(), 0, 255);
      if (server.hasArg("expirationtime")) expirationTime = server.arg("expirationtime").toInt();
      if (server.hasArg("priority"))       priority       = server.arg("priority");

      if (server.hasArg("wrap")) {
        String w = server.arg("wrap");
        w.toLowerCase();
        wrap = (w == "true" || w == "1" || w == "on");
      }

      if (server.hasArg("scrolldir"))   scrollDirection = server.arg("scrolldir");
      if (server.hasArg("scrollspeed")) scrollSpeed     = (uint8_t)constrain(server.arg("scrollspeed").toInt(), 1, 9);
      if (server.hasArg("brightness"))  brightness      = (uint8_t)constrain(server.arg("brightness").toInt(), 0, 5);

      if (server.hasArg("flash")) {
        String f = server.arg("flash");
        f.toLowerCase();
        flash = (f == "true" || f == "1" || f == "on");
      }
      if (server.hasArg("flashinterval")) {
        long v = server.arg("flashinterval").toInt();
        if (v < 50) v = 50;
        flashInterval = (ulong)v;
      }

      if (server.hasArg("pulse")) {
        String p = server.arg("pulse");
        p.toLowerCase();
        pulse = (p == "true" || p == "1" || p == "on");
      }
      if (server.hasArg("pulseduration")) {
        long v = server.arg("pulseduration").toInt();
        if (v < 100) v = 100;
        pulseDuration = (ulong)v;
      }

      if (server.hasArg("expirationtime")) expirationTime = server.arg("expirationtime").toInt();
      if (server.hasArg("priority"))       priority       = server.arg("priority");

      //Save profile if requested (web form adds saveprofile=N as hidden field)
      if (server.hasArg("saveprofile")) {
        int pidx = server.arg("saveprofile").toInt();
        if (pidx >= 0 && pidx < MAX_MSG_PROFILES) {
          msgProfiles[pidx].saved          = true;
          msgProfiles[pidx].bgColor        = bgColor;
          msgProfiles[pidx].textColor      = textColor;
          msgProfiles[pidx].font           = font;
          msgProfiles[pidx].rotation       = rotation;
          msgProfiles[pidx].hAlign         = hAlign;
          msgProfiles[pidx].vAlign         = vAlign;
          msgProfiles[pidx].wrap           = wrap;
          msgProfiles[pidx].scrollDir      = scrollDirection;
          msgProfiles[pidx].scrollSpeed    = scrollSpeed;
          msgProfiles[pidx].brightness     = brightness;
          msgProfiles[pidx].flash          = flash;
          msgProfiles[pidx].flashInterval  = flashInterval;
          msgProfiles[pidx].pulse          = pulse;
          msgProfiles[pidx].pulseDuration  = pulseDuration;
          msgProfiles[pidx].priority       = priority;
          msgProfiles[pidx].expirationTime = expirationTime;
          saveMsgProfiles();
          DEBUG_PRINTF("  Saved msgProfile %d\n", pidx);
          if (message.length() == 0) {
            server.sendHeader("Location", "/");
            server.send(303);
            return;
          }
        }
      }

      if (server.hasArg("clearprofile")) {
        int pidx = server.arg("clearprofile").toInt();
        DEBUG_PRINTF("  Clear msgProfile  : %d\n", pidx);
        if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
          DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
        } else {
          msgProfiles[pidx].saved = false;
          saveMsgProfiles();
          DEBUG_PRINTF("  ✓ Cleared msgProfile %d\n", pidx);
        }
        server.sendHeader("Location", "/");
        server.send(303);
        return;
      }
    }
  }
  //Check for GET parameters OR a form-encoded POST (e.g. save-profile-only with no message text).
  //Note: form-encoded POSTs do NOT set server.arg("plain"), so they fall through here.
  else if (server.hasArg("text") || server.hasArg("retrieveprofile") || server.hasArg("saveprofile") || server.hasArg("clearprofile")) {
    DEBUG_PRINTLN(server.method() == HTTP_POST ? "\n=== Received form POST ===" : "\n=== Received GET ===");

    //Apply profile first if specified
    if (server.hasArg("retrieveprofile")) {
      int pidx = server.arg("retrieveprofile").toInt();
      DEBUG_PRINTF("  Retrieve msgProfile  : %d\n", pidx);
      if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
        DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
      } else if (!msgProfiles[pidx].saved) {
        DEBUG_PRINTF("  ✗ Profile %d is empty (not saved)\n", pidx);
      } else {
        applyMsgProfile(pidx, bgColor, textColor, font, rotation,
                        hAlign, vAlign, wrap, scrollDirection,
                        scrollSpeed, brightness, flash, flashInterval, pulse, pulseDuration,
                        priority, expirationTime);
        DEBUG_PRINTF("  ✓ Applied msgProfile %d\n", pidx);
      }
    }

    message = server.arg("text");
    DEBUG_PRINTLN("  Message          : " + message);

    bool configChanged = false;
    getGET_Color(   "bgcolor", bgColor,     "  Background Color ", configChanged);
    getGET_Color(   "textcolor", textColor, "  Text Color       ", configChanged);
    getGET_Int(     "font", font, 6, 48,    "  Font             ", configChanged);
    font = validateRobotoFontCode(font);
    getGET_Rotation("rotation", rotation,   "  Rotation         ", configChanged);
    getGET_String(  "halign", hAlign,       "  H-Align          ", configChanged);
    getGET_String(  "valign", vAlign,       "  V-Align          ", configChanged);
    getGET_Bool(    "wrap", wrap,           "  Wrap Text        ", configChanged);
    getGET_String(  "scrolldir", scrollDirection,     "  Scroll Direction ", configChanged);
    getGET_UInt(    "scrollspeed", scrollSpeed, 1, 9, "  Scroll Speed     ", configChanged);
    getGET_UInt(    "brightness", brightness, 0, 255, "  Brightness       ", configChanged);
    getGET_Bool(    "flash", flash,         "  Flash Effect     ", configChanged);
    getGET_Int(     "flashinterval", (int&)flashInterval, 500, 60000, "  Flash Interval   ",  configChanged, " ms");
    getGET_Bool(    "pulse", pulse,         "  Pulse Effect     ", configChanged);
    getGET_Int(     "pulseduration", (int&)pulseDuration, 500, 600000, "  Pulse Duration   ", configChanged, " ms");
    getGET_String(  "priority", priority,   "  Priority         ", configChanged);
    getGET_Int(     "expirationtime", expirationTime, 0, 86400, "  Expiration       ",        configChanged, " sec");

    //Save profile if requested via GET or form POST
    if (server.hasArg("saveprofile")) {
      int pidx = server.arg("saveprofile").toInt();
      if (pidx >= 0 && pidx < MAX_MSG_PROFILES) {
        msgProfiles[pidx].saved          = true;
        msgProfiles[pidx].bgColor        = bgColor;
        msgProfiles[pidx].textColor      = textColor;
        msgProfiles[pidx].font           = font;
        msgProfiles[pidx].rotation       = rotation;
        msgProfiles[pidx].hAlign         = hAlign;
        msgProfiles[pidx].vAlign         = vAlign;
        msgProfiles[pidx].wrap           = wrap;
        msgProfiles[pidx].scrollDir      = scrollDirection;
        msgProfiles[pidx].scrollSpeed    = scrollSpeed;
        msgProfiles[pidx].brightness     = brightness;
        msgProfiles[pidx].flash          = flash;
        msgProfiles[pidx].flashInterval  = flashInterval;
        msgProfiles[pidx].pulse          = pulse;
        msgProfiles[pidx].pulseDuration  = pulseDuration;
        msgProfiles[pidx].priority       = priority;
        msgProfiles[pidx].expirationTime = expirationTime;
        saveMsgProfiles();
        DEBUG_PRINTF("  Saved msgProfile %d\n", pidx);
        //Save-only call (no message text): return success now, don't try to display anything
        if (message.length() == 0) {
          String acceptHeader = server.header("Accept");
          acceptHeader.toLowerCase();
          if (acceptHeader.indexOf("application/json") >= 0) {
            server.send(200, "application/json", "{\"message\":\"Profile saved\",\"profile\":" + String(pidx) + "}");
          } else {
            server.send(200, "text/plain", "Profile " + String(pidx) + " saved");
          }
          return;
        }
      }
    }

    //Clear profile if requested via GET or form POST
    if (server.hasArg("clearprofile")) {
      int pidx = server.arg("clearprofile").toInt();
      DEBUG_PRINTF("  Clear msgProfile  : %d\n", pidx);
      if (pidx < 0 || pidx >= MAX_MSG_PROFILES) {
        DEBUG_PRINTF("  ✗ Invalid profile index %d (valid: 0-%d)\n", pidx, MAX_MSG_PROFILES - 1);
      } else {
        msgProfiles[pidx].saved = false;
        saveMsgProfiles();
        DEBUG_PRINTF("  ✓ Cleared msgProfile %d\n", pidx);
      }
      String acceptHeader = server.header("Accept");
      acceptHeader.toLowerCase();
      if (acceptHeader.indexOf("application/json") >= 0) {
        server.send(200, "application/json", "{\"message\":\"Profile cleared\",\"profile\":" + String(pidx) + "}");
      } else {
        server.send(200, "text/plain", "Profile " + String(pidx) + " cleared");
      }
      return;
    }
  }

  //Normalize scroll direction
  scrollDirection  = normalizeScrollDir(scrollDirection);

  //Validate and normalize priority
  priority.toLowerCase();
  priority.trim();
  if (priority != "high" && priority != "normal") {
    priority = "normal";
  }

  if (message.length() > 0) {
    //Add to history
    addToHistory(message);

    //Check priority - Advanced implementation
    bool shouldDisplay = true;

    if (messagePriority == "high" && priority == "normal") {
      if (normalOverrideEnabled) {
        //Normal override enabled - allow temporary override
        DEBUG_PRINTF("Normal message overriding high priority for %d seconds\n", normalOverrideDuration);
        inNormalOverride = true;
        normalOverrideStartTime = millis();
        savedHighPriorityIndex = currentHighPriorityIndex;
        shouldDisplay = true;
      } else {
        DEBUG_PRINTLN("Normal message queued - high priority active (override disabled)");
        shouldDisplay = false;
      }
    }

    //If new message is high priority, add to queue
    if (priority == "high") {
      //Clear normal override state
      inNormalOverride = false;
      savedHighPriorityIndex = -1;

      //Find empty slot or replace oldest
      int slotIndex = -1;
      for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
        if (!highPriorityMessages[i].active) {
          slotIndex = i;
          break;
        }
      }

      //If no empty slot, replace oldest
      if (slotIndex == -1) {
        ulong oldestTime = millis();
        for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
          if (highPriorityMessages[i].startTime < oldestTime) {
            oldestTime = highPriorityMessages[i].startTime;
            slotIndex = i;
          }
        }
      }

      //Store the high priority message
      if (slotIndex >= 0) {
        highPriorityMessages[slotIndex].message         = message;
        highPriorityMessages[slotIndex].bgColor         = bgColor;
        highPriorityMessages[slotIndex].textColor       = textColor;
        highPriorityMessages[slotIndex].font            = font;
        highPriorityMessages[slotIndex].rotation        = rotation;
        highPriorityMessages[slotIndex].hAlign          = hAlign;
        highPriorityMessages[slotIndex].vAlign          = vAlign;
        highPriorityMessages[slotIndex].wrap            = wrap;
        highPriorityMessages[slotIndex].scrollDir       = scrollDirection;
        highPriorityMessages[slotIndex].scrollSpeed     = scrollSpeed;
        highPriorityMessages[slotIndex].brightness      = brightness;
        highPriorityMessages[slotIndex].flash           = flash;
        highPriorityMessages[slotIndex].flashInterval   = flashInterval;
        highPriorityMessages[slotIndex].pulse           = pulse;
        highPriorityMessages[slotIndex].pulseDuration   = pulseDuration;
        highPriorityMessages[slotIndex].expirationTime  = expirationTime;
        highPriorityMessages[slotIndex].startTime       = millis();
        highPriorityMessages[slotIndex].active          = true;

        highPriorityMessageCount = 0;  //Count active messages
        for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
          if (highPriorityMessages[i].active) {
            highPriorityMessageCount++;
          }
        }

        DEBUG_PRINTF("Added high priority message to queue (count: %d)\n", highPriorityMessageCount);
      }
    }

    //If normal priority and override disabled, clear high priority queue
    if (priority == "normal" && !normalOverrideEnabled && messagePriority != "high") {
      for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
        highPriorityMessages[i].active = false;
      }
      highPriorityMessageCount = 0;
      currentHighPriorityIndex = 0;
    }

    if (!shouldDisplay) {
      //High priority is active and this is a normal message with override disabled:
      //Queue it for display after all high priority messages are dismissed or expired
      enqueueNormalMessage(message,
                           bgColor, textColor, font, rotation,
                           hAlign, vAlign, wrap,
                           scrollDirection, scrollSpeed, brightness,
                           flash, flashInterval, pulse, pulseDuration,
                           expirationTime);

      //Send response but don't display now
      String acceptHeader = server.header("Accept");
      acceptHeader.toLowerCase();
      if (acceptHeader.indexOf("application/json") >= 0) {
        server.send(200, "application/json", "{\"message\":\"Queued normal message (high priority active)\"}");
      } else {
        server.send(200, "text/html", "<html><body><h1>Queued</h1><p>Normal message queued (high priority active)</p></body></html>");
      }
      return;
    }

    //Display the message
    deactivateScreensaver();
    showClock = false;
    uiReturnPushCurrentIfEntering(SCREEN_MESSAGE);

    currentScreen                 = SCREEN_MESSAGE;
    messageActive                 = true;
    messageExpirationTime         = expirationTime;
    messageDisplayStartTime       = millis();
    messagePriority               = priority;
    lastHighPriorityAlternateTime = millis();

    //Store advanced parameters
    currentWrap                   = wrap;
    currentScrollDirection        = scrollDirection;
    currentScrollSpeed            = scrollSpeed;
    currentFlash                  = flash;
    currentFlashInterval          = flashInterval;
    currentPulse                  = pulse;
    currentPulseDuration          = pulseDuration;

    //Stop any existing effects
    stopAllEffects();

    //Initialize effects
    isFlashing     = flash;
    flashSwapState = false;
    lastFlashTime  = millis();

    isPulsing = pulse;
    pulseStartTime = millis();
    actualCurrentBrightness = brightness;

    //Initialize scrolling
    if (scrollDirection != "" && scrollDirection != "none") {
      scrollOffset = 0;  //Always start at 0

      //For UP scroll, override to start at bottom
      if (scrollDirection == "up") {
        int rotIdx = getRotationIndex(rotation);
        gfx->setRotation(rotIdx);
        scrollOffset = gfx->height();
      }

      #if EXTENDED_DEBUG
        DEBUG_PRINTLN("\n=== Scroll Init ===");
        DEBUG_PRINTF("Direction: %s, Offset: %d\n", scrollDirection.c_str(), scrollOffset);
      #endif
    } else {
      scrollOffset = 0;
    }

    //Display the message
    displayMessage(message, bgColor, textColor, font, rotation, hAlign, vAlign,
                   wrap, scrollDirection, scrollSpeed, brightness,
                   flash, flashInterval, pulse, pulseDuration);

    //Send response
    String acceptHeader = server.header("Accept");
    acceptHeader.toLowerCase();
    if (acceptHeader.indexOf("application/json") >= 0) {
      server.send(200, "application/json", "{\"message\":\"OK\"}");
    } else {
      sendMessageSentPage(
        message, bgColor, textColor, font, rotation, hAlign, vAlign,
        wrap, scrollDirection, scrollSpeed, brightness,
        flash, flashInterval, pulse, pulseDuration,
        priority, expirationTime);
    }
  } else {
    server.send(400, "text/plain", "No message text provided");
  }
}

void handleSimpleMessage() {
  if (server.hasArg("text")) {
    String messageText = server.arg("text");

    addToHistory(messageText);

    //Display with defaults
    deactivateScreensaver();
    showClock               = false;
    currentScreen           = SCREEN_MESSAGE;
    messageActive           = true;
    messageExpirationTime   = 0;  //No expiration for simple messages
    messageDisplayStartTime = millis();
    messagePriority         = "normal";

    displayMessage(messageText, COLOR_BLACK, COLOR_WHITE, DEFAULT_FONT, DEFAULT_ROTATION, "center", "middle",
                   false, "none", 2, 255, false, 0, false, 0);

    server.send(200, "text/plain", "Message received!");
  } else {
    server.send(400, "text/plain", "Missing 'text' parameter");
  }
}

void handleClear() {
  //Dismiss all active and queued messages and return to the prior screen.
  //History is preserved. No cascade -- a rule sending /clear wants a clean
  //slate immediately, not to advance to the next queued message.

  //Discard every pending message
  for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++) {
    highPriorityMessages[i].active = false;
  }
  highPriorityMessageCount = 0;
  currentHighPriorityIndex = 0;

  normalQueueHead  = 0;
  normalQueueTail  = 0;
  normalQueueCount = 0;

  messageActive          = false;
  messageExpirationTime  = 0;
  messagePriority        = "normal";
  inNormalOverride       = false;
  savedHighPriorityIndex = -1;
  resetMessageRuntimeState();

  //Return to the screen that was showing before any message took over
  if (currentScreen == SCREEN_MESSAGE) {
    uiReturnReturnOr(SCREEN_CLOCK);
  }

  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "Redirecting...");
}
