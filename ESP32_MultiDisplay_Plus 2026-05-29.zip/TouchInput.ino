//=============================================================
// TouchInput.ino  —  touch handling, screen transitions,
//                     auto-cycle, and display-action wrappers
//=============================================================

void autoCycleTick() {
  if (!weatherCycleEnabled && !calendarCycleEnabled) return;
  if (screensaverActive) return;

  //--- Currently showing weather via auto-cycle ---
  if (weatherAutoShowing) {
    if (currentScreen != SCREEN_WEATHER && currentScreen != SCREEN_MESSAGE) {
      //User navigated away manually; restart this screen's interval
      weatherAutoShowing = false;
      weatherCycleStartTime = millis();
      DEBUG_PRINTLN("Weather auto-cycle canceled");
      return;
    }
    if (millis() - weatherCycleStartTime >= weatherShowDuration) {
      weatherAutoShowing = false;
      if (weatherCycleEnabled && calendarCycleEnabled) {
        //Both enabled: hand off to calendar and start its interval now
        cycleWeatherTurn = false;
        calendarCycleStartTime = millis();
      } else {
        //Only weather enabled: restart weather interval
        weatherCycleStartTime = millis();
      }
      cycleInitiatedReturn = true;  //Tell changeScreen not to overwrite the timers we just set
      changeScreen(SCREEN_CLOCK);
    }
    return;
  }

  //--- Currently showing calendar via auto-cycle ---
  if (calendarAutoShowing) {
    if (currentScreen != SCREEN_CALENDAR && currentScreen != SCREEN_MESSAGE) {
      calendarAutoShowing = false;
      calendarCycleStartTime = millis();
      DEBUG_PRINTLN("Calendar auto-cycle canceled");
      return;
    }
    if (millis() - calendarCycleStartTime >= calendarShowDuration) {
      calendarAutoShowing = false;
      if (weatherCycleEnabled && calendarCycleEnabled) {
        //Both enabled: hand off to weather and start its interval now
        cycleWeatherTurn = true;
        weatherCycleStartTime = millis();
      } else {
        //Only calendar enabled: restart calendar interval
        calendarCycleStartTime = millis();
      }
      cycleInitiatedReturn = true;  //Tell changeScreen not to overwrite the timers we just set
      changeScreen(SCREEN_CLOCK);
    }
    return;
  }

  //--- Idle: waiting to show the next screen ---
  if (currentScreen != SCREEN_CLOCK) return;

  if (weatherCycleEnabled && calendarCycleEnabled) {
    //Both enabled: only the screen whose turn it is checks its timer
    if (cycleWeatherTurn) {
      if (millis() - weatherCycleStartTime >= weatherCycleInterval) {
        weatherAutoShowing = true;
        weatherCycleStartTime = millis();   //reused as shownAt
        changeScreen(SCREEN_WEATHER);
      }
    } else {
      if (millis() - calendarCycleStartTime >= calendarCycleInterval) {
        calendarAutoShowing = true;
        calendarCycleStartTime = millis();  //reused as shownAt
        changeScreen(SCREEN_CALENDAR);
      }
    }
  } else if (weatherCycleEnabled) {
    if (millis() - weatherCycleStartTime >= weatherCycleInterval) {
      weatherAutoShowing = true;
      weatherCycleStartTime = millis();
      changeScreen(SCREEN_WEATHER);
    }
  } else {
    if (millis() - calendarCycleStartTime >= calendarCycleInterval) {
      calendarAutoShowing = true;
      calendarCycleStartTime = millis();
      changeScreen(SCREEN_CALENDAR);
    }
  }
}

void handleTouchInput() {
  if (!touchEnabled) return;    //Early exit if touch is disabled
  uint16_t x = 0, y = 0;
  bool rawTouching = getTouchPoint(x, y);

  //Time-based debouncing: require 20ms of continuous stable state before changing.
  //This is immune to slow loop iterations caused by flushDisplay() during scrolling.
  //A count-based debounce (e.g. 5 consecutive readings) breaks when the loop runs
  //slowly, causing taps to be dropped silently.
  static bool     touching        = false;
  static bool     lastRaw         = false;
  static uint32_t stableStartMs   = 0;
  const  uint32_t DEBOUNCE_MS     = 20;

  if (rawTouching != lastRaw) {
    //State changed - start timing the new state
    lastRaw      = rawTouching;
    stableStartMs = millis();
  } else if ((millis() - stableStartMs) >= DEBOUNCE_MS) {
    //New state has been stable for DEBOUNCE_MS - commit it
    touching = rawTouching;
  }

  if (rawTouching) {
    lastTouchX = x;
    lastTouchY = y;
  }

  //Debug output
  #if DEEP_DEBUG
    static bool lastTouching = false;
    if (touching && !lastTouching) {
      DEBUG_PRINTF(">>> TOUCH START: X=%d, Y=%d, Screen=%d\n", x, y, currentScreen);
    }
    if (!touching && lastTouching) {
      DEBUG_PRINTLN(">>> TOUCH END");
    }
    lastTouching = touching;
  #endif

  //Touch state machine
  switch (touchState) {
    case TOUCH_IDLE:
      if (touching) {
        #if DEEP_DEBUG
          DEBUG_PRINTLN("State: IDLE -> PRESSED");
        #endif
        touchState = TOUCH_PRESSED;
        touchPressX = x;
        touchPressY = y;
        touchPressTime = millis();

        //Wake from screensaver on touch - consume this touch so it doesn't also trigger Menu
        if (screensaverActive) {
          deactivateScreensaver();
          screensaverWake = true;
          lastActivity = millis();
        }
      }
      break;

    case TOUCH_PRESSED:
      if (touching) {
        #if DEEP_DEBUG
          DEBUG_PRINTLN("State: PRESSED -> HELD");
        #endif
        touchState = TOUCH_HELD;
      } else {
        #if DEEP_DEBUG
          DEBUG_PRINTLN("State: PRESSED -> RELEASED");
        #endif
        touchState = TOUCH_RELEASED;
        touchReleaseX = lastTouchX;
        touchReleaseY = lastTouchY;
      }
      break;

    case TOUCH_HELD:
      if (!touching) {
        #if DEEP_DEBUG
          DEBUG_PRINTLN("State: HELD -> RELEASED");
        #endif
        touchState = TOUCH_RELEASED;
        //Use last valid touch coords, not the invalid "no touch" coords
        touchReleaseX = lastTouchX;
        touchReleaseY = lastTouchY;
      }
      break;

    case TOUCH_RELEASED:
      #if DEEP_DEBUG
        DEBUG_PRINTLN("State: RELEASED - Calling handleTouchRelease()");
      #endif
      if (screensaverWake) {
        screensaverWake = false;  //Consume the wake touch - don't process as a normal tap
      } else {
        handleTouchRelease(touchPressX, touchPressY, touchReleaseX, touchReleaseY);
      }
      touchState = TOUCH_IDLE;
      lastActivity = millis();    //Reset screensaver timer
      #if DEEP_DEBUG
        DEBUG_PRINTLN("State: RELEASED -> IDLE");
      #endif
      break;
  }
}

void handleTouchRelease(uint16_t pressX, uint16_t pressY, uint16_t releaseX, uint16_t releaseY) {
  #if DEEP_DEBUG
    DEBUG_PRINTF("handleTouchRelease: screen=%d press(%d,%d) release(%d,%d)\n",
                (int)currentScreen, pressX, pressY, releaseX, releaseY);
  #endif

  //Cooldown check
  if (millis() - lastScreenChange < SCREEN_CHANGE_COOLDOWN) {
    DEBUG_PRINTF(">>> Cooldown active - returning early\n");
    return;
  }

  uint16_t x = releaseX;
  uint16_t y = releaseY;

  //Drag check
  int deltaX = abs((int)releaseX - (int)pressX);
  int deltaY = abs((int)releaseY - (int)pressY);

  if ((deltaX > 30 || deltaY > 30) && currentScreen != SCREEN_MESSAGES) {
    #if DEEP_DEBUG
      DEBUG_PRINTF(">>> Drag detected (deltaX=%d, deltaY=%d) - returning early\n", deltaX, deltaY);
    #endif
   return;
  }
  #if DEEP_DEBUG
    DEBUG_PRINTF(">>> Passed cooldown and drag checks - processing touch\n");
  #endif

  //If viewing a message, touch dismisses it
  if (currentScreen == SCREEN_MESSAGE) {
    DEBUG_PRINTLN("\nTouch on message - dismissing");

    //If the active message is HIGH, retire it and show next HIGH (or queued normal)
    if (messagePriority == "high") {
      if (currentHighPriorityIndex >= 0 && currentHighPriorityIndex < MAX_HIGH_PRIORITY_MESSAGES) {
        if (highPriorityMessages[currentHighPriorityIndex].active) {
          highPriorityMessages[currentHighPriorityIndex].active = false;
        }
      }
      pruneAndCountHighPriority();

      //If more high priority messages remain, keep showing them
      if (highPriorityMessageCount > 0 && !inNormalOverride) {
        int nextIdx = findNextActiveHighPriority(currentHighPriorityIndex);
        if (nextIdx >= 0) {
          activateHighPriorityIndex(nextIdx);
          return;
        }
      }

      //Otherwise, show next queued normal (if any)
      if (tryShowNextQueuedNormal()) {
        return;
      }
    }

    //Default: end message and return to prior UI state
    messageActive         = false;
    messageExpirationTime = 0;
    messagePriority       = "normal";   //Reset so checkHighPriorityAlternation() can't re-trigger
    resetMessageRuntimeState();
    uiReturnReturnOr(SCREEN_CLOCK);
    return;
  }

  if (currentScreen == SCREEN_CLOCK) {
    //If night mode is actively dimming and not already woken, treat touch as a wake
    if (nightModeActive && !nightModeWakeActive) {
      DEBUG_PRINTLN("Night mode wake: brightening display for touch");
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      //NOTE: do NOT write into screenBrightness here — that holds the day brightness
      return;  //Don't open menu — this touch just woke the screen
    }
    //Second touch while already awake (or night mode not active) → show menu normally
    DEBUG_PRINTLN("\nTouch on clock - showing menu");
    changeScreen(SCREEN_MENU);
  } else if (currentScreen == SCREEN_MENU) {
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    for (int i = 0; i < NUM_BUTTONS; i++) {
      Button btn = menuButtons[i];

      if (x >= btn.x && x <= (btn.x + btn.w) && y >= btn.y && y <= (btn.y + btn.h)) {

        DEBUG_PRINTF("Button: %s\n", btn.label);
        lastScreenChange = millis();      //harden against double-release
        changeScreen(btn.targetScreen);
        return;
      }
    }
  } else if (currentScreen == SCREEN_MESSAGES) {
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    //Special handling for message history
    int deltaX = (int)releaseX - (int)pressX;
    int deltaY = (int)releaseY - (int)pressY;
    ulong holdDuration = millis() - touchPressTime;
    int tapX = (int)((pressX + releaseX) / 2);
    int tapY = (int)((pressY + releaseY) / 2);

    #if DEEP_DEBUG
      DEBUG_PRINTF("SCREEN_MESSAGES touch: deltaX=%d, deltaY=%d, holdDuration=%lu ms\n",
                  deltaX, deltaY, holdDuration);
    #endif

    //Special case: No messages - any touch returns to clock
    if (messageCount == 0) {
      DEBUG_PRINTLN("No messages - any touch returns to clock");
      changeScreen(SCREEN_CLOCK);
      return;
    }

    //─── « Return button (lower-left, 500ms hold) ──────────────────────────
    if (holdDuration >= 500 &&
        abs(tapX - MSG_RETBTN_CX) <= MSG_RETBTN_PAD &&
        abs(tapY - MSG_RETBTN_CY) <= MSG_RETBTN_PAD) {
      DEBUG_PRINTLN("« Return button held - returning to clock");
      weatherCycleStartTime  = millis();
      calendarCycleStartTime = millis();
      cycleWeatherTurn = true;
      changeScreen(SCREEN_CLOCK);
      return;
    }

    //─── ✕ Clear-history button (lower-right, 500ms hold) ──────────────────
    if (holdDuration >= 500 &&
        abs(tapX - (int)MSG_XBTN_CX) <= MSG_XBTN_PAD &&
        abs(tapY - MSG_XBTN_CY)      <= MSG_XBTN_PAD) {
      DEBUG_PRINTLN("✕ Clear history held on device");
      messageCount        = 0;
      unreadCount         = 0;
      currentHistoryIndex = 0;
      drawMessagesScreen();
      return;
    }

    //─── Tap on ▲ up arrow (next message) ─────────────────────────────────
    if (messageCount > 1) {
      // Up arrow touch zone
      if (tapX >= MSG_ARROW_AX - MSG_ARROW_PAD &&
          tapX <= MSG_ARROW_AX + MSG_ARROW_AW + MSG_ARROW_PAD &&
          tapY >= MSG_UP_ARROW_Y - MSG_ARROW_PAD &&
          tapY <= MSG_UP_ARROW_Y + MSG_ARROW_AH + MSG_ARROW_PAD) {
        currentHistoryIndex++;
        if (currentHistoryIndex >= messageCount) currentHistoryIndex = 0;
        DEBUG_PRINTF("✓ Arrow UP tap - message %d/%d\n", currentHistoryIndex + 1, messageCount);
        drawMessagesScreen();
        return;
      }
      // Down arrow touch zone
      if (tapX >= MSG_ARROW_AX - MSG_ARROW_PAD &&
          tapX <= MSG_ARROW_AX + MSG_ARROW_AW + MSG_ARROW_PAD &&
          tapY >= MSG_DN_ARROW_Y - MSG_ARROW_PAD &&
          tapY <= MSG_DN_ARROW_Y + MSG_ARROW_AH + MSG_ARROW_PAD) {
        currentHistoryIndex--;
        if (currentHistoryIndex < 0) currentHistoryIndex = messageCount - 1;
        DEBUG_PRINTF("✓ Arrow DOWN tap - message %d/%d\n", currentHistoryIndex + 1, messageCount);
        drawMessagesScreen();
        return;
      }
    }

    //─── Anywhere long-press (2s), excluding all control zones ─────────────
    {
      bool inReturnZone = (abs(tapX - MSG_RETBTN_CX) <= MSG_RETBTN_PAD &&
                           abs(tapY - MSG_RETBTN_CY) <= MSG_RETBTN_PAD);
      bool inXZone      = (abs(tapX - (int)MSG_XBTN_CX) <= MSG_XBTN_PAD &&
                           abs(tapY - MSG_XBTN_CY)      <= MSG_XBTN_PAD);
      bool inArrowZone  = (tapX >= MSG_ARROW_AX - MSG_ARROW_PAD &&
                           tapX <= MSG_ARROW_AX + MSG_ARROW_AW + MSG_ARROW_PAD &&
                           tapY >= MSG_UP_ARROW_Y - MSG_ARROW_PAD &&
                           tapY <= MSG_DN_ARROW_Y + MSG_ARROW_AH + MSG_ARROW_PAD);
      if (holdDuration >= 2000 && !inReturnZone && !inXZone && !inArrowZone) {
        DEBUG_PRINTLN("Long press detected - returning to clock");
        weatherCycleStartTime  = millis();
        calendarCycleStartTime = millis();
        cycleWeatherTurn = true;
        changeScreen(SCREEN_CLOCK);
        return;
      }
    }

    //─── Vertical swipe (fallback) ───────────────────────────────────────────
    if (abs(deltaY) > 40 && abs(deltaY) > abs(deltaX)) {
      if (deltaY < 0) {
        //Swipe UP → Next message
        currentHistoryIndex++;
        if (currentHistoryIndex >= messageCount) currentHistoryIndex = 0;
        DEBUG_PRINTF("✓ Swipe UP - message %d/%d\n", currentHistoryIndex + 1, messageCount);
        drawMessagesScreen();
      } else {
        //Swipe DOWN → Previous message
        currentHistoryIndex--;
        if (currentHistoryIndex < 0) currentHistoryIndex = messageCount - 1;
        DEBUG_PRINTF("✓ Swipe DOWN - message %d/%d\n", currentHistoryIndex + 1, messageCount);
        drawMessagesScreen();
      }
      return;
    }

    //Quick tap or small movement → Ignore
    #if DEEP_DEBUG
      DEBUG_PRINTF("Quick tap/small movement (%lu ms, %dpx) - ignoring\n",
                  holdDuration, max(abs(deltaX), abs(deltaY)));
    #endif
    return;

  } else if (currentScreen == SCREEN_ASTRO) {
    //------------------------------------------------------------
    // Astro screen touch:
    //   Night mode dimmed → first touch brightens only
    //   HEADER ROW (y < 58):
    //     Left arrow  zone (x < ASTRO_ARROW_W)  → decrement date
    //     Right arrow zone (x > screenW-ASTRO_ARROW_W) → increment date
    //     Title zone  (center)                  → toggle Sun/Moon page
    //   DATA AREA  (y ≥ 58) → return to Clock
    //------------------------------------------------------------

    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }

    // Use pressX/pressY (where finger first landed) for zone detection –
    // release coords can drift and misfire into the adjacent title zone.
    // Touch zones defined by constants in User_Setup.h
    if (pressY < ASTRO_HDR_H) {
      // --- Header row ---
      if (pressX < ASTRO_ARROW_W) {
        // Left arrow – go back one day
        astroDateOffset--;
        viewedAstroYear = -1;        // force recompute for new date
        ensureViewedAstroData();
        drawAstroScreen();
        lastScreenChange = millis();
      } else if (pressX > (DISPLAY_LONG - ASTRO_ARROW_W)) {
        // Right arrow – go forward one day
        astroDateOffset++;
        viewedAstroYear = -1;        // force recompute for new date
        ensureViewedAstroData();
        drawAstroScreen();
        lastScreenChange = millis();
      } else {
        // Title tap – reset to today
        astroDateOffset = 0;
        viewedAstroYear = -1;
        ensureViewedAstroData();
        drawAstroScreen();
        lastScreenChange = millis();
      }
    } else if (pressY > ASTRO_FOOTER_Y) {  //ASTRO_FOOTER_Y from User_Setup.h
      // --- Footer tap – switch Sun ↔ Moon page ---
      astroShowMoon = !astroShowMoon;
      drawAstroScreen();
      lastScreenChange = millis();
    } else {
      // --- Data area – return to Clock ---
      changeScreen(SCREEN_CLOCK);
    }
    return;

  } else if (currentScreen == SCREEN_CALENDAR) {
    //--- Night mode guard: first touch while dimmed brightens display only ---
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    //--- Calendar navigation touch zones — see CAL_HDR_H, CAL_ARROW_W in User_Setup.h ---
    //  Left arrow  (◄ prev month): x < CAL_ARROW_W,               y < CAL_HDR_H
    //  Right arrow (► next month): x > DISPLAY_LONG-CAL_ARROW_W,  y < CAL_HDR_H
    //  Header label (return to today): centre band,                y < CAL_HDR_H
    //  Anywhere else: dismiss
    if (y < CAL_HDR_H) {
      if (x < CAL_ARROW_W) {
        //Previous month
        calendarViewMonth--;
        if (calendarViewMonth < 0) {
          calendarViewMonth = 11;
          calendarViewYear--;
        }
        DEBUG_PRINTLN("Calendar: previous month");
        displayCalendar();
        lastScreenChange = millis();
      } else if (x > DISPLAY_LONG - CAL_ARROW_W) {
        //Next month
        calendarViewMonth++;
        if (calendarViewMonth > 11) {
          calendarViewMonth = 0;
          calendarViewYear++;
        }
        DEBUG_PRINTLN("Calendar: next month");
        displayCalendar();
        lastScreenChange = millis();
      } else {
        //Tapped the month/year label → jump back to today's month
        struct tm _nowTm;
        if (getLocalTime(&_nowTm)) {
          calendarViewMonth = _nowTm.tm_mon;
          calendarViewYear  = _nowTm.tm_year + 1900;
        }
        DEBUG_PRINTLN("Calendar: return to today");
        displayCalendar();
        lastScreenChange = millis();
      }
      return;  //Do NOT dismiss the calendar screen
    }
    //Touch outside the header → dismiss
    DEBUG_PRINTLN("Calendar: touch outside header - returning to clock");
    changeScreen(SCREEN_CLOCK);

  } else if (currentScreen == SCREEN_WEATHER) {
    //------------------------------------------------------------
    // Weather screen touch:
    //   Night mode dimmed → first touch brightens only
    //   Indicator zone (y > WEATHER_FOOTER_Y) → toggle sub-page
    //   Elsewhere → return to Clock
    //------------------------------------------------------------
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    if (pressY > WEATHER_FOOTER_Y) {
      weatherSubPage = !weatherSubPage;
      displayWeather();
      lastScreenChange = millis();
    } else {
      changeScreen(SCREEN_CLOCK);
    }
    return;

  } else if (currentScreen == SCREEN_ABOUT) {
    //------------------------------------------------------------
    // About screen touch:
    //   Night mode dimmed → first touch brightens only
    //   Indicator zone (y > ABOUT_FOOTER_Y) → toggle sub-page
    //   Elsewhere → return to Clock
    //------------------------------------------------------------
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    if (pressY > ABOUT_FOOTER_Y) {
      // Tap in the indicator zone — switch sub-page
      aboutSubPage = !aboutSubPage;
      drawAboutScreen();
      lastScreenChange = millis();
    } else {
      changeScreen(SCREEN_CLOCK);
    }
    return;

  } else {
    //Other screens - return to clock on tap
    if (nightModeActive && !nightModeWakeActive) {
      nightModeWakeActive  = true;
      nightModeWakeEndTime = millis() + nightModeWakeDuration;
      setBrightness(nightModeWakeBrightness);
      return;
    }
    DEBUG_PRINTLN("\nTouch on feature - returning to clock");
    changeScreen(SCREEN_CLOCK);
  }
}

//=============================================================
// Unified UI Return Stack — function implementations
//
//  The UiReturnState struct and the three globals (uiReturnStack,
//  uiReturnTop, g_textWrapState) are declared in the main .ino so
//  they are visible to all .ino files regardless of compile order.
//
//  uiReturnClear / uiReturnPush / uiReturnPop are internal helpers
//  (static) — only called from within this file.
//
//  uiReturnPushCurrentIfEntering, normalizeGfxState,
//  resetMessageRuntimeState, and uiReturnReturnOr are NOT static
//  so the Arduino IDE generates correct forward declarations for
//  them, allowing MessageEngine.ino (compiled earlier) to call them.
//=============================================================

static void uiReturnClear() {
  uiReturnTop = 0;
}

static bool uiReturnPush(ScreenMode screen, int rotation, uint8_t brightness, bool textWrap) {
  if (uiReturnTop >= UI_RETURN_STACK_MAX) return false;
  uiReturnStack[uiReturnTop++] = {screen, rotation, brightness, textWrap};
  return true;
}

static bool uiReturnPop(UiReturnState &out) {
  if (uiReturnTop == 0) return false;
  out = uiReturnStack[--uiReturnTop];
  return true;
}

//Push current UI state only when entering a modal screen (prevents double-push if a
//message supersedes another message while the stack entry is already in place).
void uiReturnPushCurrentIfEntering(ScreenMode modalScreen) {
  if (currentScreen == modalScreen) return;
  (void)uiReturnPush(currentScreen, currentRotation, actualCurrentBrightness, g_textWrapState);
}

//Reset GFX state to sane defaults between screens.  textWrap=false by default because
//most screens draw measured strings and rely on clipping, not wrapping.
void normalizeGfxState(bool textWrap) {
  g_textWrapState = textWrap;
  gfx->setTextWrap(textWrap);
  gfx->setCursor(0, 0);
  gfx->setTextSize(1);
}

//Clear per-message runtime flags that must not leak when switching away from SCREEN_MESSAGE.
void resetMessageRuntimeState() {
  //scrolling
  scrollOffset = 0;
  lastScrollUpdate = 0;
  currentScrollDirection = "none";
  currentScrollSpeed = 1;

  //flashing
  isFlashing = false;
  flashSwapState = false;
  lastFlashTime = 0;

  //pulsing
  isPulsing = false;
  pulseStartTime = 0;
}

//Return to the previous UI state.  If the stack is empty, fall back to fallbackScreen.
void uiReturnReturnOr(ScreenMode fallbackScreen) {
  UiReturnState st;
  if (uiReturnPop(st)) {
    currentRotation = st.rotation;

    //Switch screen first (draws the target), then re-assert saved brightness / wrap
    changeScreen(st.screen);

    actualCurrentBrightness = st.brightness;
    setBrightness(actualCurrentBrightness);

    normalizeGfxState(st.textWrap);
  } else {
    changeScreen(fallbackScreen);
    normalizeGfxState(false);
  }
}

void changeScreen(ScreenMode newScreen) {
  ScreenMode oldScreen = currentScreen;  //Track previous screen
  currentScreen = newScreen;

  //Start cooldown immediately (blocks any "tail" touch events)
  lastScreenChange = millis();

  lastActivity = millis();  //Reset screensaver

  //Reset weather/calendar auto-cycle timers when navigating away from clock to unrelated screens.
  //Do NOT reset when leaving clock for weather/calendar (auto-cycle is triggering that transition),
  //and do NOT reset the *other* timer when returning from weather/calendar (autoCycleTick manages
  //those timers directly; cross-resetting here was the bug that prevented calendar from ever showing).
  if (oldScreen == SCREEN_CLOCK && newScreen != SCREEN_WEATHER && newScreen != SCREEN_CALENDAR && newScreen != SCREEN_CLOCK) {
    weatherCycleStartTime = millis();
    calendarCycleStartTime = millis();
    cycleWeatherTurn = true;   //restart alternation from weather when returning from an unrelated screen
    #if EXTENDED_DEBUG
      DEBUG_PRINTLN("Cycle timers reset (leaving clock to unrelated screen)");
    #endif
  }

  //Reset timers when returning TO clock from an unrelated screen (not weather/calendar).
  //This ensures a full interval before auto-showing after the user has been on another screen.
  if (newScreen == SCREEN_CLOCK && oldScreen != SCREEN_WEATHER && oldScreen != SCREEN_CALENDAR && oldScreen != SCREEN_CLOCK) {
    weatherCycleStartTime  = millis();
    calendarCycleStartTime = millis();
    cycleWeatherTurn = true;
    #if EXTENDED_DEBUG
      DEBUG_PRINTLN("Cycle timers reset (returning to clock from unrelated screen)");
    #endif
  }

  //Reset timers when manually returning to clock from weather or calendar.
  //If autoCycleTick triggered this return it sets cycleInitiatedReturn=true first,
  //meaning it already set the correct next-turn timers - we must not overwrite them.
  //If cycleInitiatedReturn is false the user navigated there manually, so stale timers
  //must be reset to give a full interval before auto-cycling fires again.
  if (newScreen == SCREEN_CLOCK && (oldScreen == SCREEN_WEATHER || oldScreen == SCREEN_CALENDAR)) {
    if (!cycleInitiatedReturn) {
      weatherCycleStartTime  = millis();
      calendarCycleStartTime = millis();
      cycleWeatherTurn = true;
      #if EXTENDED_DEBUG
        DEBUG_PRINTLN("Cycle timers reset (manual return to clock from weather/calendar)");
      #endif
    }
    cycleInitiatedReturn = false;  //Always consume the flag
  }

  //Deactivate screensaver when changing screens
  if (screensaverActive) {
    deactivateScreensaver();
  }

  int rotIdx = getRotationIndex(currentRotation);
  gfx->setRotation(rotIdx);

  switch (currentScreen) {
    case SCREEN_CLOCK:
      showClock = true;
      if (nightModeActive && !nightModeWakeActive) {
        setBrightness(nightModeBrightness);   //Apply night brightness directly
      } else if (nightModeActive && nightModeWakeActive) {
        setBrightness(nightModeWakeBrightness);
      } else {
        setBrightness(screenBrightness);      //Normal day brightness
      }
      gfx->setRotation(rotIdx);
      drawClock();
      break;

    case SCREEN_MESSAGE:
      //Message screen is drawn by displayMessage()
      break;

    case SCREEN_MESSAGES:
      currentHistoryIndex = messageCount - 1;  //start at newest message
      if (currentHistoryIndex < 0) currentHistoryIndex = 0;
      for (int i = 0; i < messageCount; i++) {
        messages[i].unread = false;
      }
      unreadCount = 0;
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      drawMessagesScreen();
      break;

    case SCREEN_MENU:
      showClock = false;  //important
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      drawMenu();
      break;

    case SCREEN_WEATHER:
      showClock = false;  //important
      weatherSubPage = false;       // always open on page 1
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      displayWeather();
      break;

    case SCREEN_CALENDAR: {
      showClock = false;  //important
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      //Reset view to today's month when freshly opening the calendar
      struct tm _calTm;
      if (getLocalTime(&_calTm)) {
        calendarViewMonth = _calTm.tm_mon;
        calendarViewYear  = _calTm.tm_year + 1900;
      }
      displayCalendar();
      break;
    }

    case SCREEN_ABOUT:
      showClock = false;  //important
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      aboutSubPage = false;         // always open on page 1
      drawAboutScreen();
      break;

    case SCREEN_ASTRO:
      showClock = false;  //important
      setBrightness(scheduledBrightness);
      gfx->setRotation(rotIdx);
      astroShowMoon = false;        // always open on Sun page
      astroDateOffset = 0;          // reset to today when entering the screen
      viewedAstroYear = -1;         // force recompute for today
      displayAstro();
      break;
  }

  switch (newScreen) {
    case SCREEN_CLOCK:
      drawClock();
      break;

    case SCREEN_MENU:
      drawMenu();
      break;

    case SCREEN_MESSAGES:
      //Initialize to show newest message
      currentHistoryIndex = messageCount - 1;
      if (currentHistoryIndex < 0) currentHistoryIndex = 0;
      drawMessagesScreen();
      break;

    case SCREEN_WEATHER:
      displayWeather();
      break;

    case SCREEN_ASTRO:
      displayAstro();
      break;

      //... other cases go here
  }

  //Refresh cooldown AFTER the draw as well
  lastScreenChange = millis();
}

bool getTouchPoint(uint16_t& x, uint16_t& y) {
  uint8_t data[AXS_MAX_TOUCH_NUMBER * 6 + 2] = { 0 };

  const uint8_t read_cmd[11] = {
    0xb5, 0xab, 0xa5, 0x5a, 0x00, 0x00,
    (uint8_t)((AXS_MAX_TOUCH_NUMBER * 6 + 2) >> 8),
    (uint8_t)((AXS_MAX_TOUCH_NUMBER * 6 + 2) & 0xff),
    0x00, 0x00, 0x00
  };

  Wire.beginTransmission(TOUCH_ADDR);
  Wire.write(read_cmd, 11);
  if (Wire.endTransmission() != 0) return false;

  if (Wire.requestFrom(TOUCH_ADDR, sizeof(data)) != sizeof(data)) return false;

  for (int i = 0; i < (int)sizeof(data); i++) {
    data[i] = Wire.read();
  }

  if (data[1] > 0 && data[1] <= AXS_MAX_TOUCH_NUMBER) {
    uint16_t rawX = ((data[2] & 0x0F) << 8) | data[3];
    uint16_t rawY = ((data[4] & 0x0F) << 8) | data[5];

    //Base mapping (known-good for ROT=90 landscape & ROT=270 landscape-flipped; 480x320)
    const int16_t baseW = DISPLAY_LONG;
    const int16_t baseH = DISPLAY_SHORT;

    uint16_t bx = rawY;
    uint16_t by = map(rawX, 0, baseH, baseH, 0);

    if (bx >= baseW) bx = baseW - 1;
    if (by >= baseH) by = baseH - 1;

    //--- Transform base coords -> current screen rotation ---
    //currentRotation is degrees: 0/90/180/270 (see getRotationIndex()).
    uint16_t tx = bx;
    uint16_t ty = by;

    switch (currentRotation) {
      case  90:  //base orientation
        tx = bx;
        ty = by;
        break;

      case 270:  //180° from base (flip both axes)
        tx = (baseW - 1) - bx;
        ty = (baseH - 1) - by;
        break;

      case   0:  //portrait (inverse of rot90 mapping)
        tx = by;
        ty = (baseW - 1) - bx;
        break;

      case 180:  //portrait flipped
        tx = (baseH - 1) - by;
        ty = bx;
        break;

      default:
        //Unknown -> treat as base
        tx = bx;
        ty = by;
        break;
    }

    //Clamp to the *current* gfx bounds (depends on rotation)
    int16_t w = gfx->width();
    int16_t h = gfx->height();
    if (tx >= (uint16_t)w) tx = (w > 0) ? (w - 1) : 0;
    if (ty >= (uint16_t)h) ty = (h > 0) ? (h - 1) : 0;

    x = tx;
    y = ty;
    return true;
  }

  return false;
}
