//=============================================================
// ClockDisplay.ino  —  clock drawing, screensaver, night mode
//=============================================================

void activateScreensaver() {
  if (!screensaverActive) {
    screensaverActive = true;
    savedBrightness = screenBrightness;

    uint8_t newBrightness = screensaverDimValue;
    setBrightness(newBrightness);

    DEBUG_PRINTF("Screensaver activated - dimmed to %d (0-255)\n", newBrightness);
  }
}

void deactivateScreensaver() {
  if (screensaverActive) {
    screensaverActive = false;

    //Restore the correct brightness for the current mode.
    //savedBrightness holds the day brightness (screenBrightness) captured at activation time,
    //but if night mode is active we must restore to the night brightness instead so the screen
    //doesn't suddenly snap to full day brightness mid-night.
    if (nightModeActive && !nightModeWakeActive) {
      setBrightness(nightModeBrightness);
    } else if (nightModeActive && nightModeWakeActive) {
      setBrightness(nightModeWakeBrightness);
    } else {
      setBrightness(savedBrightness);
    }

    //Reset the auto-cycle timers so they don't fire immediately on the same loop iteration.
    //While the screensaver was active, autoCycleTick() was suppressed but the timers kept
    //counting; without this reset the calendar/weather cycle would trigger the instant the
    //screensaver deactivates (on the very same loop pass as the waking touch).
    weatherCycleStartTime  = millis();
    calendarCycleStartTime = millis();

    DEBUG_PRINTLN("Screensaver deactivated - brightness restored, cycle timers reset");
  }
}

void checkScreensaver() {
  //Only check when clock is showing
  if (clockEnabled && currentScreen == SCREEN_CLOCK && screensaverTimeout > 0) {
    if (!screensaverActive && (millis() - lastActivity >= screensaverTimeout)) {
      activateScreensaver();
    }
  } else if (screensaverActive && currentScreen != SCREEN_CLOCK) {
    //Deactivate if not on clock screen
    deactivateScreensaver();
  }
}

void showStartupScreen() {
  gfx->fillScreen(COLOR_BLACK);

  setSmartFont(screenHeaderFont);
  int16_t x1, y1;
  uint16_t w, h;
  getTextBoundsHF("Starting...", 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(COLOR_GREEN);
  gfx->setCursor((DISPLAY_LONG - w) / 2, -y1 + 90 + SCREEN_LAYOUT_SHIFT_Y);
  printHF("Starting...");

  setSmartFont(menuFont);                                       //Device name below
  getTextBoundsHF(deviceName.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(COLOR_WHITE);
  gfx->setCursor((DISPLAY_LONG - w) / 2, DISPLAY_SHORT / 2 - (int16_t)h / 2 - y1 + SCREEN_LAYOUT_SHIFT_Y);
  printHF(deviceName.c_str());

  flushDisplay();
}

void getSunDisplayParts(char* label1, size_t lbl1Len, char* time1, size_t t1Len,
                        char* label2, size_t lbl2Len, char* time2, size_t t2Len) {

  // Helper: format a local-minutes-from-midnight value into a time string
  auto fmtMin = [](char* buf, size_t len, float localMin) {
    while (localMin <    0) localMin += 1440.0f;
    while (localMin >= 1440) localMin -= 1440.0f;
    struct tm t = {};
    t.tm_year = 70; t.tm_mon = 0; t.tm_mday = 1;
    t.tm_hour = (int)(localMin / 60) % 24;
    t.tm_min  = (int)localMin % 60;
    t.tm_sec  = 0;
    strftime(buf, len, DEFAULT_CLOCK_TIME_FORMAT, &t);
  };

  struct tm timeinfo;
  getLocalTime(&timeinfo);
  float nowMin = (float)(timeinfo.tm_hour * 60 + timeinfo.tm_min);

  // --- Use computed data if available ---
  if (cachedAstro.isValid && tomorrowAstro.isValid) {
    float riseMin = cachedAstro.sunriseValid ? cachedAstro.sunriseMin : 99999.0f;
    float setMin  = cachedAstro.sunsetValid  ? cachedAstro.sunsetMin  : -1.0f;

    if (nowMin < riseMin) {
      strlcpy(label1, "Sunrise", lbl1Len); fmtMin(time1, t1Len, cachedAstro.sunriseMin);
      strlcpy(label2, "Sunset",  lbl2Len); fmtMin(time2, t2Len, cachedAstro.sunsetMin);
    } else if (nowMin < setMin) {
      strlcpy(label1, "Sunset",  lbl1Len); fmtMin(time1, t1Len, cachedAstro.sunsetMin);
      strlcpy(label2, "Sunrise", lbl2Len); fmtMin(time2, t2Len, tomorrowAstro.sunriseMin);
    } else {
      strlcpy(label1, "Sunrise", lbl1Len); fmtMin(time1, t1Len, tomorrowAstro.sunriseMin);
      strlcpy(label2, "Sunset",  lbl2Len); fmtMin(time2, t2Len, tomorrowAstro.sunsetMin);
    }
    return;
  }

  // --- Fallback: Open-Meteo data ---
  auto fmtTime = [](char* buf, size_t len, int hour, int minute) {
    struct tm t = {};
    t.tm_year = 70; t.tm_mon = 0; t.tm_mday = 1;
    t.tm_hour = hour; t.tm_min = minute; t.tm_sec = 0;
    strftime(buf, len, DEFAULT_CLOCK_TIME_FORMAT, &t);
  };

  int todayRise = sunriseHour * 60 + sunriseMinute;
  int todaySet  = sunsetHour  * 60 + sunsetMinute;

  if (nowMin < todayRise) {
    strlcpy(label1, "Sunrise", lbl1Len); fmtTime(time1, t1Len, sunriseHour,         sunriseMinute);
    strlcpy(label2, "Sunset",  lbl2Len); fmtTime(time2, t2Len, sunsetHour,          sunsetMinute);
  } else if (nowMin < todaySet) {
    strlcpy(label1, "Sunset",  lbl1Len); fmtTime(time1, t1Len, sunsetHour,          sunsetMinute);
    strlcpy(label2, "Sunrise", lbl2Len); fmtTime(time2, t2Len, tomorrowSunriseHour, tomorrowSunriseMinute);
  } else {
    strlcpy(label1, "Sunrise", lbl1Len); fmtTime(time1, t1Len, tomorrowSunriseHour, tomorrowSunriseMinute);
    strlcpy(label2, "Sunset",  lbl2Len); fmtTime(time2, t2Len, tomorrowSunsetHour,  tomorrowSunsetMinute);
  }
}

void drawSunMoonLines(
    const char* sunLabel1,  const char* sunTime1,
    const char* sunLabel2,  const char* sunTime2,
    const char* moonLabel1, const char* moonTime1,
    const char* moonLabel2, const char* moonTime2,
    int y1, int y2, uint16_t color, int offsetX)
{
  int16_t bx, by; uint16_t tw, th;
  const int16_t screenW = DISPLAY_LONG;
  const int  LBL_GAP  = 10;  // pixels between a label's right edge and its time column
  const int  COL_GAP  = 18;  // pixels between sun time column and moon label column

  // --- 4-column layout -------------------------------------------------
  //  Col 1  |  Col 2  |  Col 3   |  Col 4
  //  Sun    |  Sun    |  Moon    |  Moon
  //  label  |  time   |  label   |  time
  //  LEFT   |  RIGHT  |  LEFT    |  RIGHT
  //  align  |  align  |  align   |  align
  // ---------------------------------------------------------------------
  // Left-aligning labels gives a clean vertical edge for each pair.
  // Right-aligning times ensures colons and digits stack perfectly
  // regardless of whether "6:45 am" or "12:03 pm" is the wider string.
  // All four individual widths are measured and kept in scope so the
  // per-row right-align offsets can be computed at draw time.

  // Col 1 — sun labels (left-aligned; measure both to size the column)
  uint16_t wSL1, wSL2;
  getTextBoundsHF(sunLabel1, 0, 0, &bx, &by, &wSL1, &th);
  getTextBoundsHF(sunLabel2, 0, 0, &bx, &by, &wSL2, &th);
  int sunLblW = (int)max(wSL1, wSL2);

  // Col 2 — sun times (right-aligned; keep individual widths for draw offset)
  uint16_t wST1, wST2;
  getTextBoundsHF(sunTime1, 0, 0, &bx, &by, &wST1, &th);
  getTextBoundsHF(sunTime2, 0, 0, &bx, &by, &wST2, &th);
  int sunTimeW = (int)max(wST1, wST2);

  // Cols 3 & 4 — moon (only present when both labels are non-empty)
  bool hasMoon = (moonLabel1 && moonLabel1[0] != '\0' &&
                  moonLabel2 && moonLabel2[0] != '\0');
  uint16_t wML1 = 0, wML2 = 0, wMT1 = 0, wMT2 = 0;
  int moonLblW = 0, moonTimeW = 0;
  if (hasMoon) {
    getTextBoundsHF(moonLabel1, 0, 0, &bx, &by, &wML1, &th);
    getTextBoundsHF(moonLabel2, 0, 0, &bx, &by, &wML2, &th);
    moonLblW = (int)max(wML1, wML2);

    getTextBoundsHF(moonTime1, 0, 0, &bx, &by, &wMT1, &th);
    getTextBoundsHF(moonTime2, 0, 0, &bx, &by, &wMT2, &th);
    moonTimeW = (int)max(wMT1, wMT2);
  }

  // --- Column X positions ----------------------------------------------
  // totalW is built from column widths; the whole block is centred.
  int totalW    = sunLblW + LBL_GAP + sunTimeW;
  if (hasMoon) totalW += COL_GAP + moonLblW + LBL_GAP + moonTimeW;
  int startX    = (screenW - totalW) / 2 + offsetX;

  // Left edges of each column
  int sunLblX   = startX;
  int sunTimeX  = sunLblX  + sunLblW  + LBL_GAP;   // right edge = sunTimeX + sunTimeW
  int moonLblX  = sunTimeX + sunTimeW + COL_GAP;
  int moonTimeX = moonLblX + moonLblW + LBL_GAP;   // right edge = moonTimeX + moonTimeW

  gfx->setTextColor(color);

  // --- Line 1 ----------------------------------------------------------
  // Col 1: left-align sun label at sunLblX
  gfx->setCursor(sunLblX,  y1);  printHF(sunLabel1);
  // Col 2: right-align sun time — shift left by (colWidth - thisWidth)
  gfx->setCursor(sunTimeX  + sunTimeW  - (int)wST1, y1);  printHF(sunTime1);
  if (hasMoon) {
    // Col 3: left-align moon label at moonLblX
    gfx->setCursor(moonLblX, y1);  printHF(moonLabel1);
    // Col 4: right-align moon time
    gfx->setCursor(moonTimeX + moonTimeW - (int)wMT1, y1);  printHF(moonTime1);
  }

  // --- Line 2 ----------------------------------------------------------
  gfx->setCursor(sunLblX,  y2);  printHF(sunLabel2);
  gfx->setCursor(sunTimeX  + sunTimeW  - (int)wST2, y2);  printHF(sunTime2);
  if (hasMoon) {
    gfx->setCursor(moonLblX, y2);  printHF(moonLabel2);
    gfx->setCursor(moonTimeX + moonTimeW - (int)wMT2, y2);  printHF(moonTime2);
  }
}

void drawClock() {
  //── REENTRY GUARD: blocks double-call from rapid touch ─────
  static bool _inDraw = false;
  if (_inDraw) { return; }
  _inDraw = true;
  struct _DrawGuard { ~_DrawGuard() { _inDraw = false; } } _guard;
  //────────────────────────────────────────────────────────────

  ensureAstroData();   //refresh computed sun/moon data if date changed (cheap when fresh)

  //Use the currently active clock palette.
  //When nightModeActive, always use the night colour profile regardless of whether
  //the screen has been temporarily woken by touch. Wake only affects brightness;
  //colours are determined solely by whether night mode is active.
  bool useNightColors = nightModeActive;
  uint16_t bgColor   = useNightColors ? nightClockBgColor       : clockBgColor;
  uint16_t timeColor = useNightColors ? nightClockTimeColor     : clockTimeColor;
  uint16_t dateColor = useNightColors ? nightClockDateColor     : clockDateColor;
  uint16_t sunColor  = useNightColors ? nightClockSuntimesColor : clockSuntimesColor;

  gfx->fillScreen(bgColor);

  if (!isTimeSynced()) {
    setSmartFont(clockTimeFont);
    int16_t x1, y1;
    uint16_t w, h;
    getTextBoundsHF("Syncing time...", 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(COLOR_YELLOW);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 160 + SCREEN_LAYOUT_SHIFT_Y);
    printHF("Syncing time...");
    flushDisplay();
    return;
  }

  String timeStr = getFormattedTime(clockTimeFormat.c_str());

  // Build date string with Julian day appended — e.g., "Mon Apr 7, 2026   Day 97"
  // Mirrors the format used on the Astro screen (tm_yday is 0-based, so +1 → Day 1 = Jan 1).
  struct tm _tmClk;
  getLocalTime(&_tmClk);
  char _dateBuf[80];
  snprintf(_dateBuf, sizeof(_dateBuf), "%s - Day %d",
           getFormattedTime(clockDateFormat.c_str()).c_str(),
           _tmClk.tm_yday + 1);
  String dateStr = _dateBuf;

  //Calculate vertical positions based on whether sunrise/sunset is enabled
  int timeY, dateY, sunTimesY;

  bool showSunMoon = clockSuntimesEnabled && (sunTimesValid || cachedAstro.isValid);

  if (showSunMoon) {    //With sunrise/sunset: stack time / date / sun line 1 / sun line 2
    timeY     =  90 + SCREEN_LAYOUT_SHIFT_Y;
    dateY     = 145 + SCREEN_LAYOUT_SHIFT_Y;
    sunTimesY = 195 + SCREEN_LAYOUT_SHIFT_Y;    //line 1; line 2 drawn at sunTimesY + lineSpacing below
  } else {              //Without sunrise/sunset: center time and date vertically
    timeY     = 135 + SCREEN_LAYOUT_SHIFT_Y;
    dateY     = 185 + SCREEN_LAYOUT_SHIFT_Y;
  }

  int16_t x1, y1;
  uint16_t w, h;

  //Draw time (Roboto 48pt - LARGE) with pixel shift
  setSmartFont(clockTimeFont);
  getTextBoundsHF(timeStr.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(timeColor);
  int timeX = (DISPLAY_LONG - w) / 2 + clockOffsetX;     //Apply pixel shift X
  gfx->setCursor(timeX, timeY + clockOffsetY);           //Apply pixel shift Y - use timeY from above
  printHF(timeStr.c_str());

  //Draw date (Roboto 16pt) with pixel shift
  setSmartFont(clockDateFont);
  getTextBoundsHF(dateStr.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(dateColor);
  int dateX = (DISPLAY_LONG - w) / 2 + clockOffsetX;     //Apply pixel shift X
  gfx->setCursor(dateX, dateY + clockOffsetY);           //Apply pixel shift Y - use dateY from above
  printHF(dateStr.c_str());

  //Two-line sunrise/sunset + moonrise/moonset display (if enabled)
  if (showSunMoon) {
    setSmartFont(clockSuntimesFont);

    char sunLbl1[16], sunTime1[16], sunLbl2[16], sunTime2[16];
    getSunDisplayParts(sunLbl1, sizeof(sunLbl1), sunTime1, sizeof(sunTime1),
                       sunLbl2, sizeof(sunLbl2), sunTime2, sizeof(sunTime2));

    // Build moon label + time strings (today's values from cachedAstro)
    auto fmtMoonTime = [&](float decHour) -> String {
      float mins = decHour * 60.0f;
      while (mins <    0) mins += 1440.0f;
      while (mins >= 1440) mins -= 1440.0f;
      struct tm mt = {};
      mt.tm_year = 70; mt.tm_mon = 0; mt.tm_mday = 1;
      mt.tm_hour = (int)(mins / 60) % 24;
      mt.tm_min  = (int)mins % 60;
      char buf[16];
      strftime(buf, sizeof(buf), clockTimeFormat.c_str(), &mt);
      return String(buf);
    };
    bool hasMoonrise = (cachedAstro.isValid && cachedAstro.moonriseCode >= 0);
    bool hasMoonset  = (cachedAstro.isValid && cachedAstro.moonsetCode  >= 0);
    String moonLbl1  = hasMoonrise ? "Moonrise" : "";
    String moonTime1 = hasMoonrise ? fmtMoonTime(cachedAstro.moonriseHour) : "";
    String moonLbl2  = hasMoonset  ? "Moonset"  : "";
    String moonTime2 = hasMoonset  ? fmtMoonTime(cachedAstro.moonsetHour)  : "";

    // Compute line spacing from font height
    int16_t x1t, y1t; uint16_t wt, ht;
    getTextBoundsHF("Sunrise", 0, 0, &x1t, &y1t, &wt, &ht);
    int lineSpacing = ht + 6;

    drawSunMoonLines(
      sunLbl1, sunTime1, sunLbl2, sunTime2,
      moonLbl1.c_str(), moonTime1.c_str(), moonLbl2.c_str(), moonTime2.c_str(),
      sunTimesY + clockOffsetY, sunTimesY + lineSpacing + clockOffsetY,
      sunColor, clockOffsetX);
  }

  //Unread messages indicator with pixel shift
  if (unreadCount > 0) {
    setSmartFont(msgNoticeFont);  //Roboto 10pt
    char msgStr[30];
    snprintf(msgStr, sizeof(msgStr), "%d unread message%s", unreadCount, unreadCount == 1 ? "" : "s");
    getTextBoundsHF(msgStr, 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(msgNoticeColor);
    int msgX = (DISPLAY_LONG - w) / 2 + clockOffsetX;   //Apply pixel shift X
    gfx->setCursor(msgX, 270 + SCREEN_LAYOUT_SHIFT_Y + clockOffsetY);  //Apply pixel shift Y
    printHF(msgStr);
  }

  //Instructions (centered) with pixel shift
  // setSmartFont(labelFont);  //Roboto 8pt
  // gfx->setTextColor(labelColor);
  // getTextBoundsHF("Touch for Menu", 0, 0, &x1, &y1, &w, &h);
  // int footerX = (DISPLAY_LONG - w) / 2 + clockOffsetX;   //Apply pixel shift X
  // gfx->setCursor(footerX, 305 + clockOffsetY);  //Apply pixel shift Y
  // printHF("Touch for Menu");

  flushDisplay();
}

void updateClock() {
  static ulong lastClockUpdate = 0;
  static String lastTimeStr = "";

  //Only update/redraw when the clock screen is active
  if (currentScreen != SCREEN_CLOCK || !showClock) {
    return;
  }

  if (millis() - lastClockUpdate >= CLOCK_UPDATE_INTERVAL) {
    String currentTime = getFormattedTime(clockTimeFormat.c_str());

    if (currentTime != lastTimeStr) {
      lastTimeStr = currentTime;
      drawClock();
    }

    lastClockUpdate = millis();
  }
}

bool shouldNightModeBeActive() {
  if (!sunTimesValid || !nightModeEnabled) {
    return false;  //Can't determine without sun times or if disabled
  }

  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return false;  //Can't get time
  }

  int currentMinutes = timeinfo.tm_hour * 60 + timeinfo.tm_min;

  //Calculate sunset time with offset
  int sunsetMinutes = (sunsetHour * 60 + sunsetMinute) + sunsetOffset;

  //Calculate sunrise time with offset
  int sunriseMinutes = (sunriseHour * 60 + sunriseMinute) + sunriseOffset;

  //Handle day wraparound (minutes can go negative or > 1440)
  if (sunsetMinutes  < 0)     sunsetMinutes  += 1440;
  if (sunsetMinutes  >= 1440) sunsetMinutes  -= 1440;
  if (sunriseMinutes < 0)     sunriseMinutes += 1440;
  if (sunriseMinutes >= 1440) sunriseMinutes -= 1440;

  //Night mode is active between sunset and sunrise
  if (sunsetMinutes > sunriseMinutes) {
    //Normal case: sunset before midnight, sunrise after midnight
    //Night mode if current time is after sunset OR before sunrise
    return (currentMinutes >= sunsetMinutes || currentMinutes < sunriseMinutes);
  } else {
    //Edge case: sunset after midnight (rare but possible with large offset)
    //Night mode if current time is between sunset and sunrise
    return (currentMinutes >= sunsetMinutes && currentMinutes < sunriseMinutes);
  }
}

void updateNightMode() {
  if (!nightModeEnabled) return;  //Night mode disabled, do nothing

  //check if a touch-wake period has expired ──────────────────────
  if (nightModeWakeActive && millis() >= nightModeWakeEndTime) {
    nightModeWakeActive = false;
    #if EXTENDED_DEBUG
      DEBUG_PRINTLN("Night mode wake: expired, reverting to night brightness");
    #endif
    //Apply night brightness directly — do NOT write into screenBrightness (that holds day brightness)
    setBrightness(nightModeBrightness);
    if (currentScreen == SCREEN_CLOCK) {
      drawClock();                                //Only redraw if clock is visible
    }
    return;
  }

  ulong now = millis();

  //Only check once per minute to avoid excessive processing
  if (now - lastNightModeCheck < 60000 && lastNightModeCheck != 0) {
    return;
  }
  lastNightModeCheck = now;

  bool shouldBeActive = shouldNightModeBeActive();

  //State change detection
  if (shouldBeActive != nightModeActive) {
    nightModeActive = shouldBeActive;

    if (nightModeActive) {
      //Entering night mode - dim the display
      DEBUG_PRINTLN("Night mode: Activating (dimming display)");
      DEBUG_PRINTF("  Setting brightness to %d\n", nightModeBrightness);

      //Apply night brightness directly — do NOT overwrite screenBrightness,
      //which holds the day-time brightness we need to restore on exit.
      setBrightness(nightModeBrightness);

      //Stop pulsing effect if active (would conflict with night mode)
      if (isPulsing) {
        isPulsing = false;
      }

    } else {
      //Exiting night mode - restore the day brightness (screenBrightness was never overwritten)
      DEBUG_PRINTLN("Night mode: Deactivating (restoring brightness)");
      DEBUG_PRINTF("  Setting brightness to %d\n", screenBrightness);

      setBrightness(screenBrightness);
    }

    //Force clock update to show new brightness
    if (currentScreen == SCREEN_CLOCK) {
      drawClock();
    }
  }
}
