#!/usr/bin/env python3
"""
MultiDisplay HTTP Test Suite
=============================
Runs against a live device.  Edit DEVICE_IP before running.

Usage:
    pip install requests
    python test_multidisplay.py [--ip 192.168.1.x] [--group GROUP]

Groups: endpoints, messages, effects, priority, profiles, clockconfig,
        control, schedules, nightmode, edge
"""

import argparse
import json
import sys
import time
import requests
from typing import Any

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────
DEVICE_IP   = "192.168.1.71"        # <── change this
TIMEOUT     = 15                    # seconds per request
PAUSE       = 0.5                   # seconds between requests (be polite)

# ─────────────────────────────────────────────
# TEST RUNNER
# ─────────────────────────────────────────────
passed = failed = skipped = 0
results: list[dict] = []

def run(name: str, fn, group: str = ""):
    global passed, failed
    try:
        fn()
        passed += 1
        results.append({"name": name, "group": group, "status": "PASS"})
        print(f"  ✓  {name}")
    except AssertionError as e:
        failed += 1
        results.append({"name": name, "group": group, "status": "FAIL", "detail": str(e)})
        print(f"  ✗  {name}")
        print(f"       {e}")
    except Exception as e:
        failed += 1
        results.append({"name": name, "group": group, "status": "ERROR", "detail": str(e)})
        print(f"  !  {name}")
        print(f"       {e}")
    finally:
        time.sleep(PAUSE)

def base(path: str = "") -> str:
    return f"http://{DEVICE_IP}{path}"

def get(path: str, **kw) -> requests.Response:
    return requests.get(base(path), timeout=TIMEOUT, **kw)

def post(path: str, **kw) -> requests.Response:
    return requests.post(base(path), timeout=TIMEOUT, **kw)

def post_json(path: str, payload: dict, **kw) -> requests.Response:
    return requests.post(
        base(path),
        data=json.dumps(payload),
        headers={"Content-Type": "application/json"},
        timeout=TIMEOUT,
        **kw
    )

def assert_ok(r: requests.Response):
    assert r.status_code == 200, f"Expected 200, got {r.status_code}"

def assert_json(r: requests.Response) -> dict:
    assert_ok(r)
    ct = r.headers.get("Content-Type", "")
    assert "json" in ct.lower(), f"Expected JSON content-type, got '{ct}'"
    return r.json()

def assert_field(d: dict, key: str, expected: Any = None):
    assert key in d, f"Missing field '{key}' in response: {d}"
    if expected is not None:
        assert d[key] == expected, f"Field '{key}': expected {expected!r}, got {d[key]!r}"

def clear_device():
    """Return device to a known clean state."""
    get("/clear")
    time.sleep(PAUSE)

# ─────────────────────────────────────────────
# GROUP: ENDPOINTS  (basic reachability)
# ─────────────────────────────────────────────
def test_endpoints():
    print("\n── Endpoints ─────────────────────────────────────────")

    def reach(path):
        r = get(path, allow_redirects=True)
        assert r.status_code in (200, 303, 302), \
            f"GET {path} → {r.status_code}"

    for ep in ["/", "/status", "/status.json", "/time", "/clock",
               "/weather", "/calendar", "/clockconfig", "/schedules",
               "/control", "/logs"]:
        run(f"GET {ep} reachable", lambda p=ep: reach(p), "endpoints")

    def status_json_fields():
        r = get("/status.json")
        d = assert_json(r)
        for field in ["deviceName", "deviceID", "messageCount",
                      "clockEnabled", "uptime", "freeHeap"]:
            assert_field(d, field)

    run("GET /status.json – required fields present",
        status_json_fields, "endpoints")

    def time_format():
        r = get("/time")
        assert_ok(r)
        body = r.text.strip()
        assert len(body) > 0, "Empty /time response"

    run("GET /time – non-empty response", time_format, "endpoints")

# ─────────────────────────────────────────────
# GROUP: MESSAGES
# ─────────────────────────────────────────────
def test_messages():
    print("\n── Messages ──────────────────────────────────────────")
    clear_device()

    # Basic JSON POST
    def basic_json_post():
        r = post_json("/message", {"text": "Test basic"})
        assert_ok(r)

    run("POST /message JSON – basic text", basic_json_post, "messages")

    # GET with text param
    def get_message():
        r = get("/message", params={"text": "GET message test"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("GET /message?text=... – accepted", get_message, "messages")

    # /msg alias
    def msg_alias():
        r = get("/msg", params={"text": "alias test", "bgcolor": "blue",
                                "textcolor": "white"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("GET /msg alias – accepted", msg_alias, "messages")

    # All standard display params
    def all_params():
        r = post_json("/message", {
            "text":         "All params",
            "bgcolor":      "#001122",
            "textcolor":    "#FFFFFF",
            "font":         5,
            "rotation":     270,
            "halign":       "center",
            "valign":       "middle",
            "brightness":   200,
            "wrap":         True,
            "expirationtime": 10
        })
        assert_ok(r)

    run("POST /message JSON – all display params", all_params, "messages")

    # Named colors
    def named_colors():
        r = post_json("/message", {
            "text": "Named colors",
            "bgcolor": "navy",
            "textcolor": "yellow"
        })
        assert_ok(r)

    run("POST /message JSON – named colors", named_colors, "messages")

    # Font boundaries
    for font in [1, 5, 10]:
        def font_test(f=font):
            r = post_json("/message", {"text": f"Font {f}", "font": f})
            assert_ok(r)
        run(f"POST /message JSON – font={font}", font_test, "messages")

    # Rotation values
    for rot in [0, 90, 180, 270]:
        def rot_test(r_=rot):
            r = post_json("/message", {"text": f"Rot {r_}", "rotation": r_})
            assert_ok(r)
        run(f"POST /message JSON – rotation={rot}", rot_test, "messages")

    # Alignment combinations
    for halign in ["left", "center", "right"]:
        for valign in ["top", "middle", "bottom"]:
            def align_test(h=halign, v=valign):
                r = post_json("/message", {
                    "text":   f"{h}/{v}",
                    "halign": h,
                    "valign": v
                })
                assert_ok(r)
            run(f"POST /message – align {halign}/{valign}", align_test, "messages")

    # Expiration = 0 (no expiration)
    def no_expire():
        r = post_json("/message", {"text": "No expire", "expirationtime": 0})
        assert_ok(r)

    run("POST /message JSON – expirationtime=0", no_expire, "messages")

    # /clear endpoint
    def clear_ep():
        r = get("/clear")
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("GET /clear – accepted", clear_ep, "messages")

    # Scroll directions
    for direction in ["left", "right", "up", "down", "none"]:
        def scroll_test(d=direction):
            r = post_json("/message", {
                "text":      "Scrolling text for testing purposes",
                "scrolldir": d,
                "scrollspeed": 3
            })
            assert_ok(r)
            time.sleep(0.5)
            get("/clear")
        run(f"POST /message – scrolldir={direction}", scroll_test, "messages")

    clear_device()

# ─────────────────────────────────────────────
# GROUP: EFFECTS
# ─────────────────────────────────────────────
def test_effects():
    print("\n── Effects ───────────────────────────────────────────")
    clear_device()

    def flash_effect():
        r = post_json("/message", {
            "text":          "FLASH TEST",
            "bgcolor":       "red",
            "textcolor":     "white",
            "flash":         True,
            "flashinterval": 500
        })
        assert_ok(r)
        time.sleep(2)
        get("/clear")

    run("POST /message – flash=true, flashinterval=500", flash_effect, "effects")

    def pulse_effect():
        r = post_json("/message", {
            "text":          "PULSE TEST",
            "pulse":         True,
            "pulseduration": 2000
        })
        assert_ok(r)
        time.sleep(2)
        get("/clear")

    run("POST /message – pulse=true, pulseduration=2000", pulse_effect, "effects")

    def flash_boundary_interval():
        # flashinterval min=500 per getJSON_ULong
        r = post_json("/message", {
            "text":          "Fast flash",
            "flash":         True,
            "flashinterval": 200   # below min; should be clamped or ignored
        })
        assert_ok(r)
        get("/clear")

    run("POST /message – flashinterval below min (200ms)", flash_boundary_interval, "effects")

    def scroll_speed_boundary():
        for spd in [1, 5, 9]:
            r = post_json("/message", {
                "text":        "Speed test " * 5,
                "scrolldir":   "left",
                "scrollspeed": spd
            })
            assert_ok(r)
            time.sleep(0.5)
        get("/clear")

    run("POST /message – scrollspeed boundary 1/5/9", scroll_speed_boundary, "effects")

    clear_device()

# ─────────────────────────────────────────────
# GROUP: PRIORITY
# ─────────────────────────────────────────────
def test_priority():
    print("\n── Priority ──────────────────────────────────────────")
    clear_device()

    def high_priority_basic():
        r = post_json("/message", {
            "text":     "HIGH PRIORITY",
            "bgcolor":  "red",
            "textcolor":"white",
            "priority": "high"
        })
        assert_ok(r)

    run("POST /message – priority=high", high_priority_basic, "priority")

    def normal_while_high_active():
        # High priority is already active from previous test.
        # A normal message should either queue or be blocked (both return 200).
        r = post_json("/message", {"text": "Normal during high", "priority": "normal"})
        assert_ok(r)

    run("POST /message – normal while high active (queued/blocked)", normal_while_high_active, "priority")

    def multiple_high_priority():
        # Send a second high priority message – should be accepted and alternated.
        r = post_json("/message", {
            "text":     "HIGH #2",
            "bgcolor":  "orange",
            "textcolor":"black",
            "priority": "high"
        })
        assert_ok(r)
        time.sleep(1)

    run("POST /message – second high priority message", multiple_high_priority, "priority")

    def expiring_high():
        r = post_json("/message", {
            "text":           "Expiring high",
            "priority":       "high",
            "expirationtime": 2
        })
        assert_ok(r)
        time.sleep(3)  # Wait for expiry

    run("POST /message – high priority with expiration", expiring_high, "priority")

    clear_device()
    time.sleep(0.5)

    def invalid_priority_falls_back():
        # "urgent" is not a valid priority; sketch normalizes to "normal"
        r = post_json("/message", {"text": "Bad priority", "priority": "urgent"})
        assert_ok(r)

    run("POST /message – invalid priority value normalized to normal", invalid_priority_falls_back, "priority")

    clear_device()

# ─────────────────────────────────────────────
# GROUP: PROFILES
# ─────────────────────────────────────────────
def test_profiles():
    print("\n── Message Profiles ──────────────────────────────────")
    clear_device()

    SLOT = 5  # use slot 5 for all tests (unlikely to conflict with user data)

    def save_profile():
        r = post_json("/message", {
            "bgcolor":    "navy",
            "textcolor":  "white",
            "font":       6,
            "halign":     "center",
            "valign":     "middle",
            "saveprofile": SLOT
        })
        assert_ok(r)

    run("POST /message – saveprofile only (no text)", save_profile, "profiles")

    def retrieve_profile():
        r = post_json("/message", {
            "text":           "From saved profile",
            "retrieveprofile": SLOT
        })
        assert_ok(r)

    run("POST /message – retrieveprofile", retrieve_profile, "profiles")

    def retrieve_and_override():
        r = post_json("/message", {
            "text":           "Override bgcolor",
            "retrieveprofile": SLOT,
            "bgcolor":        "#FF0000"   # Override the navy from saved profile
        })
        assert_ok(r)

    run("POST /message – retrieveprofile + override one field", retrieve_and_override, "profiles")

    def save_and_display():
        r = post_json("/message", {
            "text":      "Save and display",
            "bgcolor":   "green",
            "textcolor": "black",
            "saveprofile": SLOT
        })
        assert_ok(r)

    run("POST /message – save + display in one call", save_and_display, "profiles")

    def clear_profile():
        r = post_json("/message", {"clearprofile": SLOT})
        d = assert_json(r)
        assert "cleared" in d.get("message", "").lower() or \
               d.get("profile") == SLOT, f"Unexpected clear response: {d}"

    run("POST /message – clearprofile", clear_profile, "profiles")

    def retrieve_cleared_profile():
        # After clearing, retrieveprofile should silently ignore the missing slot
        r = post_json("/message", {
            "text":           "After clear",
            "retrieveprofile": SLOT
        })
        assert_ok(r)

    run("POST /message – retrieveprofile after clearing (graceful fallback)", retrieve_cleared_profile, "profiles")

    def invalid_profile_slot():
        r = post_json("/message", {"saveprofile": 99})  # MAX_MSG_PROFILES is 10
        # Should respond 200 with an error or just ignore; must not crash
        assert r.status_code in (200, 400), f"Got {r.status_code}"

    run("POST /message – saveprofile out of range (slot 99)", invalid_profile_slot, "profiles")

    clear_device()

# ─────────────────────────────────────────────
# GROUP: CLOCK CONFIG
# ─────────────────────────────────────────────
def test_clockconfig():
    print("\n── Clock Config ──────────────────────────────────────")

    def json_brightness():
        r = post_json("/clockconfig", {"brightness": 200})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – brightness", json_brightness, "clockconfig")

    def json_time_format():
        r = post_json("/clockconfig", {"timeformat": "%H:%M"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – timeformat", json_time_format, "clockconfig")

    def json_date_format():
        r = post_json("/clockconfig", {"dateformat": "%A, %B %e"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – dateformat", json_date_format, "clockconfig")

    def json_night_mode_enable():
        r = post_json("/clockconfig", {"nightmodeenable": True})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – nightmodeenable=true", json_night_mode_enable, "clockconfig")

    def json_night_mode_disable():
        r = post_json("/clockconfig", {"nightmodeenable": False})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – nightmodeenable=false", json_night_mode_disable, "clockconfig")

    # Offset boundary tests – these catch the secondary bug where the JSON path
    # still clamped at ±120.  With the fix applied, 240 and -240 should be accepted.
    for offset_val, label in [(0, "zero"), (120, "+120"), (-120, "-120"),
                               (240, "+240"), (-240, "-240"), (360, "+360"), (-360, "-360")]:
        def offset_test(v=offset_val, l=label):
            r = post_json("/clockconfig", {"sunsetoffset": v})
            assert r.status_code in (200, 303), \
                f"sunsetoffset={v} ({l}): got {r.status_code}"
        run(f"POST /clockconfig JSON – sunsetoffset={label}", offset_test, "clockconfig")

    for offset_val, label in [(240, "+240"), (-240, "-240")]:
        def sunrise_offset_test(v=offset_val, l=label):
            r = post_json("/clockconfig", {"sunriseoffset": v})
            assert r.status_code in (200, 303), \
                f"sunriseoffset={v} ({l}): got {r.status_code}"
        run(f"POST /clockconfig JSON – sunriseoffset={label}", sunrise_offset_test, "clockconfig")

    def json_night_colors():
        r = post_json("/clockconfig", {
            "nighttimecolor":     "#FF4500",
            "nightdatecolor":     "#FFA07A",
            "nightbgcolor":       "#000000",
            "nightsuntimescolor": "#FF6347"
        })
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – night color palette", json_night_colors, "clockconfig")

    def json_night_brightness():
        r = post_json("/clockconfig", {
            "nightbrightness": 30,
            "daybrightness":   200
        })
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – night+day brightness", json_night_brightness, "clockconfig")

    def json_screensaver():
        r = post_json("/clockconfig", {
            "screensavertimeout": 60000,
            "screensaverdim":     0.3
        })
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – screensaver settings", json_screensaver, "clockconfig")

    def json_suntimes_toggle():
        r = post_json("/clockconfig", {"clksuntimesenabled": True})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – clksuntimesenabled=true", json_suntimes_toggle, "clockconfig")

    def restore_defaults():
        r = post_json("/clockconfig", {
            "brightness":     255,
            "timeformat":     "%l:%M %P",
            "sunsetoffset":   0,
            "sunriseoffset":  0,
            "nightmodeenable": False
        })
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /clockconfig JSON – restore working defaults", restore_defaults, "clockconfig")

# ─────────────────────────────────────────────
# GROUP: CONTROL
# ─────────────────────────────────────────────
def test_control():
    print("\n── Control Endpoint ──────────────────────────────────")

    # GET-based controls (non-destructive)
    for param, val in [
        ("clockdark",      "true"),
        ("clockdark",      "false"),
        ("clockdark",      "toggle"),
        ("weatherdark",    "true"),
        ("weatherdark",    "false"),
        ("calendardark",   "true"),
        ("calendardark",   "false"),
        ("menudark",       "true"),
        ("menudark",       "false"),
        ("historydark",    "true"),
        ("historydark",    "false"),
        ("pixelshift",     "true"),
        ("pixelshift",     "false"),
        ("touchenable",    "true"),
        ("weathercycle",   "false"),
        ("calendarcycle",  "false"),
        ("clearhistory",   "true"),
    ]:
        def get_control(p=param, v=val):
            r = get("/control", params={p: v}, allow_redirects=False)
            assert r.status_code in (200, 303), \
                f"GET /control?{p}={v} → {r.status_code}"
        run(f"GET /control?{param}={val}", get_control, "control")

    # Re-enable cycles so the device is usable after tests
    get("/control", params={"weathercycle": "true"})
    get("/control", params={"touchenable": "true"})

    # JSON POST controls
    def json_dark_modes():
        r = post_json("/control", {
            "clockdark":    True,
            "weatherdark":  True,
            "calendardark": True,
            "menudark":     True,
            "historydark":  True
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – set all dark modes", json_dark_modes, "control")

    def json_light_modes():
        r = post_json("/control", {
            "clockdark":    False,
            "weatherdark":  False,
            "calendardark": False,
            "menudark":     False,
            "historydark":  False
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – clear all dark modes", json_light_modes, "control")

    def json_toggle():
        r = post_json("/control", {"clockdark": "toggle"})
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – clockdark toggle", json_toggle, "control")

    def json_clear_history():
        r = post_json("/control", {"clearhistory": True})
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – clearhistory", json_clear_history, "control")

    def json_cycle_timings():
        r = post_json("/control", {
            "wxshowdur":   15,
            "wxcycleint":  120,
            "calshowdur":  10,
            "calcycleint": 180
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – cycle timing parameters", json_cycle_timings, "control")

    def json_pulse_range():
        r = post_json("/control", {"pulsemaxbri": 200, "pulseminbri": 20})
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – pulse brightness range", json_pulse_range, "control")

    def json_normal_override():
        r = post_json("/control", {
            "normoverride":    True,
            "normoverridedur": 5
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – normal override settings", json_normal_override, "control")

    def json_hp_alternate():
        r = post_json("/control", {"hpalternate": 10})
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – hpalternate interval", json_hp_alternate, "control")

    def json_clock_reset_colors():
        r = post_json("/control", {"clockresetcolors": "dark"})
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /control JSON – clockresetcolors=dark", json_clock_reset_colors, "control")

    def json_invalid_bool():
        r = post_json("/control", {"clockdark": "banana"})
        assert r.status_code == 400, \
            f"Expected 400 for invalid bool value, got {r.status_code}"

    run("POST /control JSON – invalid boolean value → 400", json_invalid_bool, "control")

    def json_no_changes():
        r = post_json("/control", {})
        d = assert_json(r)
        # Should return 200 with "No changes" or similar
        assert_field(d, "message")

    run("POST /control JSON – empty payload (no changes)", json_no_changes, "control")

    # Screen navigation
    for screen in ["clock", "weather", "calendar"]:
        def nav(s=screen):
            r = get(f"/{s}", allow_redirects=True)
            assert r.status_code in (200, 303), f"GET /{s} → {r.status_code}"
        run(f"GET /{screen} – navigate to screen", nav, "control")

# ─────────────────────────────────────────────
# GROUP: SCHEDULES
# ─────────────────────────────────────────────
def test_schedules():
    print("\n── Schedules ─────────────────────────────────────────")

    # Use high schedule indices so we don't clobber real user schedules.
    # Assumes MAX_SCHEDULES >= 6.
    IDX_A, IDX_B = 5, 6

    def single_schedule_json():
        r = post_json("/schedules", {
            "index":   IDX_A,
            "enabled": True,
            "mode":    "absolute",
            "hour":    23,
            "minute":  59,
            "action":  "brightness",
            "brightness": 50
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /schedules JSON – single absolute schedule", single_schedule_json, "schedules")

    def single_relative_schedule():
        r = post_json("/schedules", {
            "index":     IDX_A,
            "enabled":   True,
            "mode":      "relative",
            "reference": "sunset",
            "offset":    30,
            "action":    "brightness",
            "brightness": 80
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /schedules JSON – single relative (sunset+30) schedule", single_relative_schedule, "schedules")

    def array_schedules():
        r = post_json("/schedules", {
            "schedules": [
                {
                    "index":   IDX_A,
                    "enabled": True,
                    "mode":    "absolute",
                    "hour":    6,
                    "minute":  0,
                    "action":  "clock"
                },
                {
                    "index":   IDX_B,
                    "enabled": True,
                    "mode":    "relative",
                    "reference": "sunrise",
                    "offset":  -15,
                    "action":  "brightness",
                    "brightness": 255
                }
            ]
        })
        d = assert_json(r)
        assert_field(d, "message")
        assert d.get("count") == 2, f"Expected count=2, got {d.get('count')}"

    run("POST /schedules JSON – array of 2 schedules", array_schedules, "schedules")

    def schedule_with_message():
        r = post_json("/schedules", {
            "index":   IDX_A,
            "enabled": True,
            "mode":    "absolute",
            "hour":    7,
            "minute":  0,
            "action":  "message",
            "message": "Good morning!"
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /schedules JSON – schedule with action=message", schedule_with_message, "schedules")

    def schedule_disable():
        r = post_json("/schedules", {
            "index":   IDX_A,
            "enabled": False,
            "mode":    "absolute",
            "hour":    7,
            "minute":  0,
            "action":  "brightness",
            "brightness": 200
        })
        d = assert_json(r)
        assert_field(d, "message")

    run("POST /schedules JSON – disable a schedule", schedule_disable, "schedules")

    def invalid_index():
        r = post_json("/schedules", {
            "index":   999,
            "enabled": True,
            "action":  "clock"
        })
        assert r.status_code in (400, 200), \
            f"Expected 400 or graceful 200, got {r.status_code}"

    run("POST /schedules JSON – invalid index (999)", invalid_index, "schedules")

    def missing_index():
        r = post_json("/schedules", {"enabled": True, "action": "clock"})
        assert r.status_code == 400, \
            f"Expected 400 for missing index, got {r.status_code}"

    run("POST /schedules JSON – missing index → 400", missing_index, "schedules")

    def invalid_json():
        r = post(
            "/schedules",
            data="not valid json",
            headers={"Content-Type": "application/json"}
        )
        assert r.status_code == 400, \
            f"Expected 400 for invalid JSON, got {r.status_code}"

    run("POST /schedules JSON – malformed JSON → 400", invalid_json, "schedules")

# ─────────────────────────────────────────────
# GROUP: NIGHT MODE (requires ENABLE_TEST_MODE)
# ─────────────────────────────────────────────
def test_nightmode():
    print("\n── Night Mode (requires ENABLE_TEST_MODE in sketch) ─")
    get("/clock")  #make sure that testing starts on the clock screen
    time.sleep(0.5)

    def test_inject_available():
        r = get("/testinject")
        assert r.status_code != 404, \
            "GET /testinject returned 404 – recompile with ENABLE_TEST_MODE defined"

    try:
        test_inject_available()
    except AssertionError:
        print("  ⚠  /testinject not available – night mode tests skipped.")
        print("     Add #define ENABLE_TEST_MODE to User_Setup.h and recompile.")
        return

    def inject(payload: dict) -> dict:
        r = post_json("/testinject", payload)
        assert r.status_code == 200, f"/testinject returned {r.status_code}: {r.text}"
        return r.json()

    def get_state() -> dict:
        r = get("/testinject")
        assert r.status_code == 200
        return r.json()

    # ── Enable night mode ──────────────────────────────────
    post_json("/clockconfig", {"nightmodeenable": True, "nightbrightness": 30, "daybrightness": 200})
    time.sleep(0.5)

    # ── Night active: set sunset in the past, sunrise in the future ──
    def night_should_be_active():
        # Current time is, say, 20:00.  Set sunset=17:00 + 0 offset, sunrise=07:00.
        # Night should be active.
        d = inject({
            "sunsethour":    17,
            "sunsetminute":  0,
            "sunrisehour":   7,
            "sunriseminute": 0,
            "forcenightcheck": True
        })
        state = get_state()
        assert state.get("nightModeActive") is True, \
            f"Expected nightModeActive=true, got {state}"

    run("Night mode – active when current time is after sunset", night_should_be_active, "nightmode")

    # ── Day active: set sunrise in the past, sunset in the future ──
    def day_should_be_active():
        d = inject({
            "sunsethour":    20,
            "sunsetminute":  0,
            "sunrisehour":   6,
            "sunriseminute": 0,
            "forcenightcheck": True
        })
        state = get_state()
        assert state.get("nightModeActive") is False, \
            f"Expected nightModeActive=false, got {state}"

    run("Night mode – inactive when current time is after sunrise", day_should_be_active, "nightmode")

    # ── Sunset offset: +240 min shifts effective sunset forward ──
    def sunset_offset_positive():
        post_json("/clockconfig", {"sunsetoffset": 240})
        time.sleep(0.3)
        # Set real sunset to 17:00.  With +240 min offset, effective sunset = 21:00.
        # If current time is 20:00, night should NOT yet be active.
        d = inject({
            "sunsethour":    17,
            "sunsetminute":  0,
            "sunrisehour":   7,
            "sunriseminute": 0,
            "forcenightcheck": True
        })
        state = get_state()
        # Whether this is day or night depends on actual current device time.
        # We just check that the state field is a bool and the inject didn't error.
        assert "nightModeActive" in state, \
            f"nightModeActive missing from state: {state}"

    run("Night mode – sunset offset +240 accepted and applied", sunset_offset_positive, "nightmode")

    # ── Negative offset: sunrise -60 min moves wake-up earlier ──
    def sunrise_offset_negative():
        post_json("/clockconfig", {"sunriseoffset": -60, "sunsetoffset": 0})
        time.sleep(0.3)
        d = inject({
            "sunsethour":    19,
            "sunsetminute":  0,
            "sunrisehour":   7,
            "sunriseminute": 0,
            "forcenightcheck": True
        })
        state = get_state()
        assert "nightModeActive" in state, \
            f"nightModeActive missing from state: {state}"

    run("Night mode – sunrise offset -60 accepted and applied", sunrise_offset_negative, "nightmode")

    # ── Wraparound: large positive offset that crosses midnight ──
    def wraparound_case():
        post_json("/clockconfig", {"sunsetoffset": 360, "sunriseoffset": 0})
        time.sleep(0.3)
        # Sunset 23:00 + 360 min = 05:00 next day (wraps to 300 minutes from midnight)
        d = inject({
            "sunsethour":    23,
            "sunsetminute":  0,
            "sunrisehour":   7,
            "sunriseminute": 0,
            "forcenightcheck": True
        })
        state = get_state()
        assert "nightModeActive" in state, \
            f"nightModeActive missing in wraparound test: {state}"

    run("Night mode – offset wraparound past midnight handled", wraparound_case, "nightmode")

    # ── Restore sane defaults ──
    post_json("/clockconfig", {
        "sunsetoffset":  0,
        "sunriseoffset": 0,
        "nightmodeenable": False
    })

# ─────────────────────────────────────────────
# GROUP: EDGE CASES
# ─────────────────────────────────────────────
def test_edge_cases():
    print("\n── Edge Cases ────────────────────────────────────────")
    clear_device()

    def empty_message():
        # Empty text – should return 200 but not change screen
        r = post_json("/message", {"text": ""})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /message – empty text string", empty_message, "edge")

    def very_long_message():
        r = post_json("/message", {
            "text": "A" * 512,
            "wrap": True,
            "font": 1
        })
        assert_ok(r)
        get("/clear")

    run("POST /message – 512-char message (wrap=true)", very_long_message, "edge")

    def special_chars():
        r = post_json("/message", {"text": "Hello & <World> \"test\" '123'"})
        assert_ok(r)
        get("/clear")

    run("POST /message – special characters in text", special_chars, "edge")

    def unicode_text():
        r = post_json("/message", {"text": "Café ☕ résumé"})
        assert_ok(r)
        get("/clear")

    run("POST /message – Unicode characters in text", unicode_text, "edge")

    def invalid_json_body():
        r = post(
            "/message",
            data="{not valid json",
            headers={"Content-Type": "application/json"}
        )
        # Sketch falls back to treating body as plain text; should not 500
        assert r.status_code in (200, 303, 400), \
            f"Unexpected status {r.status_code} for invalid JSON"

    run("POST /message – malformed JSON body (fallback behavior)", invalid_json_body, "edge")

    def out_of_range_font():
        # font=0 and font=11 are both out of the 1-10 range
        for bad_font in [0, 11]:
            r = post_json("/message", {"text": "Bad font", "font": bad_font})
            # getJSON_Int clamps or rejects; response must be 200 (clamped) or 400
            assert r.status_code in (200, 400), \
                f"font={bad_font} → unexpected status {r.status_code}"

    run("POST /message – font out of range (0 and 11)", out_of_range_font, "edge")

    def out_of_range_brightness():
        # Brightness 300 > 255; sketch uses constrain(val, 0, 255)
        r = post_json("/message", {"text": "Bright", "brightness": 300})
        assert_ok(r)
        get("/clear")

    run("POST /message – brightness=300 (above max, should clamp)", out_of_range_brightness, "edge")

    def invalid_rotation():
        # 45 is not a valid rotation; sketch accepts it via toInt() unchecked
        r = post_json("/message", {"text": "Odd rotation", "rotation": 45})
        assert_ok(r)
        get("/clear")

    run("POST /message – rotation=45 (non-standard value)", invalid_rotation, "edge")

    def missing_text_with_priority():
        # No text, just priority – should not crash
        r = post_json("/message", {"priority": "high"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("POST /message – no text, only priority field", missing_text_with_priority, "edge")

    def get_with_no_text():
        r = get("/message")
        assert r.status_code in (200, 303), f"Got {r.status_code}"

    run("GET /message – no text param", get_with_no_text, "edge")

    def bad_color_hex():
        # Unparseable color – parseColor should return a fallback, not crash
        r = post_json("/message", {"text": "Bad color", "bgcolor": "#ZZZZZZ"})
        assert r.status_code in (200, 303), f"Got {r.status_code}"
        get("/clear")

    run("POST /message – unparseable color hex (#ZZZZZZ)", bad_color_hex, "edge")

    def clockconfig_invalid_json():
        r = post(
            "/clockconfig",
            data="{broken",
            headers={"Content-Type": "application/json"}
        )
        assert r.status_code in (200, 303, 400), \
            f"clockconfig invalid JSON → {r.status_code}"

    run("POST /clockconfig – malformed JSON body", clockconfig_invalid_json, "edge")

    clear_device()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
GROUP_MAP = {
    "endpoints":  test_endpoints,
    "messages":   test_messages,
    "effects":    test_effects,
    "priority":   test_priority,
    "profiles":   test_profiles,
    "clockconfig":test_clockconfig,
    "control":    test_control,
    "schedules":  test_schedules,
    "nightmode":  test_nightmode,
    "edge":       test_edge_cases,
}

def main():
    global DEVICE_IP
    parser = argparse.ArgumentParser(description="MultiDisplay HTTP test suite")
    parser.add_argument("--ip",    default=DEVICE_IP,
                        help="Device IP address (default: %(default)s)")
    parser.add_argument("--group", default="",
                        help="Run only this group (omit for all). "
                             "Choices: " + ", ".join(GROUP_MAP))
    args = parser.parse_args()


    DEVICE_IP = args.ip

    print(f"\n{'='*55}")
    print(f" MultiDisplay Test Suite  –  {DEVICE_IP}")
    print(f"{'='*55}")

    try:
        # Quick connectivity check
        get("/time")
    except requests.exceptions.ConnectionError:
        print(f"\n✗  Cannot reach {DEVICE_IP} – is the device on the network?\n")
        sys.exit(1)

    if args.group:
        if args.group not in GROUP_MAP:
            print(f"Unknown group '{args.group}'. Choices: {', '.join(GROUP_MAP)}")
            sys.exit(1)
        GROUP_MAP[args.group]()
    else:
        for fn in GROUP_MAP.values():
            fn()

    print(f"\n{'='*55}")
    print(f" Results: {passed} passed, {failed} failed, {skipped} skipped")
    print(f"{'='*55}\n")

    if failed:
        print("Failed tests:")
        for r in results:
            if r["status"] != "PASS":
                print(f"  [{r['status']}] {r['name']}")
                if "detail" in r:
                    print(f"         {r['detail']}")
        print()
        sys.exit(1)


if __name__ == "__main__":
    main()
