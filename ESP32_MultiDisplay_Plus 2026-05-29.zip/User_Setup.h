/*
 User_Setup.h - PHASE 2: Enhanced Message System

  Hardware pin definitions and all configuration defaults
   SUPPORTED BOARD:
    - JC3248W535C_I_Y ESP32-S3 device (Shenzhen Jingcai Intelligent) 3.5" 320x480 capacitive touch display with AXS15231B driver chip
    - Arduino IDE settings: board = ESP32 Dev Module, 16MB Flash size, custom partition scheme "partitions.csv"
*/

#ifndef USER_SETUP_H
#define USER_SETUP_H

#include "Colors.h"  //For COLOR_ constants
#include <Arduino.h>
#include <time.h>    //For time_t (used in Message struct)

//=============================================================
//Display Pin Definitions (QSPI)
//=============================================================
#define QSPI_CS   45
#define QSPI_SCK  47
#define QSPI_D0   21
#define QSPI_D1   48
#define QSPI_D2   40
#define QSPI_D3   39
#define GFX_BL    1    //Backlight

//=============================================================
//Display Dimensions
//  DISPLAY_LONG  = the longer (landscape) dimension in pixels
//  DISPLAY_SHORT = the shorter (portrait) dimension in pixels
//  Used everywhere instead of hard-coded 480 / 320.
//=============================================================
#define DISPLAY_LONG  480
#define DISPLAY_SHORT 320

//=============================================================
//Touch Pin Definitions (I2C)
//=============================================================
#define TOUCH_ADDR            0x3B
#define TOUCH_SDA             4
#define TOUCH_SCL             8
#define TOUCH_I2C_CLOCK       400000
#define TOUCH_RST_PIN         12
#define TOUCH_INT_PIN         11
#define AXS_MAX_TOUCH_NUMBER  1

//=============================================================
//RobotoFonts.h Map (Arduino_GFX format only)
//=============================================================
//Font Code | Size  | Font Object
//----------|-------|---------------------------
//   6      |  6pt  | Roboto_Regular6pt8b
//   8      |  8pt  | Roboto_Regular8pt8b
//  10      | 10pt  | Roboto_Regular10pt8b
//  12      | 12pt  | Roboto_Regular12pt8b   ← Menu text
//  14      | 14pt  | Roboto_Regular14pt8b
//  16      | 16pt  | Roboto_Regular16pt8b   ← Date, messages
//  18      | 18pt  | Roboto_Regular18pt8b
//  20      | 20pt  | Roboto_Regular20pt8b
//  22      | 22pt  | Roboto_Regular22pt8b
//  24      | 24pt  | Roboto_Regular24pt8b
//  26      | 26pt  | Roboto_Regular26pt8b
//  28      | 28pt  | Roboto_Regular28pt8b
//  30      | 30pt  | Roboto_Regular30pt8b   ← Screen titles
//  32      | 32pt  | Roboto_Regular32pt8b
//  34      | 34pt  | Roboto_Regular34pt8b
//  36      | 36pt  | Roboto_Regular36pt8b
//  38      | 38pt  | Roboto_Regular38pt8b
//  40      | 40pt  | Roboto_Regular40pt8b
//  42      | 42pt  | Roboto_Regular42pt8b
//  44      | 44pt  | Roboto_Regular44pt8b
//  46      | 46pt  | Roboto_Regular46pt8b
//  48      | 48pt  | Roboto_Regular48pt8b   ← Clock time (LARGE)
//=============================================================
//Colors.h defined colors
//=============================================================
/*
  COLOR_BLACK
  COLOR_WHITE
  COLOR_OFF_WHITE
  COLOR_RED
  COLOR_GREEN
  COLOR_DARK_GREEN
  COLOR_BLUE
  COLOR_CYAN
  COLOR_YELLOW
  COLOR_MAGENTA
  COLOR_ORANGE
  COLOR_PURPLE
  COLOR_PINK
  COLOR_BROWN
  COLOR_LIGHTGRAY
  COLOR_GRAY
  COLOR_DARKGRAY
  COLOR_CHARCOAL
  COLOR_GRAY10 through COLOR_GRAY90  (10%–90% gray in 10% steps)
*/

//*****************************************************************************************************************
//                          User settings for COMPILE-TIME configuration constants
//*****************************************************************************************************************
#define EXTENDED_DEBUG      false   //true = add some debugging info to the serial/web log output
#define DEEP_DEBUG          false   //true = add even more debugging info to the serial/web log output
#define SCREEN_DEBUG        false   //true = short test times for weather/calendar screen cycles

#define ENABLE_TEST_MODE    false   //true = enable testing code; false = disable testing code
#define ENABLE_WEB_LOGGING  true    //true = enable web logging
#define ENABLE_ARDUINO_OTA  true    //true = enable OTA uploads of firmware to devices

#define SCREEN_LAYOUT_SHIFT_Y 10    //Vertical layout nudge; set positive/negative values to move most fixed UI elements down/up together

constexpr size_t        MAX_MESSAGES                      = 50;     //Maximum number of messages to store
constexpr int           MESSAGE_HISTORY_MAX_AGE_HOURS     = 24;     //Default max age (hours) for message history purging — used as the initial value for the runtime maxMsgAge variable (persisted in NVRAM). Set to 0 to disable purging by default.
constexpr int           LOG_BUFFER_SIZE                   = 100;    //Maximum number of *web* log entries
constexpr int           MAX_SCHEDULES                     = 10;     //Maximum number of scheduled actions
constexpr int           MAX_MSG_PROFILES                  = 10;     //Maximum number of Message attribute profiles 0-9
constexpr ulong         CLOCK_UPDATE_INTERVAL             = 1000;   //Clock update rate in milliseconds
constexpr bool          TEMP_CELSIUS                      = false;  //true=°C, false=°F
constexpr bool          TEMP_ACTUAL                       = true;   //true=actual temp, false=apparent (feels-like)

//*****************************************************************************************************************

constexpr int           GLOBAL_ROTATION                   = 270;    //Landscape, USB-C port on left
constexpr bool          DEFAULT_CLOCK_DARK_MODE           = true;
constexpr bool          DEFAULT_CALENDAR_DARK_MODE        = true;
constexpr bool          DEFAULT_WEATHER_DARK_MODE         = true;
constexpr bool          DEFAULT_MENU_DARK_MODE            = true;
constexpr bool          DEFAULT_HISTORY_DARK_MODE         = true;
constexpr bool          DEFAULT_ASTRO_DARK_MODE           = true;
constexpr bool          DEFAULT_TEMP_ALTERNATION_MODE     = true;   //true=alternate between actual and apparent temperature
constexpr bool          DEFAULT_AP_ALTERNATION_MODE       = true;   //false=always show local air pressureavg; true=alternate local ↔ open-meteo

//=============================================================
//Clock Display Defaults
//=============================================================
constexpr int           DEFAULT_TIME_FONT                 = 48;              //Roboto 48pt
constexpr int           DEFAULT_DATE_FONT                 = 16;              //Roboto 16pt
constexpr int           DEFAULT_MSG_NOTICE_FONT           = 10;              //Roboto 10pt
constexpr int           DEFAULT_LABEL_FONT                = 8;               //Roboto 8pt; also used in Weather screen
constexpr uint16_t      DEFAULT_CLOCK_TIME_COLOR          = COLOR_WHITE;
constexpr uint16_t      DEFAULT_CLOCK_TIME_COLOR_L        = COLOR_BLACK;
constexpr uint16_t      DEFAULT_CLOCK_DATE_COLOR          = COLOR_WHITE;
constexpr uint16_t      DEFAULT_CLOCK_DATE_COLOR_L        = COLOR_BLACK;
constexpr uint16_t      DEFAULT_CLOCK_BG_COLOR            = COLOR_BLACK;
constexpr uint16_t      DEFAULT_CLOCK_BG_COLOR_L          = COLOR_WHITE;
constexpr uint16_t      DEFAULT_MSG_NOTICE_COLOR          = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_LABEL_COLOR               = COLOR_GRAY;
constexpr const char*   DEFAULT_CLOCK_TIME_FORMAT         = "%l:%M %P";      //Default: "9:45 am"
constexpr const char*   DEFAULT_CLOCK_DATE_FORMAT         = "%A  %Y-%m-%d";  //Default: "Sunday  2025-11-23"
constexpr int           DEFAULT_CLOCK_ROTATION            = GLOBAL_ROTATION;
constexpr bool          DEFAULT_CLOCK_ENABLED             = true;
constexpr int           DEFAULT_SUNTIMES_FONT             = 12;              //Sun times on Clock & Weather screens; Roboto 12pt
constexpr uint16_t      DEFAULT_SUNTIMES_COLOR            = COLOR_YELLOW;    //Sunrise/sunset text
constexpr uint16_t      DEFAULT_SUNTIMES_COLOR_L          = COLOR_BLACK;     //Sunrise/sunset text
constexpr bool          DEFAULT_SUNTIMES_ENABLED          = true;            //Toggle sunrise/sunset display on clock
constexpr uint8_t       DEFAULT_SCREEN_BRIGHTNESS         = 140;             //0-255; applies to clock, calendar, weather, and all other screens (outside Night Mode)
constexpr uint8_t       DEFAULT_SCREENSAVER_DIM           = 25;              //Screensaver brightness (0-255)
constexpr bool          DEFAULT_WEATHER_CYCLE_ENABLED     = true;            //Auto-cycle to weather screen
constexpr bool          DEFAULT_CALENDAR_CYCLE_ENABLED    = true;            //Auto-cycle to calendar screen
#if EXTENDED_DEBUG
  constexpr ulong       DEFAULT_SCREENSAVER_TIMEOUT       = 30000;           //30 seconds (ms)
#else
  constexpr ulong       DEFAULT_SCREENSAVER_TIMEOUT       = 300000;          //5 minutes = 300000ms
#endif

//=============================================================
//Menu Display Defaults
//=============================================================
constexpr int           DEFAULT_MENU_FONT                 = 12;              //Roboto 12pt
constexpr int           DEFAULT_MENU_BG_COLOR             = COLOR_BLACK;
constexpr int           DEFAULT_MENU_BG_COLOR_L           = COLOR_WHITE;

//=============================================================
//Message Display Defaults
//=============================================================
constexpr const char*   DEFAULT_MESSAGE                   = "== Ready for messages ==";
constexpr uint16_t      DEFAULT_BG_COLOR                  = COLOR_WHITE;
constexpr uint16_t      DEFAULT_TEXT_COLOR                = COLOR_BLACK;
constexpr int           DEFAULT_FONT                      = 20;              //Roboto 20pt
constexpr int           DEFAULT_ROTATION                  = GLOBAL_ROTATION;
constexpr const char*   DEFAULT_H_ALIGN                   = "center";
constexpr const char*   DEFAULT_V_ALIGN                   = "middle";
constexpr uint8_t       DEFAULT_BRIGHTNESS                = 255;             //Full brightness = 255
constexpr int           DEFAULT_EXPIRATION_TIME           = 0;               //SECONDS until message expiration (0 = no expiration)
constexpr const char*   DEFAULT_PRIORITY                  = "normal";        //Choices are "normal" or "high"
constexpr bool          DEFAULT_WRAP                      = true;            //Text wrapping
constexpr const char*   DEFAULT_SCROLL_DIRECTION          = "none";          //"" or "none", "left", "right", "up", "down"
constexpr uint8_t       DEFAULT_SCROLL_SPEED              = 3;               //1 (slow) to 10 (fast)
constexpr bool          DEFAULT_FLASH                     = false;           //Flashing effect
constexpr ulong         DEFAULT_FLASH_INTERVAL            = 1000;            //Flash interval (ms)
constexpr bool          DEFAULT_PULSE                     = false;           //Pulsing brightness
constexpr ulong         DEFAULT_PULSE_DURATION            = 2000;            //Pulse duration (ms)
constexpr uint8_t       DEFAULT_PULSE_MAX_BRIGHTNESS      = 255;             //Pulse maximum brightness
constexpr uint8_t       DEFAULT_PULSE_MIN_BRIGHTNESS      = 25;              //Pulse minimum brightness

//High priority message settings
constexpr int           MAX_HIGH_PRIORITY_MESSAGES        = 10;              //Max number of high-priority messages
constexpr int           MAX_NORMAL_QUEUED_MESSAGES        = 10;              //Max # of queued normal messages (if high-priority is active)
constexpr int           DEFAULT_HIGH_PRIORITY_ALTERNATE   = 10;              //SECONDS between alternating high-priority messages

//Normal override settings (allow normal msg to temporarily interrupt high priority msg)
constexpr bool          DEFAULT_NORMAL_OVERRIDE_ENABLED   = true;           //Allow normal override; usually no need to change
constexpr int           DEFAULT_NORMAL_OVERRIDE_DURATION  = 30;             //SECONDS for how long normal msg overrides high priority msg

//Message History
constexpr uint16_t      DEFAULT_HISTORY_TEXT_FONT         = 12;              //Roboto 12pt
constexpr uint16_t      DEFAULT_HISTORY_BG_COLOR          = COLOR_BLACK;
constexpr uint16_t      DEFAULT_HISTORY_BG_COLOR_L        = COLOR_WHITE;
constexpr uint16_t      DEFAULT_HISTORY_TITLE_COLOR       = COLOR_WHITE;
constexpr uint16_t      DEFAULT_HISTORY_TITLE_COLOR_L     = COLOR_BLACK;
constexpr uint16_t      DEFAULT_HISTORY_MSG_COLOR         = COLOR_WHITE;
constexpr uint16_t      DEFAULT_HISTORY_MSG_COLOR_L       = COLOR_BLACK;
constexpr uint16_t      DEFAULT_TIMESTAMP_COLOR           = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_TIMESTAMP_COLOR_L         = COLOR_BLUE;
constexpr uint16_t      DEFAULT_MSG_NUM_COLOR             = COLOR_CYAN;
constexpr uint16_t      DEFAULT_MSG_NUM_COLOR_L           = COLOR_RED;
constexpr uint16_t      DEFAULT_BAR_COLOR                 = COLOR_CYAN;
constexpr uint16_t      DEFAULT_BAR_COLOR_L               = COLOR_RED;

//=============================================================
//Weather Settings
//=============================================================

//── MQTT client — subscribes to data broadcast from the Elecrow broker ──────────
// Set MQTT_BROKER_IP in secrets.h (e.g. "192.168.1.55").
// Leave undefined or set to "" to disable the MQTT client entirely.
#ifndef MQTT_BROKER_IP
  #define MQTT_BROKER_IP  ""   // override in secrets.h
#endif
#define MQTT_BROKER_PORT 1883

// PubSubClient receive buffer — must be large enough for the biggest
// history chunk (~25 readings × ~65 bytes + JSON wrapper ≈ 1700 bytes).
// Defined here so the preprocessor sees it before PubSubClient.h is pulled in.
#define MQTT_MAX_PACKET_SIZE  2048
#define MQTT_TOPIC_WEATHER   "multidisplay/weather"
#define MQTT_TOPIC_PRESSURE  "multidisplay/pressure"
#define MQTT_TOPIC_TIME      "multidisplay/time"

//── Altitude fallback (metres, sea-level pressure correction) ───────────────────
#ifndef ALTITUDE
#  define ALTITUDE  "0"
#endif

//── Pressure history buffer & forecast ──────────────────────────────────────────
#define PRESSURE_BUF_SIZE         97      // 24 h at 15-min intervals
#define PRESSURE_TREND_3H_S       (3UL  * 3600UL)  // 3-hour  trend window (seconds)
#define PRESSURE_TREND_24H_S      (24UL * 3600UL)  // 24-hour trend window (seconds)
#define PRESSURE_TREND_THRESHOLD  1.6f    // hPa change over window → rising/falling
#define PRESSURE_BUF_FILE         "/pressure_buf.bin"  // LittleFS save path

// Defined here so the Arduino IDE auto-prototype generator sees these
// types before it emits forward declarations for functions that use them.
struct PressureReading {
    uint32_t ts;       // UTC epoch seconds (from time()) — survives reboots
    float    hpa;      // raw station pressure (hPa)
    float    windDeg;  // wind direction, degrees (NAN = unavailable)
    float    temp;     // local outdoor temperature (NAN = unavailable)
    float    humidity; // local outdoor humidity % (NAN = unavailable)
};

struct LocalForecast {
    char summary[200];  // base forecast + humidity/wind modifiers
    char confidence[8]; // "High", "Medium", or "Low"
};
constexpr ulong         WEATHER_FETCH_INTERVAL            = 600000;          //10 minutes (600,000 ms)
constexpr ulong         LOCAL_PRESSURE_FETCH_INTERVAL     = 300000UL;        //Default HTTP backup poll interval (5 min); extended automatically when MQTT is active
constexpr ulong         LOCAL_PRESSURE_FETCH_INTERVAL_MQTT= 1800000UL;       //Extended HTTP poll interval used while MQTT is delivering pressure (30 min)
constexpr ulong         LOCAL_PRESSURE_STALE_MS           = 30UL * 60UL * 1000UL;
constexpr ulong         MQTT_RECONNECT_INTERVAL_MS        = 30000UL;  //Retry connect every 30 s
constexpr ulong         MQTT_WEATHER_STALE_MS             = 15UL * 60UL * 1000UL; //Use HTTP if no MQTT weather in 15 min
constexpr uint8_t       DEFAULT_WEATHER_FONT              = 16;              //Roboto 16pt
constexpr uint16_t      DEFAULT_WEATHER_FORECAST_COLOR    = COLOR_WHITE;
constexpr uint16_t      DEFAULT_WEATHER_FORECAST_COLOR_L  = COLOR_BLACK;
constexpr uint16_t      DEFAULT_WEATHER_BG_COLOR          = COLOR_BLACK;
constexpr uint16_t      DEFAULT_WEATHER_BG_COLOR_L        = COLOR_WHITE;
constexpr uint8_t       DEFAULT_WEATHER_TITLE_FONT        = 12;              //Roboto 12pt
constexpr uint16_t      DEFAULT_WEATHER_TITLE_COLOR       = COLOR_GREEN;
constexpr uint16_t      DEFAULT_WEATHER_TITLE_COLOR_L     = COLOR_RED;
constexpr uint8_t       DEFAULT_WEATHER_TEMP_FONT         = 20;              //Roboto 20pt
constexpr uint16_t      DEFAULT_WEATHER_TEMP_COLOR        = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_WEATHER_TEMP_COLOR_L      = COLOR_BLUE;
constexpr uint8_t       DEFAULT_WEATHER_HUMID_FONT        = 20;              //Roboto 20pt
constexpr uint16_t      DEFAULT_WEATHER_HUMID_COLOR       = COLOR_CYAN;
constexpr uint16_t      DEFAULT_WEATHER_HUMID_COLOR_L     = COLOR_MAGENTA;
constexpr uint8_t       DEFAULT_AIR_PRESSURE_FONT         = 20;              //Roboto 20pt
constexpr uint8_t       DEFAULT_AIR_PRESSURE_UNITS_FONT   = 16;              //Roboto 16pt
constexpr uint16_t      DEFAULT_AIR_PRESSURE_COLOR        = COLOR_ORANGE;
constexpr uint16_t      DEFAULT_AIR_PRESSURE_COLOR_L      = COLOR_BROWN;
constexpr uint16_t      DEFAULT_WEATHER_SUN_INFO_COLOR    = COLOR_WHITE;
constexpr uint16_t      DEFAULT_WEATHER_SUN_INFO_COLOR_L  = COLOR_BLACK;
constexpr uint16_t      DEFAULT_WEATHER_FOOTER_COLOR      = COLOR_LIGHTGRAY;
constexpr uint16_t      DEFAULT_WEATHER_FOOTER_COLOR_L    = COLOR_DARKGRAY;
constexpr int           DEFAULT_TEMP_ALTERNATION_TIME     = 5;               //SECONDS between temperature alternations
constexpr int           DEFAULT_AP_ALTERNATION_TIME       = 5;               //SECONDS between air pressure alternations

#if SCREEN_DEBUG
  constexpr ulong       WEATHER_SHOW_DURATION             = 10UL * 1000UL;           //10s
  constexpr ulong       WEATHER_CYCLE_INTERVAL            = 1UL  * 60UL * 1000UL;    //1 min
  constexpr ulong       CALENDAR_SHOW_DURATION            = 10UL * 1000UL;           //10s
  constexpr ulong       CALENDAR_CYCLE_INTERVAL           = 1UL  * 60UL * 1000UL;    //1 min
#else
  constexpr ulong       WEATHER_SHOW_DURATION             = 20UL * 1000UL;           //20s
  constexpr ulong       WEATHER_CYCLE_INTERVAL            = 5UL  * 60UL * 1000UL;    //5 min
  constexpr ulong       CALENDAR_SHOW_DURATION            = 15UL * 1000UL;           //15s
  constexpr ulong       CALENDAR_CYCLE_INTERVAL           = 5UL  * 60UL * 1000UL;    //5 min
#endif

//=============================================================
//Astro (Sun & Moon data) Settings
//=============================================================
constexpr uint8_t       DEFAULT_ASTRO_HEADER_FONT         = 20;              //Also for arrows
constexpr uint8_t       DEFAULT_ASTRO_TEXT_FONT           = 10;              //For rows, subtitle, footer, phase name
constexpr uint16_t      DEFAULT_ASTRO_BG_COLOR            = COLOR_BLACK;
constexpr uint16_t      DEFAULT_ASTRO_BG_COLOR_L          = COLOR_WHITE;
constexpr uint16_t      DEFAULT_ASTRO_SUN_HEADER_COLOR    = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_ASTRO_SUN_HEADER_COLOR_L  = COLOR_ORANGE;
constexpr uint16_t      DEFAULT_ASTRO_MOON_HEADER_COLOR   = COLOR_CYAN;
constexpr uint16_t      DEFAULT_ASTRO_MOON_HEADER_COLOR_L = COLOR_BLUE;
constexpr uint16_t      DEFAULT_ASTRO_LABEL_COLOR         = COLOR_WHITE;
constexpr uint16_t      DEFAULT_ASTRO_LABEL_COLOR_L       = COLOR_BLACK;
constexpr uint16_t      DEFAULT_ASTRO_VALUE_COLOR         = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_ASTRO_VALUE_COLOR_L       = COLOR_BLUE;
constexpr uint16_t      DEFAULT_ASTRO_DIM_TEXT_COLOR      = COLOR_GRAY;
constexpr uint16_t      DEFAULT_ASTRO_DIM_TEXT_COLOR_L    = COLOR_LIGHTGRAY;

//=============================================================
//Night Mode Settings
//=============================================================
constexpr bool          DEFAULT_NIGHTMODE_ENABLED         = true;            //Enable auto-dim at night
constexpr uint8_t       DEFAULT_NIGHTMODE_BRIGHTNESS      = 25;              //Night brightness quiescent state (0-255)
constexpr uint8_t       DEFAULT_NIGHTMODE_WAKE_BRIGHTNESS = 100;             //Brightness when display is touched during Night Mode (0-255)
constexpr ulong         DEFAULT_NIGHTMODE_WAKE_DURATION   = 60000;           //1 minute (ms) - touch wakes display at night

//Night-mode clock color profile (applied when nightModeActive && !nightModeWakeActive)
constexpr uint16_t      DEFAULT_NIGHT_TIME_COLOR          = COLOR_RED;       //Night time text color
constexpr uint16_t      DEFAULT_NIGHT_DATE_COLOR          = COLOR_RED;       //Night date text color
constexpr uint16_t      DEFAULT_NIGHT_BG_COLOR            = COLOR_BLACK;     //Night background color
constexpr uint16_t      DEFAULT_NIGHT_SUNTIMES_COLOR      = COLOR_ORANGE;    //Night suntimes text color
constexpr int           DEFAULT_SUNSET_OFFSET             = 0;               //Minutes (+after/-before sunset)
constexpr int           DEFAULT_SUNRISE_OFFSET            = 0;               //Minutes (+after/-before sunrise)

//=============================================================
//Calendar, Weather, About Settings
//=============================================================
constexpr uint8_t       DEFAULT_SCREEN_HEADER_FONT        = 20;              //Roboto 20pt
constexpr uint8_t       DEFAULT_CALENDAR_DAY_FONT         = 10;              //Day numbers (Roboto 10pt)
constexpr uint16_t      DEFAULT_CALENDAR_DAY_COLOR        = COLOR_WHITE;
constexpr uint16_t      DEFAULT_CALENDAR_DAY_COLOR_L      = COLOR_BLACK;
constexpr uint16_t      DEFAULT_CALENDAR_TEXT_COLOR       = COLOR_DARKGRAY;
constexpr uint16_t      DEFAULT_CALENDAR_TEXT_COLOR_L     = COLOR_LIGHTGRAY;
constexpr uint16_t      DEFAULT_CALENDAR_HI_LIGHT_COLOR   = COLOR_CYAN;
constexpr uint16_t      DEFAULT_CALENDAR_HI_LIGHT_COLOR_L = COLOR_GREEN;
constexpr uint16_t      DEFAULT_CALENDAR_BG_COLOR         = COLOR_BLACK;
constexpr uint16_t      DEFAULT_CALENDAR_BG_COLOR_L       = COLOR_WHITE;
constexpr uint16_t      DEFAULT_CALENDAR_TODAY_COLOR      = COLOR_BLACK;      //Highlight color for today
constexpr uint16_t      DEFAULT_CALENDAR_TODAY_COLOR_L    = COLOR_BLACK;      //Highlight color for today
constexpr uint16_t      DEFAULT_CALENDAR_DAYNAME_COLOR    = COLOR_YELLOW;
constexpr uint16_t      DEFAULT_CALENDAR_DAYNAME_COLOR_L  = COLOR_ORANGE;

//=============================================================
//Pixel Shifting Settings (Burn-in Mitigation)
//=============================================================
constexpr bool          DEFAULT_PIXEL_SHIFT_ENABLED       = true;            //Enable pixel shifting
constexpr bool          DEFAULT_TOUCH_ENABLED             = true;            //Enable touch interface
constexpr ulong         DEFAULT_PIXEL_SHIFT_INTERVAL      = 300000;          //5 minutes (300,000 ms) - recommended for LCD
constexpr int           DEFAULT_PIXEL_SHIFT_RANGE         = 10;              //±10 pixels - recommended for LCD
/*For OLED displays, consider these values instead:
constexpr ulong         DEFAULT_PIXEL_SHIFT_INTERVAL      = 120000;          //2 minutes (120,000 ms)
constexpr int           DEFAULT_PIXEL_SHIFT_RANGE         = 15;              //±15 pixels
*/

//=============================================================
//Persistence Settings (NVS Flash Storage)
//=============================================================
constexpr const char*   PREFERENCES_NAMESPACE             = "ClockDisplay";  //Non-volatile storage (NVS) namespace for settings

//=============================================================
// UI Layout Constants — keep draw and touch coordinates in sync
//=============================================================

// ── MENU ──────────────────────────────────────────────────────
//  2-column, 3-row layout
//  Col 1  x=10..229   Col 2  x=250..469   BtnH=85  gaps=10
//  Vertically centred in 320px: 3 rows × 85h + 2 gaps × 10 = 275px → top margin 15px
#define MENU_BTN_X0           10                  // left column x
#define MENU_BTN_X1           250                 // right column x
#define MENU_BTN_W            220                 // button width
#define MENU_BTN_H            85                  // button height
#define MENU_BTN_ROW0         (15  + SCREEN_LAYOUT_SHIFT_Y)  // top row y
#define MENU_BTN_ROW1         (110 + SCREEN_LAYOUT_SHIFT_Y)  // middle row y
#define MENU_BTN_ROW2         (205 + SCREEN_LAYOUT_SHIFT_Y)  // bottom row y

// ── MESSAGES HISTORY ──────────────────────────────────────────
// Right-edge arrow/button column
#define MSG_ARROW_AW          18                  // arrow bounding-box width (px)
#define MSG_ARROW_AH          14                  // arrow bounding-box height (px)
#define MSG_ARROW_AX          (DISPLAY_LONG - 24) // left edge of arrow bbox
// Arrow Y positions (top of bounding box)
#define MSG_UP_ARROW_Y        80                  // up arrow top
#define MSG_DN_ARROW_Y        205                 // down arrow top
// Touch zone padding around each arrow bbox
#define MSG_ARROW_PAD         15                  // px of touch padding around arrow bbox
// ✕ clear button — lower-right corner
#define MSG_XBTN_CX           (DISPLAY_LONG - 22) // horiz centre
#define MSG_XBTN_CY           298                 // vert centre (lower-right corner)
#define MSG_XBTN_R            12                  // circle radius
#define MSG_XBTN_PAD          20                  // touch padding
// « return button — lower-left corner
#define MSG_RETBTN_CX         22                  // horiz centre
#define MSG_RETBTN_CY         298                 // vert centre (lower-left corner)
#define MSG_RETBTN_R          12                  // circle radius
#define MSG_RETBTN_PAD        20                  // touch padding

// ── ASTRO ─────────────────────────────────────────────────────
#define ASTRO_HDR_H           58                  // header row height (arrows + title)
#define ASTRO_ARROW_W         90                  // horizontal touch zone width each side
#define ASTRO_FOOTER_Y        (295 + SCREEN_LAYOUT_SHIFT_Y)  // y above which is data, below is footer tap
#define ABOUT_FOOTER_Y        285                             // y threshold: below = indicator zone tap (no SHIFT — fixed near screen bottom)
#define WEATHER_FOOTER_Y      308                             // y threshold: below = weather page indicator zone tap

// ── ASTRO arrow draw coords (mirror calendar left/right style) ──
// Left ◄ : tip at (16, 28), base at x=36, top=16, bot=40
#define ASTRO_LARROW_TIP_X    16
#define ASTRO_LARROW_TIP_Y    (28 + SCREEN_LAYOUT_SHIFT_Y)
#define ASTRO_LARROW_BASE_X   36
#define ASTRO_LARROW_BASE_T   (16 + SCREEN_LAYOUT_SHIFT_Y)
#define ASTRO_LARROW_BASE_B   (40 + SCREEN_LAYOUT_SHIFT_Y)

// ── CALENDAR ──────────────────────────────────────────────────
#define CAL_HDR_H             55                  // header row height
#define CAL_ARROW_W           60                  // horizontal touch zone width each side
// Arrow draw coords (left ◄ tip, right ► tip) — matches existing fillTriangle calls
#define CAL_LARROW_TIP_X      16
#define CAL_LARROW_TIP_Y      (25 + SCREEN_LAYOUT_SHIFT_Y)
#define CAL_LARROW_BASE_X     36
#define CAL_LARROW_BASE_T     (13 + SCREEN_LAYOUT_SHIFT_Y)   // base top y
#define CAL_LARROW_BASE_B     (37 + SCREEN_LAYOUT_SHIFT_Y)   // base bottom y
#define CAL_RARROW_TIP_X      (DISPLAY_LONG - 16)
#define CAL_RARROW_TIP_Y      (25 + SCREEN_LAYOUT_SHIFT_Y)
#define CAL_RARROW_BASE_X     (DISPLAY_LONG - 36)
#define CAL_RARROW_BASE_T     (13 + SCREEN_LAYOUT_SHIFT_Y)
#define CAL_RARROW_BASE_B     (37 + SCREEN_LAYOUT_SHIFT_Y)

//=============================================================
//Message Profile Structure - stores message attributes (not text)
//=============================================================
struct MsgProfile {
  bool     saved          = false;
  uint16_t bgColor        = DEFAULT_BG_COLOR;
  uint16_t textColor      = DEFAULT_TEXT_COLOR;
  int8_t   font           = DEFAULT_FONT;
  int16_t  rotation       = DEFAULT_ROTATION;
  String   hAlign         = DEFAULT_H_ALIGN;
  String   vAlign         = DEFAULT_V_ALIGN;
  bool     wrap           = DEFAULT_WRAP;
  String   scrollDir      = DEFAULT_SCROLL_DIRECTION;
  uint8_t  scrollSpeed    = DEFAULT_SCROLL_SPEED;
  uint8_t  brightness     = DEFAULT_BRIGHTNESS;
  bool     flash          = DEFAULT_FLASH;
  ulong    flashInterval  = DEFAULT_FLASH_INTERVAL;
  bool     pulse          = DEFAULT_PULSE;
  ulong    pulseDuration  = DEFAULT_PULSE_DURATION;
  String   priority       = DEFAULT_PRIORITY;        //"normal" or "high"
  int      expirationTime = DEFAULT_EXPIRATION_TIME; //seconds; 0 = no expiration
};

//=============================================================
//Scheduled Action Structure - used in .ino and HTML.cpp
//=============================================================
struct ScheduledAction {
  bool    enabled        = false;
  String  mode           = "absolute";       //"absolute" or "relative"
  uint8_t hour           = 0;
  uint8_t minute         = 0;
  String  reference      = "";               //"sunrise" or "sunset"
  int16_t offset         = 0;                //Minutes (+/-)
  String  action         = "message";        //"brightness", "clock", "weather", "calendar", "message"
  String  message        = "";
  uint8_t brightness     = 255;
  int8_t  msgProfileIdx  = -1;               //-1 = none; 0-9 = apply that MsgProfile
  bool    triggered;
};

//=============================================================
//Message Storage
//=============================================================
struct Message {
  String text;
  String time;
  bool   unread;
  time_t timestamp;  //Unix epoch time when message was received (0 = unknown)
};

//=============================================================
// WiFi Health Watchdog
//  checkWiFiHealth() is called from loop() on WIFI_HEALTH_CHECK_INTERVAL.
//  Two-stage response to degraded signal:
//    Stage 1 — Soft reconnect: triggered when WiFi drops OR SNR stays below
//              WIFI_SNR_RECONNECT_THRESHOLD for WIFI_SNR_FAIL_COUNT consecutive checks.
//              Blocks loop() for up to WIFI_RECONNECT_TIMEOUT_MS while rejoining.
//    Stage 2 — Hard reboot:   triggered if the soft reconnect fails, or if soft
//              reconnects have been needed WIFI_MAX_RECONNECTS times this session.
//
//  SNR thresholds for reference (snrLabel() in HelpFunctions.cpp):
//    ≥ 40 dB  → Excellent
//    ≥ 25 dB  → Good
//    ≥ 15 dB  → Fair       ← default trigger threshold
//     < 15 dB → Poor
//  25 dB ("below Good") triggers too frequently in marginal-signal environments;
//  15 dB ("below Fair" / Poor only) is a more practical operating point for
//  a fixed device where the signal is stable but not strong.
//
//  Note: rom_check_noise_floor() sign-bit unreliability is corrected in
//  Network.ino with:  if (nf > 0) nf = -nf;
//  This matches the fix already present in HTML.cpp and WeatherCalendar.ino.
//=============================================================
constexpr ulong         WIFI_HEALTH_CHECK_INTERVAL        = 120000;  //Check every 2 minutes (ms)
constexpr int           WIFI_SNR_RECONNECT_THRESHOLD      = 15;      //Reconnect when SNR falls below this (dB)
constexpr int           WIFI_SNR_FAIL_COUNT               = 3;       //Consecutive sub-threshold readings before acting
constexpr uint32_t      WIFI_RECONNECT_TIMEOUT_MS         = 20000;   //Max wait for soft reconnect (ms)
constexpr int           WIFI_MAX_RECONNECTS               = 5;       //Hard reboot after this many soft reconnects

#endif //USER_SETUP_H
