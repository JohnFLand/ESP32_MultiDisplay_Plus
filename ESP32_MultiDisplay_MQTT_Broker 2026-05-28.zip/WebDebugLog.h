#ifndef WEB_DEBUG_LOG_H
    #define WEB_DEBUG_LOG_H
    //============================================================
    // Web-Based Debug Logging System
    //============================================================
    // This file provides macros that can redirect Serial output
    // to a web page for remote debugging over WiFi.
    //
    // When ENABLE_WEB_LOGGING is false:
    //   - Zero overhead (direct Serial.print calls)
    //   - No extra RAM usage
    //   - No extra code size
    //
    // When ENABLE_WEB_LOGGING is true:
    //   - Logs to both Serial AND web buffer
    //   - ~3-5KB RAM for circular buffer
    //   - ~2KB code size
    //============================================================
    // Usage Examples:
    //============================================================
    // Replace:
    //   Serial.print("Temperature: ");
    //   Serial.println(temp);
    //
    // With:
    //   DEBUG_PRINT("Temperature: ");
    //   DEBUG_PRINTLN(temp);
    //
    // Or use printf style:
    //   DEBUG_PRINTF("Temperature: %.1f\n", temp);
    //
    // To enable web logging:
    //   1. Set ENABLE_WEB_LOGGING to true
    //   2. Add webLogSetup() to the .ino file setup() function
    //   3. Access logs at: http://your-device.local/logs
    //============================================================

    // ========== CONFIGURATION ==========
    #include <Arduino.h>
    #include "User_Setup.h"                 //Get ENABLE_WEB_LOGGING & LOG_BUFFER_SIZE from User_Setup.h
    // ===================================

    #if ENABLE_WEB_LOGGING                  //Print to both Serial and web log when web logging is enabled

        void webLogSetup();                 //Initialize web logging endpoint
        void webLogClear();                 //Clear all logs
        String webLogGetJSON();             //Get logs as JSON

        //Web logging enabled - use wrapper functions
        extern String webLogBuffer[LOG_BUFFER_SIZE];
        extern int webLogIndex;
        extern unsigned long webLogTimestamps[LOG_BUFFER_SIZE];

        //Add entry to web log buffer
        inline void addToWebLog(const String& msg) {
            webLogBuffer[webLogIndex] = msg;
            webLogTimestamps[webLogIndex] = millis();
            webLogIndex = (webLogIndex + 1) % LOG_BUFFER_SIZE;
        }

        //Emulate "print" ================================
        inline void webDebugPrint(const String& msg) {
            Serial.print(msg);
            addToWebLog(msg);
        }

        inline void webDebugPrint(const char* msg) {
            Serial.print(msg);
            addToWebLog(String(msg));
        }

        inline void webDebugPrint(int val) {
            Serial.print(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrint(unsigned int val) {
            Serial.print(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrint(long val) {
            Serial.print(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrint(unsigned long val) {
            Serial.print(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrint(float val, int decimals = 2) {
            Serial.print(val, decimals);
            addToWebLog(String(val, decimals));
        }

        //Emulate "println" ================================
        inline void webDebugPrintln(const String& msg) {
            Serial.println(msg);
            addToWebLog(msg);
        }

        inline void webDebugPrintln(const char* msg) {
            Serial.println(msg);
            addToWebLog(String(msg));
        }

        inline void webDebugPrintln(int val) {
            Serial.println(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrintln(unsigned int val) {
            Serial.println(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrintln(long val) {
            Serial.println(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrintln(unsigned long val) {
            Serial.println(val);
            addToWebLog(String(val));
        }

        inline void webDebugPrintln(float val, int decimals = 2) {
            Serial.println(val, decimals);
            addToWebLog(String(val, decimals));
        }

        inline void webDebugPrintln() {
            Serial.println();
            //Don't add empty line to web log
        }

        //Emulate "printf" ================================
        inline void webDebugPrintf(const char* format, ...) {
            char buffer[256];
            va_list args;
            va_start(args, format);
            vsnprintf(buffer, sizeof(buffer), format, args);
            va_end(args);
            Serial.print(buffer);
            addToWebLog(String(buffer));
        }

        //Macros that route to web logging functions
        #define DEBUG_PRINT(x)      webDebugPrint(x)
        #define DEBUG_PRINTLN(x)    webDebugPrintln(x)
        #define DEBUG_PRINTF(...)   webDebugPrintf(__VA_ARGS__)

    #else
        //Web logging is disabled - direct Serial calls (ZERO overhead!)
        #define DEBUG_PRINT(x)      Serial.print(x)
        #define DEBUG_PRINTLN(x)    Serial.println(x)
        #define DEBUG_PRINTF(...)   Serial.printf(__VA_ARGS__)
    #endif

#endif //WEB_DEBUG_LOG_H
