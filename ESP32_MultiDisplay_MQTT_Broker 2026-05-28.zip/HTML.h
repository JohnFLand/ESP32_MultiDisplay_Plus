#ifndef HTML_H
#define HTML_H

#include <WebServer.h>

//Handler function declarations
void handleRoot();
void handleStatusPage();
void handleStatusJson();
void handleClockPage();
void handleClockConfigPage();
void handleWeatherPage();
void handleCalendarPage();
void handleAstroPage();
void handleSchedulerConfigPage();
void handleOTAPasswordPage();
void handleResetSettingsPage();
void handleOTAUpdateForm(); 

//Helper functions
void handleClockConfig();        //POST handler for clock config
void handleLocationConfigPage(); //GET handler for location config
void handleLocationConfig();     //POST handler for location config
void handleSchedulerConfig();    //POST handler for scheduler
void handleOTAPasswordPost();    //POST handler for OTA password
void handleResetSettingsPost();  //POST handler for reset

//Control endpoint
void handleControl();  //For theme and state controls

//Time endpoint
void handleTimeInfo();

//Detailed confirmation page after posting a message (no auto-redirect)
void sendMessageSentPage(
  const String &message,
  uint16_t bgColor,
  uint16_t textColor,
  int font,
  int rotation,
  const String &hAlign,
  const String &vAlign,
  bool wrap,
  const String &scrollDirection,
  uint8_t scrollSpeed,
  uint8_t brightness,
  bool flash,
  unsigned long flashInterval,
  bool pulse,
  unsigned long pulseDuration,
  const String &priority,
  int expirationTime
);

#endif //HTML_H
