//=============================================================
// MQTTBroker.ino  —  Bridge wrappers only
//
// IMPORTANT: This file intentionally contains NO class definitions.
// The sMQTTBroker subclass lives in MQTTBroker.cpp so it is never
// processed by Arduino IDE's prototype generator, which would
// otherwise fail to generate prototypes for the entire sketch.
//
// These wrappers give MQTTBroker.cpp access to sketch-internal
// types (ScreenMode, HighPriorityMessage, Preferences, etc.)
// without those types needing to be declared in MQTTBroker.cpp.
//=============================================================

#include "MQTTBroker.h"

//-------------------------------------------------------------
// mqttPushMessageScreen()
// Full sequence needed before displaying a message via MQTT:
// deactivate screensaver → disable clock → push UI return state
// → set currentScreen = SCREEN_MESSAGE
//-------------------------------------------------------------
void mqttPushMessageScreen() {
  deactivateScreensaver();
  showClock = false;
  if (currentScreen != SCREEN_MESSAGE)
    uiReturnPushCurrentIfEntering(SCREEN_MESSAGE);
  currentScreen = SCREEN_MESSAGE;
}

//-------------------------------------------------------------
// mqttClearDisplay()
// Clears all pending/active messages and returns to the clock.
// This is the complete clear-display logic, consolidated here
// because it requires HighPriorityMessage[], ScreenMode, and
// other sketch-specific types unavailable in MQTTBroker.cpp.
//-------------------------------------------------------------
void mqttClearDisplay() {
  // Discard all queued high-priority messages
  for (int i = 0; i < MAX_HIGH_PRIORITY_MESSAGES; i++)
    highPriorityMessages[i].active = false;
  highPriorityMessageCount = 0;
  currentHighPriorityIndex = 0;

  // Discard normal message queue
  normalQueueHead  = 0;
  normalQueueTail  = 0;
  normalQueueCount = 0;

  // Clear active message state
  messageActive          = false;
  messageExpirationTime  = 0;
  messagePriority        = "normal";
  inNormalOverride       = false;
  savedHighPriorityIndex = -1;
  resetMessageRuntimeState();

  // Return to clock
  if (currentScreen == SCREEN_MESSAGE)
    uiReturnReturnOr(SCREEN_CLOCK);

  DEBUG_PRINTLN("MQTT: display cleared");
}

//-------------------------------------------------------------
// mqttShowScreen()
// Triggers an async screen change via pendingScreen.
// Use MQTT_SCREEN_* constants from MQTTBroker.h.
// Called from MQTTBroker.cpp::onEvent() for display/screen topic.
//-------------------------------------------------------------
void mqttShowScreen(int screen) {
  pendingScreen = static_cast<ScreenMode>(screen);
}

//-------------------------------------------------------------
// mqttSaveSettingsAndRedraw()
// Saves settings to NVS then redraws the currently active screen.
// Called after device/control settings changes.
//-------------------------------------------------------------
void mqttSaveSettingsAndRedraw() {
  saveSettings();
  switch (currentScreen) {
    case SCREEN_CLOCK    : drawClock();          break;
    case SCREEN_WEATHER  : displayWeather();     break;
    case SCREEN_CALENDAR : displayCalendar();    break;
    case SCREEN_MENU     : drawMenu();           break;
    case SCREEN_MESSAGES : drawMessagesScreen(); break;
    case SCREEN_ASTRO    : drawAstroScreen();    break;
    default: break;
  }
}

//-------------------------------------------------------------
// mqttClockConfigApply()
// Applies clock configuration changes: marks colors customized
// if needed, saves settings, forces night-mode re-evaluation,
// and immediately redraws the clock if it is the active screen.
//-------------------------------------------------------------
void mqttClockConfigApply(bool anyColorChanged) {
  if (anyColorChanged) {
    clockColorsCustomized = true;
  }
  saveSettings();
  lastNightModeCheck = 0;   // force immediate re-eval on next loop()
  updateNightMode();
  if (currentScreen == SCREEN_CLOCK) {
    currentRotation = clockRotation;
    setBrightness(screenBrightness);
    drawClock();
    DEBUG_PRINTLN("MQTT: clock display updated");
  } else {
    DEBUG_PRINTLN("MQTT: clock config saved — will apply when clock screen shown");
  }
}

//-------------------------------------------------------------
// mqttClearHistory()
// Clears the message history log without affecting the active
// message or queue.
//-------------------------------------------------------------
void mqttClearHistory() {
  messageCount        = 0;
  unreadCount         = 0;
  currentHistoryIndex = 0;
  if (currentScreen == SCREEN_MESSAGES)
    drawMessagesScreen();
  DEBUG_PRINTLN("MQTT: message history cleared");
}

//-------------------------------------------------------------
// mqttResetSettingsAndReboot()
// Clears all NVS preferences and reboots (resetsettings /
// resetdevice commands). Runs a brief delay so the MQTT
// client has time to receive any pending event before restart.
//-------------------------------------------------------------
void mqttResetSettingsAndReboot() {
  DEBUG_PRINTLN("MQTT: clearing NVS settings and rebooting");
  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();
  preferences.end();
  delay(300);
  ESP.restart();
}

//-------------------------------------------------------------
// mqttRefreshWeatherIfShowing()
// Redraws the weather screen immediately when a fresh local
// pressure value arrives via MQTT, but only if the weather
// screen is currently showing the local-pressure turn.
// Mirrors the same trigger used by the HTTP fetchLocalPressure().
//-------------------------------------------------------------
void mqttRefreshWeatherIfShowing() {
  if (currentScreen == SCREEN_WEATHER &&
      (!apAlternate || apAlternateShowLocal)) {
    displayWeather();
    DEBUG_PRINTLN("MQTT: weather display refreshed with local pressure");
  }
}

//-------------------------------------------------------------
// mqttPublishWeather()
// Serializes all current weather globals to a compact JSON
// payload and publishes to MQTT_TOPIC_WEATHER with retain=true.
// Called from WeatherCalendar.ino after a successful HTTP fetch.
//-------------------------------------------------------------
void mqttPublishWeather() {
  JsonDocument doc;
  doc["temp"]        = weatherTemp;
  doc["apparent"]    = weatherApparentTemp;
  doc["humidity"]    = weatherHumidity;
  doc["pressure"]    = weatherPressure;
  doc["is_day"]      = (int)weatherIsDay;
  doc["code"]        = weatherCode;
  doc["hi"]          = dailyTempMax;
  doc["ahi"]         = dailyApparentTempMax;
  doc["lo"]          = dailyTempMin;
  doc["alo"]         = dailyApparentTempMin;
  doc["precip"]      = dailyPrecipitationSum;
  doc["precip_prob"] = dailyPrecipProbMax;
  doc["celsius"]     = (bool)tempCelsius;
  doc["ts"]          = (long)time(nullptr);

  String payload;
  serializeJson(doc, payload);
  mqttPublish(MQTT_TOPIC_WEATHER, payload.c_str(), true);
  DEBUG_PRINTF("MQTT: weather published (%d bytes)\n", (int)payload.length());
}

//-------------------------------------------------------------
// mqttPublishPressure()
// Publishes the current local air-pressure reading to
// MQTT_TOPIC_PRESSURE with retain=true.
// Called from WeatherCalendar.ino after a successful fetch or
// when Hubitat MQTT delivers a fresh value.
//-------------------------------------------------------------
void mqttPublishPressure() {
  if (!localPressureValid) return;
  // Feed the forecast buffer with all available sensor data
  addPressureReading(localPressureHpa, localWindDeg, localTemp, localHumidity);
  // Build enriched payload for CYD subscribers
  JsonDocument doc;
                             doc["hpa"]      = localPressureHpa;
  if (!isnan(localWindDeg))  doc["wind"]     = localWindDeg;
  if (!isnan(localTemp))     doc["temp"]     = localTemp;
  if (!isnan(localHumidity)) doc["humidity"] = localHumidity;
  String payload;
  serializeJson(doc, payload);
  mqttPublish(MQTT_TOPIC_PRESSURE, payload.c_str(), true);
  DEBUG_PRINTF("MQTT: pressure published: %s\n", payload.c_str());
  mqttPublishPressureHistory();
}

//-------------------------------------------------------------
// mqttPublishPressureHistory()
//
// Serialises the entire pressure ring-buffer into up to
// PRESSURE_HISTORY_CHUNKS retained topics:
//
//   multidisplay/pressure/history/0
//   multidisplay/pressure/history/1
//   ...
//
// Each chunk carries up to PRESSURE_HISTORY_CHUNK_SIZE readings
// as a compact JSON array plus a "total" field so the subscriber
// knows how many readings the complete snapshot contains:
//
//   { "total":85, "from":0,
//     "readings":[{"ts":1748500000,"h":1013.2,"w":270.0,"t":18.5,"u":65.0}, ...] }
//
// Field names are kept short (h/w/t/u) so each chunk stays well
// under the 2048-byte PubSubClient buffer used on the CYD side.
//
// Called:
//   • from mqttPublishPressure() after every new sensor reading
//   • from the NewClient_sMQTTEventType handler so a freshly
//     booted CYD immediately receives the full history
//-------------------------------------------------------------
#define PRESSURE_HISTORY_CHUNK_SIZE  25   // readings per retained chunk topic
#define PRESSURE_HISTORY_CHUNKS       4   // ceil(97 / 25) = 4

void mqttPublishPressureHistory() {
  int total = pressureBufSize();
  if (total == 0) return;

  for (int chunk = 0; chunk < PRESSURE_HISTORY_CHUNKS; chunk++) {
    int startIdx = chunk * PRESSURE_HISTORY_CHUNK_SIZE;
    if (startIdx >= total) {
      // No readings for this chunk — publish an empty marker so stale
      // retained data from a previous larger buffer is overwritten.
      char topic[48];
      snprintf(topic, sizeof(topic), "multidisplay/pressure/history/%d", chunk);
      mqttPublish(topic, "{\"total\":0,\"from\":0,\"readings\":[]}", true);
      continue;
    }

    JsonDocument doc;
    doc["total"] = total;
    doc["from"]  = startIdx;
    JsonArray arr = doc["readings"].to<JsonArray>();

    int endIdx = min(startIdx + PRESSURE_HISTORY_CHUNK_SIZE, total);
    for (int i = startIdx; i < endIdx; i++) {
      PressureReading r;
      if (!pressureBufEntry(i, r)) continue;
      JsonObject obj = arr.add<JsonObject>();
      obj["ts"] = (long)r.ts;
      obj["h"]  = serialized(String(r.hpa, 1));
      if (!isnan(r.windDeg))  obj["w"] = serialized(String(r.windDeg, 0));
      if (!isnan(r.temp))     obj["t"] = serialized(String(r.temp, 1));
      if (!isnan(r.humidity)) obj["u"] = serialized(String(r.humidity, 0));
    }

    String payload;
    payload.reserve(1600);
    serializeJson(doc, payload);

    char topic[48];
    snprintf(topic, sizeof(topic), "multidisplay/pressure/history/%d", chunk);
    mqttPublish(topic, payload.c_str(), true);
    DEBUG_PRINTF("MQTT: pressure history chunk %d published (%d readings, %d bytes)\n",
                 chunk, endIdx - startIdx, (int)payload.length());
  }
}

//-------------------------------------------------------------
// mqttPublishTime()
// Publishes the current UTC epoch and POSIX TZ string to
// MQTT_TOPIC_TIME with retain=true.
// Called from loop() every MQTT_TIME_PUBLISH_INTERVAL_MS.
//-------------------------------------------------------------
void mqttPublishTime() {
  time_t epoch = time(nullptr);
  if (epoch < 1000000L) return;   // NTP not yet synced

  JsonDocument doc;
  doc["epoch"] = (long)epoch;
  doc["tz"]    = weatherTzString;

  String payload;
  serializeJson(doc, payload);
  mqttPublish(MQTT_TOPIC_TIME, payload.c_str(), true);
  DEBUG_PRINTF("MQTT: time published (epoch=%ld)\n", (long)epoch);
}
