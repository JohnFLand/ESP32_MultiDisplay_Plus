//=============================================================
// Settings.ino  —  NVS persistence and pixel-shift housekeeping
//=============================================================

void updatePixelShift() {
  if (!pixelShiftEnabled) return;

  //Check if it's time to shift
  if (millis() - lastPixelShift >= pixelShiftInterval || lastPixelShift == 0) {
    //Generate random offsets within the configured range
    clockOffsetX = random(-pixelShiftRange, pixelShiftRange + 1);
    clockOffsetY = random(-pixelShiftRange, pixelShiftRange + 1);

    lastPixelShift = millis();

#if DEEP_DEBUG
    DEBUG_PRINTF("\nCurrent pixel shift: X=%d, Y=%d\n", clockOffsetX, clockOffsetY);
#endif
  }
}

void applyDefaultClockPaletteFromMode() {
  clockTimeColor     = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
  clockDateColor     = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
  clockBgColor       = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR   : DEFAULT_CLOCK_BG_COLOR_L;
  clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR   : DEFAULT_SUNTIMES_COLOR_L;
}

void loadSettings() {
  DEBUG_PRINTLN("\n=== Loading Settings from NVRAM ===");

  preferences.begin(PREFERENCES_NAMESPACE, false);  //false = read/write mode

  //Has the user customized any clock colors yet?
  clockColorsCustomized    = preferences.getBool(       "clkClrCust",       false);

  //Start from the theme palette, then optionally override from NVRAM
  applyDefaultClockPaletteFromMode();

  //Load dark/light mode settings early so clock color defaults can follow the selected theme
  clockDarkMode            = preferences.getBool(       "clockDark",        DEFAULT_CLOCK_DARK_MODE);
  calendarDarkMode         = preferences.getBool(       "calendarDark",     DEFAULT_CALENDAR_DARK_MODE);
  weatherDarkMode          = preferences.getBool(       "weatherDark",      DEFAULT_WEATHER_DARK_MODE);
  menuDarkMode             = preferences.getBool(       "menuDark",         DEFAULT_MENU_DARK_MODE);
  historyDarkMode          = preferences.getBool(       "historyDark",      DEFAULT_HISTORY_DARK_MODE);
  astroDarkMode            = preferences.getBool(       "astroDark",        DEFAULT_ASTRO_DARK_MODE);

  //Load clock settings
  clockTimeFont            = validateRobotoFontCode(preferences.getUChar("timeFont",        DEFAULT_TIME_FONT));
  clockDateFont            = validateRobotoFontCode(preferences.getUChar("dateFont",        DEFAULT_DATE_FONT));
  menuFont                 = validateRobotoFontCode(preferences.getUChar("menuFont",        DEFAULT_MENU_FONT));
  labelFont                = validateRobotoFontCode(preferences.getUChar("labelFont",       DEFAULT_LABEL_FONT));
  msgNoticeFont            = validateRobotoFontCode(preferences.getUChar("msgNoticeFont",   DEFAULT_MSG_NOTICE_FONT));
  labelColor               = preferences.getUInt(       "labelColor",      DEFAULT_LABEL_COLOR);
  msgNoticeColor           = preferences.getUInt(       "msgNoticeColor",  DEFAULT_MSG_NOTICE_COLOR);
  clockTimeColor           = preferences.getUInt(       "timeColor",       clockTimeColor);
  clockDateColor           = preferences.getUInt(       "dateColor",       clockDateColor);
  clockBgColor             = preferences.getUInt(       "bgColor",         clockBgColor);
  clockTimeFormat          = preferences.getString(     "timeFormat",      DEFAULT_CLOCK_TIME_FORMAT);
  clockDateFormat          = preferences.getString(     "dateFormat",      DEFAULT_CLOCK_DATE_FORMAT);
  screenBrightness         = preferences.getUChar(      "brightness",      DEFAULT_SCREEN_BRIGHTNESS);
  clockRotation            = preferences.getInt(        "rotation",        DEFAULT_CLOCK_ROTATION);
  clockEnabled             = preferences.getBool(       "clockEnable",     DEFAULT_CLOCK_ENABLED);
  clockSuntimesEnabled     = preferences.getBool(       "sunEnable",       DEFAULT_SUNTIMES_ENABLED);
  clockSuntimesColor       = preferences.getUInt(       "sunColor",        clockSuntimesColor);
  clockSuntimesFont        = validateRobotoFontCode(preferences.getUChar("sunFont",         DEFAULT_SUNTIMES_FONT));

  //Load screen-specific fonts & colors
  historyTextFont          = validateRobotoFontCode(preferences.getUChar("histTextFont",    DEFAULT_HISTORY_TEXT_FONT));
  weatherFont              = validateRobotoFontCode(preferences.getUChar("weatherFont",     DEFAULT_WEATHER_FONT));
  weatherTitleFont         = validateRobotoFontCode(preferences.getUChar("weatherTitleFnt", DEFAULT_WEATHER_TITLE_FONT));
  weatherTempFont          = validateRobotoFontCode(preferences.getUChar("weatherTempFnt",  DEFAULT_WEATHER_TEMP_FONT));
  weatherHumidFont         = validateRobotoFontCode(preferences.getUChar("weatherHumFnt",   DEFAULT_WEATHER_HUMID_FONT));
  weatherPressureFont      = validateRobotoFontCode(preferences.getUChar("weatherPresFnt",  DEFAULT_AIR_PRESSURE_FONT));
  weatherPressureUnitsFont = validateRobotoFontCode(preferences.getUChar("weatherPresUFnt", DEFAULT_AIR_PRESSURE_UNITS_FONT));
  screenHeaderFont         = validateRobotoFontCode(preferences.getUChar("calHdrFont",      DEFAULT_SCREEN_HEADER_FONT));
  calendarDayFont          = validateRobotoFontCode(preferences.getUChar("calDayFont",      DEFAULT_CALENDAR_DAY_FONT));
  astroHeaderFont          = validateRobotoFontCode(preferences.getUChar("astroHdrFont",    DEFAULT_ASTRO_HEADER_FONT));
  astroTextFont            = validateRobotoFontCode(preferences.getUChar("astroTxtFont",    DEFAULT_ASTRO_TEXT_FONT));
  nightClockTimeColor      = preferences.getUInt(       "niteTimeColor",   DEFAULT_NIGHT_TIME_COLOR);
  nightClockDateColor      = preferences.getUInt(       "niteDateColor",   DEFAULT_NIGHT_DATE_COLOR);
  nightClockBgColor        = preferences.getUInt(       "niteBgColor",     DEFAULT_NIGHT_BG_COLOR);
  nightClockSuntimesColor  = preferences.getUInt(       "niteSunColor",    DEFAULT_NIGHT_SUNTIMES_COLOR);

  //Load screensaver settings
  screensaverDimValue      = preferences.getUChar(     "dimLevel",        DEFAULT_SCREENSAVER_DIM);
  screensaverTimeout       = preferences.getULong(     "ssTimeout",       DEFAULT_SCREENSAVER_TIMEOUT);

  //Load pixel shift settings
  pixelShiftEnabled        = preferences.getBool(       "pixelShift",      DEFAULT_PIXEL_SHIFT_ENABLED);
  pixelShiftInterval       = preferences.getULong(      "shiftInterval",   DEFAULT_PIXEL_SHIFT_INTERVAL);
  pixelShiftRange          = preferences.getInt(        "shiftRange",      DEFAULT_PIXEL_SHIFT_RANGE);
 
  //Load auto-cycle settings
  weatherCycleEnabled      = preferences.getBool(       "wCycleEn",        DEFAULT_WEATHER_CYCLE_ENABLED);
  calendarCycleEnabled     = preferences.getBool(       "calCycleEn",      DEFAULT_CALENDAR_CYCLE_ENABLED);
  weatherShowDuration      = preferences.getULong(      "wxShowDur",       WEATHER_SHOW_DURATION);
  weatherCycleInterval     = preferences.getULong(      "wxCycleInt",      WEATHER_CYCLE_INTERVAL);
  calendarShowDuration     = preferences.getULong(      "calShowDur",      CALENDAR_SHOW_DURATION);
  calendarCycleInterval    = preferences.getULong(      "calCycleInt",     CALENDAR_CYCLE_INTERVAL);
  touchEnabled             = preferences.getBool(       "touchEnable",     DEFAULT_TOUCH_ENABLED);

  //In SCREEN_DEBUG mode the compiled-in defaults always win.
  //NVS values persist across flashes; a stale false can silently disable a cycle
  //and make testing impossible. Force the values here so the sketch always
  //behaves exactly as the #defines say when SCREEN_DEBUG is on.
  #if SCREEN_DEBUG
    weatherCycleEnabled   = DEFAULT_WEATHER_CYCLE_ENABLED;
    calendarCycleEnabled  = DEFAULT_CALENDAR_CYCLE_ENABLED;
  #endif

  //Load night mode settings
  nightModeEnabled              = preferences.getBool(  "nightEnable",     DEFAULT_NIGHTMODE_ENABLED);
  sunsetOffset                  = preferences.getShort( "sunsetOff",       DEFAULT_SUNSET_OFFSET);
  sunriseOffset                 = preferences.getShort( "sunriseOff",      DEFAULT_SUNRISE_OFFSET);
  nightModeBrightness           = preferences.getUChar( "nightBright",     DEFAULT_NIGHTMODE_BRIGHTNESS);
  nightModeWakeDuration         = preferences.getULong( "nightWakeDur",    DEFAULT_NIGHTMODE_WAKE_DURATION);
  tempCelsius                   = preferences.getBool(  "tempCelsius",     TEMP_CELSIUS);
  tempActual                    = preferences.getBool(  "tempActual",      TEMP_ACTUAL);
  tempAlternate                 = preferences.getBool(  "tempAlternate",   DEFAULT_TEMP_ALTERNATION_MODE);
  apAlternate                   = preferences.getBool(  "apAlternate",     DEFAULT_AP_ALTERNATION_MODE);
  highPriorityAlternateInterval = preferences.getInt(   "hpAltSec",        DEFAULT_HIGH_PRIORITY_ALTERNATE) * 1000;
  normalOverrideEnabled         = preferences.getBool(  "normOverrideEn",  DEFAULT_NORMAL_OVERRIDE_ENABLED);
  normalOverrideDuration        = preferences.getInt(   "normOverrideDur", DEFAULT_NORMAL_OVERRIDE_DURATION);
  pulseMaxBrightness            = preferences.getUChar( "pulseMaxBri",     DEFAULT_PULSE_MAX_BRIGHTNESS);
  pulseMinBrightness            = preferences.getUChar( "pulseMinBri",     DEFAULT_PULSE_MIN_BRIGHTNESS);
  nightModeWakeBrightness       = preferences.getUChar( "dayBright",       DEFAULT_NIGHTMODE_WAKE_BRIGHTNESS);

  //Load Message History max message age
  maxMsgAge                     = preferences.getInt(   "maxMsgAge",       MESSAGE_HISTORY_MAX_AGE_HOURS);

  //Load OTA password
  otaPassword                   = preferences.getString("otaPass",         DEFAULT_OTA_PASSWORD);

  //Load location/timezone settings (runtime-configurable via /locationconfig)
  weatherLocation  = preferences.getString("location",   LOCATION);
  weatherLatitude  = preferences.getString("latitude",   LATITUDE);
  weatherLongitude = preferences.getString("longitude",  LONGITUDE);
  weatherTimezone  = preferences.getString("timezone",   TIMEZONE);
  weatherTzString  = preferences.getString("tzString",   TZ_STRING);
  weatherAltitude  = preferences.getString("altitude",   ALTITUDE);

  //If the user has NOT customized clock colors, force the theme palette
  //(This keeps the HTML clock config page in sync with the active theme defaults)
  if (!clockColorsCustomized) {
    applyDefaultClockPaletteFromMode();
  }

  preferences.end();

  //DEBUG_PRINTLN("\n=== Settings loaded from NVRAM ===");
  DEBUG_PRINTLN("  Clock enabled            : " + String(clockEnabled ? "true" : "false"));
  DEBUG_PRINTLN("  Time format              : " + clockTimeFormat);
  DEBUG_PRINTLN("  Date format              : " + clockDateFormat);
  DEBUG_PRINTLN("  Clock time font          : " + String(clockTimeFont));
  DEBUG_PRINTLN("  Clock date font          : " + String(clockDateFont));
  DEBUG_PRINTLN("  Clock time color         : " + String(clockTimeColor));
  DEBUG_PRINTLN("  Clock date color         : " + String(clockDateColor));
  DEBUG_PRINTLN("  Background color         : " + String(clockBgColor));
  DEBUG_PRINTLN("  Clock rotation           : " + String(clockRotation) + "°");
  DEBUG_PRINTLN("  Screen brightness        : " + String(screenBrightness));
  DEBUG_PRINTLN("  Screensaver dim          : " + String(screensaverDimValue) + " (0-5)");
  DEBUG_PRINTLN("  Screensaver timeout      : " + String(screensaverTimeout)  + " ms");
  DEBUG_PRINTLN("  Suntimes enabled         : " + String(clockSuntimesEnabled ? "true" : "false"));
  DEBUG_PRINTLN("  Suntimes font            : " + String(clockSuntimesFont));
  DEBUG_PRINTLN("  Suntimes color           : " + String(clockSuntimesColor));
  DEBUG_PRINTLN("  Colors customized        : " + String(clockColorsCustomized ? "true" : "false"));

  DEBUG_PRINTLN("  Night-mode enabled       : " + String(nightModeEnabled ? "true" : "false"));
  DEBUG_PRINTLN("  Sunset offset            : " + String(sunsetOffset)  + " min");
  DEBUG_PRINTLN("  Sunrise offset           : " + String(sunriseOffset) + " min");
  DEBUG_PRINTLN("  Night-mode brightness    : " + String(nightModeBrightness));
  DEBUG_PRINTLN("  Night wake brightness    : " + String(nightModeWakeBrightness));

  DEBUG_PRINTLN("  Night time color         : " + String(nightClockTimeColor));
  DEBUG_PRINTLN("  Night date color         : " + String(nightClockDateColor));
  DEBUG_PRINTLN("  Night bg color           : " + String(nightClockBgColor));
  DEBUG_PRINTLN("  Night suntimes color     : " + String(nightClockSuntimesColor));
  DEBUG_PRINTLN("  Label color              : " + String(labelColor));
  DEBUG_PRINTLN("  Msg notice color         : " + String(msgNoticeColor));

  DEBUG_PRINTLN("  Menu font                : " + String(menuFont));
  DEBUG_PRINTLN("  Label font               : " + String(labelFont));
  DEBUG_PRINTLN("  Msg notice font          : " + String(msgNoticeFont));
  DEBUG_PRINTLN("  History text font        : " + String(historyTextFont));
  DEBUG_PRINTLN("  Weather font             : " + String(weatherFont));
  DEBUG_PRINTLN("  Weather title font       : " + String(weatherTitleFont));
  DEBUG_PRINTLN("  Weather temp font        : " + String(weatherTempFont));
  DEBUG_PRINTLN("  Weather humid font       : " + String(weatherHumidFont));
  DEBUG_PRINTLN("  Weather pressure font    : " + String(weatherPressureFont));
  DEBUG_PRINTLN("  Weather pres units font  : " + String(weatherPressureUnitsFont));
  DEBUG_PRINTLN("  Calendar header font     : " + String(screenHeaderFont));
  DEBUG_PRINTLN("  Calendar day font        : " + String(calendarDayFont));
  DEBUG_PRINTLN("  Astro header font        : " + String(astroHeaderFont));
  DEBUG_PRINTLN("  Astro text font          : " + String(astroTextFont));

  DEBUG_PRINTLN("  Pixel Shift enabled      : " + String(pixelShiftEnabled ? "true" : "false"));
  DEBUG_PRINTF( "  Pixel Shift Range        : ±%d pixels\n", pixelShiftRange);
  DEBUG_PRINTF( "  Pixel Shift Interval     : %d seconds\n", pixelShiftInterval / 1000);

  DEBUG_PRINTLN("  Clock dark mode          : " + String(clockDarkMode    ? "true" : "false"));
  DEBUG_PRINTLN("  Calendar dark mode       : " + String(calendarDarkMode ? "true" : "false"));
  DEBUG_PRINTLN("  Weather dark mode        : " + String(weatherDarkMode  ? "true" : "false"));
  DEBUG_PRINTLN("  Menu dark mode           : " + String(menuDarkMode     ? "true" : "false"));
  DEBUG_PRINTLN("  History dark mode        : " + String(historyDarkMode  ? "true" : "false"));
  DEBUG_PRINTLN("  Astro dark mode          : " + String(astroDarkMode    ? "true" : "false"));

  DEBUG_PRINTLN("  Touch enabled            : " + String(touchEnabled         ? "true" : "false"));
  DEBUG_PRINTLN("  Weather cycle enabled    : " + String(weatherCycleEnabled  ? "true" : "false"));
  DEBUG_PRINTLN("  Calendar cycle enabled   : " + String(calendarCycleEnabled ? "true" : "false"));
  DEBUG_PRINTF( "  Weather show duration    : %lu sec\n", weatherShowDuration   / 1000);
  DEBUG_PRINTF( "  Weather cycle interval   : %lu sec\n", weatherCycleInterval  / 1000);
  DEBUG_PRINTF( "  Calendar show duration   : %lu sec\n", calendarShowDuration  / 1000);
  DEBUG_PRINTF( "  Calendar cycle interval  : %lu sec\n", calendarCycleInterval / 1000);
  DEBUG_PRINTF( "  Night wake duration      : %lu sec\n", nightModeWakeDuration / 1000);
  DEBUG_PRINTLN("  Temperature Celsius      : " + String(tempCelsius ? "true" : "false"));
  DEBUG_PRINTLN("  Temperature Actual       : " + String(tempAlternate ? "alternate" : (tempActual ? "actual" : "apparent (feels-like)")));
  DEBUG_PRINTF( "  Hi Priority alternation  : %d sec\n",  highPriorityAlternateInterval / 1000);
  DEBUG_PRINTLN("  Normal override enabled  : " + String(normalOverrideEnabled ? "true" : "false"));
  DEBUG_PRINTF( "  Normal override duration : %d sec\n",  normalOverrideDuration);
  DEBUG_PRINTF( "  Pulse max brightness     : %d\n",      pulseMaxBrightness);
  DEBUG_PRINTF( "  Pulse min brightness     : %d\n",      pulseMinBrightness);
  DEBUG_PRINTF( "  Maximum message age      : %d hrs\n",  maxMsgAge);
}

void saveSettings() {
  DEBUG_PRINTLN("\n=== Saving Settings to Flash ===");

  preferences.begin(PREFERENCES_NAMESPACE, false);  //false = read/write mode

  //Save whether the user has overridden the theme default clock colors
  preferences.putBool("clkClrCust", clockColorsCustomized);

  //Save clock settings
  preferences.putUChar(   "timeFont",         clockTimeFont);
  preferences.putUChar(   "dateFont",         clockDateFont);
  preferences.putUChar(   "menuFont",         menuFont);
  preferences.putUChar(   "labelFont",        labelFont);
  preferences.putUChar(   "msgNoticeFont",    msgNoticeFont);
  preferences.putUInt(    "labelColor",       labelColor);
  preferences.putUInt(    "msgNoticeColor",   msgNoticeColor);
  preferences.putUInt(    "timeColor",        clockTimeColor);
  preferences.putUInt(    "dateColor",        clockDateColor);
  preferences.putUInt(    "bgColor",          clockBgColor);
  preferences.putString(  "timeFormat",       clockTimeFormat);
  preferences.putString(  "dateFormat",       clockDateFormat);
  preferences.putUChar(   "brightness",       screenBrightness);
  preferences.putInt(     "rotation",         clockRotation);
  preferences.putBool(    "clockEnable",      clockEnabled);

  //Save sunrise/sunset settings
  preferences.putBool(    "sunEnable",        clockSuntimesEnabled);
  preferences.putUChar(   "sunFont",          clockSuntimesFont);
  preferences.putUInt(    "sunColor",         clockSuntimesColor);

  //Save night mode settings
  preferences.putBool(    "nightEnable",      nightModeEnabled);
  preferences.putULong(   "nightWakeDur",     nightModeWakeDuration);
  preferences.putBool(    "tempCelsius",      tempCelsius);
  preferences.putBool(    "tempActual",       tempActual);
  preferences.putBool(    "tempAlternate",    tempAlternate);
  preferences.putBool(    "apAlternate",      apAlternate);
  preferences.putInt(     "hpAltSec",         highPriorityAlternateInterval / 1000);
  preferences.putBool(    "normOverrideEn",   normalOverrideEnabled);
  preferences.putInt(     "normOverrideDur",  normalOverrideDuration);
  preferences.putUChar(   "pulseMaxBri",      pulseMaxBrightness);
  preferences.putUChar(   "pulseMinBri",      pulseMinBrightness);
  preferences.putShort(   "sunsetOff",        sunsetOffset);
  preferences.putShort(   "sunriseOff",       sunriseOffset);
  preferences.putUChar(   "nightBright",      nightModeBrightness);
  preferences.putUChar(   "dayBright",        nightModeWakeBrightness);
  preferences.putUInt(    "niteTimeColor",    nightClockTimeColor);
  preferences.putUInt(    "niteDateColor",    nightClockDateColor);
  preferences.putUInt(    "niteBgColor",      nightClockBgColor);
  preferences.putUInt(    "niteSunColor",     nightClockSuntimesColor);

  //Save screensaver settings
  preferences.putUChar(   "dimLevel",         screensaverDimValue);
  preferences.putULong(   "ssTimeout",        screensaverTimeout);

  //Save screen-specific fonts
  preferences.putUChar(   "histTextFont",     historyTextFont);
  preferences.putUChar(   "weatherFont",      weatherFont);
  preferences.putUChar(   "weatherTitleFnt",  weatherTitleFont);
  preferences.putUChar(   "weatherTempFnt",   weatherTempFont);
  preferences.putUChar(   "weatherHumFnt",    weatherHumidFont);
  preferences.putUChar(   "weatherPresFnt",   weatherPressureFont);
  preferences.putUChar(   "weatherPresUFnt",  weatherPressureUnitsFont);
  preferences.putUChar(   "calHdrFont",       screenHeaderFont);
  preferences.putUChar(   "calDayFont",       calendarDayFont);
  preferences.putUChar(   "astroHdrFont",     astroHeaderFont);
  preferences.putUChar(   "astroTxtFont",     astroTextFont);

  //Save pixel shift settings
  preferences.putBool(    "pixelShift",       pixelShiftEnabled);
  preferences.putULong(   "shiftInterval",    pixelShiftInterval);
  preferences.putInt(     "shiftRange",       pixelShiftRange);

  //Save dark/light mode settings
  preferences.putBool(    "clockDark",        clockDarkMode);
  preferences.putBool(    "calendarDark",     calendarDarkMode);
  preferences.putBool(    "weatherDark",      weatherDarkMode);
  preferences.putBool(    "menuDark",         menuDarkMode);
  preferences.putBool(    "historyDark",      historyDarkMode);
  preferences.putBool(    "astroDark",        astroDarkMode);

  //Save screen cycle settings
  preferences.putBool(    "touchEnable",      touchEnabled);
  preferences.putBool(    "wCycleEn",         weatherCycleEnabled);
  preferences.putBool(    "calCycleEn",       calendarCycleEnabled);
  preferences.putULong(   "wxShowDur",        weatherShowDuration);
  preferences.putULong(   "wxCycleInt",       weatherCycleInterval);
  preferences.putULong(   "calShowDur",       calendarShowDuration);
  preferences.putULong(   "calCycleInt",      calendarCycleInterval);

  //Save message history age limit (0 = disabled)
  preferences.putInt(     "maxMsgAge",        maxMsgAge);

  //Save location/timezone settings
  preferences.putString(  "location",         weatherLocation);
  preferences.putString(  "latitude",         weatherLatitude);
  preferences.putString(  "longitude",        weatherLongitude);
  preferences.putString(  "timezone",         weatherTimezone);
  preferences.putString(  "tzString",         weatherTzString);
  preferences.putString(  "altitude",         weatherAltitude);

  preferences.end();

  DEBUG_PRINTLN("Settings saved successfully");
}

//=============================================================
// resetSettings()
//
// Clears all preferences and reloads in-memory state to
// defaults.  Currently not called — reset handlers in
// AdminHandlers.ino (handleResetSettingsPost, handleDeviceFullReset)
// and MQTTBroker.ino (mqttResetSettingsAndReboot) each clear
// preferences directly and reboot immediately, so no in-memory
// reload is needed.
//
// Retained as the canonical consolidation point: if new preference
// namespaces or runtime defaults are added, update this function
// and migrate the inline handlers to call it.
//=============================================================
void resetSettings() {
  DEBUG_PRINTLN("\n=== Resetting Settings to Defaults ===");

  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();  //Clear all saved settings
  preferences.end();

  //Reload defaults
  clockTimeFont                 = DEFAULT_TIME_FONT;
  clockDateFont                 = DEFAULT_DATE_FONT;
  menuFont                      = DEFAULT_MENU_FONT;
  labelFont                     = DEFAULT_LABEL_FONT;
  msgNoticeFont                 = DEFAULT_MSG_NOTICE_FONT;
  labelColor                    = DEFAULT_LABEL_COLOR;
  msgNoticeColor                = DEFAULT_MSG_NOTICE_COLOR;
  clockTimeFormat               = DEFAULT_CLOCK_TIME_FORMAT;
  clockDateFormat               = DEFAULT_CLOCK_DATE_FORMAT;
  screenBrightness              = DEFAULT_SCREEN_BRIGHTNESS;
  clockRotation                 = DEFAULT_CLOCK_ROTATION;
  clockEnabled                  = DEFAULT_CLOCK_ENABLED;
  clockSuntimesFont             = DEFAULT_SUNTIMES_FONT;
  clockSuntimesEnabled          = DEFAULT_SUNTIMES_ENABLED;
  historyTextFont               = DEFAULT_HISTORY_TEXT_FONT;
  weatherFont                   = DEFAULT_WEATHER_FONT;
  weatherTitleFont              = DEFAULT_WEATHER_TITLE_FONT;
  weatherTempFont               = DEFAULT_WEATHER_TEMP_FONT;
  weatherHumidFont              = DEFAULT_WEATHER_HUMID_FONT;
  weatherPressureFont           = DEFAULT_AIR_PRESSURE_FONT;
  weatherPressureUnitsFont      = DEFAULT_AIR_PRESSURE_UNITS_FONT;
  screenHeaderFont              = DEFAULT_SCREEN_HEADER_FONT;
  calendarDayFont               = DEFAULT_CALENDAR_DAY_FONT;
  astroHeaderFont               = DEFAULT_ASTRO_HEADER_FONT;
  astroTextFont                 = DEFAULT_ASTRO_TEXT_FONT;
  screensaverDimValue           = DEFAULT_SCREENSAVER_DIM;
  screensaverTimeout            = DEFAULT_SCREENSAVER_TIMEOUT;
  pixelShiftEnabled             = DEFAULT_PIXEL_SHIFT_ENABLED;
  pixelShiftInterval            = DEFAULT_PIXEL_SHIFT_INTERVAL;
  pixelShiftRange               = DEFAULT_PIXEL_SHIFT_RANGE;
  touchEnabled                  = DEFAULT_TOUCH_ENABLED;
  nightModeEnabled              = DEFAULT_NIGHTMODE_ENABLED;
  nightModeBrightness           = DEFAULT_NIGHTMODE_BRIGHTNESS;
  nightModeWakeBrightness       = DEFAULT_NIGHTMODE_WAKE_BRIGHTNESS;
  nightClockTimeColor           = DEFAULT_NIGHT_TIME_COLOR;
  nightClockDateColor           = DEFAULT_NIGHT_DATE_COLOR;
  nightClockBgColor             = DEFAULT_NIGHT_BG_COLOR;
  nightClockSuntimesColor       = DEFAULT_NIGHT_SUNTIMES_COLOR;
  sunsetOffset                  = DEFAULT_SUNSET_OFFSET;
  sunriseOffset                 = DEFAULT_SUNRISE_OFFSET;
  calendarDarkMode              = DEFAULT_CALENDAR_DARK_MODE;
  weatherDarkMode               = DEFAULT_WEATHER_DARK_MODE;
  menuDarkMode                  = DEFAULT_MENU_DARK_MODE;
  historyDarkMode               = DEFAULT_HISTORY_DARK_MODE;
  astroDarkMode                 = DEFAULT_ASTRO_DARK_MODE;
  clockDarkMode                 = DEFAULT_CLOCK_DARK_MODE;
  weatherCycleEnabled           = DEFAULT_WEATHER_CYCLE_ENABLED;
  calendarCycleEnabled          = DEFAULT_CALENDAR_CYCLE_ENABLED;
  weatherShowDuration           = WEATHER_SHOW_DURATION;
  weatherCycleInterval          = WEATHER_CYCLE_INTERVAL;
  calendarShowDuration          = CALENDAR_SHOW_DURATION;
  calendarCycleInterval         = CALENDAR_CYCLE_INTERVAL;
  nightModeWakeDuration         = DEFAULT_NIGHTMODE_WAKE_DURATION;
  tempCelsius                   = TEMP_CELSIUS;
  tempActual                    = TEMP_ACTUAL;
  tempAlternate                 = DEFAULT_TEMP_ALTERNATION_MODE;
  apAlternate                   = DEFAULT_AP_ALTERNATION_MODE;
  highPriorityAlternateInterval = DEFAULT_HIGH_PRIORITY_ALTERNATE * 1000;
  normalOverrideEnabled         = DEFAULT_NORMAL_OVERRIDE_ENABLED;
  normalOverrideDuration        = DEFAULT_NORMAL_OVERRIDE_DURATION;
  pulseMaxBrightness            = DEFAULT_PULSE_MAX_BRIGHTNESS;
  pulseMinBrightness            = DEFAULT_PULSE_MIN_BRIGHTNESS;
  clockColorsCustomized         = false;
  maxMsgAge                     = MESSAGE_HISTORY_MAX_AGE_HOURS;

  applyDefaultClockPaletteFromMode();   //clockDarkMode set above (needed before applying default clock palette)

  DEBUG_PRINTLN("Settings reset complete - please restart device");
}
