/*
 * Colors.h
 * 
 * RGB565 Color Definitions
 * Separated from HelpFunctions.h to avoid circular includes
 */

#ifndef COLORS_H
#define COLORS_H

//=============================================================
// Color Definitions (RGB565)
//=============================================================
#define COLOR_BLACK      0x0000
#define COLOR_WHITE      0xFFFF
#define COLOR_OFF_WHITE  0xF7BD
#define COLOR_RED        0xF800
#define COLOR_GREEN      0x07E0
#define COLOR_DARK_GREEN 0x0408
#define COLOR_BLUE       0x001F
#define COLOR_CYAN       0x07FF
#define COLOR_YELLOW     0xFFE0
#define COLOR_MAGENTA    0xF81F
#define COLOR_ORANGE     0xFD20
#define COLOR_PURPLE     0x8010
#define COLOR_PINK       0xFE19
#define COLOR_BROWN      0xA145
#define COLOR_LIGHTGRAY  0xC618
#define COLOR_GRAY       0x8410 
#define COLOR_DARKGRAY   0x528A
#define COLOR_CHARCOAL   0x2925
#define COLOR_GRAY10     0x18C3  // 10% gray
#define COLOR_GRAY20     0x31A6  // 20% gray
#define COLOR_GRAY30     0x4A69  // 30% gray
#define COLOR_GRAY40     0x632C  // 40% gray
#define COLOR_GRAY50     0x8410  // 50% gray (same as COLOR_GRAY)
#define COLOR_GRAY60     0x9CD3  // 60% gray
#define COLOR_GRAY70     0xB596  // 70% gray
#define COLOR_GRAY80     0xCE59  // 80% gray
#define COLOR_GRAY90     0xE73C  // 90% gray

#endif // COLORS_H
