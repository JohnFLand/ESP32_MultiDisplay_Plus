//=============================================================
// ElecrowHW.ino — Elecrow CrowPanel Advance 5" hardware drivers
//
//  Backlight / buzzer MCU: STC8H1K28 at I2C address 0x30
//
//  Brightness codes (0x05–0x10):
//    0x05 = off, 0x06–0x09 = levels 1–4, 0x10 = full (level 5)
//
//  elecrowBrightnessToCode()  — maps 0-5 user level to I2C code
//  elecrowBacklightWriteRaw() — sends a raw I2C code to the MCU
//  elecrowApplyBrightness()   — converts level then writes (used as
//                               the hardware callback for RGBPanelGFXBridge)
//
//  These were previously defined at the bottom of the main .ino.
//  Keeping them here isolates the board-specific HAL from application logic.
//=============================================================

static uint8_t elecrowBrightnessToCode(uint8_t brightness) {
  //Map 0-5 brightness level to the six I2C codes the Elecrow backlight
  //controller accepts (confirmed by exhaustive I2C probe on the hardware).
  switch (constrain(brightness, 0, 5)) {
    case 0:  return 0x05;
    case 1:  return 0x06;
    case 2:  return 0x07;
    case 3:  return 0x08;
    case 4:  return 0x09;
    default: return 0x10;   //case 5 — full brightness
  }
}

void elecrowBacklightWriteRaw(uint8_t level) {
  Wire.beginTransmission(ELECROW_BACKLIGHT_ADDR);
  Wire.write(level);
  Wire.endTransmission();
}

void elecrowApplyBrightness(uint8_t brightness) {
  elecrowBacklightWriteRaw(elecrowBrightnessToCode(brightness));
}
