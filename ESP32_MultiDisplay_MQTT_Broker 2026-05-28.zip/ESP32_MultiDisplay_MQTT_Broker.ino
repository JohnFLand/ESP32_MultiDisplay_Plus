/*
  ESP32_MultiDisplay_MQTT_Broker
  -----------------------
  Author:   John Land
  Date:     2026-05-22
*/
const char* Version = "3.1-EL-MQTT";
/*
  PURPOSE:
    - HTTP-controlled message display for ESP32-S3 with a 4.3" or 5.0" capacitive touch screen.
    - Displays messages, clock, weather, and calendar on the ELECROW CrowPanel Advance 4.3" & 5.0" (800x480).

  HARDWARE:
    - ELECROW CrowPanel Advance 5.0" or CrowPanel Advance 4.3" HMI ESP32-S3
    - 16MB Flash, 8MB OPI PSRAM
    - 800x480 RGB parallel display (ST7262-class panel via Arduino_GFX RGB backend)
    - GT911 capacitive touch (direct I2C read on GPIO 15/16)
    - Backlight MCU at I2C 0x30
    - Backlight is stepped over I2C (0x05..0x10) via the onboard backlight controller

  COMPILER ENVIRONMENT:
    - Arduino IDE 2.3.8
    - ESP32S3 Dev Module, 
    - ESP32 board package 3.3.8
    - PSRAM: OPI PSRAM, Flash Size: 16MB, custom partition: "partitions.csv"
    - USB CDC on Boot: *************** DISABLED ***************
    - Critical Libraries: 
        * Arduino_GFX_Library 1.6.5, a.k.a. "GFX Library for Arduino" (for RGB panel + PSRAMCanvas) 
        * Wire
        * LovyanGFX 1.2.21 (important, older versions conflicted with newer board packages)
    - 
  KEY FEATURES:
    - MQTT broker on port 1883 (sMQTTBroker — see MQTTBroker.ino)
    - CYD display forwarding via parallel HTTP POST
    - HTTP message API (JSON POST & GET)
    - Clock with NTP sync, configurable fonts/colors/formats
    - Weather & Calendar screens
    - Message history (persistent storage)
    - Touch controls & screensaver
    - Night mode (auto-dim at sunset/sunrise)
    - 18-command /control endpoint for automation
    - Web logging & OTA updates

  QUICK START:
    1. Navigate to: http://YOUR_IP/
    2. Use web form to send test message
    3. Configure clock at: http://YOUR_IP/clockconfig
    4. Full API documentation: See README.md

  WEB INTERFACE:
    http://YOUR_IP/          - Interactive form + quick reference
    http://YOUR_IP/status    - Device status & message history
    http://YOUR_IP/logs      - Debug logs (if enabled)

  DOCUMENTATION:
    Complete API reference, examples, and troubleshooting in README.md.

  ============================== LICENSE =====================================

  Dedicated to the public domain in 2025.

  Unless required by applicable law or agreed to in writing, this software is
  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
  either express or implied.
*/

//============================================================
//Included libraries
//============================================================
#include "secrets.h"
#include "MQTTBroker.h"           // MQTT broker public API (class is in MQTTBroker.cpp)
#include <Arduino_GFX_Library.h>
#include <Wire.h>
#include <WiFi.h> 
#include <WebServer.h>  
#include <ArduinoJson.h>  
#include <time.h> 
#include <Preferences.h>  
#include "weather_icons_gfx.h"    //Weather icons (RGB565 format)
#include <HTTPClient.h>           //Weather API
#include "User_Setup.h"           //Must be BEFORE HelpFunctions.h (for COLOR_ constants)
#include "HTML.h" 
#include "WebDebugLog.h"  
#include "PSRAM_Helpers.h"  
#include "HelpFunctions.h"  
#if ENABLE_ARDUINO_OTA
  #include <ArduinoOTA.h>           //For Arduino IDE OTA
#endif
#include <Update.h>               //For web OTA
#include <utility>                //FOR C++ utility functions, like "move"
#include "AstroCalc.h"            //Sun & Moon astronomical calculations
#include "DeviceInfo.h"           //Outputs device metadata for debugging

//ESP32-S3 ROM function for RF noise floor measurement, returns 1/4 dBm units
extern "C" { int rom_check_noise_floor(void); }

//=============================================================
// Display Objects — ELECROW Advance 4.3" or 5.0" via Arduino_GFX RGB backend
//   lcd    : Arduino_RGB_Display driving the ESP32-S3 RGB peripheral
//   bridge : wraps lcd as an Arduino_GFX output target for PSRAMCanvas
//            and forwards brightness changes to the Elecrow backlight controller
//   gfx    : PSRAMCanvas — all drawing goes here, flushed to lcd via bridge
//=============================================================
static constexpr int     ELECROW_I2C_SDA        = 15;
static constexpr int     ELECROW_I2C_SCL        = 16;
static constexpr uint8_t ELECROW_BACKLIGHT_ADDR = 0x30;
static constexpr uint8_t ELECROW_TOUCH_ADDR     = 0x5D;

Arduino_ESP32RGBPanel* rgbpanel = nullptr;
Arduino_RGB_Display*   lcd      = nullptr;
RGBPanelGFXBridge*     bridge   = nullptr;
PSRAMCanvas*           gfx      = nullptr;
Preferences preferences;

//RGB stability tuning for ELECROW Advance
// These defaults favor a rock-steady image over maximum refresh speed.
// 14 MHz is the lowest stable PCLK for this Elecrow ST7262 setup.
// 13 MHz and lower cause panel color-cycling / loss of valid sync.
static constexpr int32_t ELECROW_RGB_PCLK_HZ        = 16000000; //THIS IS A MINIMUM, DO NOT GO LOWER
static constexpr bool    ELECROW_COPY_EACH_FLUSH    = false;    //was = true in early testing
static constexpr uint8_t ELECROW_HSYNC_FRONT_PORCH  = 8;
static constexpr uint8_t ELECROW_HSYNC_PULSE_WIDTH  = 4;
static constexpr uint8_t ELECROW_HSYNC_BACK_PORCH   = 8;
static constexpr uint8_t ELECROW_VSYNC_FRONT_PORCH  = 8;
static constexpr uint8_t ELECROW_VSYNC_PULSE_WIDTH  = 4;
static constexpr uint8_t ELECROW_VSYNC_BACK_PORCH   = 8;
static constexpr bool    ELECROW_PCLK_ACTIVE_NEG    = true;
static constexpr bool    ELECROW_DE_IDLE_HIGH       = false;
static constexpr bool    ELECROW_PCLK_IDLE_HIGH     = true;
static constexpr bool    ELECROW_LCD_AUTO_FLUSH     = false;
static constexpr size_t  ELECROW_BOUNCE_BUFFER_PX   = DISPLAY_LONG * 20; //20 scanlines = 32 KB DRAM

// Board-specific helpers — implementations in ElecrowHW.ino
bool elecrowReadTouchRaw(uint16_t& x, uint16_t& y);
bool elecrowTouchProbe();
void elecrowBacklightWriteRaw(uint8_t level);
void elecrowApplyBrightness(uint8_t brightness);

using ulong = unsigned long;  //Create an alias for the type "unsigned long"

//=============================================================
//Web Server
//=============================================================
WebServer server(80);

//Timestamp of the compilation time
char Timestamp[20];           //"YYYY-MM-DD_HH:MM" — built once in setup() from __DATE__/__TIME__

//=============================================================
//Device Identification (from HelpFunctions.cpp)
//=============================================================
String deviceID                 = "";
String deviceName               = "";
String otaPassword              = "";  //persisted in Preferences via /otapassword

//=============================================================
//Current Message Parameters (for display)
//=============================================================
String currentMessage           = DEFAULT_MESSAGE;
uint16_t currentBgColor         = DEFAULT_BG_COLOR;
uint16_t currentTextColor       = DEFAULT_TEXT_COLOR;
int currentFont                 = DEFAULT_FONT;
int currentRotation             = DEFAULT_ROTATION;
String currentHAlign            = DEFAULT_H_ALIGN;
String currentVAlign            = DEFAULT_V_ALIGN;
uint8_t currentBrightness       = DEFAULT_BRIGHTNESS;
uint8_t scheduledBrightness     = 5;                              //Brightness set by scheduler (applied to non-clock screens & clock when night mode is off)

//Message timing & priority
String messagePriority          = DEFAULT_PRIORITY;
int messageExpirationTime       = DEFAULT_EXPIRATION_TIME;  //seconds
ulong lastMessageTime           = 0;                        //Timestamp of last message
ulong messageDisplayStartTime   = 0;
bool messageActive              = false;                    //Is a message currently displayed?

//=============================================================
//Advanced Message Parameters
//=============================================================

//Text wrapping and scrolling
bool currentWrap                = DEFAULT_WRAP;
String currentScrollDirection   = DEFAULT_SCROLL_DIRECTION;
uint8_t currentScrollSpeed      = DEFAULT_SCROLL_SPEED;
int scrollOffset                = 0;                             //Current scroll position (pixels)
ulong lastScrollUpdate          = 0;                             //Last time scroll was updated

//Flashing effect
bool currentFlash               = DEFAULT_FLASH;
ulong currentFlashInterval      = DEFAULT_FLASH_INTERVAL;
bool isFlashing                 = false;                          //Is message currently flashing?
bool flashSwapState             = false;                          //Current flash state (swapped or normal)
ulong lastFlashTime             = 0;                              //Last time flash swapped

//Pulsing brightness effect
bool currentPulse               = DEFAULT_PULSE;
ulong currentPulseDuration      = DEFAULT_PULSE_DURATION;
bool isPulsing                  = false;                          //Is brightness currently pulsing?
ulong pulseStartTime            = 0;                              //When pulse cycle started
uint8_t pulseMaxBrightness      = DEFAULT_PULSE_MAX_BRIGHTNESS;
uint8_t pulseMinBrightness      = DEFAULT_PULSE_MIN_BRIGHTNESS;
uint8_t actualCurrentBrightness = 5;                              //Track actual brightness for pulsing
//Deferred brightness: setBrightness() sets these; the main loop applies the I2C write
//at a safe point (top of loop) so it never races with a DMA tail-flush in flight.
static bool    g_pendingBrightnessChange = true;                  //true = I2C write needed; prime on boot
static uint8_t g_pendingBrightnessVal    = 5;

//High priority message queue
struct HighPriorityMessage {
  String    message;
  uint16_t  bgColor;
  uint16_t  textColor;
  int       font;
  int       rotation;
  String    hAlign;
  String    vAlign;
  bool      wrap;
  String    scrollDir;
  uint8_t   scrollSpeed;
  uint8_t   brightness;
  bool      flash;
  ulong     flashInterval;
  bool      pulse;
  ulong     pulseDuration;
  int       expirationTime;
  ulong     startTime;
  bool      active;
};

//Normal message queue (used when a high-priority message is currently active)
struct QueuedNormalMessage {
  String    message;
  uint16_t  bgColor;
  uint16_t  textColor;
  int       font;
  int       rotation;
  String    hAlign;
  String    vAlign;
  bool      wrap;
  String    scrollDir;
  uint8_t   scrollSpeed;
  uint8_t   brightness;
  bool      flash;
  ulong     flashInterval;
  bool      pulse;
  ulong     pulseDuration;
  int       expirationTime;
  ulong     queuedTime;
};

HighPriorityMessage highPriorityMessages[MAX_HIGH_PRIORITY_MESSAGES];
int highPriorityMessageCount        = 0;
int currentHighPriorityIndex        = 0;
ulong lastHighPriorityAlternateTime = 0;
int currentHistoryIndex             = 0;                                       //Which message in history we're viewing
int highPriorityAlternateInterval   = DEFAULT_HIGH_PRIORITY_ALTERNATE * 1000;  //Convert seconds to ms

//Buzzer
bool  buzzerEnabled                 = DEFAULT_BUZZER_ENABLED;
int   buzzerBeepInterval            = DEFAULT_BUZZER_INTERVAL;  //Seconds between repeat beeps while high priority is active
ulong lastHighPriorityBeepTime      = 0;                        //millis() of the most recent high-priority beep

//Normal override settings
bool normalOverrideEnabled          = DEFAULT_NORMAL_OVERRIDE_ENABLED;
int  normalOverrideDuration         = DEFAULT_NORMAL_OVERRIDE_DURATION;
bool inNormalOverride               = false;
ulong normalOverrideStartTime       = 0;
int  savedHighPriorityIndex         = -1;

QueuedNormalMessage normalMessageQueue[MAX_NORMAL_QUEUED_MESSAGES];
int normalQueueHead                 = 0;
int normalQueueTail                 = 0;
int normalQueueCount                = 0;

Message messages[MAX_MESSAGES];
int messageCount                    = 0;
int unreadCount                     = 0;
int maxMsgAge                       = MESSAGE_HISTORY_MAX_AGE_HOURS;  //Hours before messages are purged; 0 = disabled (persisted in NVRAM)

//=============================================================
//Clock Configuration
//=============================================================
int clockTimeFont                   = DEFAULT_TIME_FONT;
int clockDateFont                   = DEFAULT_DATE_FONT;
int labelFont                       = DEFAULT_LABEL_FONT;
int msgNoticeFont                   = DEFAULT_MSG_NOTICE_FONT;
uint16_t labelColor                 = DEFAULT_LABEL_COLOR;
uint16_t msgNoticeColor             = DEFAULT_MSG_NOTICE_COLOR;
//Clock colors: start with the DEFAULT dark/light palette until the user customizes colors via web UI/GET/POST
bool clockColorsCustomized          = false;
uint16_t clockTimeColor             = DEFAULT_CLOCK_DARK_MODE ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
uint16_t clockDateColor             = DEFAULT_CLOCK_DARK_MODE ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
uint16_t clockBgColor               = DEFAULT_CLOCK_DARK_MODE ? DEFAULT_CLOCK_BG_COLOR   : DEFAULT_CLOCK_BG_COLOR_L;
String clockTimeFormat              = DEFAULT_CLOCK_TIME_FORMAT;
String clockDateFormat              = DEFAULT_CLOCK_DATE_FORMAT;
uint8_t screenBrightness            = DEFAULT_SCREEN_BRIGHTNESS;
int clockRotation                   = DEFAULT_CLOCK_ROTATION;
bool clockEnabled                   = DEFAULT_CLOCK_ENABLED;
bool showClock                      = true;
uint8_t clockSuntimesFont           = DEFAULT_SUNTIMES_FONT;
uint16_t clockSuntimesColor         = DEFAULT_CLOCK_DARK_MODE ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;

//Screen-specific font runtime variables
int menuFont                        = DEFAULT_MENU_FONT;
uint8_t historyTextFont             = DEFAULT_HISTORY_TEXT_FONT;
uint8_t weatherFont                 = DEFAULT_WEATHER_FONT;
uint8_t weatherTitleFont            = DEFAULT_WEATHER_TITLE_FONT;
uint8_t weatherTempFont             = DEFAULT_WEATHER_TEMP_FONT;
uint8_t weatherHumidFont            = DEFAULT_WEATHER_HUMID_FONT;
uint8_t weatherPressureFont         = DEFAULT_AIR_PRESSURE_FONT;
uint8_t weatherPressureUnitsFont    = DEFAULT_AIR_PRESSURE_UNITS_FONT;
uint8_t screenHeaderFont            = DEFAULT_SCREEN_HEADER_FONT;
uint8_t calendarDayFont             = DEFAULT_CALENDAR_DAY_FONT;
uint8_t astroHeaderFont             = DEFAULT_ASTRO_HEADER_FONT;
uint8_t astroTextFont               = DEFAULT_ASTRO_TEXT_FONT;

//Night-mode clock color profile (applied when nightModeActive && !nightModeWakeActive)
uint16_t nightClockTimeColor        = DEFAULT_NIGHT_TIME_COLOR;
uint16_t nightClockDateColor        = DEFAULT_NIGHT_DATE_COLOR;
uint16_t nightClockBgColor          = DEFAULT_NIGHT_BG_COLOR;
uint16_t nightClockSuntimesColor    = DEFAULT_NIGHT_SUNTIMES_COLOR;
bool clockSuntimesEnabled           = DEFAULT_SUNTIMES_ENABLED;  //Toggle sunrise/sunset display on clock

//Screensaver
uint8_t screensaverDimValue         = DEFAULT_SCREENSAVER_DIM;
ulong screensaverTimeout            = DEFAULT_SCREENSAVER_TIMEOUT;
bool screensaverActive              = false;
bool screensaverWake                = false;    //True when current touch is just waking the screensaver
uint8_t savedBrightness             = 5;
ulong lastActivity                  = 0;

//Sunrise/Sunset (with reasonable defaults for Portland)
//Today
int sunriseHour                     = 7;            //7:30 AM default
int sunriseMinute                   = 30;
int sunsetHour                      = 17;           //5:15 PM default
int sunsetMinute                    = 15;
//Tomorrow        
int tomorrowSunriseHour             = 7;            //same defaults until first fetch
int tomorrowSunriseMinute           = 30;
int tomorrowSunsetHour              = 17;
int tomorrowSunsetMinute            = 15;
bool sunTimesValid                  = true;         //Set to true so they display by default

//Pixel shifting for burn-in prevention
bool pixelShiftEnabled              = DEFAULT_PIXEL_SHIFT_ENABLED;
ulong pixelShiftInterval            = 300000;       //5 minutes for LCD
int pixelShiftRange                 = 10;           //±10 pixels for LCD
int clockOffsetX                    = 0;            //Current X offset
int clockOffsetY                    = 0;            //Current Y offset
ulong lastPixelShift                = 0;            //Last shift time

//=============================================================
//Touch State
//=============================================================
bool touchEnabled = DEFAULT_TOUCH_ENABLED;
enum TouchState {
  TOUCH_IDLE,
  TOUCH_PRESSED,
  TOUCH_HELD,
  TOUCH_RELEASED
};

TouchState touchState               = TOUCH_IDLE;
uint16_t touchPressX                = 0;
uint16_t touchPressY                = 0;
uint16_t touchReleaseX              = 0;
uint16_t touchReleaseY              = 0;
uint16_t lastTouchX                 = 0;
uint16_t lastTouchY                 = 0;
ulong touchPressTime                = 0;
ulong lastScreenChange              = 0;
ulong weatherCycleStartTime         = 0;
bool weatherAutoShowing             = false;
bool weatherCycleEnabled            = DEFAULT_WEATHER_CYCLE_ENABLED;
ulong weatherShowDuration           = WEATHER_SHOW_DURATION;    //ms - how long weather screen shows during auto-cycle
ulong weatherCycleInterval          = WEATHER_CYCLE_INTERVAL;   //ms - how long between auto weather shows
ulong calendarCycleStartTime        = 0;
bool calendarAutoShowing            = false;
bool calendarCycleEnabled           = DEFAULT_CALENDAR_CYCLE_ENABLED;
ulong calendarShowDuration          = CALENDAR_SHOW_DURATION;   //ms - how long calendar screen shows during auto-cycle
ulong calendarCycleInterval         = CALENDAR_CYCLE_INTERVAL;  //ms - how long between auto calendar shows
bool cycleWeatherTurn               = true;   //When both cycles enabled: true=show weather next, false=show calendar next
bool cycleInitiatedReturn           = false;  //Set by autoCycleTick before calling changeScreen(SCREEN_CLOCK) so changeScreen
                                              //knows NOT to reset the timers that autoCycleTick already set correctly.
const ulong SCREEN_CHANGE_COOLDOWN  = 300;

#define TOUCH_DEBOUNCE_MS 50

//=============================================================
//Weather data
//=============================================================
bool    tempAlternate                = DEFAULT_TEMP_ALTERNATION_MODE;  //true=alternate between actual & apparent every DEFAULT_TEMP_ALTERNATION_TIME seconds
bool    tempCelsius                  = TEMP_CELSIUS;            //Temperature unit: true=°C, false=°F
bool    tempActual                   = TEMP_ACTUAL;             //true=actual temp, false=apparent (feels-like)
bool    tempAlternateShowActual      = true;                    //tracks which temp is currently shown when alternating
ulong   lastTempAlternation          = 0;                       //millis() of last temp alternation
String  weatherLocation              = LOCATION;                //persisted; fallback default from secrets.h
String  weatherLatitude              = LATITUDE;                //persisted; fallback default from secrets.h
String  weatherLongitude             = LONGITUDE;               //persisted; fallback default from secrets.h
String  weatherTimezone              = TIMEZONE;                //persisted; fallback default from secrets.h
String  weatherTzString              = TZ_STRING;               //persisted; fallback default from secrets.h
String  weatherAltitude              = ALTITUDE;                //persisted; elevation in metres for SLP correction
float   weatherTemp                  = 0.0;
float   weatherApparentTemp          = 0.0;
int     weatherHumidity              = 0;
float   weatherPressure              = 0.0;

// ── Local pressure (fetched from Hubitat, averaged across online sensors) ──
bool   apAlternate                   = DEFAULT_AP_ALTERNATION_MODE;    //Air pressure alternation (mirrors temp pattern)
bool   apAlternateShowLocal          = true;                    //true = show local avg, false = show open-meteo (~prefixed)
ulong  lastApAlternation             = 0;
bool   localPressureValid            = false;
float  localPressureHpa              = 0.0f;
float  localWindDeg                  = NAN;   //wind direction degrees from Hubitat (NAN until first reading)
float  localTemp                     = NAN;   //local outdoor temperature from Hubitat (NAN until first reading)
float  localHumidity                 = NAN;   //local outdoor humidity % from Hubitat (NAN until first reading)
ulong  lastLocalPressureReceived     = 0;
ulong  lastLocalPressureFetch        = 0;                       //millis() of last Hubitat pressure fetch

int    weatherCode                   = 0;
String weatherDescription            = "";
bool   weatherIsDay                  = true;
String weatherLastUpdate             = "";
ulong  lastWeatherFetch              = 0;
// ── Daily forecast (from Open-Meteo &daily= block) ──────────────────────────
float  dailyTempMax                  = 0.0f;   // temperature_2m_max
float  dailyApparentTempMax          = 0.0f;   // apparent_temperature_max
float  dailyTempMin                  = 0.0f;   // temperature_2m_min
float  dailyApparentTempMin          = 0.0f;   // apparent_temperature_min
float  dailyPrecipitationSum         = 0.0f;   // precipitation_sum
int    dailyPrecipProbMax            = 0;       // precipitation_probability_max (%)
//Sunrise/Sunset — defaults for user's location in Secrets.h; overwritten by computed astro data once available
//Still used by shouldNightModeBeActive() and checkScheduledActions() for relative schedules

//=============================================================
//Night Mode
//=============================================================
bool nightModeEnabled               = DEFAULT_NIGHTMODE_ENABLED;
uint8_t nightModeBrightness         = DEFAULT_NIGHTMODE_BRIGHTNESS;
uint8_t nightModeWakeBrightness     = DEFAULT_NIGHTMODE_WAKE_BRIGHTNESS;
int sunsetOffset                    = DEFAULT_SUNSET_OFFSET;            //Minutes offset
int sunriseOffset                   = DEFAULT_SUNRISE_OFFSET;           //Minutes offset
bool nightModeActive                = false;                            //Current state
ulong lastNightModeCheck            = 0;                                //Last check time
ulong lastHistoryPurge              = 0;                                //Last hourly message-history purge (millis)
bool nightModeWakeActive            = false;                            //Display temporarily brightened by touch
ulong nightModeWakeDuration         = DEFAULT_NIGHTMODE_WAKE_DURATION;  //ms - how long touch wakes display during night mode
ulong nightModeWakeEndTime          = 0;                                //millis() when wake period expires

//=============================================================
//Calendar
//=============================================================
bool calendarScreenActive           = false;
int calendarViewMonth               = 0;    //0-11: month currently displayed (may differ from today)
int calendarViewYear                = 2000; //year currently displayed

//=============================================================
//Astro Screen
//=============================================================
bool astroShowMoon                  = false; //false = show Sun page, true = show Moon page
bool aboutSubPage                   = false; //false = page 1 (device info), true = page 2 (location)
bool weatherSubPage                 = false; //false = page 1 (current), true = page 2 (pressure trend)
int  astroDateOffset                = 0;     //Days offset from today for the astro screen view

//Cached astro data – recomputed once per calendar day
static AstroData cachedAstro;
static int astroDataYear            = -1;
static int astroDataMonth           = -1;
static int astroDataDay             = -1;

static AstroData tomorrowAstro;
static int tomorrowAstroYear        = -1;
static int tomorrowAstroMonth       = -1;
static int tomorrowAstroDay         = -1;

//Astro screen view data – recomputed when astroDateOffset changes
static AstroData viewedAstro;
static int viewedAstroYear          = -1;
static int viewedAstroMonth         = -1;
static int viewedAstroDay           = -1;

//=============================================================
//Screen Modes
//=============================================================
enum ScreenMode {
  SCREEN_NONE = -1,
  SCREEN_CLOCK,
  SCREEN_MENU,
  SCREEN_MESSAGE,  //Dedicated message display mode
  SCREEN_MESSAGES,
  SCREEN_WEATHER,
  SCREEN_CALENDAR,
  SCREEN_ASTRO,
  SCREEN_ABOUT
};
ScreenMode currentScreen = SCREEN_CLOCK;
volatile ScreenMode pendingScreen = SCREEN_NONE;

//=============================================================
//Dark Mode Flags
//=============================================================
bool clockDarkMode                  = DEFAULT_CLOCK_DARK_MODE;
bool calendarDarkMode               = DEFAULT_CALENDAR_DARK_MODE;
bool weatherDarkMode                = DEFAULT_WEATHER_DARK_MODE;
bool menuDarkMode                   = DEFAULT_MENU_DARK_MODE;
bool historyDarkMode                = DEFAULT_HISTORY_DARK_MODE;
bool astroDarkMode                  = DEFAULT_ASTRO_DARK_MODE;

//=============================================================
//Scheduled Actions
//=============================================================
ScheduledAction schedules[MAX_SCHEDULES];
int lastCheckedMinute = -1;  //Track last minute checked

MsgProfile msgProfiles[MAX_MSG_PROFILES];       //Message Profiles (attributes only, no text)

//=============================================================
//Button Definitions
//=============================================================
//Button Definitions  (2-column, 3-row layout  DISPLAY_LONG×DISPLAY_SHORT screen)
//  800×480: Col 1 x=20..409  Col 2 x=420..809  BtnH=130  gaps=15
//=============================================================
struct Button {
  int x, y, w, h;
  const char* label;
  uint16_t color;
  ScreenMode targetScreen;
};

Button menuButtons[] = {
  //  x              y              w           h           label            color            target
  { MENU_BTN_X0, MENU_BTN_ROW0, MENU_BTN_W, MENU_BTN_H, "Clock",       COLOR_DARKGRAY,   SCREEN_CLOCK    },
  { MENU_BTN_X0, MENU_BTN_ROW1, MENU_BTN_W, MENU_BTN_H, "Weather",     COLOR_MAGENTA,    SCREEN_WEATHER  },
  { MENU_BTN_X0, MENU_BTN_ROW2, MENU_BTN_W, MENU_BTN_H, "Calendar",    COLOR_BROWN,      SCREEN_CALENDAR },
  { MENU_BTN_X1, MENU_BTN_ROW0, MENU_BTN_W, MENU_BTN_H, "Astro Times", COLOR_DARK_GREEN, SCREEN_ASTRO    },
  { MENU_BTN_X1, MENU_BTN_ROW1, MENU_BTN_W, MENU_BTN_H, "History",     COLOR_BLUE,       SCREEN_MESSAGES },
  { MENU_BTN_X1, MENU_BTN_ROW2, MENU_BTN_W, MENU_BTN_H, "About",       COLOR_PURPLE,     SCREEN_ABOUT    }
};
const int NUM_BUTTONS = 6;

//=============================================================
// UI Return Stack — struct + globals
//  These must live in the main .ino so they are visible to all
//  other .ino files regardless of alphabetical compile order.
//  Function implementations are in TouchInput.ino.
//=============================================================
struct UiReturnState {
  ScreenMode screen;
  int rotation;
  uint8_t brightness;
  bool textWrap;
};

constexpr size_t UI_RETURN_STACK_MAX = 6;
static UiReturnState uiReturnStack[UI_RETURN_STACK_MAX];
static size_t        uiReturnTop     = 0;

//Track the last textWrap state applied (Arduino_GFX has no getter)
static bool g_textWrapState = false;

void elecrowTCA9534BacklightOn() {
  // Config register 0x03: set pins 0-3 as outputs
  Wire.beginTransmission(0x18);
  Wire.write(0x03);
  Wire.write(0xF0);
  uint8_t r1 = Wire.endTransmission();

  // Output register 0x01: set pin 1 HIGH (backlight ON)
  Wire.beginTransmission(0x18);
  Wire.write(0x01);
  Wire.write(0x02);  // bit 1 = pin 1 HIGH
  uint8_t r2 = Wire.endTransmission();

  DEBUG_PRINTF("TCA9534 config=%d output=%d\n", r1, r2);
}

//===================================================================================================================
//===================================================================================================================
//Setup
//===================================================================================================================
//===================================================================================================================
void setup() {
  Serial.begin(115200);

  delay(2500);                            //let the serial monitor connection settle

  Serial.println("\n\n\n\n\n");
  DEBUG_PRINTLN("=== ELECROW CrowPanel Advanced 4.3/5.0\" HMI ESP32-S3 ===\n");

  deviceID   = getDeviceID();             //Get device ID from HelpFunctions.cpp
  deviceName = getDeviceName();           //Get device Name from HelpFunctions.cpp; function prints deviceID & deviceName

  buildTimestamp(__DATE__, __TIME__);     //Format compile-time __DATE__/__TIME__ into Timestamp global
  DEBUG_PRINTF("FW Version  : %s\n", Version);
  DEBUG_PRINTF("Built       : %s\n", Timestamp);

  //Initialize PSRAM
  if (!initPSRAM(8192)) {
    DEBUG_PRINTLN("\nWarning: PSRAM not available, using internal RAM only");
  } else {
    DEBUG_PRINTLN("✓ PSRAM initialized successfully");
    #if EXTENDED_DEBUG
      printMemoryStats();                 //Show initial memory state
    #endif
  }

  loadSettings();                         //Load basic settings from NVRAM

  loadSchedules();                        //Load schedules

  loadMsgProfiles();                      //Load message profiles

  //--- ELECROW Advance hardware init via Arduino_GFX RGB backend ---
  //    Display pins/timing follow Elecrow's official V1.1 Advance 4.3"/5.0" mapping.
  //    Touch is read directly from GT911 over I2C (GPIO 15/16, addr 0x5D).
  //    Backlight is controlled by the onboard MCU at I2C address 0x30.

  // Wire.begin(ELECROW_I2C_SDA, ELECROW_I2C_SCL);
  // Wire.setClock(100000);

  #if DEEP_DEBUG
    DEBUG_PRINTLN("✓ Touch/backlight I2C set to 100 kHz for GT911 stability test");
  #endif

  rgbpanel = new Arduino_ESP32RGBPanel(
    42 /* DE */, 41 /* VSYNC */, 40 /* HSYNC */, 39 /* PCLK */,
     7 /* R0 */, 17 /* R1 */, 18 /* R2 */,  3 /* R3 */, 46 /* R4 */,
     9 /* G0 */, 10 /* G1 */, 11 /* G2 */, 12 /* G3 */, 13 /* G4 */, 14 /* G5 */,
    21 /* B0 */, 47 /* B1 */, 48 /* B2 */, 45 /* B3 */, 38 /* B4 */,
     0 /* hsync_polarity */, ELECROW_HSYNC_FRONT_PORCH /* hsync_front_porch */, ELECROW_HSYNC_PULSE_WIDTH /* hsync_pulse_width */, ELECROW_HSYNC_BACK_PORCH /* hsync_back_porch */,
     0 /* vsync_polarity */, ELECROW_VSYNC_FRONT_PORCH /* vsync_front_porch */, ELECROW_VSYNC_PULSE_WIDTH /* vsync_pulse_width */, ELECROW_VSYNC_BACK_PORCH /* vsync_back_porch */,
     ELECROW_PCLK_ACTIVE_NEG ? 1 : 0 /* pclk_active_neg */, ELECROW_RGB_PCLK_HZ /* prefer_speed */, false /* useBigEndian */,
     ELECROW_DE_IDLE_HIGH ? 1 : 0 /* de_idle_high */, ELECROW_PCLK_IDLE_HIGH ? 1 : 0 /* pclk_idle_high */,
     ELECROW_BOUNCE_BUFFER_PX /* bounce_buffer_size_px */
  );

  lcd = new Arduino_RGB_Display(DISPLAY_LONG, DISPLAY_SHORT, rgbpanel, 0 /* rotation */, ELECROW_LCD_AUTO_FLUSH /* auto_flush */);

  //Create bridge and canvas now that RGB objects exist
  bridge = new RGBPanelGFXBridge(lcd, DISPLAY_LONG, DISPLAY_SHORT, elecrowApplyBrightness,
                                 ELECROW_COPY_EACH_FLUSH);
  gfx    = new PSRAMCanvas(DISPLAY_LONG, DISPLAY_SHORT, bridge, 0, 0, 0);
  gfx->begin();

  //Prime the backlight and push a clean first frame

  gfx->fillScreen(0x0000);
  for (int i = 0; i < 5; i++) {
    flushDisplay();
    delay(20);                            //~100ms total; covers 3+ full frame periods at 16MHz/800x480
  }
  DEBUG_PRINTLN("✓ Arduino_GFX RGB display initialized");

  Wire.begin(ELECROW_I2C_SDA, ELECROW_I2C_SCL);
  Wire.setClock(100000);

  delay(50);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
if (ELECROW_BACKLIGHT_ADDR == 0x18) {
  elecrowTCA9534BacklightOn();
} else {
  elecrowBacklightWriteRaw(0x10);
}
//------------------------------------------------------------
  
  #if DEEP_DEBUG
    DEBUG_PRINTF("  RGB stability mode: PCLK=%ld Hz, pclk_neg=%s, bounce_px=%u, auto_flush=%s, copy_each_flush=%s\n",
                (long)ELECROW_RGB_PCLK_HZ,
                ELECROW_PCLK_ACTIVE_NEG ? "true" : "false",
                (unsigned)ELECROW_BOUNCE_BUFFER_PX,
                ELECROW_LCD_AUTO_FLUSH ?  "true" : "false",
                ELECROW_COPY_EACH_FLUSH ? "true" : "false");
  #endif

  gfx->setRotation(getRotationIndex(currentRotation));  //honor DEFAULT_ROTATION / saved rotation

  doubleBeep();                           //Two beeps signal the display is initialised (I2C cmd 0x14 to 0x30)
  delay(500);

  showStartupScreen();                    //Show startup screen
  delay(2000);

  bool touchPresent = elecrowTouchProbe();
  DEBUG_PRINTLN("✓ Display touch initialized");
  #if DEEP_DEBUG
    DEBUG_PRINTF("✓ Touch probe at 0x%02X: %s\n", ELECROW_TOUCH_ADDR, touchPresent ? "present" : "not found");
    if (touchPresent) {
      elecrowGT911PrintInfo();
    }
  #endif

  connectWiFi();                          //Setup WiFi connection

  startWebServer();                       //Start web server

  startMqttBroker();                      //Start MQTT broker + CYD forwarder (MQTTBroker.ino)

  checkFirstBootReboot();                 //One-time reboot after fresh flash for RGB DMA frame sync

  fetchLocalPressure();                   //Get first local pressure reading immediately on boot
  delay(500);                             //let HTTP stack settle after local LAN air pressure fetch
  fetchLocalPressureViaMQTT();            //Get first local pressure via a pending MQTT message

  fetchWeather();                         //Fetch initial weather data
  delay(1000);                            //let HTTP stack settle after Internet weather fetch

  RTC_Init();                             //Initialize RTC (PCF8563) — must be after Wire.begin()

  NTP_Init();                             //Initialize NTP time (falls back to RTC if NTP fails)
  loadPressureBuffer();                   //Restore pressure history from LittleFS
  mqttHistoryReady = true;                //Signal NewClient handler: buffer loaded, safe to publish

  //Show initial screen (Clock) using the unified screen switcher (sets rotation, brightness, etc.)
  showClock       = true;
  currentScreen   = SCREEN_CLOCK;
  currentRotation = clockRotation;        //Ensure clock comes up in the configured/default clock rotation
  elecrowBacklightWriteRaw(0x10);         // ← direct write, bypasses deferred path entirely
  changeScreen(SCREEN_CLOCK);

  // Re-stabilise the RGB panel DMA after the heavy network phase —
  // mirrors the 5-flush pattern used during initial display bringup.
  for (int i = 0; i < 3; i++) {
      flushDisplay();
      delay(20);
  }

  weatherCycleStartTime  = millis();      //Guarantee full interval before 1st auto-cycle regardless of how long setup() took
  calendarCycleStartTime = millis();

  #if EXTENDED_DEBUG
    dumpEsp32Metadata();                  //Output ESP32 metadata for debugging
  #endif

  lastActivity = millis();                //Initialize screensaver timer

  // ★ Force immediate backlight write after first clock draw ★
  // The deferred path can miss if I2C bus is still settling from GT911 probe.
  if (bridge) bridge->applyDeferredBrightness(g_pendingBrightnessVal);  // writes I2C + updates bridge->_brightness
  g_pendingBrightnessChange = false;      // Already applied; skip the first loop drain

  DEBUG_PRINTLN("\n=== System Ready - Touch the screen to show Menu ===");
  DEBUG_PRINTF("  Send messages to: http://%s/message\n\n", WiFi.localIP().toString().c_str());

}

//===================================================================================================================
//===================================================================================================================
//Main Loop
//===================================================================================================================
//===================================================================================================================
void loop() {
  //Drain any queued brightness change first, before anything can trigger a
  //flushDisplay(). This is the only point in the execution path where we
  //can guarantee no RGB panel DMA is in flight, so I2C writes are safe here.
  if (g_pendingBrightnessChange) {
    if (bridge) bridge->applyDeferredBrightness(g_pendingBrightnessVal);
    g_pendingBrightnessChange = false;
  }

  if (pendingScreen != SCREEN_NONE) {
    ScreenMode req = pendingScreen;
    pendingScreen  = SCREEN_NONE;
    changeScreen(req);
  }
  handleTouchInput();              //Touch input handling

  checkScreensaver();

  checkMessageExpiration();        //Check if message should expire
  checkHighPriorityAlternation();  //Check if high priority messages should alternate
  checkHighPriorityBuzzer();       //Periodic beep while a high-priority message is active
  checkNormalOverride();           //Check if normal override should end
  checkTempAlternation();          //Check if temp display should alternate
  checkAPAlternation();            //Check if air pressure display should alternate

  //Screen-specific updates
  if (currentScreen == SCREEN_CLOCK) {
    updateClock();
    updatePixelShift();            //Update pixel shift
  } else if (currentScreen == SCREEN_MESSAGE) {
    handlePulsing();               //Handle message effects
    handleFlashing();
    handleScrolling();
  }

  updateLocalPressure();           //Update local pressure every LOCAL_PRESSURE_FETCH_INTERVAL minutes

  updateWeather();                 //Update weather every WEATHER_FETCH_INTERVAL minutes

  updateNightMode();               //Check night mode every 60 seconds
  autoCycleTick();

  checkScheduledActions();         //Check if any schedules should trigger

  //Hourly garbage-collection: purge messages older than MESSAGE_HISTORY_MAX_AGE_HOURS
  if (millis() - lastHistoryPurge >= 3600000UL) {
    lastHistoryPurge = millis();
    purgeOldMessages();
  }

  NTP_CheckSync();                 //Background NTP sync

  //Publish current UTC epoch + TZ string to MQTT_TOPIC_TIME every 60 s
  //CYDs subscribe and use this to stay in sync when internet NTP is unavailable
  { static ulong lastTimePublish = 0;
    if (millis() - lastTimePublish >= MQTT_TIME_PUBLISH_INTERVAL_MS) {
      lastTimePublish = millis();
      mqttPublishTime();
    }
  }

  checkWiFiHealth();               //SNR watchdog: soft reconnect or reboot if signal degrades
  
  server.handleClient();           //Web server
  
  mqttBrokerUpdate();              //MQTT broker client I/O (MQTTBroker.ino)
  
  #if ENABLE_ARDUINO_OTA
    ArduinoOTA.handle();             //Handle Arduino IDE Over-The-Air (OTA) updates
  #endif

  delay(10);
}
