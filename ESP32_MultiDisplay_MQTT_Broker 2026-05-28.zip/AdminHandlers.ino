//=============================================================
// AdminHandlers.ino  —  OTA updates, device reboot/reset,
//                        first-boot sync, and OTA password.
// Note: OTA security/upload functions consolidated here from
//       HelpFunctions.cpp where they did not logically belong.
//=============================================================

#if ENABLE_ARDUINO_OTA
  #include <ArduinoOTA.h>
#endif
#include <Update.h>

//=============================================================
//OTA Configuration
//=============================================================
extern String otaPassword;
extern const unsigned long OTA_LOCKOUT_TIME = 300000;
extern const int MAX_OTA_ATTEMPTS           = 5;
unsigned long lastFailedOTAAttempt          = 0;
int failedOTAAttempts                       = 0;
bool otaAuthenticationFailed                = false;
bool otaUpdateSuccessful                    = false;

//=============================================================
//Check OTA Security (Password + Rate Limiting)
//=============================================================
bool checkOtaSecurity() {
  //Check rate limiting
  if (failedOTAAttempts >= MAX_OTA_ATTEMPTS) {
    if (millis() - lastFailedOTAAttempt < OTA_LOCKOUT_TIME) {
      unsigned long remaining = (OTA_LOCKOUT_TIME - (millis() - lastFailedOTAAttempt)) / 1000;
      DEBUG_PRINTF("OTA: Rate limit exceeded. %lu seconds remaining\n", remaining);
      otaAuthenticationFailed = true;
      return false;
    } else {
      //Lockout expired, reset counter
      failedOTAAttempts = 0;
    }
  }
  
  //Check password
  String submittedPassword = server.arg("password");
  
  if (submittedPassword != otaPassword) {
    DEBUG_PRINTLN("OTA: Authentication failed - incorrect password");
    failedOTAAttempts++;
    lastFailedOTAAttempt = millis();
    otaAuthenticationFailed = true;
    return false;
  }
  
  //Success!
  DEBUG_PRINTLN("OTA: Authentication successful");
  failedOTAAttempts = 0;  //Reset on success
  otaAuthenticationFailed = false;
  return true;
}

//=============================================================
//Setup OTA Endpoints
//=============================================================
void setupOTAEndpoints() {
  //Web OTA form
  server.on("/update", HTTP_GET, handleOTAUpdateForm);
  
  //OTA upload handler - capture external variables with [&]
  server.on("/doupdate", HTTP_POST, [&]() {
    server.sendHeader("Connection", "close");
    
    if (otaAuthenticationFailed) {
      if (failedOTAAttempts >= MAX_OTA_ATTEMPTS) {
        unsigned long remaining = (OTA_LOCKOUT_TIME - (millis() - lastFailedOTAAttempt)) / 1000;
        server.send(429, "text/plain", "Too many failed attempts. Try again in " + String(remaining) + " seconds");
      } else {
        server.send(401, "text/plain", "Authentication failed");
      }
      return;
    }
    
    if (otaUpdateSuccessful) {
      server.send(200, "text/plain", "Update successful! Rebooting...");
      delay(100);
      ESP.restart();
      return;
    }
    
    if (Update.hasError()) {
      server.send(500, "text/plain", "Update failed: " + String(Update.errorString()));
    } else {
      server.send(200, "text/plain", "Update successful! Rebooting...");
      delay(100);
      ESP.restart();
    }
  }, handleOTAUpload);
  
  #if ENABLE_ARDUINO_OTA
    //Set ArduinoOTA password
    if (otaPassword.length() > 0) {
      ArduinoOTA.setPassword(otaPassword.c_str());
      DEBUG_PRINTF("\n✓ OTA password configured (%d chars)\n", otaPassword.length());
    } else {
      DEBUG_PRINTLN("\n⚠️  WARNING: OTA password not set!");
    }

    //ArduinoOTA callbacks
    ArduinoOTA.onStart([]() {
      DEBUG_PRINTLN("\nArduino OTA: Update starting");
    });

    ArduinoOTA.onEnd([]() {
      DEBUG_PRINTLN("\nArduino OTA: Update complete");
    });

    ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
      DEBUG_PRINTF("Arduino OTA Progress: %u%%\r", (progress / (total / 100)));
    });

    ArduinoOTA.onError([](ota_error_t error) {
      DEBUG_PRINTF("Arduino OTA Error[%u]: ", error);
      if      (error == OTA_AUTH_ERROR)    DEBUG_PRINTLN("Auth Failed");
      else if (error == OTA_BEGIN_ERROR)   DEBUG_PRINTLN("Begin Failed");
      else if (error == OTA_CONNECT_ERROR) DEBUG_PRINTLN("Connect Failed");
      else if (error == OTA_RECEIVE_ERROR) DEBUG_PRINTLN("Receive Failed");
      else if (error == OTA_END_ERROR)     DEBUG_PRINTLN("End Failed");
    });
  #endif  //#if ENABLE_ARDUINO_OTA
}

//=============================================================
// Handle OTA Upload — PSRAM-staged two-phase implementation
//
//  Phase 1 — WiFi → PSRAM (UPLOAD_FILE_WRITE):
//    Chunks are accumulated into a PSRAM buffer. No flash writes
//    occur, so the SPIRAM cache is never stalled and the display
//    runs normally. A smooth progress bar is shown throughout.
//    Beep every 5 seconds.
//
//  Phase 2 — PSRAM → Flash (UPLOAD_FILE_END):
//    The complete binary is written to flash in 32 KB chunks.
//    Before each chunk: backlight off (hides DMA starvation).
//    After each chunk: full green screen flushed and backlight on
//    briefly, giving a visible green flash between writes.
//    Beep every 5 seconds throughout.
//=============================================================
void handleOTAUpload() {
  HTTPUpload& upload = server.upload();

  //Staging buffer — persists across callback invocations
  static uint8_t*      otaBuf              = nullptr;
  static size_t        otaBufSize          = 0;
  static size_t        otaReceived         = 0;
  static unsigned long lastBeepTime        = 0;
  static int           lastRxPct           = -1;
  static size_t        otaContentLength    = 0;  //total POST Content-Length for progress %
  static bool          otaOverflow         = false; //true if upload exceeded PSRAM buffer — abort at END

  if (upload.status == UPLOAD_FILE_START) {
    if (!checkOtaSecurity()) return;

    DEBUG_PRINTF("\n=== OTA Upload Started (PSRAM-staged) ===\n");
    DEBUG_PRINTF("File: %s (%u bytes)\n", upload.filename.c_str(), upload.totalSize);

    //Prevent the main loop from overwriting the OTA canvas between chunk callbacks.
    //server.handleClient() sits at the bottom of loop(), so the full loop body —
    //including updateClock() which calls gfx->fillScreen() and flushDisplay() —
    //executes between every pair of chunk callbacks. Setting currentScreen to
    //SCREEN_ABOUT bypasses the SCREEN_CLOCK and SCREEN_MESSAGE drawing branches.
    //Clearing message state prevents checkMessageExpiration() and
    //checkHighPriorityAlternation() from calling changeScreen() mid-upload.
    //No restore needed; the device reboots at the end of OTA.
    currentScreen            = SCREEN_ABOUT;
    messageActive            = false;
    highPriorityMessageCount = 0;

    //Reset staging state, freeing any leftover buffer from a previous attempt
    if (otaBuf) { heap_caps_free(otaBuf); otaBuf = nullptr; }
    otaBufSize       = 0;
    otaReceived      = 0;
    lastBeepTime     = 0;
    lastRxPct        = -1;
    otaContentLength = 0;
    otaOverflow      = false;

    //Read total POST Content-Length from request headers for accurate progress %.
    //upload.totalSize is NOT reliable for this — it tracks previous-chunk cumulative
    //bytes (updated after each callback returns), so it always lags otaReceived and
    //produces pct values well above 100% (200% on the second chunk, etc.).
    //Content-Length is the full POST body size: binary + small multipart overhead (<2 KB).
    String clHeader = server.header("Content-Length");
    if (clHeader.length() > 0) {
      otaContentLength = (size_t)clHeader.toInt();
      DEBUG_PRINTF("OTA: Content-Length = %u bytes\n", otaContentLength);
    }

    //Allocate 3 MB PSRAM buffer. This accommodates binaries up to ~2.9 MB plus
    //the multipart boundary overhead (~1-2 KB) that trails the file content in
    //the HTTP POST body. The previous 2 MB ceiling was too small — the binary
    //plus trailing boundary overflowed it, corrupting the staged data.
    size_t allocSize = 3UL * 1024 * 1024;
    otaBuf = (uint8_t*)heap_caps_malloc(allocSize, MALLOC_CAP_SPIRAM);
    if (!otaBuf) {
      DEBUG_PRINTF("OTA: PSRAM alloc failed (%u bytes) — aborting\n", allocSize);
      return;
    }
    otaBufSize = allocSize;
    DEBUG_PRINTF("OTA: PSRAM buffer allocated: %u bytes\n", allocSize);

    //Show OTA screen — backlight stays ON for the entire receive phase
    setBrightness(5);
    gfx->fillScreen(COLOR_BLACK);
    gfx->setTextColor(COLOR_YELLOW);
    setSmartFont(32);
    int16_t x1, y1; uint16_t w, h;
    getTextBoundsHF("OTA UPDATE", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 160);
    printHF("OTA UPDATE");

    setSmartFont(28);
    gfx->setTextColor(COLOR_WHITE);
    getTextBoundsHF("Uploading firmware...", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 210);
    printHF("Uploading firmware...");

    //Draw empty progress bar
    int barX = (DISPLAY_LONG - 600) / 2;
    gfx->fillRect(barX, 260, 600, 35, COLOR_DARKGRAY);
    gfx->drawRect(barX - 1, 259, 602, 37, COLOR_WHITE);

    for (int i = 0; i < 3; i++) { flushDisplay(); delay(20); }

    //First beep signals upload starting
    if (buzzerEnabled) { singleBeep(); lastBeepTime = millis(); }
  }
  else if (upload.status == UPLOAD_FILE_WRITE) {
    //PHASE 1: accumulate chunk into PSRAM — no flash writes, no stalls, no tearing

    if (!otaBuf) return;

    if (otaReceived + upload.currentSize <= otaBufSize) {
      memcpy(otaBuf + otaReceived, upload.buf, upload.currentSize);
      otaReceived += upload.currentSize;
    } else {
      if (!otaOverflow) {
        //Log once; subsequent chunks are also discarded silently
        DEBUG_PRINTF("OTA: PSRAM buffer overflow at %u bytes — upload will be aborted at END\n",
                     otaReceived + upload.currentSize);
        otaOverflow = true;
      }
    }

    //Beep every 5 seconds
    unsigned long now = millis();
    if (buzzerEnabled && now - lastBeepTime >= 5000) {
      lastBeepTime = now;
      singleBeep();
    }

    //Update progress bar — PSRAM/display fully available during receive.
    //Use Content-Length (captured at FILE_START) as the denominator; fall back
    //to buffer size. Clamp to 100 — multipart overhead means the POST body is
    //slightly larger than the binary, so we'd otherwise overshoot by <0.1%.
    {
      size_t denom = (otaContentLength > 0) ? otaContentLength : otaBufSize;
      int pct = (int)min(100UL, (otaReceived * 100UL) / denom);
      if (pct != lastRxPct) {
        lastRxPct = pct;
        int barX = (DISPLAY_LONG - 600) / 2;
        gfx->fillRect(barX, 260, 600, 35, COLOR_DARKGRAY);
        gfx->fillRect(barX, 260, (600 * pct) / 100, 35, COLOR_GREEN);
        gfx->drawRect(barX - 1, 259, 602, 37, COLOR_WHITE);
        flushDisplay();
      }
      static int lastSerialPct = -1;
      if (pct / 10 > lastSerialPct) { lastSerialPct = pct / 10; DEBUG_PRINTF("Received: %d%%\n", pct); }
    }
  }
  else if (upload.status == UPLOAD_FILE_END) {
    if (!otaBuf || otaReceived == 0) {
      DEBUG_PRINTF("OTA: No staged data — aborting\n");
      return;
    }

    //Abort if the upload exceeded the staging buffer — a truncated image must never be flashed.
    if (otaOverflow) {
      DEBUG_PRINTF("OTA: Aborting — binary exceeded PSRAM buffer (%u bytes max). Flash was NOT written.\n", otaBufSize);
      heap_caps_free(otaBuf); otaBuf = nullptr;
      otaOverflow = false;

      elecrowBacklightWriteRaw(0x10);
      gfx->fillScreen(COLOR_BLACK);
      gfx->setTextColor(COLOR_RED);
      setSmartFont(28);
      int16_t x1, y1; uint16_t w, h;
      getTextBoundsHF("OTA FAILED", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 190);
      printHF("OTA FAILED");
      setSmartFont(22);
      gfx->setTextColor(COLOR_WHITE);
      getTextBoundsHF("Binary too large for buffer", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 250);
      printHF("Binary too large for buffer");
      for (int i = 0; i < 3; i++) { flushDisplay(); delay(20); }
      delay(3000);
      ESP.restart();
      return;
    }

    DEBUG_PRINTF("\n=== OTA Phase 2: flashing %u bytes from PSRAM ===\n", otaReceived);

    //PHASE 2: write PSRAM → Flash in 32 KB chunks with green-screen flash between writes

    //Use UPDATE_SIZE_UNKNOWN: the Update library reads the image header to determine
    //the correct binary size, ignoring any trailing multipart boundary bytes in the
    //staged buffer. Passing otaReceived would include those extra bytes and cause
    //esp_image validation failure ("invalid segment length 0xffffffff").
    if (!Update.begin(UPDATE_SIZE_UNKNOWN, U_FLASH)) {
      Update.printError(Serial);
      DEBUG_PRINTF("OTA: Update.begin failed\n");
      heap_caps_free(otaBuf); otaBuf = nullptr;
      return;
    }

    const size_t FLASH_CHUNK = 262144;  //256 KB — ~8 flashes for a 2 MB binary; increase further to reduce flash rate
    size_t offset  = 0;
    bool   writeOk = true;
    lastBeepTime   = millis();

    while (offset < otaReceived && writeOk) {
      size_t chunkSize = min(FLASH_CHUNK, otaReceived - offset);

      //Beep every 5 seconds (may fire here during the lit window)
      unsigned long now = millis();
      if (buzzerEnabled && now - lastBeepTime >= 5000) {
        lastBeepTime = now;
        singleBeep();
      }

      //Draw full green screen and flush before going dark — user sees the flash
      gfx->fillScreen(COLOR_GREEN);
      for (int i = 0; i < 2; i++) { flushDisplay(); delay(20); }
      elecrowBacklightWriteRaw(0x10);   //ON: green flash visible
      delay(300);                       //hold green long enough to register visually; increase to slow flash rate further

      //Blank backlight before flash write — hides DMA starvation artifacts
      elecrowBacklightWriteRaw(0x05);   //OFF

      //Write chunk to flash (SPIRAM cache stalls during this call)
      if (Update.write(otaBuf + offset, chunkSize) != chunkSize) {
        Update.printError(Serial);
        DEBUG_PRINTF("OTA: write failed at offset %u\n", offset);
        writeOk = false;
        break;
      }
      offset += chunkSize;
      DEBUG_PRINTF("Flash: %d%%\n", (int)((offset * 100UL) / otaReceived));
    }

    heap_caps_free(otaBuf); otaBuf = nullptr;

    if (!writeOk) { Update.abort(); return; }

    if (Update.end(true)) {
      otaUpdateSuccessful = true;
      DEBUG_PRINTF("\n=== OTA Complete: %u bytes written ===\n", otaReceived);

      //Flash writes done — restore display for success screen
      elecrowBacklightWriteRaw(0x10);
      delay(20);

      gfx->fillScreen(COLOR_BLACK);
      gfx->setTextColor(COLOR_GREEN);
      setSmartFont(32);
      int16_t x1, y1; uint16_t w, h;
      getTextBoundsHF("SUCCESS!", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 200);
      printHF("SUCCESS!");

      setSmartFont(28);
      gfx->setTextColor(COLOR_WHITE);
      getTextBoundsHF("Rebooting...", 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((DISPLAY_LONG - w) / 2, 265);
      printHF("Rebooting...");

      for (int i = 0; i < 3; i++) { flushDisplay(); delay(20); }
    }
  } 
  else if (upload.status == UPLOAD_FILE_ABORTED) {
    //Network drop or browser cancellation mid-upload.
    //Free staged buffer, show error, then reboot for clean state.
    DEBUG_PRINTF("\n=== OTA Upload Aborted at %u bytes received ===\n", otaReceived);

    if (otaBuf) { heap_caps_free(otaBuf); otaBuf = nullptr; }
    otaBufSize       = 0;
    otaReceived      = 0;
    otaContentLength = 0;
    lastRxPct        = -1;
    otaOverflow      = false;

    if (Update.isRunning()) Update.abort();

    elecrowBacklightWriteRaw(0x10);   //ensure backlight is on
    gfx->fillScreen(COLOR_BLACK);
    gfx->setTextColor(COLOR_RED);
    setSmartFont(32);
    int16_t x1, y1; uint16_t w, h;
    getTextBoundsHF("OTA FAILED", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 190);
    printHF("OTA FAILED");

    setSmartFont(24);
    gfx->setTextColor(COLOR_WHITE);
    getTextBoundsHF("Upload interrupted — rebooting", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 255);
    printHF("Upload interrupted — rebooting");

    for (int i = 0; i < 3; i++) { flushDisplay(); delay(20); }
    delay(3000);
    ESP.restart();
  }
}

//=============================================================
//POST JSON Helper Functions for /control endpoint
//=============================================================

//Parse JSON boolean value flexibly
//Accepts: true/false, 1/0, "true"/"false", "on"/"off", "yes"/"no", "toggle" or "t"


void checkFirstBootReboot() {
  // Fires exactly once after a fresh flash (or after handleDeviceFullReset(), which also
  // clears the "boot" namespace).  The ESP32-S3 RGB LCD DMA controller can miss its first
  // frame-sync boundary on the very first power-on after a flash, leaving the display
  // blank or showing noise until a subsequent boot.  This single forced reboot ensures
  // the DMA picks up a clean frame-sync on what the application then treats as "first boot".
  //
  // Mechanism: NVS key "boot/count"
  //   0 (absent) → set to 1, reboot immediately (this is the sync-fix reboot)
  //   1+         → do nothing (normal operation)
  //
  // The "boot" namespace is separate from PREFERENCES_NAMESPACE so routine
  // settings clears (/resetsettings) do NOT reset this counter; only a full
  // device reset (/resetdevice) does, which is intentional so the sync reboot
  // fires again whenever the device is fully re-initialised.
  Preferences _bootPrefs;
  _bootPrefs.begin("boot", false);
  uint8_t _bootCount = _bootPrefs.getUChar("count", 0);
  if (!ENABLE_FIRST_BOOT_RGB_SYNC_REBOOT) {
    DEBUG_PRINTF("First-boot RGB sync reboot disabled (boot count=%u)\n", _bootCount);
    _bootPrefs.end();
    return;
  }
  if (_bootCount == 0) {
    _bootPrefs.putUChar("count", 1);
    _bootPrefs.end();
    DEBUG_PRINTLN("First boot after flash — rebooting for RGB DMA frame sync");
    Serial.flush();
    delay(100);
    ESP.restart();
  }
  _bootPrefs.end();
}

void handleOTAPasswordPost() {
  String newPass = server.hasArg("otapassword") ? server.arg("otapassword") : "";
  newPass.trim();
  if (newPass.length() < 3) {
    server.send(400, "text/plain", "Password too short");
    return;
  }

  //Persist
  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.putString("otaPass", newPass);
  preferences.end();

  otaPassword = newPass;

  //Refresh ArduinoOTA password (if OTA enabled)
  #if ENABLE_ARDUINO_OTA
    ArduinoOTA.setPassword(otaPassword.c_str());
  #endif

  //Redirect back
  server.sendHeader("Location", "/otapassword");
  server.send(303, "text/plain", "Saved");
}

void handleResetSettingsPost() {
  bool keepProfiles = server.hasArg("keepprofiles") && server.arg("keepprofiles") == "true";

  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();
  preferences.end();
  //Clear boot counter so the frame-sync reboot fires again after a full reset
  { Preferences _bp; _bp.begin("boot", false); _bp.clear(); _bp.end(); }

  // msgProfiles[] is still intact in RAM — re-persist them before rebooting
  if (keepProfiles) {
    saveMsgProfiles();
  }

  String msg = keepProfiles ? "Settings cleared (profiles kept). Rebooting..."
                            : "Settings cleared. Rebooting...";
  server.send(200, "text/plain", msg);
  delay(250);
  ESP.restart();
}

void handleDeviceReboot() {
  //Respond first so the caller gets an acknowledgement
  String acceptHeader = server.header("Accept");
  acceptHeader.toLowerCase();

  if (acceptHeader.indexOf("application/json") >= 0) {
    server.send(200, "application/json", "{\"message\":\"Rebooting\"}");
  } else {
    server.send(200, "text/plain", "Rebooting...");
  }

  delay(250);       //Give the HTTP stack a moment to flush
  ESP.restart();
}

void handleDeviceFullReset() {
  //Clear saved settings
  preferences.begin(PREFERENCES_NAMESPACE, false);
  preferences.clear();
  preferences.end();

  //Also clear the "boot" namespace so the RGB DMA frame-sync reboot fires on the next
  //power-on, exactly as it would after a fresh flash.  Without this, /resetdevice left
  //the boot counter at 1, so checkFirstBootReboot() was a no-op and the display could
  //come up with DMA-sync artifacts or a momentarily blank screen.
  Preferences _bootReset;
  _bootReset.begin("boot", false);
  _bootReset.clear();
  _bootReset.end();

  //Respond first so the caller gets an acknowledgement
  String acceptHeader = server.header("Accept");
  acceptHeader.toLowerCase();

  if (acceptHeader.indexOf("application/json") >= 0) {
    server.send(200, "application/json", "{\"message\":\"Settings cleared; rebooting\"}");
  } else {
    server.send(200, "text/plain", "Settings cleared. Rebooting...");
  }

  delay(250);
  ESP.restart();
}

#if ENABLE_TEST_MODE
  void handleTestInject() {
    //── GET: return current state ────────────────────────────────
    if (server.method() == HTTP_GET) {
      String json = "{";
      json += "\"nightModeActive\":"          + String(nightModeActive     ? "true" : "false") + ",";
      json += "\"nightModeEnabled\":"         + String(nightModeEnabled    ? "true" : "false") + ",";
      json += "\"nightModeWakeActive\":"      + String(nightModeWakeActive ? "true" : "false") + ",";
      json += "\"nightModeBrightness\":"      + String(nightModeBrightness)     + ",";
      json += "\"nightModeWakeBrightness\":"  + String(nightModeWakeBrightness) + ",";
      json += "\"screenBrightness\":"         + String(screenBrightness)        + ",";
      json += "\"sunsetOffset\":"             + String(sunsetOffset)            + ",";
      json += "\"sunriseOffset\":"            + String(sunriseOffset)           + ",";
      json += "\"sunriseHour\":"              + String(sunriseHour)             + ",";
      json += "\"sunriseMinute\":"            + String(sunriseMinute)           + ",";
      json += "\"sunsetHour\":"               + String(sunsetHour)              + ",";
      json += "\"sunsetMinute\":"             + String(sunsetMinute)            + ",";
      json += "\"sunTimesValid\":"            + String(sunTimesValid       ? "true" : "false") + ",";
      json += "\"currentScreen\":"            + String((int)currentScreen);
      json += "}";
      server.send(200, "application/json", json);
      return;
    }

    //── POST: inject values and/or force a state check for testing purposes ───────────
    if (server.method() == HTTP_POST && server.hasArg("plain")) {
      String body = server.arg("plain");
      JsonDocument doc;
      DeserializationError error = deserializeJson(doc, body);

      if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
      }

      //Override sun times
      if (doc.containsKey("sunsethour"))    sunsetHour    = (int)doc["sunsethour"];
      if (doc.containsKey("sunsetminute"))  sunsetMinute  = (int)doc["sunsetminute"];
      if (doc.containsKey("sunrisehour"))   sunriseHour   = (int)doc["sunrisehour"];
      if (doc.containsKey("sunriseminute")) sunriseMinute = (int)doc["sunriseminute"];

      //Tomorrow's sun times (used by getSunDisplayStrings / night mode after midnight)
      if (doc.containsKey("sunrisehourtomorrow"))   tomorrowSunriseHour   = (int)doc["sunrisehourtomorrow"];
      if (doc.containsKey("sunriseminutetomorrow")) tomorrowSunriseMinute = (int)doc["sunriseminutetomorrow"];

      //Validity flag
      if (doc.containsKey("setsuntimesvalid")) {
        sunTimesValid = (bool)doc["setsuntimesvalid"];
      } else {
        //Default: mark as valid when any sun time is injected
        if (doc.containsKey("sunsethour") || doc.containsKey("sunrisehour")) {
          sunTimesValid = true;
        }
      }

      //Force an immediate night-mode evaluation
      if (doc.containsKey("forcenightcheck") && (bool)doc["forcenightcheck"]) {
        lastNightModeCheck = 0;   //reset debounce timer
        updateNightMode();        //evaluate now
      }

      // Local air pressure pushed from Hubitat
      if (doc.containsKey("local_pressure")) {
        int incomingHpa = (int)doc["local_pressure"];
        if (incomingHpa > 800 && incomingHpa < 1100) {   // sanity-check reasonable hPa range
          localPressureHpa       = incomingHpa;
          localPressureValid     = true;
          lastLocalPressureReceived = millis();
        }
      }
      
      server.send(200, "application/json", "{\"message\":\"Injected\"}");
      return;
    }

    server.send(405, "application/json", "{\"error\":\"Method not allowed\"}");
  }
#endif  

//=============================================================
// startWebServer()
//  Registers every HTTP route, starts the WebServer, enables web
//  logging (if configured), and initialises ArduinoOTA.
//
//  Moved here from main .ino — all HTTP handler
//  registrations belong alongside the handlers themselves.
//  Called once from setup().
//=============================================================
void startWebServer() {
  server.on("/",                HTTP_GET,  handleRoot);                 //HTML UI for controlling the device
  server.on("/message",         HTTP_ANY,  handleDisplayMessage);       //Main message endpoint
  server.on("/msg",             HTTP_GET,  handleSimpleMessage);        //Simple compatibility endpoint
  server.on("/clear",           HTTP_ANY,  handleClear);                //Clears display, returns to Clock
  server.on("/time",            HTTP_GET,  handleTimeInfo);             //Just returns the time for diagnostic purposes
  server.on("/clock",           HTTP_ANY,  handleClockPage);            //Shows the Clock screen
  server.on("/clockconfig",     HTTP_GET,  handleClockConfigPage);
  server.on("/clockconfig",     HTTP_POST, handleClockConfig);
  server.on("/locationconfig",  HTTP_GET,  handleLocationConfigPage);
  server.on("/locationconfig",  HTTP_POST, handleLocationConfig);
  server.on("/weather",         HTTP_ANY,  handleWeatherPage);          //Shows the Weather screen
  server.on("/calendar",        HTTP_ANY,  handleCalendarPage);         //Shows the Calendar screen
  server.on("/astro",           HTTP_ANY,  handleAstroPage);            //Shows the Astro screen (Sun page)
  server.on("/schedules",       HTTP_ANY,  handleSchedulerConfig);
  server.on("/status",          HTTP_GET,  handleStatusPage);
  server.on("/status.json",     HTTP_GET,  handleStatusJson);
  server.on("/otapassword",     HTTP_GET,  handleOTAPasswordPage);
  server.on("/otapassword",     HTTP_POST, handleOTAPasswordPost);
  server.on("/reboot",          HTTP_ANY,  handleDeviceReboot);         //Immediate reboot (for automation)
  server.on("/resetdevice",     HTTP_ANY,  handleDeviceFullReset);      //Clear Preferences + reboot
  server.on("/resetsettings",   HTTP_GET,  handleResetSettingsPage);
  server.on("/resetsettings",   HTTP_POST, handleResetSettingsPost);
  server.on("/control",         HTTP_ANY,  handleControl);              //Multi-function endpoint, see README.md
  #if ENABLE_TEST_MODE  
    server.on("/testinject",    HTTP_ANY,  handleTestInject);
  #endif

  const char* headerKeys[] = {"Content-Type", "Accept"};
  server.collectHeaders(headerKeys, 2);

  server.begin();

  #if ENABLE_WEB_LOGGING
    webLogSetup();
    DEBUG_PRINTLN("\n✓ Web debug logging enabled");
    DEBUG_PRINTLN("  Access logs at: http://" + WiFi.localIP().toString() + "/logs");
  #endif

  DEBUG_PRINTLN("\n✓ Web server started");
  DEBUG_PRINTF("  Send messages to: http://%s/message\n", WiFi.localIP().toString().c_str());

  //Setup OTA updates
  setupOTAEndpoints();
  #if ENABLE_ARDUINO_OTA
    ArduinoOTA.setHostname(deviceName.c_str());  //Name the OTA access point before beginning the OTA ability
    ArduinoOTA.begin();
    DEBUG_PRINTLN("\n✓ Arduino OTA enabled");
    DEBUG_PRINTLN("  via Arduino IDE: Select '" + String(deviceName) + "' as port");
  #endif
  DEBUG_PRINTLN("  via Web UI: http://" + WiFi.localIP().toString() + "/update");
}
