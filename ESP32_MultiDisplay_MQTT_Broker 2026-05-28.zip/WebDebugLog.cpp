#include "WebDebugLog.h"

#if ENABLE_WEB_LOGGING
    #include <WebServer.h>

    //Global log buffer storage
    String webLogBuffer[LOG_BUFFER_SIZE];
    int webLogIndex = 0;
    unsigned long webLogTimestamps[LOG_BUFFER_SIZE];
    String logRefreshRate = "5";

    //External reference to your web server
    extern WebServer server;

    //Forward declaration
    void handleLogs();

    //============================================================
    // Setup web logging (call this from your setup() function)
    //============================================================
    void webLogSetup() {
        // Initialize buffer
        for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
            webLogBuffer[i] = "";
            webLogTimestamps[i] = 0;
        }
        
        // Register log viewing endpoints (multiple routes to same handler)
        server.on("/logs", HTTP_GET, handleLogs);
        server.on("/log", HTTP_GET, handleLogs);
        server.on("/logging", HTTP_GET, handleLogs);

        // Add endpoint to clear logs
        server.on("/logs/clear", HTTP_GET, []() {
            for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
                webLogBuffer[i] = "";
                webLogTimestamps[i] = 0;
            }
            webLogIndex = 0;
            server.send(200, "text/plain", "Logs cleared");
        });
        
        //DEBUG_PRINTLN("Web debug logging enabled");
        //DEBUG_PRINTLN("Access logs at: http://" + WiFi.localIP().toString() + "/logs");
    }

    void handleLogs() {
        String html = F("<!DOCTYPE html><html><head>");
        html += F("<meta charset='UTF-8'>");
        html += F("<meta http-equiv='refresh' content='5'>");  // Auto-refresh every 5 seconds
        html += F("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        html += F("<title>Debug Logs</title>");
        html += F("<style>");
        html += F("body{font-family:'Courier New',monospace;background:#000;color:#0f0;margin:0;padding:10px;}");
        html += F("h2{color:#0ff;border-bottom:2px solid #0f0;padding-bottom:10px;}");
        html += F("pre{white-space:pre-wrap;word-wrap:break-word;font-size:12px;line-height:1.4;}");
        html += F(".log-entry{border-left:3px solid #0f0;padding-left:10px;margin:5px 0;}");
        html += F(".timestamp{color:#ff0;font-weight:bold;}");
        html += F(".controls{margin:10px 0;padding:10px;background:#111;border-radius:5px;}");
        html += F(".btn{background:#0f0;color:#000;padding:8px 15px;border:none;cursor:pointer;");
        html += F("border-radius:4px;margin-right:10px;font-weight:bold;}");
        html += F(".btn:hover{background:#0ff;}");
        html += F(".info{color:#888;font-size:11px;margin-top:20px;}");
        html += F("</style></head><body>");
        
        html += F("<h2>🔍 Debug Log Monitor</h2>");
        
        html += F("<div class='controls'>");
        html += F("<button class='btn' onclick='location.reload()'>🔄 Refresh Now</button>");
        html += F("<button class='btn' onclick='fetch(\"/logs/clear\").then(()=>location.reload())'>🗑️ Clear Logs</button>");
        html += F("<span style='color:#888;margin-left:20px;'>Auto-refresh: 5s</span>");
        html += F("</div>");
        
        // Count non-empty entries
        int logCount = 0;
        for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
            if (webLogBuffer[i].length() > 0) logCount++;
        }
        
        html += F("<div class='info'>Showing ");
        html += String(logCount);
        html += F(" of ");
        html += String(LOG_BUFFER_SIZE);
        html += F(" log entries | Free heap: ");
        html += String(ESP.getFreeHeap());
        html += F(" bytes</div>");
        
        html += F("<pre>");
        
        // Display logs in chronological order (oldest to newest)
        for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
            int idx = (webLogIndex + i) % LOG_BUFFER_SIZE;
            if (webLogBuffer[idx].length() > 0) {
                html += F("<div class='log-entry'>");
                
                // Format timestamp (seconds since boot)
                unsigned long seconds = webLogTimestamps[idx] / 1000;
                unsigned long minutes = seconds / 60;
                unsigned long hours = minutes / 60;
                
                html += F("<span class='timestamp'>[");
                if (hours > 0) {
                    html += String(hours) + "h ";
                }
                if (minutes > 0) {
                    html += String(minutes % 60) + "m ";
                }
                html += String(seconds % 60) + "s] </span>";
                
                // Log message (HTML escape special characters)
                String msg = webLogBuffer[idx];
                msg.replace("&", "&amp;");
                msg.replace("<", "&lt;");
                msg.replace(">", "&gt;");
                html += msg;
                
                html += F("</div>");
            }
        }
        
        html += F("</pre>");
        html += F("<div class='info'>Uptime: ");
        html += String(millis() / 1000);
        html += F(" seconds</div>");
        html += F("</body></html>");
        
        server.send(200, "text/html", html);
    };
    
    //============================================================
    // Get log buffer as JSON (optional - for API access)
    //============================================================
    String webLogGetJSON() {
        String json = "{\"logs\":[";
        bool first = true;
        
        for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
            int idx = (webLogIndex + i) % LOG_BUFFER_SIZE;
            if (webLogBuffer[idx].length() > 0) {
                if (!first) json += ",";
                json += "{\"timestamp\":";
                json += String(webLogTimestamps[idx]);
                json += ",\"message\":\"";
                
                // Escape quotes in message
                String msg = webLogBuffer[idx];
                msg.replace("\"", "\\\"");
                json += msg;
                json += "\"}";
                
                first = false;
            }
        }
        
        json += "],\"heap\":";
        json += String(ESP.getFreeHeap());
        json += ",\"uptime\":";
        json += String(millis());
        json += "}";
        
        return json;
    }

    //============================================================
    // Clear all logs
    //============================================================
    void webLogClear() {
        for (int i = 0; i < LOG_BUFFER_SIZE; i++) {
            webLogBuffer[i] = "";
            webLogTimestamps[i] = 0;
        }
        webLogIndex = 0;
    }

#endif // ENABLE_WEB_LOGGING