//=============================================================
// MQTTBroker.cpp  —  MQTT broker + CYD HTTP forwarder
//
// Compiled as a SEPARATE translation unit — not merged with .ino
// files and not processed by Arduino IDE's prototype generator.
// This is why the sMQTTBroker subclass lives here.
//
// TOPIC ROUTING:
//   display/message               → display locally + forward to CYDs
//   display/clear                 → clear locally + forward clear to CYDs
//   display/message/elecrow       → local display only
//   display/message/cyd           → forward to CYDs only
//   display/screen                → navigate Elecrow + all CYDs to that screen
//   device/control                → apply on Elecrow + forward to CYDs (reboot/resetsettings/resetdevice NOT forwarded)
//   device/clockconfig            → apply on Elecrow + forward to all CYDs
//   display/message/device/<name> → forward to that named CYD only
//   display/clear/device/<name>   → clear that named CYD only
//
// Public API (startMqttBroker, mqttBrokerUpdate) declared in MQTTBroker.h.
// Bridge wrappers for sketch-internal types are in MQTTBroker.ino.
//=============================================================

#include "MQTTBroker.h"
#include "User_Setup.h"       // DEFAULT_* MAX_* PREFERENCES_NAMESPACE constants
#include "HelpFunctions.h"    // getJSON_*, parseColor, findKeyIgnoreCase,
                              // parseJsonBoolKey, getRotationIndex,
                              // validateRobotoFontCode, gfx, server
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <sMQTTBroker.h>

using ulong = unsigned long;    // Match type alias in main .ino

//=============================================================
// Forward declarations for functions defined in .ino files.
// Resolved at link time — .ino files compile as C++ so mangling matches.
//=============================================================
String  normalizeScrollDir(String dir);
void    addToHistory(String msg);
void    deactivateScreensaver();
void    stopAllEffects();
void    doubleBeep();
void    resetMessageRuntimeState();
void    saveSettings();
void    updateNightMode();
void    setBrightness(uint8_t brightness);

void displayMessage(String msg,
                    uint16_t bg, uint16_t fg,
                    int font, int rotation,
                    String hAlign, String vAlign,
                    bool wrap,
                    String scrollDir, uint8_t scrollSpeed,
                    uint8_t brightness,
                    bool flash, ulong flashInterval,
                    bool pulse, ulong pulseDuration);

//=============================================================
// Extern declarations for global variables in the main .ino.
// Only primitive / String types are used here so the .cpp
// doesn't need ScreenMode, HighPriorityMessage, or other
// sketch-specific types.
//=============================================================
extern bool    messageActive;
extern int     messageExpirationTime;
extern ulong   messageDisplayStartTime;
extern String  messagePriority;
extern ulong   lastHighPriorityAlternateTime;
extern bool    currentWrap;
extern String  currentScrollDirection;
extern uint8_t currentScrollSpeed;
extern bool    currentFlash;
extern ulong   currentFlashInterval;
extern bool    currentPulse;
extern ulong   currentPulseDuration;
extern bool    isFlashing;
extern bool    flashSwapState;
extern ulong   lastFlashTime;
extern bool    isPulsing;
extern ulong   pulseStartTime;
extern uint8_t actualCurrentBrightness;
extern int     scrollOffset;
extern bool    showClock;
extern int     normalQueueHead;
extern int     normalQueueTail;
extern int     normalQueueCount;
extern bool    inNormalOverride;
extern int     savedHighPriorityIndex;
extern ulong   lastHighPriorityBeepTime;
extern int     highPriorityMessageCount;
extern int     currentHighPriorityIndex;

// Dark mode flags
extern bool     clockDarkMode;
extern bool     weatherDarkMode;
extern bool     calendarDarkMode;
extern bool     menuDarkMode;
extern bool     historyDarkMode;
extern bool     astroDarkMode;

// Feature toggles
extern bool     pixelShiftEnabled;
extern bool     touchEnabled;
extern bool     clockEnabled;
extern bool     weatherCycleEnabled;
extern bool     calendarCycleEnabled;
extern bool     tempActual;
extern bool     tempCelsius;
extern bool     normalOverrideEnabled;

// Cycle timing (stored in ms; /control JSON values are in seconds)
extern ulong    weatherShowDuration;
extern ulong    weatherCycleInterval;
extern ulong    calendarShowDuration;
extern ulong    calendarCycleInterval;

// Message priority/queue settings
extern int      highPriorityAlternateInterval;  // ms
extern int      normalOverrideDuration;          // seconds
extern int      maxMsgAge;                       // hours
extern int      messageCount;
extern int      unreadCount;
extern int      currentHistoryIndex;

// Pulse brightness limits
extern uint8_t  pulseMaxBrightness;
extern uint8_t  pulseMinBrightness;

// Local pressure and weather station data (pushed from Hubitat)
extern float    localPressureHpa;
extern bool     localPressureValid;
extern ulong    lastLocalPressureReceived;
extern ulong    lastLocalPressureFetch;
extern float    localWindDeg;    // wind direction degrees (NAN until received)
extern float    localTemp;       // local outdoor temperature (NAN until received)
extern float    localHumidity;   // local outdoor humidity % (NAN until received)       // reset when MQTT delivers fresh value, so HTTP backup timer restarts

// Clock display settings
extern bool     clockColorsCustomized;
extern int      clockTimeFont;
extern int      clockDateFont;
extern String   clockTimeFormat;
extern String   clockDateFormat;
extern uint16_t clockTimeColor;
extern uint16_t clockDateColor;
extern uint16_t clockBgColor;
extern uint16_t clockSuntimesColor;
extern uint8_t  screenBrightness;
extern int      clockRotation;
extern bool     clockSuntimesEnabled;

// Night mode clock colors
extern uint16_t nightClockTimeColor;
extern uint16_t nightClockDateColor;
extern uint16_t nightClockBgColor;
extern uint16_t nightClockSuntimesColor;

// Screen font settings
extern int      labelFont;
extern int      msgNoticeFont;
extern uint8_t  weatherTempFont;
extern uint8_t  weatherHumidFont;
extern uint8_t  weatherPressureFont;
extern uint16_t labelColor;
extern uint16_t msgNoticeColor;

// Night mode settings
extern bool     nightModeEnabled;
extern uint8_t  nightModeBrightness;
extern uint8_t  nightModeWakeBrightness;
extern ulong    nightModeWakeDuration;
extern ulong    lastNightModeCheck;
extern int      sunsetOffset;
extern int      sunriseOffset;

// Screensaver
extern uint8_t  screensaverDimValue;
extern ulong    screensaverTimeout;

//=============================================================
// Configuration
//=============================================================
#ifndef MQTT_PORT
  #define MQTT_PORT 1883
#endif

#ifndef MQTT_DISPLAYS_FALLBACK
  #define MQTT_DISPLAYS_FALLBACK R"([
    { "name":"CYD 1", "messageUrl":"http://192.168.1.2/message", "clearUrl":"http://192.168.1.2/clear" }
  ])"
#endif

static constexpr int MQTT_HTTP_TIMEOUT_MS  = 3000;
static constexpr int MQTT_HTTP_RETRY_COUNT = 2;    // 3 total attempts (initial + 2 retries)
static constexpr int MQTT_FWD_TASK_STACK   = 8192;

//=============================================================
// Statistics
//=============================================================
static int mqttClientCount      = 0;
static int mqttMessagesReceived = 0;
static int mqttFwdOkCount       = 0;
static int mqttFwdFailCount     = 0;

// Defined false at start; set true by the main sketch after loadPressureBuffer()
// completes. Prevents the NewClient handler from overwriting Mosquitto's good
// retained history chunks with an empty snapshot during broker boot.
bool mqttHistoryReady = false;

//=============================================================
// CYD Display Registry
//=============================================================
struct CYDDisplay { String name, messageUrl, clearUrl; };
static std::vector<CYDDisplay> cydDisplays;

static void loadCYDDisplays() {
  cydDisplays.clear();
  String json;

  if (LittleFS.exists("/displays.json")) {
    File f = LittleFS.open("/displays.json", "r");
    if (f) { json = f.readString(); f.close();
      DEBUG_PRINTLN("\nMQTT: loaded CYD config from /displays.json"); }
  }
  if (json.isEmpty()) {
    json = MQTT_DISPLAYS_FALLBACK;
    DEBUG_PRINTLN("MQTT: /displays.json absent — using hardcoded fallback from secrets.h");
  }

  JsonDocument doc;
  if (deserializeJson(doc, json)) {
    DEBUG_PRINTLN("MQTT: displays.json parse error — using fallback");
    deserializeJson(doc, MQTT_DISPLAYS_FALLBACK);
  }
  for (JsonObject d : doc.as<JsonArray>()) {
    CYDDisplay disp;
    disp.name       = d["name"].as<String>();
    disp.messageUrl = d["messageUrl"].as<String>();
    disp.clearUrl   = d["clearUrl"].as<String>();
    cydDisplays.push_back(disp);
    DEBUG_PRINTF("  CYD: %-20s  %s\n", disp.name.c_str(), disp.messageUrl.c_str());
  }
  DEBUG_PRINTF("MQTT: %d CYD display(s) configured\n", (int)cydDisplays.size());
}

//=============================================================
// HTTP Forwarder — parallel FreeRTOS tasks
//=============================================================
static SemaphoreHandle_t mqttFwdMutex = nullptr;
struct MQTTFwdTask { String url, body, name; };

static void mqttHttpFwdTask(void* param) {
  MQTTFwdTask* t = static_cast<MQTTFwdTask*>(param);
  bool ok = false;
  int  code = 0;

  for (int attempt = 0; attempt <= MQTT_HTTP_RETRY_COUNT; attempt++) {
    HTTPClient http;
    http.begin(t->url);
    http.addHeader("Content-Type", "application/json");
    http.setTimeout(MQTT_HTTP_TIMEOUT_MS);
    code = t->body.isEmpty() ? http.POST("") : http.POST(t->body);
    http.end();
    if (code >= 200 && code < 400) { ok = true; break; }
    DEBUG_PRINTF("  MQTT Fwd [%s] attempt %d failed (HTTP %d)\n",
                 t->name.c_str(), attempt + 1, code);
    if (attempt < MQTT_HTTP_RETRY_COUNT) delay(500);
  }

  if (mqttFwdMutex) {
    xSemaphoreTake(mqttFwdMutex, portMAX_DELAY);
    ok ? mqttFwdOkCount++ : mqttFwdFailCount++;
    DEBUG_PRINTF("  MQTT Fwd [%s] %s (HTTP %d)\n",
                 t->name.c_str(), ok ? "OK" : "FAIL", code);
    xSemaphoreGive(mqttFwdMutex);
  }
  delete t;
  vTaskDelete(NULL);
}

static void forwardToCYDs(const String& body, bool isClear) {
  if (cydDisplays.empty()) return;
  DEBUG_PRINTF("MQTT: forwarding to %d CYD(s) [%s]\n",
               (int)cydDisplays.size(), isClear ? "CLEAR" : "MESSAGE");
  for (const auto& d : cydDisplays) {
    MQTTFwdTask* tp = new MQTTFwdTask();
    tp->url  = isClear ? d.clearUrl : d.messageUrl;
    tp->body = isClear ? "" : body;
    tp->name = d.name;
    if (xTaskCreate(mqttHttpFwdTask, "mqttFwd", MQTT_FWD_TASK_STACK,
                    tp, 1, NULL) != pdPASS) {
      DEBUG_PRINTF("  MQTT Fwd [%s] task create failed\n", d.name.c_str());
      delete tp;
    }
  }
}

// Forward a JSON body to a derived endpoint on all CYD displays.
// Base URL is extracted from each display's messageUrl
//   (e.g. "http://192.168.1.71/message" → "http://192.168.1.71" + endpoint).
static void forwardJsonToCYDs(const String& endpoint, const String& body) {
  if (cydDisplays.empty() || body.isEmpty()) return;
  DEBUG_PRINTF("MQTT: forwarding [%s] to %d CYD(s)\n",
               endpoint.c_str(), (int)cydDisplays.size());
  for (const auto& d : cydDisplays) {
    // Derive base URL: strip path from messageUrl
    String baseUrl = d.messageUrl;
    int schemeEnd  = baseUrl.indexOf("://");
    if (schemeEnd >= 0) {
      int pathStart = baseUrl.indexOf('/', schemeEnd + 3);
      if (pathStart >= 0) baseUrl = baseUrl.substring(0, pathStart);
    }
    MQTTFwdTask* tp = new MQTTFwdTask();
    tp->url  = baseUrl + endpoint;
    tp->body = body;
    tp->name = d.name;
    if (xTaskCreate(mqttHttpFwdTask, "mqttFwd", MQTT_FWD_TASK_STACK,
                    tp, 1, NULL) != pdPASS) {
      DEBUG_PRINTF("  MQTT Fwd [%s] task create failed\n", d.name.c_str());
      delete tp;
    }
  }
}

// Strip commands that must not be forwarded to CYDs, then return the
// sanitized JSON string.  Returns empty string if payload is not valid JSON.
// Blocked: reboot, resetsettings, resetdevice.
// Forwarded: everything else including localpressure, clockdark, clear, etc.
static String sanitizeControlForCYDs(const String& payload) {
  JsonDocument doc;
  if (deserializeJson(doc, payload)) return "";
  doc.remove("reboot");
  doc.remove("resetsettings");
  doc.remove("resetdevice");
  if (doc.size() == 0) return "";   // nothing left to forward
  String result;
  serializeJson(doc, result);
  return result;
}

//=============================================================
// Local message display
// Parses same JSON format as HTTP /message endpoint.
// Falls back to plain-text for non-JSON payloads.
//=============================================================
static void mqttProcessMessage(const String& jsonBody) {
  // Default values (same as handleDisplayMessage in MessageEngine.ino)
  String   message       = "";
  uint16_t bgColor       = DEFAULT_BG_COLOR;
  uint16_t textColor     = DEFAULT_TEXT_COLOR;
  int      font          = DEFAULT_FONT;
  int      rotation      = DEFAULT_ROTATION;
  String   hAlign        = DEFAULT_H_ALIGN;
  String   vAlign        = DEFAULT_V_ALIGN;
  bool     wrap          = DEFAULT_WRAP;
  String   scrollDir     = normalizeScrollDir(DEFAULT_SCROLL_DIRECTION);
  uint8_t  scrollSpeed   = DEFAULT_SCROLL_SPEED;
  uint8_t  brightness    = DEFAULT_BRIGHTNESS;
  bool     flash         = DEFAULT_FLASH;
  ulong    flashInterval = DEFAULT_FLASH_INTERVAL;
  bool     pulse         = DEFAULT_PULSE;
  ulong    pulseDur      = DEFAULT_PULSE_DURATION;
  String   priority      = DEFAULT_PRIORITY;
  int      expiry        = DEFAULT_EXPIRATION_TIME;

  JsonDocument doc;
  if (!deserializeJson(doc, jsonBody)) {
    // Full JSON format — same keys as HTTP POST
    getJSON_String(doc,  "text",           message,       "  MQTT text      ");
    getJSON_Color(doc,   "bgcolor",        bgColor,       "  MQTT bgcolor   ");
    getJSON_Color(doc,   "textcolor",      textColor,     "  MQTT textcolor ");
    getJSON_Int(doc,     "font",           font, 6, 60,   "  MQTT font      ");
    font = validateRobotoFontCode(font);  
    getJSON_Rotation(doc,"rotation",       rotation,      "  MQTT rotation  ");
    getJSON_String(doc,  "halign",         hAlign,        "  MQTT halign    ");
    getJSON_String(doc,  "valign",         vAlign,        "  MQTT valign    ");
    getJSON_Bool(doc,    "wrap",           wrap,          "  MQTT wrap      ");
    getJSON_String(doc,  "scrolldir",      scrollDir,     "  MQTT scrolldir ");
    getJSON_UInt(doc,    "scrollspeed",    scrollSpeed,   1,  9, "  MQTT speed    ");
    getJSON_UInt(doc,    "brightness",     brightness,    0,  5, "  MQTT bright   ");
    getJSON_Bool(doc,    "flash",          flash,         "  MQTT flash     ");
    getJSON_ULong(doc,   "flashinterval",  flashInterval, 500,  60000, "  MQTT flashint ");
    getJSON_Bool(doc,    "pulse",          pulse,         "  MQTT pulse     ");
    getJSON_ULong(doc,   "pulseduration",  pulseDur,      500, 600000, "  MQTT pulsedur ");
    getJSON_String(doc,  "priority",       priority,      "  MQTT priority  ");
    getJSON_Int(doc,     "expirationtime", expiry,        0, 86400, "  MQTT expiry   ");
  } else {
    // Not valid JSON — treat entire payload as plain text message
    message = jsonBody;
    DEBUG_PRINTLN("MQTT: plain-text payload (not JSON)");
  }

  message = normalizeDisplayTextEncoding(message);  //fix encoding mismatch for msgs received from Hubitat
  
  if (message.isEmpty()) {
    DEBUG_PRINTLN("MQTT: empty message — ignored");
    return;
  }

  scrollDir = normalizeScrollDir(scrollDir);
  priority.toLowerCase(); priority.trim();
  if (priority != "high" && priority != "normal") priority = "normal";

  // ── Update display state (mirrors handleDisplayMessage's "shouldDisplay=true" path)
  addToHistory(message);
  mqttPushMessageScreen();           // wrapper: deactivate screensaver, push screen

  messageActive                 = true;
  messageExpirationTime         = expiry;
  messageDisplayStartTime       = millis();
  messagePriority               = priority;
  lastHighPriorityAlternateTime = millis();

  currentWrap                   = wrap;
  currentScrollDirection        = scrollDir;
  currentScrollSpeed            = scrollSpeed;
  currentFlash                  = flash;
  currentFlashInterval          = flashInterval;
  currentPulse                  = pulse;
  currentPulseDuration          = pulseDur;

  stopAllEffects();     
  isFlashing                    = flash;
  flashSwapState                = false;
  lastFlashTime                 = millis();
  isPulsing                     = pulse;
  pulseStartTime                = millis();
  actualCurrentBrightness       = brightness;

  if (priority == "high") {
    doubleBeep();
    lastHighPriorityBeepTime = millis();
  }

  // Initialise scroll offset
  if (scrollDir != "" && scrollDir != "none") {
    scrollOffset = 0;
    if (scrollDir == "up") {
      gfx->setRotation(getRotationIndex(rotation));
      scrollOffset = gfx->height();
    }
  } else {
    scrollOffset = 0;
  }

  displayMessage(message, bgColor, textColor, font, rotation,
                 hAlign, vAlign, wrap, scrollDir, scrollSpeed, brightness,
                 flash, flashInterval, pulse, pulseDur);
  DEBUG_PRINTF("MQTT: message displayed (priority=%s expiry=%ds)\n",
               priority.c_str(), expiry);
}

//=============================================================
// device/control handler
// Mirrors handleControl() in HTML.cpp exactly, using the same
// parseJsonBoolKey / findKeyIgnoreCase / getJSON_* helpers.
// No HTTP server calls — uses mqttSaveSettingsAndRedraw() wrapper
// instead of server.send() + screen redraw.
//=============================================================
static void handleMqttControl(const String& payload) {
  DEBUG_PRINTLN("\n=== MQTT device/control ===");
  DEBUG_PRINTLN(payload);

  JsonDocument doc;
  if (deserializeJson(doc, payload)) {
    DEBUG_PRINTLN("MQTT control: JSON parse error — ignored");
    return;
  }

  bool settingsChanged = false;

  // ── Boolean / toggle flags ──────────────────────────────────────────────
  #define MQTT_PARSE_BOOL(key, var) \
    { bool _v; bool _f = false; \
      if (parseJsonBoolKey(doc, key, _v, _f, var) && _f) { var = _v; settingsChanged = true; } }

  MQTT_PARSE_BOOL("clockdark",     clockDarkMode)
  MQTT_PARSE_BOOL("weatherdark",   weatherDarkMode)
  MQTT_PARSE_BOOL("calendardark",  calendarDarkMode)
  MQTT_PARSE_BOOL("menudark",      menuDarkMode)
  MQTT_PARSE_BOOL("historydark",   historyDarkMode)
  MQTT_PARSE_BOOL("astrodark",     astroDarkMode)
  MQTT_PARSE_BOOL("pixelshift",    pixelShiftEnabled)
  MQTT_PARSE_BOOL("touchenable",   touchEnabled)
  MQTT_PARSE_BOOL("clockenable",   clockEnabled)
  MQTT_PARSE_BOOL("weathercycle",  weatherCycleEnabled)
  MQTT_PARSE_BOOL("calendarcycle", calendarCycleEnabled)
  MQTT_PARSE_BOOL("tempactual",    tempActual)
  MQTT_PARSE_BOOL("normoverride",  normalOverrideEnabled)
  #undef MQTT_PARSE_BOOL

  // When clockdark changes, auto-apply the palette if colors not customized
  {
    bool _v; bool _f = false;
    if (parseJsonBoolKey(doc, "clockdark", _v, _f, clockDarkMode) && _f && !clockColorsCustomized) {
      clockTimeColor     = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
      clockDateColor     = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
      clockBgColor       = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR   : DEFAULT_CLOCK_BG_COLOR_L;
      clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR   : DEFAULT_SUNTIMES_COLOR_L;
    }
  }

  // ── Numeric settings ────────────────────────────────────────────────────
  ulong tempULong;
  if (getJSON_ULong(doc, "wxshowdur",      tempULong, 1, 3600,  "  wxshowdur    ", " sec")) {
    weatherShowDuration   = tempULong * 1000; settingsChanged = true; }
  if (getJSON_ULong(doc, "wxcycleint",     tempULong, 1, 86400, "  wxcycleint   ", " sec")) {
    weatherCycleInterval  = tempULong * 1000; settingsChanged = true; }
  if (getJSON_ULong(doc, "calshowdur",     tempULong, 1, 3600,  "  calshowdur   ", " sec")) {
    calendarShowDuration  = tempULong * 1000; settingsChanged = true; }
  if (getJSON_ULong(doc, "calcycleint",    tempULong, 1, 86400, "  calcycleint  ", " sec")) {
    calendarCycleInterval = tempULong * 1000; settingsChanged = true; }

  int tempInt;
  if (getJSON_Int(doc, "hpalternate",     tempInt, 1, 3600,  "  hpalternate  ", " sec")) {
    highPriorityAlternateInterval = tempInt * 1000; settingsChanged = true; }
  if (getJSON_Int(doc, "normoverridedur", tempInt, 1, 3600,  "  normoverride ", " sec")) {
    normalOverrideDuration        = tempInt; settingsChanged = true; }
  if (getJSON_Int(doc, "maxmsgage",       tempInt, 0, 8760,  "  maxmsgage    ", " hr")) {
    maxMsgAge = tempInt; settingsChanged = true; }

  uint8_t tempBri;
  if (getJSON_UInt(doc, "pulsemaxbri", tempBri, 0, 5, "  pulsemaxbri  ")) {
    pulseMaxBrightness = tempBri; settingsChanged = true; }
  if (getJSON_UInt(doc, "pulseminbri", tempBri, 0, 5, "  pulseminbri  ")) {
    pulseMinBrightness = tempBri; settingsChanged = true; }

  // ── Local pressure (pushed from Hubitat) ────────────────────────────────
  const char* lpKey = findKeyIgnoreCase(doc, "localpressure");
  if (lpKey && (doc[lpKey].is<float>() || doc[lpKey].is<int>())) {
    float lp = doc[lpKey].as<float>();
    if (lp >= 800 && lp <= 1200) {
      localPressureHpa          = (float)lp;
      localPressureValid        = true;
      lastLocalPressureReceived = millis();
      DEBUG_PRINTF("  localpressure  : %.1f hPa\n", lp);    }
  }

  // ── Wind direction, local temperature, local humidity (from Hubitat) ──────
  const char* wdKey = findKeyIgnoreCase(doc, "winddir");
  if (wdKey) {
    float wd = doc[wdKey].as<float>();
    if (wd >= 0.0f && wd < 360.0f) {
      localWindDeg = wd;
      DEBUG_PRINTF("  winddir        : %.0f deg\n", wd);
    }
  }
  const char* ltKey = findKeyIgnoreCase(doc, "localtemp");
  if (ltKey) {
    localTemp = doc[ltKey].as<float>();
    DEBUG_PRINTF("  localtemp      : %.1f\n", localTemp);
  }
  const char* lhKey = findKeyIgnoreCase(doc, "localhumidity");
  if (lhKey) {
    float lh = doc[lhKey].as<float>();
    if (lh >= 0.0f && lh <= 100.0f) {
      localHumidity = lh;
      DEBUG_PRINTF("  localhumidity  : %.0f%%\n", lh);
    }
  }

  // ── Clock palette reset ─────────────────────────────────────────────────
  const char* crcKey = findKeyIgnoreCase(doc, "clockresetcolors");
  if (crcKey) {
    String v = String(doc[crcKey].as<const char*>()); v.toLowerCase();
    if (v == "dark" || v == "light") clockDarkMode = (v == "dark");
    clockColorsCustomized = false;
    clockTimeColor     = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
    clockDateColor     = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
    clockBgColor       = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR   : DEFAULT_CLOCK_BG_COLOR_L;
    clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR   : DEFAULT_SUNTIMES_COLOR_L;
    settingsChanged = true;
    DEBUG_PRINTLN("MQTT: clock colors reset");
  }

  // ── Comprehensive clock reset ───────────────────────────────────────────
  const char* craKey = findKeyIgnoreCase(doc, "clockresetall");
  if (craKey) {
    bool doReset = false; String resetMode = "dark";
    if      (doc[craKey].is<bool>())       { doReset = doc[craKey].as<bool>(); }
    else if (doc[craKey].is<const char*>()) {
      String v = String(doc[craKey].as<const char*>()); v.toLowerCase();
      doReset = (v == "true" || v == "1" || v == "yes" || v == "dark" || v == "light");
      if (v == "dark" || v == "light") resetMode = v;
    }
    if (doReset) {
      clockDarkMode         = (resetMode == "dark");
      clockTimeFont         = DEFAULT_TIME_FONT;
      clockDateFont         = DEFAULT_DATE_FONT;
      clockTimeFormat       = DEFAULT_CLOCK_TIME_FORMAT;
      clockDateFormat       = DEFAULT_CLOCK_DATE_FORMAT;
      screenBrightness      = DEFAULT_SCREEN_BRIGHTNESS;
      clockRotation         = DEFAULT_CLOCK_ROTATION;
      clockEnabled          = DEFAULT_CLOCK_ENABLED;
      screensaverDimValue   = DEFAULT_SCREENSAVER_DIM;
      screensaverTimeout    = DEFAULT_SCREENSAVER_TIMEOUT;
      clockSuntimesEnabled  = DEFAULT_SUNTIMES_ENABLED;
      clockColorsCustomized = false;
      clockTimeColor        = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
      clockDateColor        = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
      clockBgColor          = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR   : DEFAULT_CLOCK_BG_COLOR_L;
      clockSuntimesColor    = clockDarkMode ? DEFAULT_SUNTIMES_COLOR   : DEFAULT_SUNTIMES_COLOR_L;
      mqttSaveSettingsAndRedraw();
      DEBUG_PRINTLN("MQTT: clock reset to defaults");
      return;
    }
  }

  // ── Destructive actions (handled last; they reboot or clear) ────────────
  const char* rsKey = findKeyIgnoreCase(doc, "resetsettings");
  if (!rsKey) rsKey = findKeyIgnoreCase(doc, "resetdevice");
  if (rsKey) {
    bool doReset = false;
    if      (doc[rsKey].is<bool>())       { doReset = doc[rsKey].as<bool>(); }
    else if (doc[rsKey].is<const char*>()) {
      String v = String(doc[rsKey].as<const char*>()); v.toLowerCase();
      doReset = (v == "true" || v == "1" || v == "yes");
    }
    if (doReset) { mqttResetSettingsAndReboot(); return; }
  }

  const char* rebootKey = findKeyIgnoreCase(doc, "reboot");
  if (rebootKey) {
    bool doReboot = false;
    if      (doc[rebootKey].is<bool>())       { doReboot = doc[rebootKey].as<bool>(); }
    else if (doc[rebootKey].is<const char*>()) {
      String v = String(doc[rebootKey].as<const char*>()); v.toLowerCase();
      doReboot = (v == "true" || v == "1" || v == "yes");
    }
    if (doReboot) { DEBUG_PRINTLN("MQTT: reboot requested"); delay(200); ESP.restart(); return; }
  }

  // ── Screen navigation ────────────────────────────────────────────────────
  auto mqttBool = [&](const char* key) -> bool {
    const char* k = findKeyIgnoreCase(doc, key);
    if (!k) return false;
    if (doc[k].is<bool>()) return doc[k].as<bool>();
    if (doc[k].is<const char*>()) {
      String v = String(doc[k].as<const char*>()); v.toLowerCase();
      return (v == "true" || v == "1" || v == "yes");
    }
    return false;
  };

  if (mqttBool("weather"))  { mqttShowScreen(MQTT_SCREEN_WEATHER);  return; }
  if (mqttBool("calendar")) { mqttShowScreen(MQTT_SCREEN_CALENDAR); return; }
  if (mqttBool("clock"))    { mqttShowScreen(MQTT_SCREEN_CLOCK);    return; }

  // ── Clear actions ────────────────────────────────────────────────────────
  if (mqttBool("clear")) {
    mqttClearDisplay(); return;
  }
  if (mqttBool("clearhistory")) {
    mqttClearHistory(); return;
  }

  // ── Persist if anything changed ─────────────────────────────────────────
  if (settingsChanged) {
    mqttSaveSettingsAndRedraw();
    DEBUG_PRINTLN("MQTT: control settings saved");
  } else {
    DEBUG_PRINTLN("MQTT: control — no changes");
  }
}

//=============================================================
// device/clockconfig handler
// Mirrors handleClockConfig() in HTML.cpp (JSON POST path).
// Parameters and behavior identical to POST /clockconfig.
//=============================================================
static void handleMqttClockConfig(const String& payload) {
  DEBUG_PRINTLN("\n=== MQTT device/clockconfig ===");
  DEBUG_PRINTLN(payload);

  JsonDocument doc;
  if (deserializeJson(doc, payload)) {
    DEBUG_PRINTLN("MQTT clockconfig: JSON parse error — ignored");
    return;
  }

  bool anyColorChanged = false;

  // String settings
  if (doc.containsKey("timeformat")) { clockTimeFormat = doc["timeformat"].as<String>(); }
  if (doc.containsKey("dateformat")) { clockDateFormat = doc["dateformat"].as<String>(); }

  // Font settings (int → validated)
  int tempInt;
  if (getJSON_Int(doc, "timefont",      tempInt, 6, 60, "  timefont      "))
    { clockTimeFont   = validateRobotoFontCode(tempInt); }
  if (getJSON_Int(doc, "datefont",      tempInt, 6, 60, "  datefont      "))
    { clockDateFont   = validateRobotoFontCode(tempInt); }
  if (getJSON_Int(doc, "labelfont",     tempInt, 6, 60, "  labelfont     "))
    { labelFont       = validateRobotoFontCode(tempInt); }
  if (getJSON_Int(doc, "msgnoticefont", tempInt, 6, 60, "  msgnoticefont "))
    { msgNoticeFont   = validateRobotoFontCode(tempInt); }
  if (getJSON_Int(doc, "weathertempfnt",tempInt, 6, 60, "  wxTempFont    "))
    { weatherTempFont  = (uint8_t)tempInt; }
  if (getJSON_Int(doc, "weatherhumfnt", tempInt, 6, 60, "  wxHumFont     "))
    { weatherHumidFont = (uint8_t)tempInt; }
  if (getJSON_Int(doc, "weatherpresfnt",tempInt, 6, 60, "  wxPresFont    "))
    { weatherPressureFont = (uint8_t)tempInt; }
  if (getJSON_Int(doc, "rotation",      tempInt, 0, 270,"  rotation      ", "°"))
    { clockRotation   = tempInt; }

  // Color settings — mark customized if any color explicitly set
  uint16_t tempColor;
  if (getJSON_Color(doc, "timecolor",          tempColor, "  timecolor     ")) { clockTimeColor     = tempColor; anyColorChanged = true; }
  if (getJSON_Color(doc, "datecolor",          tempColor, "  datecolor     ")) { clockDateColor     = tempColor; anyColorChanged = true; }
  if (getJSON_Color(doc, "bgcolor",            tempColor, "  bgcolor       ")) { clockBgColor       = tempColor; anyColorChanged = true; }
  if (getJSON_Color(doc, "clksuntimescolor",   tempColor, "  suntimescolor ")) { clockSuntimesColor = tempColor; anyColorChanged = true; }
  if (getJSON_Color(doc, "nighttimecolor",     tempColor, "  nighttimeclr  ")) { nightClockTimeColor     = tempColor; }
  if (getJSON_Color(doc, "nightdatecolor",     tempColor, "  nightdateclr  ")) { nightClockDateColor     = tempColor; }
  if (getJSON_Color(doc, "nightbgcolor",       tempColor, "  nightbgclr    ")) { nightClockBgColor       = tempColor; }
  if (getJSON_Color(doc, "nightsuntimescolor", tempColor, "  nightsunclr   ")) { nightClockSuntimesColor = tempColor; }
  if (getJSON_Color(doc, "labelcolor",         tempColor, "  labelcolor    ")) { labelColor   = tempColor; }
  if (getJSON_Color(doc, "msgnoticecolor",     tempColor, "  noticecolor   ")) { msgNoticeColor = tempColor; }

  // Screensaver settings
  if (doc.containsKey("screensaverdim")) {
    screensaverDimValue = (uint8_t)constrain(doc["screensaverdim"].as<int>(), 0, 5);
  }
  ulong tempULong;
  if (getJSON_ULong(doc, "screensavertimeout", tempULong, 0, 3600000, "  screensaverto ", " ms"))
    { screensaverTimeout = tempULong; }

  // Brightness settings
  uint8_t tempBri;
  if (getJSON_UInt(doc, "brightness",      tempBri, 0, 5, "  brightness    ")) { screenBrightness       = tempBri; }
  if (getJSON_UInt(doc, "nightbrightness", tempBri, 0, 5, "  nightbright   ")) { nightModeBrightness    = tempBri; }
  if (getJSON_UInt(doc, "daybrightness",   tempBri, 0, 5, "  daybright     ")) { nightModeWakeBrightness= tempBri; }

  // Sunset/sunrise offsets
  if (getJSON_Int(doc, "sunsetoffset",  tempInt, -360, 360, "  sunsetoffset  ", " min")) { sunsetOffset  = tempInt; }
  if (getJSON_Int(doc, "sunriseoffset", tempInt, -360, 360, "  sunriseoffset ", " min")) { sunriseOffset = tempInt; }

  // Night wake duration (seconds → ms)
  if (getJSON_ULong(doc, "nightwakedur", tempULong, 1, 3600, "  nightwakedur  ", " sec"))
    { nightModeWakeDuration = tempULong * 1000; }

  // Boolean settings
  bool tempBool;
  if (getJSON_Bool(doc, "clockenable",        tempBool, "  clockenable   ")) { clockEnabled        = tempBool; }
  if (getJSON_Bool(doc, "nightmodeenable",    tempBool, "  nightmodeen   ")) { nightModeEnabled    = tempBool; }
  if (getJSON_Bool(doc, "clksuntimesenabled", tempBool, "  suntimesen    ")) { clockSuntimesEnabled= tempBool; }
  if (getJSON_Bool(doc, "tempcelsius",        tempBool, "  tempcelsius   ")) { tempCelsius         = tempBool; }

  mqttClockConfigApply(anyColorChanged);
}

//=============================================================
// sMQTTBroker subclass  (class definition in .cpp — NOT .ino)
//=============================================================
class MultiDisplayBroker : public sMQTTBroker {

public:
  bool onEvent(sMQTTEvent* event) override {
    switch (event->Type()) {

      case NewClient_sMQTTEventType:
        mqttClientCount++;
        DEBUG_PRINTF("MQTT: client connected | total %d\n", mqttClientCount);
        if (mqttHistoryReady) {
          mqttPublishPressureHistory();  // buffer loaded — safe to publish
        } else {
          DEBUG_PRINTLN("MQTT: NewClient — history not ready yet, skipping publish");
        }
        break;

      case RemoveClient_sMQTTEventType:
        if (mqttClientCount > 0) mqttClientCount--;
        DEBUG_PRINTF("MQTT: client disconnected | total %d\n", mqttClientCount);
        break;

      case Public_sMQTTEventType: {
        auto* e        = static_cast<sMQTTPublicClientEvent*>(event);
        String topic   = String(e->Topic().c_str());
        String payload = String(e->Payload().c_str());
        mqttMessagesReceived++;

        // Suppress Hubitat beta bug — HA discovery traffic published even
        // when that option is disabled. All empty payloads, nothing to process.
        if (topic.startsWith("homeassistant/")) return true;

        DEBUG_PRINTF("MQTT: topic=%s len=%d\n", topic.c_str(), (int)payload.length());

        if (topic == "display/clear") {
          mqttClearDisplay();            // wrapper in MQTTBroker.ino
          forwardToCYDs("", true);

        } else if (topic == "display/message") {
          mqttProcessMessage(payload);
          forwardToCYDs(payload, false);

        } else if (topic == "display/message/elecrow") {
          mqttProcessMessage(payload);   // local only

        } else if (topic == "display/message/cyd") {
          forwardToCYDs(payload, false); // CYDs only

        } else if (topic.startsWith("display/message/device/")) {
          String targetName = topic.substring(strlen("display/message/device/"));
          for (const auto& d : cydDisplays) {
            if (d.name == targetName) {
              MQTTFwdTask* tp = new MQTTFwdTask();
              tp->url  = d.messageUrl;
              tp->body = payload;
              tp->name = d.name;
              if (xTaskCreate(mqttHttpFwdTask, "mqttFwd", MQTT_FWD_TASK_STACK,
                              tp, 1, NULL) != pdPASS) {
                DEBUG_PRINTF("  MQTT Fwd [%s] task create failed\n", d.name.c_str());
                delete tp;
              }
              DEBUG_PRINTF("MQTT: targeted message to [%s]\n", d.name.c_str());
              break;
            }
          }

        } else if (topic.startsWith("display/clear/device/")) {
          String targetName = topic.substring(strlen("display/clear/device/"));
          for (const auto& d : cydDisplays) {
            if (d.name == targetName) {
              MQTTFwdTask* tp = new MQTTFwdTask();
              tp->url  = d.clearUrl;
              tp->body = "";
              tp->name = d.name;
              if (xTaskCreate(mqttHttpFwdTask, "mqttFwd", MQTT_FWD_TASK_STACK,
                              tp, 1, NULL) != pdPASS) {
                DEBUG_PRINTF("  MQTT Fwd [%s] task create failed\n", d.name.c_str());
                delete tp;
              }
              DEBUG_PRINTF("MQTT: targeted clear to [%s]\n", d.name.c_str());
              break;
            }
          }
    
        } else if (topic == "display/screen") {
          // Navigate Elecrow AND all CYDs to the requested screen.
          String screen = payload;
          screen.toLowerCase(); screen.trim();
          if      (screen == "weather")  { mqttShowScreen(MQTT_SCREEN_WEATHER);
            forwardJsonToCYDs("/control", "{\"weather\":true}"); }
          else if (screen == "calendar") { mqttShowScreen(MQTT_SCREEN_CALENDAR);
            forwardJsonToCYDs("/control", "{\"calendar\":true}"); }
          else if (screen == "clock")    { mqttShowScreen(MQTT_SCREEN_CLOCK);
            forwardJsonToCYDs("/control", "{\"clock\":true}"); }
          else DEBUG_PRINTF("MQTT: unknown screen '%s'\n", screen.c_str());
        }
        else if (topic == "device/control") {
          handleMqttControl(payload);                               //apply on Elecrow display
          String safe = sanitizeControlForCYDs(payload);
          if (!safe.isEmpty()) forwardJsonToCYDs("/control", safe); //forward safe subset to CYD displays
        }
        else if (topic == "device/clockconfig") {
          handleMqttClockConfig(payload);                           //apply on Elecrow display
          forwardJsonToCYDs("/clockconfig", payload);               //forward to all CYD displays
        }
        else if (topic.endsWith("/devices/" + String(HUBITAT_PRESSURE_DEVICE_ID))) {
        // Hubitat MQTT Export Integration publishes full device JSON on any
        // attribute change. Topic: hubitat/<hub-uuid>/devices/<id>
        // We need to find the "pressure" attribute in the attributes array.
        JsonDocument doc;
        if (!deserializeJson(doc, payload)) {
          JsonArray attrs = doc["attributes"].as<JsonArray>();
          for (JsonObject attr : attrs) {
            if (strcmp(attr["name"].as<const char*>(), "pressure") == 0) {
              float hpa = String(attr["value"].as<const char*>()).toFloat();
              if (hpa >= 800.0f && hpa <= 1200.0f) {
                localPressureHpa          = hpa;
                localPressureValid        = true;
                lastLocalPressureReceived = millis();
                lastLocalPressureFetch    = millis(); // reset backup timer — no HTTP fetch needed for 30 min
                DEBUG_PRINTF("MQTT: local pressure updated: %.1f hPa\n", hpa);
                mqttRefreshWeatherIfShowing();        // redraw weather screen if it is showing local pressure
                mqttPublishPressure();                // rebroadcast as retained topic for CYD subscribers
                forwardJsonToCYDs("/control", "{\"localpressure\":" + String((int)hpa) + "}");
              } else {
                DEBUG_PRINTF("MQTT: pressure value %.1f out of range — ignored\n", hpa);
              }
              break;   // found pressure attribute, no need to continue loop
            }
          }
        }
      }
        break;
      }

      case LostConnect_sMQTTEventType:
        DEBUG_PRINTLN("MQTT: broker lost network connection");
        break;

      default: break;
    }
    return true;
  }
};

static MultiDisplayBroker broker;

//=============================================================
// mqttPublish() — inject a retained message into the broker
//
// Calls broker.publish() with std::string arguments, which matches
// the sMQTTBroker API used by this sketch (SloCompTech/sMQTTBroker).
// If your sMQTTBroker version expects (const char*, const char*, bool)
// instead, change the two std::string() casts to direct char* calls.
//=============================================================
void mqttPublish(const char* topic, const char* payload, bool retain) {
  broker.publish(std::string(topic), std::string(payload), retain);
}

//=============================================================
// Public API
//=============================================================
void startMqttBroker() {
  mqttFwdMutex = xSemaphoreCreateMutex();
  if (!LittleFS.begin(true)) {
    DEBUG_PRINTLN("MQTT: LittleFS mount failed — CYD config unavailable");
  }

  loadCYDDisplays();

  broker.init(MQTT_PORT);

  DEBUG_PRINTF("MQTT: broker started on port %d (%d CYD display(s))\n",
               MQTT_PORT, (int)cydDisplays.size());
  DEBUG_PRINTF("MQTT: connect to %s:%d\n",
               WiFi.localIP().toString().c_str(), MQTT_PORT);
}

void mqttBrokerUpdate() {
  broker.update();
}
