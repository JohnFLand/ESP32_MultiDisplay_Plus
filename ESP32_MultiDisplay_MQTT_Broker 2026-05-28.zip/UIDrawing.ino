//=============================================================
// UIDrawing.ino  —  menu, message history screen, nav arrows
//=============================================================

// Renders a solid-colour icon using a PROGMEM alpha mask.
// fgColor is drawn where the mask is opaque; bgColor where transparent.
void drawAlphaMaskIcon(PSRAMCanvas* gfx,
                       int16_t x, int16_t y,
                       const uint8_t* alpha,
                       int16_t w, int16_t h,
                       uint16_t fgColor, uint16_t bgColor)
{
  // Unpack fg and bg to 8-bit channels once
  uint8_t fr = ((fgColor >> 11) & 0x1F) * 255 / 31;
  uint8_t fg = ((fgColor >>  5) & 0x3F) * 255 / 63;
  uint8_t fb = ((fgColor      ) & 0x1F) * 255 / 31;

  uint8_t br = ((bgColor >> 11) & 0x1F) * 255 / 31;
  uint8_t bg = ((bgColor >>  5) & 0x3F) * 255 / 63;
  uint8_t bb = ((bgColor      ) & 0x1F) * 255 / 31;

  static uint16_t* row = nullptr;
  static int16_t   rowW = 0;
  if (rowW < w) {
    if (row) free(row);
    row  = (uint16_t*)malloc(w * sizeof(uint16_t));
    rowW = w;
  }
  if (!row) return;

  for (int16_t yy = 0; yy < h; yy++) {
    const uint8_t* a = alpha + (yy * w);
    for (int16_t xx = 0; xx < w; xx++) {
      uint8_t A = pgm_read_byte(&a[xx]);
      if      (A == 0)   { row[xx] = bgColor; }
      else if (A == 255) { row[xx] = fgColor; }
      else {
        uint8_t orr = (uint16_t(fr)*A + uint16_t(br)*(255-A)) / 255;
        uint8_t org = (uint16_t(fg)*A + uint16_t(bg)*(255-A)) / 255;
        uint8_t orb = (uint16_t(fb)*A + uint16_t(bb)*(255-A)) / 255;
        row[xx] = ((orr & 0xF8) << 8) | ((org & 0xFC) << 3) | (orb >> 3);
      }
    }
    gfx->draw16bitRGBBitmap(x, y + yy, row, w, 1);
  }
}

void drawMenu() {
  int bgColor = menuDarkMode ? DEFAULT_MENU_BG_COLOR : DEFAULT_MENU_BG_COLOR_L;

  gfx->fillScreen(bgColor);
  int16_t x1, y1;
  uint16_t w, h;

  for (int i = 0; i < NUM_BUTTONS; i++) {
    Button btn = menuButtons[i];
    gfx->fillRoundRect(btn.x, btn.y, btn.w, btn.h, 10, btn.color);
    gfx->drawRoundRect(btn.x, btn.y, btn.w, btn.h, 10, COLOR_WHITE);

    setSmartFont(menuFont);  //Roboto 12pt for button labels

    uint16_t textW, textH;
    getTextBoundsHF(btn.label, 0, 0, &x1, &y1, &textW, &textH);
    gfx->setTextColor(COLOR_WHITE);
    int textX = btn.x + (btn.w - textW) / 2;
    int textY = btn.y + (btn.h + textH) / 2 - 2;

    gfx->setCursor(textX, textY);
    printHF(btn.label);

    // Unread badge on the History button — radius auto-sized to the count text
    if (btn.targetScreen == SCREEN_MESSAGES && unreadCount > 0) {
      char countStr[4];
      snprintf(countStr, sizeof(countStr), "%d", min(unreadCount, 99));

      // Measure the count string at the menu font (radius auto-adapts)
      setSmartFont(menuFont);
      getTextBoundsHF(countStr, 0, 0, &x1, &y1, &w, &h);

      // Radius snugly wraps the text (driven by whichever dimension is larger)
      const int16_t pad    = 5;
      int16_t       badgeR = (int16_t)(max(w, h) / 2) + pad;
      int16_t       badgeCX = btn.x + btn.w - badgeR;
      int16_t       badgeCY = btn.y + badgeR;

      gfx->fillCircle(badgeCX, badgeCY, badgeR, COLOR_RED);
      gfx->setTextColor(COLOR_WHITE);
      // Centre text using the GFX bounding-box anchor (x1 / y1) for
      // pixel-perfect alignment regardless of digit count or font metrics
      gfx->setCursor(badgeCX - x1 - (int16_t)w / 2,
                     badgeCY - y1 - (int16_t)h / 2);
      printHF(countStr);

      setSmartFont(menuFont);  // restore button-label font
    }
  }

  flushDisplay();
}

void drawMessagesScreen() {
  uint16_t bgColor      = historyDarkMode ? DEFAULT_HISTORY_BG_COLOR    : DEFAULT_HISTORY_BG_COLOR_L;
  uint16_t titleColor   = historyDarkMode ? DEFAULT_HISTORY_TITLE_COLOR : DEFAULT_HISTORY_TITLE_COLOR_L;
  uint16_t msgColor     = historyDarkMode ? DEFAULT_HISTORY_MSG_COLOR   : DEFAULT_HISTORY_MSG_COLOR_L;
  uint16_t msgNumColor  = historyDarkMode ? DEFAULT_MSG_NUM_COLOR       : DEFAULT_MSG_NUM_COLOR_L;
  uint16_t msgTimeColor = historyDarkMode ? DEFAULT_TIMESTAMP_COLOR     : DEFAULT_TIMESTAMP_COLOR_L;
  uint16_t msgBarColor  = historyDarkMode ? DEFAULT_BAR_COLOR           : DEFAULT_BAR_COLOR_L;

  //── REENTRY GUARD: blocks double-call from rapid touch ─────
  static bool _inDraw = false;
  if (_inDraw) { return; }
  _inDraw = true;
  struct _DrawGuard { ~_DrawGuard() { _inDraw = false; } } _guard;
  //────────────────────────────────────────────────────────────

  gfx->fillScreen(bgColor);

  //Title — setTextColor AFTER getTextBounds (color not needed for measuring)
  setSmartFont(screenHeaderFont);  //Roboto 20pt for title

  int16_t x1, y1;
  uint16_t w, h;
  getTextBoundsHF("MESSAGE HISTORY", 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(titleColor);
  gfx->setCursor((DISPLAY_LONG - w) / 2, -y1 + 8 + SCREEN_LAYOUT_SHIFT_Y);
  printHF("MESSAGE HISTORY");

  if (messageCount == 0) {
    //No messages - show help text
    setSmartFont(currentFont);  //Roboto 12pt
    gfx->setTextColor(msgColor);
    getTextBoundsHF("No messages", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, DISPLAY_SHORT / 2 - (int16_t)h / 2 - y1);
    printHF("No messages");

    setSmartFont(msgNoticeFont);  //Roboto 10pt
    gfx->setTextColor(COLOR_RED);
    getTextBoundsHF("Send a message to:", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 300 + SCREEN_LAYOUT_SHIFT_Y);
    printHF("Send a message to:");

    String url = "http://" + WiFi.localIP().toString() + "/message";
    getTextBoundsHF(url.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 325 + SCREEN_LAYOUT_SHIFT_Y);
    printHF(url.c_str());
  } else {
    //Ensure currentHistoryIndex is valid
    if (currentHistoryIndex >= messageCount) currentHistoryIndex = messageCount - 1;
    if (currentHistoryIndex < 0) currentHistoryIndex = 0;

    //Get the message to display
    Message& msg = messages[currentHistoryIndex];
    if (msg.unread) {  //Mark as read
      msg.unread = false;
      unreadCount--;
      if (unreadCount < 0) unreadCount = 0;
    }

    //Display message number indicator
    setSmartFont(msgNoticeFont);  //Roboto 10pt

    String indicator = "Message " + String(currentHistoryIndex + 1) + " of " + String(messageCount);
    getTextBoundsHF(indicator.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(msgNumColor);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 80 + SCREEN_LAYOUT_SHIFT_Y);
    printHF(indicator.c_str());

    //Display timestamp
    gfx->setTextColor(msgTimeColor);
    getTextBoundsHF(msg.time.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 115 + SCREEN_LAYOUT_SHIFT_Y);
    printHF(msg.time.c_str());

    //Display message text in larger font
    setSmartFont(historyTextFont);  //Roboto 16pt
    gfx->setTextColor(msgColor);

    //Word wrap the message manually for better control
    String text = msg.text;
    int lineHeight = 30;                    //Line height for 18pt historyTextFont
    int y = 160 + SCREEN_LAYOUT_SHIFT_Y;    //Start below timestamp 
    int maxWidth = 760;                     //Leave 20px margin each side of 800px
    int x = 20;

    //Simple word wrapping
    String currentLine = "";
    int wordStart = 0;
    int i = 0;

    while (i < text.length()) {
      //Find next space or end of string
      int nextSpace = text.indexOf(' ', i);
      if (nextSpace == -1) nextSpace = text.length();

      String word = text.substring(i, nextSpace);
      String testLine = currentLine + (currentLine.length() > 0 ? " " : "") + word;

      //Check if line would be too wide
      getTextBoundsHF(testLine.c_str(), 0, 0, &x1, &y1, &w, &h);

      if (w > maxWidth && currentLine.length() > 0) {
        //Print current line and start new one
        gfx->setCursor(x, y);
        printHF(currentLine.c_str());
        y += lineHeight;
        currentLine = word;
      } else {
        currentLine = testLine;
      }

      i = nextSpace + 1;

      //Stop if we're running out of space
      if (y > 380) break;
    }

    //Print last line
    if (currentLine.length() > 0 && y <= 380) {
      gfx->setCursor(x, y);
      printHF(currentLine.c_str());
    }
  }

  //Progress indicator (visual bar showing position in message list)
  if (messageCount > 1) {
    int barWidth = DISPLAY_LONG - 80;  //720px: 40px margins on 800px display
    int barHeight = 4;
    int barX = 40;
    int barY = 390;                    //progress bar near bottom

    //Background bar
    gfx->fillRect(barX, barY, barWidth, barHeight, COLOR_GRAY);

    //Progress indicator pip (2 px taller than background for visibility)
    int indicatorWidth = barWidth / messageCount;
    int indicatorX = barX + (currentHistoryIndex * barWidth / messageCount);
    gfx->fillRect(indicatorX, barY - 2, indicatorWidth, barHeight + 4, msgBarColor);
  }

  //Navigation hint — centred between progress bar and bottom buttons
  //Only shown when there are multiple messages to swipe through
  if (messageCount > 1) {
    setSmartFont(msgNoticeFont);  //Roboto 10pt
    gfx->setTextColor(msgColor);
    String line1 = "Swipe up/down to navigate";
    getTextBoundsHF(line1.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 460);
    printHF(line1.c_str());
  }

  //Draw navigation arrows if we have multiple messages
  if (messageCount > 1) {
    uint16_t c = msgBarColor;
    drawNavArrow(true,  MSG_ARROW_AX, MSG_UP_ARROW_Y, MSG_ARROW_AW, MSG_ARROW_AH, c);  //Up arrow
    drawNavArrow(false, MSG_ARROW_AX, MSG_DN_ARROW_Y, MSG_ARROW_AW, MSG_ARROW_AH, c);  //Down arrow
  }  //end if (messageCount > 1)

  //Draw ✕ clear-history button (lower-right) whenever there is at least one message
  if (messageCount > 0) {
    gfx->fillCircle(MSG_XBTN_CX, MSG_XBTN_CY, MSG_XBTN_R, COLOR_RED);
    setSmartFont(msgNoticeFont);
    int16_t bx1, by1; uint16_t bw, bh;
    getTextBoundsHF("x", 0, 0, &bx1, &by1, &bw, &bh);
    gfx->setTextColor(COLOR_WHITE);
    gfx->setCursor(MSG_XBTN_CX - bw / 2, MSG_XBTN_CY + bh / 2 - 1);
    printHF("x");
  }  //end if (messageCount > 0)

  //Draw « return button (lower-left) — only when there are messages
  if (messageCount > 0) {
    gfx->fillCircle(MSG_RETBTN_CX, MSG_RETBTN_CY, MSG_RETBTN_R, COLOR_BLUE);
    setSmartFont(msgNoticeFont);
    int16_t bx1, by1; uint16_t bw, bh;
    getTextBoundsHF("\xAB", 0, 0, &bx1, &by1, &bw, &bh);  // «
    gfx->setTextColor(COLOR_WHITE);
    gfx->setCursor(MSG_RETBTN_CX - bw / 2, MSG_RETBTN_CY + bh / 2 - 1);
    printHF("\xAB");
  }  //end if (messageCount > 0)

  flushDisplay();
}

static void drawNavArrow(bool up, int x, int y, int w, int h, uint16_t color) {
  //x,y = top-left of arrow bounding box
  //w,h = size
  if (up) {
    gfx->fillTriangle(x + w/2, y,        x, y + h,        x + w, y + h, color);
  } else {
    gfx->fillTriangle(x, y,             x + w, y,        x + w/2, y + h, color);
  }
}
