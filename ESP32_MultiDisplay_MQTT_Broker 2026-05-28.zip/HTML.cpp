#include "HTML.h"
#include "HelpFunctions.h"
#include "User_Setup.h"
#include "WebDebugLog.h"
#include <WiFi.h>
#include <Update.h>
#include <Preferences.h>

//ROM function for RF noise floor measurement (ESP32-S3; returns 1/4 dBm units)
extern "C" { int rom_check_noise_floor(void); }

// External references from main sketch
extern const char* Version;
extern char Timestamp[20];
extern Preferences preferences;
extern WebServer server;
extern String deviceName;
extern String deviceID;
extern int messageCount;
extern int unreadCount;
extern int currentHistoryIndex;

// OTA security state
extern String otaPassword;
extern bool otaAuthenticationFailed;
extern int failedOTAAttempts;
extern ulong lastFailedOTAAttempt;
extern bool otaUpdateSuccessful;

// Scheduling
extern int sunriseHour;
extern int sunriseMinute;
extern int sunsetHour;
extern int sunsetMinute;
extern bool sunTimesValid;
extern ScheduledAction schedules[];
extern MsgProfile msgProfiles[];

// Display states
extern bool showClock;
extern bool screensaverActive;
extern bool isPulsing;
extern bool isFlashing;
extern ulong lastMessageTime;
extern ulong lastClockOrMessageTime;
extern uint8_t actualCurrentBrightness;
extern ulong currentPulseDuration;

// Current message settings
extern uint16_t currentBgColor;
extern uint16_t currentTextColor;
extern uint8_t currentTextSize;
extern uint8_t currentFont;
extern int currentRotation;
extern String currentHAlign;
extern String currentVAlign;
extern bool currentWrap;
extern String currentScrollDirection;
extern uint8_t currentScrollSpeed;
extern uint8_t currentBrightness;
extern ulong currentFlashInterval;
extern bool currentFlash;
extern bool currentPulse;
extern bool messageActive;
extern int messageExpirationTime;
extern String messagePriority;
extern ulong messageDisplayStartTime;

// Clock settings
extern bool clockEnabled;
extern String clockTimeFormat;
extern String clockDateFormat;
extern uint8_t clockTimeFont;
extern uint8_t clockDateFont;
extern uint16_t clockTimeColor;
extern uint16_t clockDateColor;
extern uint16_t clockBgColor;
extern bool clockColorsCustomized;
extern uint8_t screenBrightness;
extern int clockRotation;
extern uint8_t screensaverDimValue;
extern ulong screensaverTimeout;
extern bool clockSuntimesEnabled;
extern uint16_t clockSuntimesColor;
extern ulong lastNightModeCheck;
extern int labelFont;
extern int msgNoticeFont;
extern uint16_t labelColor;
extern uint16_t msgNoticeColor;
extern uint8_t weatherTempFont;
extern uint8_t weatherHumidFont;
extern uint8_t weatherPressureFont;
extern String weatherLocation;
extern String weatherLatitude;
extern String weatherLongitude;
extern String weatherTimezone;
extern String weatherTzString;
extern String weatherAltitude;

// Night mode
extern bool nightModeEnabled;
extern bool nightModeActive;
extern uint8_t nightModeBrightness;
extern uint8_t nightModeWakeBrightness;
extern int sunsetOffset;
extern int sunriseOffset;
extern uint16_t nightClockTimeColor;
extern uint16_t nightClockDateColor;
extern uint16_t nightClockBgColor;
extern uint16_t nightClockSuntimesColor;

// Light/Dark Theme modes
extern bool weatherDarkMode;
extern bool calendarDarkMode;
extern bool menuDarkMode;
extern bool historyDarkMode;
extern bool clockDarkMode;
extern bool astroDarkMode;
extern bool astroShowMoon;
extern bool aboutSubPage;
extern bool weatherSubPage;

// Screen mode enum
enum ScreenMode {
  SCREEN_NONE = -1,
  SCREEN_CLOCK,
  SCREEN_MENU,
  SCREEN_MESSAGE,
  SCREEN_MESSAGES,
  SCREEN_WEATHER,
  SCREEN_CALENDAR,
  SCREEN_ASTRO,
  SCREEN_ABOUT
};
extern ScreenMode currentScreen;

// Device controls
extern bool pixelShiftEnabled;
extern bool touchEnabled;
extern bool weatherCycleEnabled;
extern bool calendarCycleEnabled;
extern ulong weatherShowDuration;
extern ulong weatherCycleInterval;
extern ulong calendarShowDuration;
extern ulong calendarCycleInterval;
extern ulong nightModeWakeDuration;
extern bool tempCelsius;
extern bool tempActual;
extern bool tempAlternate;
extern bool tempAlternateShowActual;
extern bool  localPressureValid;
extern float localPressureHpa;
extern float localWindDeg;
extern float localTemp;
extern float localHumidity;
extern ulong lastLocalPressureReceived;
extern ulong lastTempAlternation;
extern int highPriorityAlternateInterval;
extern bool normalOverrideEnabled;
extern int normalOverrideDuration;
extern uint8_t pulseMaxBrightness;
extern uint8_t pulseMinBrightness;
extern int maxMsgAge;

// OTA security constants
extern const int MAX_OTA_ATTEMPTS;
extern const ulong OTA_LOCKOUT_TIME;

extern Message messages[];
extern int messageCount;

// Helper: color to string
extern String colorToString(uint16_t color);

// .ino functions
extern void displayWeather();
extern void displayCalendar();
extern void drawClock();
extern void drawMenu();
extern void drawMessagesScreen();
extern void drawAstroScreen();
extern void saveSettings();
extern void setBrightness(uint8_t brightness);
extern void changeScreen(ScreenMode newScreen);
extern volatile ScreenMode pendingScreen;
extern void updateNightMode();

// Additional variables for clear functionality
extern int normalQueueHead;
extern int normalQueueTail;
extern int normalQueueCount;

//=============================================================
// Named color <option> builder (avoids repeating compare logic)
//=============================================================
struct NamedColorOption {
  const char *value;  // POST/GET value (e.g., "magenta")
  const char *label;  // UI label (e.g., "Magenta")
  uint16_t rgb565;    // COLOR_* constant
};

static const NamedColorOption COLOR_OPTIONS[] = {
  { "white",      "White",      COLOR_WHITE },
  { "black",      "Black",      COLOR_BLACK },
  { "red",        "Red",        COLOR_RED },
  { "green",      "Green",      COLOR_GREEN },
  { "blue",       "Blue",       COLOR_BLUE },
  { "cyan",       "Cyan",       COLOR_CYAN },
  { "yellow",     "Yellow",     COLOR_YELLOW },
  { "magenta",    "Magenta",    COLOR_MAGENTA },
  { "orange",     "Orange",     COLOR_ORANGE },
  { "purple",     "Purple",     COLOR_PURPLE },
  { "pink",       "Pink",       COLOR_PINK },
  { "brown",      "Brown",      COLOR_BROWN },
  { "lightgray",  "Light Gray", COLOR_LIGHTGRAY },
  { "gray",       "Gray",       COLOR_GRAY },
  { "darkgray",   "Dark Gray",  COLOR_DARKGRAY },
  { "gray10",     "Gray 10%",   COLOR_GRAY10 },
  { "gray20",     "Gray 20%",   COLOR_GRAY20 },
  { "gray30",     "Gray 30%",   COLOR_GRAY30 },
  { "gray40",     "Gray 40%",   COLOR_GRAY40 },
  { "gray50",     "Gray 50%",   COLOR_GRAY50 },
  { "gray60",     "Gray 60%",   COLOR_GRAY60 },
  { "gray70",     "Gray 70%",   COLOR_GRAY70 },
  { "gray80",     "Gray 80%",   COLOR_GRAY80 },
  { "gray90",     "Gray 90%",   COLOR_GRAY90 },
};

static String buildNamedColorOptions(uint16_t currentColor, bool blackFirst) {
  String out;
  out.reserve(1200);
  out += F("<option value=''>Named Color...</option>");

  // If you prefer "Black" as the first option (common for backgrounds), do that.
  if (blackFirst) {
    out += String(F("<option value='black' data-hex='")) + colorToHex(COLOR_BLACK) + "'" +
           String(currentColor == COLOR_BLACK ? F(" selected") : F("")) +
           F(">Black</option>");

    // Add the rest, skipping black
    for (size_t i = 0; i < sizeof(COLOR_OPTIONS) / sizeof(COLOR_OPTIONS[0]); i++) {
      if (strcmp(COLOR_OPTIONS[i].value, "black") == 0) continue;

      out += String(F("<option value='")) + COLOR_OPTIONS[i].value +
             F("' data-hex='") + colorToHex(COLOR_OPTIONS[i].rgb565) + "'" +
             String(currentColor == COLOR_OPTIONS[i].rgb565 ? F(" selected") : F("")) +
             ">" + COLOR_OPTIONS[i].label + "</option>";
    }
    return out;
  }

  // Default order (white first as defined above)
  for (size_t i = 0; i < sizeof(COLOR_OPTIONS) / sizeof(COLOR_OPTIONS[0]); i++) {
    out += String(F("<option value='")) + COLOR_OPTIONS[i].value +
           F("' data-hex='") + colorToHex(COLOR_OPTIONS[i].rgb565) + "'" +
           String(currentColor == COLOR_OPTIONS[i].rgb565 ? F(" selected") : F("")) +
           ">" + COLOR_OPTIONS[i].label + "</option>";
  }

  return out;
}

static const uint8_t ROBOTO_FONT_POINTS[] = {
  6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28,
  30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 54, 60
};

static String buildRobotoFontOptions(int currentFont, int starredFont = -1) {
  String out;
  out.reserve(1800);

  for (size_t i = 0; i < sizeof(ROBOTO_FONT_POINTS) / sizeof(ROBOTO_FONT_POINTS[0]); i++) {
    const int fontPt = ROBOTO_FONT_POINTS[i];
    out += "<option value='" + String(fontPt) + "'";
    if (currentFont == fontPt) out += " selected";
    out += ">";
    if (fontPt < 10) out += "&nbsp;&nbsp;";
    out += String(fontPt) + " - Roboto " + String(fontPt) + "pt";
    if (fontPt == starredFont) out += " ⭐";
    out += "</option>";
  }

  return out;
}

static String buildRobotoFontGuide(int messageDefaultFont) {
  String out;
  out.reserve(1200);
  out += "<ul>";

  for (size_t i = 0; i < sizeof(ROBOTO_FONT_POINTS) / sizeof(ROBOTO_FONT_POINTS[0]); i++) {
    const int fontPt = ROBOTO_FONT_POINTS[i];
    out += "<li><b>";
    if (fontPt < 10) out += "&nbsp;&nbsp;";
    out += String(fontPt) + ":</b> Roboto " + String(fontPt) + "pt";
    if (fontPt == 6) out += " (smallest)";
    if (fontPt == messageDefaultFont) out += " (default for messages)";
    if (fontPt == 48) out += " (largest)";
    out += "</li>";
  }

  out += "</ul>";
  return out;
}

//=============================================================
// HTML Helpers
//=============================================================
//Build the Signal / Noise / SNR portion of an info-bar (returns empty string if WiFi not connected)
static String wifiSignalHtml() {
  if (WiFi.status() != WL_CONNECTED) return "";
  int rssi = WiFi.RSSI();
  int nf   = rom_check_noise_floor() / 4;
  if (nf > 0) nf = -nf;
  int snr  = rssi - nf;
  return String("<br><strong>Signal:</strong> ") + rssi +
         " dBm &nbsp; <strong>Noise:</strong> " + nf +
         " dBm &nbsp; <strong>SNR:</strong> " + snr +
         " dB (" + snrLabel(snr) + ")";
}

static String htmlEscape(const String &in) {
  String out;
  out.reserve(in.length() + 16);
  for (size_t i = 0; i < in.length(); i++) {
    char c = in[i];
    switch (c) {
      case '&':  out += F("&amp;");  break;
      case '<':  out += F("&lt;");   break;
      case '>':  out += F("&gt;");   break;
      case '"':  out += F("&quot;"); break;
      case '\'': out += F("&#39;");  break;
      default:   out += c;           break;
    }
  }
  return out;
}

//=============================================================
// Message Sent confirmation page (no auto-redirect)
//=============================================================
void sendMessageSentPage(
  const String &message,
  uint16_t bgColor,
  uint16_t textColor,
  int font,
  int rotation,
  const String &hAlign,
  const String &vAlign,
  bool wrap,
  const String &scrollDirection,
  uint8_t scrollSpeed,
  uint8_t brightness,
  bool flash,
  ulong flashInterval,
  bool pulse,
  ulong pulseDuration,
  const String &priority,
  int expirationTime
) {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  String html;
  html.reserve(3800);

  html += "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Message Sent</title>";
  html += "<style>";
  html += "body{font-family:Arial,Helvetica,sans-serif;max-width:900px;margin:20px auto;padding:0 16px;color:#222;"
          "background:#f5f5f5;}";
  html += "h1{color:#333;border-bottom:3px solid #4CAF50;padding-bottom:10px;margin:0 0 12px 0;}";
  html += ".card{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;margin:14px 0;}";
  html += ".summary-item{display:grid;grid-template-columns:180px 1fr;gap:10px;margin:10px 0;padding:8px;border-bottom:1px solid "
          "#eee;}";
  html += ".summary-label{font-weight:bold;color:#555;}";
  html += ".summary-value{color:#333;}";
  html += ".message-preview{background:#f9f9f9;padding:15px;border-radius:6px;border-left:4px solid #2196F3;"
          "font-family:monospace;word-wrap:break-word;white-space:pre-wrap;margin:15px 0;}";
  html += "a{color:#1a73e8;text-decoration:none;}";
  html += "a:hover{text-decoration:underline;}";
  html += ".badge{display:inline-block;padding:3px 8px;border-radius:10px;font-size:12px;font-weight:bold;}";
  html += ".badge-yes{background:#4CAF50;color:#fff;}";
  html += ".badge-no{background:#9e9e9e;color:#fff;}";
  html += "</style></head><body>";

  html += "<h1>✅ Message Sent Successfully</h1>";
  html += "<p>Your message has been displayed on the device and is now showing.</p>";

  html += "<div class='card'>";
  html += "<h3 style='margin:0 0 8px 0;'>Message Summary</h3>";

  html += "<div class='message-preview'>\"";
  html += htmlEscape(message);
  html += "\"</div>";

  html += "<div class='summary-item'><div class='summary-label'>High Priority:</div><div class='summary-value'>";
  bool isHigh = (priority.equalsIgnoreCase("high") || priority.equalsIgnoreCase("true") || priority.equalsIgnoreCase("1"));
  html += (isHigh ? "<span class='badge badge-yes'>YES</span>" : "<span class='badge badge-no'>NO</span>");
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Message Expiration:</div><div class='summary-value'>";
  if (expirationTime > 0) {
    html += String(expirationTime);
    html += " sec";
  } else {
    html += "None";
  }
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Background Color:</div><div class='summary-value'>";
  html += colorToString(bgColor);
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Text Color:</div><div class='summary-value'>";
  html += colorToString(textColor);
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Font:</div><div class='summary-value'>";
  html += String(font);
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Rotation:</div><div class='summary-value'>";
  html += String(rotation);
  html += "°</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Alignment:</div><div class='summary-value'>";
  html += htmlEscape(hAlign);
  html += " / ";
  html += htmlEscape(vAlign);
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Text Wrap:</div><div class='summary-value'>";
  html += (wrap ? "<span class='badge badge-yes'>YES</span>" : "<span class='badge badge-no'>NO</span>");
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Brightness:</div><div class='summary-value'>";
  html += String(brightness);
  html += " / 5</div></div>";

  // Scrolling
  html += "<div class='summary-item'><div class='summary-label'>Scroll Direction:</div><div class='summary-value'>";
  html += (scrollDirection.length() > 0 ? htmlEscape(scrollDirection) : String("none"));
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Scroll Speed:</div><div class='summary-value'>";
  if (scrollDirection.length() > 0 && scrollDirection != "none") {
    html += String(scrollSpeed);
  } else {
    html += "—";
  }
  html += "</div></div>";

  // Flash
  html += "<div class='summary-item'><div class='summary-label'>Flash:</div><div class='summary-value'>";
  html += (flash ? "<span class='badge badge-yes'>ON</span>" : "<span class='badge badge-no'>OFF</span>");
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Flash Interval:</div><div class='summary-value'>";
  if (flash) {
    html += String(flashInterval);
    html += " ms";
  } else {
    html += "—";
  }
  html += "</div></div>";
  // Pulse
  html += "<div class='summary-item'><div class='summary-label'>Pulse:</div><div class='summary-value'>";
  html += (pulse ? "<span class='badge badge-yes'>ON</span>" : "<span class='badge badge-no'>OFF</span>");
  html += "</div></div>";

  html += "<div class='summary-item'><div class='summary-label'>Pulse Duration:</div><div class='summary-value'>";
  if (pulse) {
    html += String(pulseDuration);
    html += " ms";
  } else {
    html += "—";
  }
  html += "</div></div>";


  html += "</div>";  // card

  html += "<p style='margin-top:20px;'><a href='/'>← Return to Home</a></p>";
  html += "</body></html>";

  server.sendContent(html);
  server.sendContent("");
}

static void sendNav(const String &activePath) {
  struct Link { const char* path; const char* label; };
  const Link row1[] = {
    { "/", "🏠 Home" },
    { "/status", "📊 Status" },
    { "/weather", "🌤️ Weather" },
    { "/calendar", "📅 Calendar" },
    { "/astro", "🌙 Astro" },
    { "/clock", "🕒 Clock" },
    { "/clockconfig", "🕐 Clock Config" }
  };
  const Link row2[] = {
    { "/schedules", "⏰ Schedules" },
    { "/logs", "📋 Web Log" },
    { "/locationconfig", "📍 Location" },
    { "/update", "⬆️ OTA Update" },
    { "/otapassword", "🔐 OTA Password" },
    { "/resetsettings", "⚠️ Reset Settings" }
  };

  server.sendContent("<div class='nav-links'>");
  server.sendContent("<div class='nav-row row1'>");
  for (auto &l : row1) {
    String cls = (activePath == l.path) ? " class='active'" : "";
    server.sendContent(String("<a") + cls + " href='" + l.path + "'>" + l.label + "</a>");
  }
  server.sendContent("</div>");
  server.sendContent("<div class='nav-row row2'>");
  for (auto &l : row2) {
    String cls = (activePath == l.path) ? " class='active'" : "";
    server.sendContent(String("<a") + cls + " href='" + l.path + "'>" + l.label + "</a>");
  }
  server.sendContent("</div>");
  server.sendContent("</div><hr>");
}

static void sendHtmlHeader(const String &title, const String &activePath) {
  server.sendContent(
    "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
    "<meta name='viewport' content='width=device-width, initial-scale=1'>"
  );
  server.sendContent(String("<title>") + title + "</title>");

  server.sendContent(
    "<style>"
    "*,*::before,*::after{box-sizing:border-box;}"
    "body{font-family:Arial,Helvetica,sans-serif;max-width:900px;margin:20px auto;padding:0 16px;color:#222;background:#f5f5f5;}"
    "h1{color:#333;border-bottom:3px solid #4CAF50;padding-bottom:10px;margin:0 0 12px 0;}"
    "h2{color:#555;margin-top:26px;border-left:4px solid #4CAF50;padding-left:10px;}"
    ".info-bar{background:#fff;padding:12px;border-radius:6px;margin:12px 0;border:1px solid #ddd;}"
    ".nav-links{margin:10px 0 14px 0;display:flex;flex-direction:column;gap:10px;}"
    ".nav-row{display:grid;gap:10px;}"
    ".nav-row.row1{grid-template-columns:repeat(7,minmax(0,1fr));}"
    ".nav-row.row2{grid-template-columns:repeat(6,minmax(0,1fr));}"
    ".nav-links a{display:block;text-decoration:none;color:#1a73e8;padding:5px 8px;border-radius:6px;background:#fff;"
    "border:1px solid #ddd;text-align:center;font-size:12.5px;white-space:nowrap;}"
    ".nav-links a:hover{background:#e3f2fd;border-color:#2196F3;}"
    ".nav-links a.active{background:#4CAF50;color:white;border-color:#45a049;}"
    "form{background:#fff;padding:16px;border-radius:8px;border:1px solid #ddd;margin:14px 0;}"
    "label{display:block;margin:10px 0 4px 0;font-weight:bold;}"
    "input[type='text'],input[type='password'],input[type='number'],input[type='color'],select{width:100%;max-width:520px;"
    "padding:8px;margin:0 0 10px 0;border:1px solid #ccc;border-radius:4px;}input[type='color']{padding:0;}"
    "input[type='range']{width:100%;max-width:520px;}"
    ".row{display:flex;flex-wrap:wrap;gap:14px;margin:10px 0;}"
    ".row .col{flex:1;min-width:220px;}"
    ".btn{background:#4CAF50;color:#fff;padding:12px 20px;border:none;border-radius:6px;cursor:pointer;font-size:15px;"
    "margin:10px 5px 0 0;text-decoration:none;display:inline-block;}"
    ".btn:hover{background:#45a049;}"
    ".btn.active{outline:3px solid #fff;box-shadow:0 0 0 4px #1a1a1a;filter:brightness(1.25);}"
    ".btn.secondary{background:#1976d2;}"
    ".btn.secondary:hover{background:#1565c0;}"
    "details{margin:20px 0;background:#fff;border:1px solid #ddd;border-radius:8px;}"
    "summary{background:#e0e0e0;padding:12px;border-radius:8px 8px 0 0;cursor:pointer;font-weight:bold;user-select:none;}"
    "summary:hover{background:#d0d0d0;}"
    ".details-content{padding:16px;}"
    ".mode-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin:15px 0;}"
    ".mode-card{background:#f9f9f9;padding:15px;border-radius:6px;border:1px solid #ddd;}"
    ".mode-card h4{margin:0 0 10px 0;color:#555;}"
    ".btnrow{display:flex;gap:8px;}"
    ".btnrow .btn{flex:1;padding:8px;font-size:14px;margin:0;}"
    "hr{border:0;border-top:1px solid #ddd;margin:20px 0;}"
    ".hint{color:#666;font-size:13px;margin-top:4px;}"
    ".nav-back{margin:10px 0;}"
    ".nav-back a{color:#2196F3;text-decoration:none;font-size:16px;}"
    ".nav-back a:hover{text-decoration:underline;}"
    "pre{background:#f5f5f5;padding:12px;border-radius:6px;overflow-x:auto;border:1px solid #ddd;}"
    "code{background:#f0f0f0;padding:2px 6px;border-radius:3px;}"
    ".status-section{background:#fff;padding:20px;border-radius:8px;border:1px solid #ddd;margin:20px 0;}"
    ".info-grid{display:grid;grid-template-columns:200px 1fr;gap:12px;margin:12px 0;}"
    ".info-label{font-weight:bold;color:#555;text-align:right;padding-right:15px;}"
    ".info-value{color:#333;}"
    ".status-badge{display:inline-block;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:bold;}"
    ".badge-active{background:#4CAF50;color:white;}"
    ".badge-inactive{background:#9e9e9e;color:white;}"
    ".badge-yes{background:#4CAF50;color:white;}"
    ".badge-no{background:#f44336;color:white;}"
    ".badge-enabled{background:#4CAF50;color:white;}"
    ".badge-disabled{background:#9e9e9e;color:white;}"
    ".btn.disabled{opacity:0.45;pointer-events:none;filter:grayscale(0.6);}"
    "</style>"
    "</head><body>"
  );

  server.sendContent(String("<h1>") + title + "</h1>");
  sendNav(activePath);
  server.sendContent("<div class='info-bar'><strong>Device:</strong> " + deviceName +
                     " &nbsp; <strong>Version:</strong> " + String(Version) +
                     " &nbsp; <strong>Built:</strong> " + String(Timestamp) +
                     " &nbsp; <strong>IP:</strong> " + WiFi.localIP().toString() +
                       wifiSignalHtml() + "</div>");
}

static void sendHtmlFooter() {
  server.sendContent("<hr><p class='hint'>Build: " __DATE__ " " __TIME__ "</p></body></html>");
  server.sendContent("");  // Signal end of chunked transfer
}

static void beginHtmlPage(const String &title, const String &activePath) {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");
  sendHtmlHeader(title, activePath);
}

static void endHtmlPage() {
  sendHtmlFooter();
}

//=============================================================
// ROOT PAGE - Enhanced with hex colors, named fonts, degrees, slider, etc.
//=============================================================
void handleRoot() {
  beginHtmlPage("ESP32 Display", "/");

  server.sendContent("<h2>📝 Send a Message</h2>");
  server.sendContent("<form action='/message' method='POST'>");
  // Hex strings for current message colors (used to prefill the form)
  String textHex = colorToHex(currentTextColor);
  String bgHex   = colorToHex(currentBgColor);


  // ===== Row 1: Text + Wrap =====
  server.sendContent(
    "<label>Text</label>"
    "<div style='display:flex;align-items:center;gap:10px;'>"
    "<input type='text' name='text' required placeholder='Message to display' "
    "style='flex:1;height:40px;margin:0;padding:0 10px;box-sizing:border-box;'>"
    "<label style='display:flex;align-items:center;gap:8px;margin:0;white-space:nowrap;font-weight:bold;'>"
    "<input type='checkbox' name='wrap' value='true' style='width:auto;margin:0;'"
    + String(currentWrap ? " checked" : "") + ">"
    "Wrap Text"
    "</label>"
    "</div>"
  );


  // ===== Row 2: Priority + Expiration =====
  server.sendContent(
    "<div class='row'>"
    "<div class='col'>"
    "<div style='display:flex;align-items:center;gap:10px;flex-wrap:wrap;'>"
    "<label style='display:flex;align-items:center;gap:8px;margin:0;white-space:nowrap;font-weight:bold;'>"
    "<input type='checkbox' name='priority' value='high' style='width:auto;'>"
    "High Priority Message"
    "</label>"
    "<input type='number' name='expirationtime' min='0' value='" + String(DEFAULT_EXPIRATION_TIME) + "' "
    "style='width:120px;max-width:120px;margin:0;'>"
    "<span style='white-space:nowrap;'>seconds until expiration (0 = never expires)</span>"
    "</div>"
    "</div>"
    "</div>"
  );

  // Row: Text Color + Font
  server.sendContent(
    "<div class='row'>"

    // ===== Column 1: Text Color =====
    "<div class='col'>"
    "<label>Text Color</label>"
    "<div class='color-input-group' style='display:flex;align-items:center;gap:10px;flex-wrap:nowrap;'>"
    "<span id='textcolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
    "align-self:center;"
    "background:" + htmlEscape(textHex) + ";border:1px solid #888;border-radius:3px;'></span>"
    "<select id='textcolor_select' style='flex:1;min-width:0;'>");
  server.sendContent(buildNamedColorOptions(currentTextColor, false));
  server.sendContent(
    "</select>"
    "<span style='white-space:nowrap;'>OR</span>"
    "<input type='text' id='textcolor_hex' value='"
    + htmlEscape(textHex) + "' placeholder='#FFFFFF' maxlength='7' "
                            "style='width:120px;max-width:120px;flex:0 0 auto;'>"
                            "<input type='hidden' name='textcolor' id='textcolor_val' value='"
    + htmlEscape(textHex) + "'>"
                            "</div>"
                            "</div>"

                            // ===== Column 2: Font =====
                            "<div class='col'>"
                            "<label>Font</label>"
                            "<select name='font'>");
  server.sendContent(buildRobotoFontOptions(currentFont, DEFAULT_FONT));
  server.sendContent(
                            "</select>"
                            "</div>"

                            "</div>");

  // ===== Row: Background Color =====
  server.sendContent(
    "<div class='row'>"
    "<div class='col'>"
    "<label>Background Color</label>"
    "<div class='color-input-group' style='display:flex;align-items:center;gap:10px;flex-wrap:nowrap;'>"
    "<span id='bgcolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
    "align-self:center;"
    "background:" + htmlEscape(bgHex) + ";border:1px solid #888;border-radius:3px;'></span>"
    "<select id='bgcolor_select' style='flex:1;min-width:0;'>");
  server.sendContent(buildNamedColorOptions(currentBgColor, true));
  server.sendContent(
    "</select>"
    "<span style='white-space:nowrap;'>OR</span>"
    "<input type='text' id='bgcolor_hex' value='"
    + htmlEscape(bgHex) + "' placeholder='#000000' maxlength='7' "
                          "style='width:120px;max-width:120px;flex:0 0 auto;'>"
                          "<input type='hidden' name='bgcolor' id='bgcolor_val' value='"
    + htmlEscape(bgHex) + "'>"
                          "</div>"
                          "</div>"
                          "<div class='col' aria-hidden='true' style='visibility:hidden'>&nbsp;</div>"
                          "</div>");

  // Bind dropdowns to hex + hidden fields (message page)
  server.sendContent(
    "<script>"
    "function bindColorPair(selId, hexId, hiddenId, swatchId){"
    "var sel=document.getElementById(selId);"
    "var hex=document.getElementById(hexId);"
    "var hid=document.getElementById(hiddenId);"
    "var sw=swatchId?document.getElementById(swatchId):null;"
    "if(!sel||!hex||!hid) return;"
    "function updateSwatch(c){if(sw&&c)sw.style.background=c;}"
    "function applyFromSelect(){"
    "var opt=sel.options[sel.selectedIndex];"
    "if(!opt) return;"
    "var v=sel.value||'';"
    "if(v===''){hid.value=(hex.value||'').trim();updateSwatch(hid.value);return;}"
    "var hx=opt.getAttribute('data-hex');"
    "if(hx){hex.value=hx;}"
    "hid.value=v;"
    "updateSwatch(v);"
    "}"
    "function applyFromHex(){"
    "var v=(hex.value||'').trim();"
    "hid.value=v;"
    "if(v.length>0){sel.value='';}"
    "updateSwatch(v);"
    "}"
    "sel.addEventListener('change', applyFromSelect);"
    "hex.addEventListener('input', applyFromHex);"
    "applyFromSelect();"
    "}"
    "bindColorPair('textcolor_select','textcolor_hex','textcolor_val','textcolor_swatch');"
    "bindColorPair('bgcolor_select','bgcolor_hex','bgcolor_val','bgcolor_swatch');"
    "</script>");

  server.sendContent(
    // Row: Rotation + Brightness
    "<div class='row'>"
    "<div class='col'>"
    "<label>Rotation</label>"
    "<select name='rotation'>"
    "<option value='0'"   + String(currentRotation == 0   ? " selected" : "") + ">0° (Normal)</option>"
    "<option value='90'"  + String(currentRotation == 90  ? " selected" : "") + ">90° (Clockwise)</option>"
    "<option value='180'" + String(currentRotation == 180 ? " selected" : "") + ">180° (Inverted)</option>"
    "<option value='270'" + String(currentRotation == 270 ? " selected" : "") + ">270° (Counter-Clockwise)</option>"
    "</select>"
    "</div>"

    "<div class='col'>"
    "<label>Brightness: <span id='brightnessValue'>" + String(currentBrightness) + "</span></label>"
    "<input type='range' name='brightness' min='0' max='5' value='" + String(currentBrightness) + "' "
    "oninput='document.getElementById(\"brightnessValue\").textContent=this.value'>"
    "</div>"

    "</div>"

    // Row: Alignment
    "<div class='row'>"
    "<div class='col'>"
    "<label>Horizontal Align</label>"
    "<select name='halign'>"
    "<option value='left'"   + String(currentHAlign == "left"   ? " selected" : "") + ">Left</option>"
    "<option value='center'" + String(currentHAlign == "center" ? " selected" : "") + ">Center</option>"
    "<option value='right'"  + String(currentHAlign == "right"  ? " selected" : "") + ">Right</option>"
    "</select>"
    "</div>"

    "<div class='col'>"
    "<label>Vertical Align</label>"
    "<select name='valign'>"
    "<option value='top'"    + String(currentVAlign == "top"    ? " selected" : "") + ">Top</option>"
    "<option value='middle'" + String(currentVAlign == "middle" ? " selected" : "") + ">Middle</option>"
    "<option value='bottom'" + String(currentVAlign == "bottom" ? " selected" : "") + ">Bottom</option>"
    "</select>"
    "</div>"

    "</div>"

    // Row: Scrolling (sized to fit under Horizontal Align)
    "<div class='row'>"
    "<div class='col'>"
    "<label>Scroll Direction</label>"
    "<select name='scrolldir' style='flex:1;min-width:0;'>"
    "<option value='none'"  + String((currentScrollDirection == "none" || currentScrollDirection == "") ? " selected" : "") + ">none (Static)</option>"
    "<option value='left'"  + String(currentScrollDirection == "left"  ? " selected" : "") + ">Left</option>"
    "<option value='right'" + String(currentScrollDirection == "right" ? " selected" : "") + ">Right</option>"
    "<option value='up'"    + String(currentScrollDirection == "up"    ? " selected" : "") + ">Up</option>"
    "<option value='down'"  + String(currentScrollDirection == "down"  ? " selected" : "") + ">Down</option>"
    "</select>"
    "</div>"

    "<div class='col'>"
    "<label>Scroll Speed</label>"
    "<input type='number' name='scrollspeed' min='1' max='9' value='" + String(currentScrollSpeed) + "' style='width:128px;max-width:128px;'>"
    "</div>"
    "<div class='col' aria-hidden='true' style='visibility:hidden'></div>"
    "</div>"
  );

  server.sendContent(
    // Effects Row
    "<div class='row'>"
    // Flash (left column)
    "<div class='col'>"
    "<div style='display:flex;align-items:center;gap:10px;'>"

    "<label style='display:flex;align-items:center;gap:8px;margin:0;white-space:nowrap;font-weight:bold;'>"
    "<input type='checkbox' name='flash' value='true' style='width:auto;'"
    + String(currentFlash ? " checked" : "") + "> Flash Effect"
    "</label>"

    "<input type='number' name='flashinterval' placeholder='ms' value='" + String(currentFlashInterval) + "' "
    "style='width:120px;max-width:120px;margin:0;'>"

    "<span style='white-space:nowrap;'>ms interval</span>"

    "</div>"
    "</div>"

    // Pulse (right column)
    "<div class='col'>"
    "<div style='display:flex;align-items:center;gap:10px;'>"

    "<label style='display:flex;align-items:center;gap:8px;margin:0;white-space:nowrap;font-weight:bold;'>"
    "<input type='checkbox' name='pulse' value='true' style='width:auto;'"
    + String(currentPulse ? " checked" : "") + "> Pulse Effect"
    "</label>"

    "<input type='number' name='pulseduration' placeholder='ms' value='" + String(currentPulseDuration) + "' "
    "style='width:120px;max-width:120px;margin:0;'>"

    "<span style='white-space:nowrap;'>ms duration</span>"

    "</div>"
    "</div>"
    "</div>"

    // Submit Button + Clear Button + Form Close
    "<div style='display:flex;gap:10px;align-items:center;flex-wrap:wrap;'>"
    "<button type='submit' class='btn'>📤 Send Message</button>"
    "<a href='/clear' class='btn' style='background:#f44336;text-decoration:none;display:inline-block;'>🗑️ Clear Message</a>"
    "<button type='button' class='btn' style='background:#2196F3;' onclick='resetMsgDefaults()'>&#8617; Reset Form</button>"
    "</div>"
    "</form>"
    "<script>"
    "function resetMsgDefaults(){"
    "var f=document.querySelector('form[action=\"/message\"]');"
    "f.querySelector('[name=text]').value='';"
    "f.querySelector('[name=wrap]').checked=" + String(DEFAULT_WRAP ? "true" : "false") + ";"
    "f.querySelector('[name=priority]').checked=false;"
    "f.querySelector('[name=expirationtime]').value=" + String(DEFAULT_EXPIRATION_TIME) + ";"
    "f.querySelector('[name=font]').value=" + String(DEFAULT_FONT) + ";"
    "f.querySelector('[name=rotation]').value=" + String(DEFAULT_ROTATION) + ";"
    "var br=f.querySelector('[name=brightness]');br.value=" + String(DEFAULT_BRIGHTNESS) + ";"
    "document.getElementById('brightnessValue').textContent=" + String(DEFAULT_BRIGHTNESS) + ";"
    "f.querySelector('[name=halign]').value='" + String(DEFAULT_H_ALIGN) + "';"
    "f.querySelector('[name=valign]').value='" + String(DEFAULT_V_ALIGN) + "';"
    "f.querySelector('[name=scrolldir]').value='" + String(DEFAULT_SCROLL_DIRECTION) + "';"
    "f.querySelector('[name=scrollspeed]').value=" + String(DEFAULT_SCROLL_SPEED) + ";"
    "f.querySelector('[name=flash]').checked=" + String(DEFAULT_FLASH ? "true" : "false") + ";"
    "f.querySelector('[name=flashinterval]').value=" + String(DEFAULT_FLASH_INTERVAL) + ";"
    "f.querySelector('[name=pulse]').checked=" + String(DEFAULT_PULSE ? "true" : "false") + ";"
    "f.querySelector('[name=pulseduration]').value=" + String(DEFAULT_PULSE_DURATION) + ";"
    "var tcs=document.getElementById('textcolor_select');tcs.value='black';tcs.dispatchEvent(new Event('change'));"
    "var bcs=document.getElementById('bgcolor_select');bcs.value='white';bcs.dispatchEvent(new Event('change'));"
    "}"
    "</script>"
  );

  // ========== JSON / GET API STRING PREVIEW ==========
  server.sendContent(
    "<details id='msgApiPreview' style='margin-top:16px;'>"
    "<summary>📋 API String Preview</summary>"
    "<div class='details-content'>"
    "<p style='margin:0 0 12px;font-size:0.85em;color:#888;'>"
    "Updates live as you change fields above. Copy for use in Hubitat Rule Machine, HTTP requests, etc."
    "</p>"

    "<label style='font-weight:bold;display:block;margin-bottom:4px;'>JSON Body (POST /message)</label>"
    "<div style='display:flex;gap:8px;align-items:flex-start;margin-bottom:14px;'>"
    "<textarea id='msg_json_preview' readonly rows='3' "
    "style='flex:1;font-family:monospace;font-size:0.82em;resize:vertical;background:#f9f9f9;'></textarea>"
    "<button type='button' onclick='copyPreview(\"msg_json_preview\",this)' class='btn' "
    "style='white-space:nowrap;align-self:flex-start;'>&#128203; Copy</button>"
    "</div>"

    "<label style='font-weight:bold;display:block;margin-bottom:4px;'>GET Query String</label>"
    "<div style='display:flex;gap:8px;align-items:flex-start;'>"
    "<textarea id='msg_get_preview' readonly rows='2' "
    "style='flex:1;font-family:monospace;font-size:0.82em;resize:vertical;background:#f9f9f9;'></textarea>"
    "<button type='button' onclick='copyPreview(\"msg_get_preview\",this)' class='btn' "
    "style='white-space:nowrap;align-self:flex-start;'>&#128203; Copy</button>"
    "</div>"
    "</div>"  // end details-content
    "</details>"

    "<script>"
    // Read current values from the form and update both preview textareas
    "function msgPreviewUpdate(){"
      "var form=document.querySelector('form[action=\"/message\"]');"
      "if(!form)return;"
      "var fv=function(nm){var e=form.querySelector('[name='+nm+']');return e?e.value:'';};"
      "var fc=function(nm){var e=form.querySelector('[name='+nm+']');return !!(e&&e.checked);};"
      "var ni=function(v,d){var x=parseInt(v,10);return isNaN(x)?d:x;};"
      "var text=fv('text');"
      "var bgcolor=(document.getElementById('bgcolor_val')||{value:''}).value;"
      "var textcolor=(document.getElementById('textcolor_val')||{value:''}).value;"
      "var font=ni(fv('font'),30);"
      "var rotation=ni(fv('rotation'),0);"
      "var halign=fv('halign')||'center';"
      "var valign=fv('valign')||'middle';"
      "var wrap=fc('wrap');"
      "var scrolldir=fv('scrolldir')||'none';"
      "var scrollspeed=ni(fv('scrollspeed'),3);"
      "var brightness=ni(fv('brightness'),5);"
      "var flash=fc('flash');"
      "var flashinterval=ni(fv('flashinterval'),1000);"
      "var pulse=fc('pulse');"
      "var pulseduration=ni(fv('pulseduration'),2000);"
      "var priority=fc('priority')?'high':'normal';"
      "var expirationtime=ni(fv('expirationtime'),0);"
      "var obj={"
        "text:text,bgcolor:bgcolor,textcolor:textcolor,font:font,rotation:rotation,"
        "halign:halign,valign:valign,wrap:wrap,scrolldir:scrolldir,scrollspeed:scrollspeed,"
        "brightness:brightness,flash:flash,flashinterval:flashinterval,"
        "pulse:pulse,pulseduration:pulseduration,priority:priority,expirationtime:expirationtime"
      "};"
      "var jp=document.getElementById('msg_json_preview');"
      "if(jp)jp.value=JSON.stringify(obj);"
      "var p=[];"
      "p.push('text='+encodeURIComponent(text));"
      "p.push('bgcolor='+encodeURIComponent(bgcolor));"
      "p.push('textcolor='+encodeURIComponent(textcolor));"
      "p.push('font='+font);"
      "p.push('rotation='+rotation);"
      "p.push('halign='+encodeURIComponent(halign));"
      "p.push('valign='+encodeURIComponent(valign));"
      "p.push('wrap='+wrap);"
      "p.push('scrolldir='+encodeURIComponent(scrolldir));"
      "p.push('scrollspeed='+scrollspeed);"
      "p.push('brightness='+brightness);"
      "p.push('flash='+flash);"
      "p.push('flashinterval='+flashinterval);"
      "p.push('pulse='+pulse);"
      "p.push('pulseduration='+pulseduration);"
      "p.push('priority='+encodeURIComponent(priority));"
      "p.push('expirationtime='+expirationtime);"
      "var gp=document.getElementById('msg_get_preview');"
      "if(gp)gp.value='/message?'+p.join('&');"
    "}"
    // Copy button handler with momentary confirmation label
    "function copyPreview(id,btn){"
      "var ta=document.getElementById(id);"
      "if(!ta)return;"
      "var done=function(){"
        "var o=btn.textContent;"
        "btn.textContent='\\u2705 Copied!';"
        "setTimeout(function(){btn.textContent=o;},1500);"
      "};"
      "if(navigator.clipboard){navigator.clipboard.writeText(ta.value).then(done).catch(function(){"
        "ta.select();document.execCommand('copy');done();"
      "});}else{ta.select();document.execCommand('copy');done();}"
    "}"
    // Attach listeners. setTimeout(0) ensures preview runs after bindColorPair has
    // already written the updated value into the hidden textcolor/bgcolor fields.
    "(function(){"
      "var form=document.querySelector('form[action=\"/message\"]');"
      "if(!form)return;"
      "var upd=function(){setTimeout(msgPreviewUpdate,0);};"
      "form.addEventListener('input',upd);"
      "form.addEventListener('change',upd);"
      "msgPreviewUpdate();"
    "})();"
    "</script>"
    "<script>"
    "(function(){"
      "var d=document.getElementById('msgApiPreview');"
      "if(!d)return;"
      "try{if(localStorage.getItem('msgApiPreviewOpen')==='1')d.setAttribute('open','open');}catch(e){}"
      "d.addEventListener('toggle',function(){try{localStorage.setItem('msgApiPreviewOpen',d.open?'1':'0');}catch(e){}});"
    "})();"
    "</script>"
  );

  // Keep named color dropdowns and hex boxes in sync (dropdown fills hex; typing hex clears dropdown)
  server.sendContent(
    "<script>"
    "function bindColorPair(selId, hexId, hiddenId, swatchId){"
    "var sel=document.getElementById(selId);"
    "var hex=document.getElementById(hexId);"
    "var hid=document.getElementById(hiddenId);"
    "var sw=swatchId?document.getElementById(swatchId):null;"
    "if(!sel||!hex||!hid) return;"
    "function updateSwatch(c){if(sw&&c)sw.style.background=c;}"
    "function applyFromSelect(){"
    "var opt=sel.options[sel.selectedIndex];"
    "if(!opt) return;"
    "var v=sel.value||'';"
    "if(v===''){"
    "hid.value=(hex.value||'').trim();"
    "updateSwatch(hid.value);"
    "return;"
    "}"
    "var hx=opt.getAttribute('data-hex');"
    "if(hx){ hex.value=hx; }"
    "hid.value=v;"
    "updateSwatch(v);"
    "}"
    "function applyFromHex(){"
    "var v=(hex.value||'').trim();"
    "hid.value=v;"
    "if(v.length>0){ sel.value=''; }"
    "updateSwatch(v);"
    "}"
    "sel.addEventListener('change', applyFromSelect);"
    "hex.addEventListener('input', applyFromHex);"
    "applyFromSelect();"
    "}"
    "bindColorPair('textcolor_select','textcolor_hex','textcolor_val','textcolor_swatch');"
    "bindColorPair('bgcolor_select','bgcolor_hex','bgcolor_val','bgcolor_swatch');"
    "</script>");

  // ========== THEME AND STATE CONTROLS ==========
  server.sendContent(
    "<details id='themeControls'>"
    "<summary>🎨 Theme and State Controls</summary>"
    "<div class='details-content'>"
    "<h4>Dark Mode Settings</h4>"
    "<div class='mode-grid'>"
  );

  // Clock
  if (clockColorsCustomized) {
    server.sendContent(
      "<div class='mode-card'><h4>Clock</h4><div class='btnrow'>"
      "<span class='btn disabled' title='Clock colors are customized. Use Clock Config to reset to theme defaults.'>Light</span>"
      "<span class='btn disabled' title='Clock colors are customized. Use Clock Config to reset to theme defaults.'>Dark</span>"
      "<span class='btn disabled' title='Clock colors are customized. Use Clock Config to reset to theme defaults.'>Toggle</span>"
      "</div><small style='display:block;margin-top:6px;color:#666;'>Disabled: clock colors customized</small></div>"
    );
  } else {
    server.sendContent(
      "<div class='mode-card'><h4>Clock</h4><div class='btnrow'>"
      "<a class='btn" + String(!clockDarkMode ? " active" : "") + "' href='/control?clockdark=false'>Light</a>"
      "<a class='btn" + String( clockDarkMode ? " active" : "") + "' href='/control?clockdark=true'>Dark</a>"
      "<a class='btn' href='/control?clockdark=toggle'>Toggle</a>"
      "</div></div>"
    );
  }

  // Weather
  server.sendContent(
    "<div class='mode-card'><h4>Weather</h4><div class='btnrow'>"
    "<a class='btn" + String(!weatherDarkMode ? " active" : "") + "' href='/control?weatherdark=false'>Light</a>"
    "<a class='btn" + String( weatherDarkMode ? " active" : "") + "' href='/control?weatherdark=true'>Dark</a>"
    "<a class='btn' href='/control?weatherdark=toggle'>Toggle</a>"
    "</div></div>"
  );

  // Calendar
  server.sendContent(
    "<div class='mode-card'><h4>Calendar</h4><div class='btnrow'>"
    "<a class='btn" + String(!calendarDarkMode ? " active" : "") + "' href='/control?calendardark=false'>Light</a>"
    "<a class='btn" + String( calendarDarkMode ? " active" : "") + "' href='/control?calendardark=true'>Dark</a>"
    "<a class='btn' href='/control?calendardark=toggle'>Toggle</a>"
    "</div></div>"
  );

  // Astro Times
  server.sendContent(
    "<div class='mode-card'><h4>Astro Times</h4><div class='btnrow'>"
    "<a class='btn" + String(!astroDarkMode ? " active" : "") + "' href='/control?astrodark=false'>Light</a>"
    "<a class='btn" + String( astroDarkMode ? " active" : "") + "' href='/control?astrodark=true'>Dark</a>"
    "<a class='btn' href='/control?astrodark=toggle'>Toggle</a>"
    "</div></div>"
  );

  // History
  server.sendContent(
    "<div class='mode-card'><h4>Message History</h4><div class='btnrow'>"
    "<a class='btn" + String(!historyDarkMode ? " active" : "") + "' href='/control?historydark=false'>Light</a>"
    "<a class='btn" + String( historyDarkMode ? " active" : "") + "' href='/control?historydark=true'>Dark</a>"
    "<a class='btn' href='/control?historydark=toggle'>Toggle</a>"
    "</div></div>"
  );

  // Menu
  server.sendContent(
    "<div class='mode-card'><h4>Menu</h4><div class='btnrow'>"
    "<a class='btn" + String(!menuDarkMode ? " active" : "") + "' href='/control?menudark=false'>Light</a>"
    "<a class='btn" + String( menuDarkMode ? " active" : "") + "' href='/control?menudark=true'>Dark</a>"
    "<a class='btn' href='/control?menudark=toggle'>Toggle</a>"
    "</div></div>"
  );

  server.sendContent("</div><hr>");

  // Device State Controls
  server.sendContent(
    "<h4>Device State Controls</h4>"
    "<div class='mode-grid'>"
    "<div class='mode-card'>"
    "<h4>Pixel Shift</h4>"
    "<div class='btnrow'>"
    "<a class='btn" + String( pixelShiftEnabled ? " active" : "") + "' href='/control?pixelshift=true'>ON</a>"
    "<a class='btn" + String(!pixelShiftEnabled ? " active" : "") + "' href='/control?pixelshift=false'>OFF</a>"
    "<a class='btn' href='/control?pixelshift=toggle'>Toggle</a>"
    "</div>"
    "<small style='display:block;margin-top:6px;color:#666;'>Prevent screen burn-in</small>"
    "</div>"
    "<div class='mode-card'>"
    "<h4>Touch Control</h4>"
    "<div class='btnrow'>"
    "<a class='btn" + String( touchEnabled ? " active" : "") + "' href='/control?touchenable=true'>ON</a>"
    "<a class='btn" + String(!touchEnabled ? " active" : "") + "' href='/control?touchenable=false'>OFF</a>"
    "<a class='btn' href='/control?touchenable=toggle'>Toggle</a>"
    "</div>"
    "<small style='display:block;margin-top:6px;color:#666;'>Enable/disable touch input</small>"
    "</div>"
    "<div class='mode-card'>"
    "<h4>Temp Display</h4>"
    "<div class='btnrow'>"
    "<a class='btn" + String( tempActual && !tempAlternate ? " active" : "") + "' href='/control?tempactual=true'>Actual</a>"
    "<a class='btn" + String(!tempActual && !tempAlternate ? " active" : "") + "' href='/control?tempactual=false'>Apparent</a>"
    "<a class='btn" + String( tempAlternate                ? " active" : "") + "' href='/control?tempactual=alternate'>Alternate</a>"
    "</div>"
    "<small style='display:block;margin-top:6px;color:#666;'>Actual or apparent</small>"
    "</div>"
    "<div class='mode-card'>"
    "<h4>Weather Cycle</h4>"
    "<div class='btnrow'>"
    "<a class='btn" + String( weatherCycleEnabled ? " active" : "") + "' href='/control?weathercycle=true'>ON</a>"
    "<a class='btn" + String(!weatherCycleEnabled ? " active" : "") + "' href='/control?weathercycle=false'>OFF</a>"
    "<a class='btn' href='/control?weathercycle=toggle'>Toggle</a>"
    "</div>"
    "<small style='display:block;margin-top:6px;color:#666;'>Auto-show weather every " + String(WEATHER_CYCLE_INTERVAL / 60000UL) + " min for " + String(WEATHER_SHOW_DURATION / 1000UL) + "s</small>"
    "</div>"
    "<div class='mode-card'>"
    "<h4>Calendar Cycle</h4>"
    "<div class='btnrow'>"
    "<a class='btn" + String( calendarCycleEnabled ? " active" : "") + "' href='/control?calendarcycle=true'>ON</a>"
    "<a class='btn" + String(!calendarCycleEnabled ? " active" : "") + "' href='/control?calendarcycle=false'>OFF</a>"
    "<a class='btn' href='/control?calendarcycle=toggle'>Toggle</a>"
    "</div>"
    "<small style='display:block;margin-top:6px;color:#666;'>Auto-show calendar every " + String(CALENDAR_CYCLE_INTERVAL / 60000UL) + " min for " + String(CALENDAR_SHOW_DURATION / 1000UL) + "s</small>"
    "</div>"
    "</div></div></details>"
  );

  // ========== MESSAGE PROFILES ==========
  {
    // Serialize all profile data into an inline JS array for client-side load
    server.sendContent(
      "<details id='msgProfileSection'>"
      "<summary>📌 Message Profiles</summary>"
      "<div class='details-content'>"
      "<p>Save/load up to 10 sets of message display attributes (profiles 0–9). "
      "Profiles store all visual settings but <em>not</em> the message text.</p>"
    );

    server.sendContent("<script>var msgProfiles=[");
    for (int pi = 0; pi < MAX_MSG_PROFILES; pi++) {
      if (pi > 0) server.sendContent(",");
      if (msgProfiles[pi].saved) {
        server.sendContent(
          "{saved:true,"
          "bgcolor:'" + colorToHex(msgProfiles[pi].bgColor) + "',"
          "textcolor:'" + colorToHex(msgProfiles[pi].textColor) + "',"
          "font:" + String(msgProfiles[pi].font) + ","
          "rotation:" + String(msgProfiles[pi].rotation) + ","
          "halign:'" + htmlEscape(msgProfiles[pi].hAlign) + "',"
          "valign:'" + htmlEscape(msgProfiles[pi].vAlign) + "',"
          "wrap:" + String(msgProfiles[pi].wrap ? "true" : "false") + ","
          "scrolldir:'" + htmlEscape(msgProfiles[pi].scrollDir) + "',"
          "scrollspeed:" + String(msgProfiles[pi].scrollSpeed) + ","
          "brightness:" + String(msgProfiles[pi].brightness) + ","
          "flash:" + String(msgProfiles[pi].flash ? "true" : "false") + ","
          "flashinterval:" + String(msgProfiles[pi].flashInterval) + ","
          "pulse:" + String(msgProfiles[pi].pulse ? "true" : "false") + ","
          "pulseduration:" + String(msgProfiles[pi].pulseDuration) + ","
          "priority:'" + htmlEscape(msgProfiles[pi].priority) + "',"
          "expiration:" + String(msgProfiles[pi].expirationTime) + "}"
        );
      } else {
        server.sendContent("{saved:false}");
      }
    }
    server.sendContent("];</script>");

    // Profile selector + buttons
    server.sendContent(
      "<div style='display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px;'>"
      "<label style='margin:0;font-weight:bold;'>Profile:</label>"
      "<select id='profileSelect' style='width:170px;margin:0;'>"
    );
    for (int pi = 0; pi < MAX_MSG_PROFILES; pi++) {
      server.sendContent(
        "<option value='" + String(pi) + "'>" +
        String(pi) + (msgProfiles[pi].saved ? " ✔ (saved)" : " (empty)") +
        "</option>"
      );
    }
    server.sendContent(
      "</select>"
      "<button type='button' class='btn' onclick='loadMsgProfile()'>📂 Load into Form</button>"
      "<button type='button' class='btn' style='background:#2196F3;' onclick='saveMsgProfile()'>💾 Save Form Settings</button>"
      "<button type='button' class='btn' style='background:#c0392b;' onclick='clearMsgProfile()'>🗑️ Clear Profile</button>"
      "</div>"
      "<div id='profileStatus' style='font-size:13px;color:#555;min-height:20px;'></div>"
    );

    server.sendContent(
      "<script>"
      "function loadMsgProfile(){"
        "var idx=parseInt(document.getElementById('profileSelect').value);"
        "var p=msgProfiles[idx];"
        "if(!p||!p.saved){document.getElementById('profileStatus').textContent='Profile '+idx+' is empty.';return;}"
        // bg color
        "var bgSel=document.getElementById('bgcolor_select');"
        "var bgHex=document.getElementById('bgcolor_hex');"
        "var bgVal=document.getElementById('bgcolor_val');"
        "if(bgHex){bgHex.value=p.bgcolor;}"
        "if(bgVal){bgVal.value=p.bgcolor;}"
        "if(bgSel){bgSel.value='';}"
        "var bgSw=document.getElementById('bgcolor_swatch');if(bgSw)bgSw.style.background=p.bgcolor;"
        // text color
        "var tcSel=document.getElementById('textcolor_select');"
        "var tcHex=document.getElementById('textcolor_hex');"
        "var tcVal=document.getElementById('textcolor_val');"
        "if(tcHex){tcHex.value=p.textcolor;}"
        "if(tcVal){tcVal.value=p.textcolor;}"
        "if(tcSel){tcSel.value='';}"
        "var tcSw=document.getElementById('textcolor_swatch');if(tcSw)tcSw.style.background=p.textcolor;"
        // other fields
        "var el;"
        "el=document.querySelector('[name=font]');if(el)el.value=String(p.font);"
        "el=document.querySelector('[name=rotation]');if(el)el.value=String(p.rotation);"
        "el=document.querySelector('[name=halign]');if(el)el.value=p.halign;"
        "el=document.querySelector('[name=valign]');if(el)el.value=p.valign;"
        "el=document.querySelector('[name=brightness]');if(el){el.value=p.brightness;var bv=document.getElementById('brightnessValue');if(bv)bv.textContent=p.brightness;}"
        "el=document.querySelector('[name=wrap]');if(el)el.checked=p.wrap;"
        "el=document.querySelector('[name=scrolldir]');if(el)el.value=p.scrolldir;"
        "el=document.querySelector('[name=scrollspeed]');if(el)el.value=String(p.scrollspeed);"
        "el=document.querySelector('[name=flash]');if(el)el.checked=p.flash;"
        "el=document.querySelector('[name=flashinterval]');if(el)el.value=p.flashinterval;"
        "el=document.querySelector('[name=pulse]');if(el)el.checked=p.pulse;"
        "el=document.querySelector('[name=pulseduration]');if(el)el.value=p.pulseduration;"
        "el=document.querySelector('[name=priority]');if(el)el.checked=(p.priority==='high');"
        "el=document.querySelector('[name=expirationtime]');if(el)el.value=p.expiration!==undefined?p.expiration:0;"
        "document.getElementById('profileStatus').textContent='Profile '+idx+' loaded into form.';"
      "}"
      "function saveMsgProfile(){"
        "var idx=parseInt(document.getElementById('profileSelect').value);"
        "var p={};"
        "var el;"
        "el=document.getElementById('bgcolor_val');p.bgcolor=el?el.value:'';"
        "el=document.getElementById('textcolor_val');p.textcolor=el?el.value:'';"
        "el=document.querySelector('[name=font]');p.font=el?el.value:'30';"
        "el=document.querySelector('[name=rotation]');p.rotation=el?el.value:'270';"
        "el=document.querySelector('[name=halign]');p.halign=el?el.value:'center';"
        "el=document.querySelector('[name=valign]');p.valign=el?el.value:'middle';"
        "el=document.querySelector('[name=brightness]');p.brightness=el?el.value:'5';"
        "el=document.querySelector('[name=wrap]');p.wrap=el&&el.checked?'true':'false';"
        "el=document.querySelector('[name=scrolldir]');p.scrolldir=el?el.value:'none';"
        "el=document.querySelector('[name=scrollspeed]');p.scrollspeed=el?el.value:'5';"
        "el=document.querySelector('[name=flash]');p.flash=el&&el.checked?'true':'false';"
        "el=document.querySelector('[name=flashinterval]');p.flashinterval=el?el.value:'1000';"
        "el=document.querySelector('[name=pulse]');p.pulse=el&&el.checked?'true':'false';"
        "el=document.querySelector('[name=pulseduration]');p.pulseduration=el?el.value:'5000';"
        "el=document.querySelector('[name=priority]');p.priority=el&&el.checked?'high':'normal';"
        "el=document.querySelector('[name=expirationtime]');p.expirationtime=el?el.value:'0';"
        "var params=new URLSearchParams();"
        "params.append('saveprofile',idx);"
        "Object.keys(p).forEach(function(k){params.append(k,p[k]);});"
        "fetch('/message',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params.toString()})"
        ".then(function(r){document.getElementById('profileStatus').textContent='Profile '+idx+' saved! Reload page to update labels.';});"
      "}"
      "function clearMsgProfile(){"
        "var idx=parseInt(document.getElementById('profileSelect').value);"
        "if(!confirm('Clear profile '+idx+'?')) return;"
        "var params=new URLSearchParams();"
        "params.append('clearprofile',idx);"
        "fetch('/message',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params.toString()})"
        ".then(function(r){"
          "msgProfiles[idx]={saved:false};"
          "document.getElementById('profileStatus').textContent='Profile '+idx+' cleared. Reload page to update labels.';"
        "});"
      "}"
      "</script>"
      "</div></details>"
    );
  }

  // ========== COMPLETE JSON EXAMPLE ==========
  server.sendContent(
    "<details>"
    "<summary>📖 Complete JSON Example</summary>"
    "<div class='details-content'>"
    "<p>Send a POST request to <code>/message</code> with this JSON:</p>"
    "<pre>{\n"
    "  \"text\": \"Hello World\",\n"
    "  \"bgcolor\": \"#000000\",\n"
    "  \"textcolor\": \"#FFFF00\",\n"
    "  \"font\": 30,\n"
    "  \"rotation\": 0,\n"
    "  \"halign\": \"center\",\n"
    "  \"valign\": \"middle\",\n"
    "  \"wrap\": true,\n"
    "  \"scrolldir\": \"none\",\n"
    "  \"scrollspeed\": 3,\n"
    "  \"brightness\": 5,\n"
    "  \"flash\": false,\n"
    "  \"flashinterval\": 1000,\n"
    "  \"pulse\": false,\n"
    "  \"pulseduration\": 5000,\n"
    "  \"priority\": \"normal\",\n"
    "  \"expirationtime\": 0\n"
    "}</pre>"
    "<h4>Message Profile Examples:</h4>"
    "<pre>// Retrieve profile 1 and send message (explicit attrs override profile):\n"
    "{\"text\": \"Hello\", \"retrieveprofile\": 1}\n\n"
    "// Send message AND save its attrs to profile 2:\n"
    "{\"text\": \"Hello\", \"bgcolor\": \"blue\", \"textcolor\": \"white\", \"saveprofile\": 2}\n\n"
    "// Override one attr from profile 1 (bgcolor becomes blue, rest from profile):\n"
    "{\"text\": \"Hello\", \"bgcolor\": \"blue\", \"retrieveprofile\": 1}\n\n"
    "// Save form settings to profile 0 without sending a message:\n"
    "{\"saveprofile\": 0, \"bgcolor\": \"#000000\", \"textcolor\": \"#00FF00\", \"font\": 30}</pre>"
    "</div></details>"
  );

  // ========== COMPLETE GET EXAMPLE ==========
  server.sendContent(
    "<details>"
    "<summary>🔗 Complete GET Example</summary>"
    "<div class='details-content'>"
    "<p>Send a GET request to <code>/msg</code> or <code>/message</code> with query parameters:</p>"
    "<pre style='white-space: pre-wrap; word-break: break-all;'>http://device-ip/msg?text=Hello%20World&amp;bgcolor=%23000000&amp;textcolor=%23FFFF00&amp;font=30&amp;rotation=0&amp;halign=center&amp;valign=middle&amp;wrap=true&amp;scrolldir=none&amp;scrollspeed=3&amp;brightness=255&amp;flash=false&amp;flashinterval=1000&amp;pulse=false&amp;pulseduration=5000&amp;priority=normal&amp;expirationtime=0</pre>"
    "<p><strong>Simple example:</strong></p>"
    "<pre>http://device-ip/msg?text=Hello%20World</pre>"
    "<p><strong>With colors and font:</strong></p>"
    "<pre>http://device-ip/msg?text=Temperature:%2025C&amp;bgcolor=black&amp;textcolor=cyan&amp;font=30</pre>"
    "<p><strong>Note:</strong> URL-encode special characters: Spaces = <code>%20</code>, # = <code>%23</code>, : = <code>%3A</code></p>"
    "</div></details>"
  );

  // ========== FONT GUIDE (Roboto only) ==========
  server.sendContent(
    "<details>"
    "<summary>📚 Font Guide (Roboto Fonts)</summary>"
    "<div class='details-content'>"
    "<h4>Available Roboto Fonts:</h4>");
  server.sendContent(buildRobotoFontGuide(DEFAULT_FONT));
  server.sendContent(
    "<p><strong>Note:</strong> Font values now match the actual Roboto point sizes passed to <code>setSmartFont()</code>.</p>"
    "</div></details>"
  );

  // ========== ADDITIONAL ENDPOINTS ==========
  server.sendContent(
    "<details>"
    "<summary>🎯 Additional Endpoints</summary>"
    "<div class='details-content'>"
    "<h4>Status & Information</h4>"
    "<ul>"
    "<li><b>GET /status</b> - View detailed device status (HTML)</li>"
    "<li><b>GET /status.json</b> - View status as JSON (for automation)</li>"
    "<li><b>GET /time</b> - Current device time</li>"
    "</ul>"
    "<h4>Display Screens</h4>"
    "<ul>"
    "<li><b>GET/POST /weather</b> - Show weather screen</li>"
    "<li><b>GET/POST /calendar</b> - Show calendar screen</li>"
    "<li><b>GET/POST /clock</b> - Show clock screen</li>"
    "<li><b>GET/POST /clear</b> - Clear display and show clock</li>"
    "</ul>"
    "<h4>Message Endpoints</h4>"
    "<ul>"
    "<li><b>GET/POST /message</b> - Main message API (supports JSON POST and GET with query params)</li>"
    "<li><b>GET /msg</b> - Simple GET-only message endpoint (query params)</li>"
    "</ul>"
    "<h4>Configuration Pages</h4>"
    "<ul>"
    "<li><b>GET/POST /clockconfig</b> - Clock configuration page (GET) / save all clock &amp; night mode settings (POST)</li>"
    "<li><b>GET/POST /schedules</b> - Scheduler configuration page (GET) / save schedules (POST)</li>"
    "<li><b>GET/POST /control</b> - Universal control endpoint - see commands below</li>"
    "</ul>"
    "<h4>/control Endpoint Commands (JSON POST or GET params)</h4>"
    "<ul style='font-size:0.9em;'>"
    "<li><b>Display Modes:</b> clockdark, weatherdark, calendardark, menudark, historydark, astrodark (true/false/\"toggle\")</li>"
    "<li><b>Features:</b> pixelshift, touchenable, clockenable (true/false/\"toggle\"), maxMsgAge (in hours; 0=disabled)</li>"
    "<li><b>Clock Resets:</b> clockresetcolors (\"dark\"/\"light\"), clockresetall (true/\"dark\"/\"light\")</li>"
    "<li><b>Navigation:</b> weather, calendar, clock (true)</li>"
    "<li><b>Actions:</b> clear (true), clearhistory (true), reboot (true), resetsettings (true), resetdevice (true)</li>"
    "<li style='margin-left:1.2em;font-size:0.95em;'><b>clear</b> - clears active message, display state &amp; queue &nbsp;|&nbsp; <b>clearhistory</b> - clears history log only (active message &amp; queue unaffected)</li>"
    "</ul>"
    "<h4>System Management</h4>"
    "<ul>"
    "<li><b>GET /logs</b> - Web debug logging (if enabled)</li>"
    "<li><b>GET/POST /update</b> - OTA firmware update page</li>"
    "<li><b>GET/POST /otapassword</b> - Set/view OTA password</li>"
    "<li><b>GET /resetsettings</b> - HTML page to select reboot or reset</li>"
    "<li><b>POST /resetsettings</b> - Reset all settings and reboot</li>"
    "<li><b>GET/POST /resetdevice</b> - Immediately reset all settings and reboot</li>"
    "<li><b>GET/POST /reboot</b> - Immediately reboot device</li>"
    "</ul>"
    "</div></details>"
  );

  // ========== TROUBLESHOOTING ==========
  server.sendContent(
    "<details>"
    "<summary>⚠️ Troubleshooting</summary>"
    "<div class='details-content'>"
    "<ul>"
    "<li><b>Text not wrapping?</b> Enable the 'Wrap Text' checkbox</li>"
    "<li><b>Text cut off?</b> Try smaller font or enable wrapping</li>"
    "<li><b>Flash not working?</b> Check flash interval (500-5000ms recommended)</li>"
    "<li><b>Scroll too fast/slow?</b> Adjust scroll speed (1-9)</li>"
    "<li><b>Colors not showing?</b> Use hex format like #FF0000</li>"
    "<li><b>Display rotated wrong?</b> Choose correct rotation (0°/90°/180°/270°)</li>"
    "<li><b>Display too dim?</b> Increase brightness slider to 5</li>"
    "</ul>"
    "</div></details>"
  );

  server.sendContent(
    "<script>"
    "(function(){"
      "var d=document.getElementById('theme_controls');"
      "if(!d||!window.localStorage) return;"
      "var k='details_theme_controls_open';"
      "try{ if(localStorage.getItem(k)==='1') d.open=true; }catch(e){}"
      "d.addEventListener('toggle', function(){ try{ localStorage.setItem(k, d.open?'1':'0'); }catch(e){} });"
      "var els=d.querySelectorAll('a,button,input[type=submit]');"
      "for(var i=0;i<els.length;i++){"
        "els[i].addEventListener('click', function(){ try{ localStorage.setItem(k, d.open?'1':'0'); }catch(e){} });"
      "}"
    "})();"
    "</script>"
  );

server.sendContent(
  "<script>"
  "(function(){"
    "var d=document.getElementById('themeControls');"
    "if(!d) return;"
    "try{"
      "var wasOpen=localStorage.getItem('themeControlsOpen')==='1';"
      "if(wasOpen) d.setAttribute('open','open');"
    "}catch(e){}"
    "d.addEventListener('toggle',function(){"
      "try{"
        "localStorage.setItem('themeControlsOpen', d.open ? '1' : '0');"
      "}catch(e){}"
    "});"
  "})();"
  "</script>"
);

  endHtmlPage();
}

//=============================================================
// Handle /control - Dark/Light Mode & Device Control
//=============================================================
void handleControl() {
  bool settingsChanged = false;
  String returnTo = "/";

  // Variables for POST JSON handling
  bool clockdark_found = false, clockdark_value = false;
  bool weatherdark_found = false, weatherdark_value = false;
  bool calendardark_found = false, calendardark_value = false;
  bool menudark_found = false, menudark_value = false;
  bool historydark_found = false, historydark_value = false;
  bool astrodark_found = false, astrodark_value = false;
  bool pixelshift_found = false, pixelshift_value = false;
  bool touchenable_found = false, touchenable_value = false;
  bool  localpressure_found = false;
  float localpressure_value = 0.0f;
  bool localPressureUpdated = false;

  // Check for POST JSON
  if (server.method() == HTTP_POST && server.hasArg("plain")) {
    String body = server.arg("plain");
    DEBUG_PRINTLN("\n=== Received POST (JSON) to /control ===");
    DEBUG_PRINTLN(body);

    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, body);

    if (!error) {
      DEBUG_PRINTLN("JSON parsed successfully");

      // Parse all boolean parameters
      if (!parseJsonBoolKey(doc, "clockdark", clockdark_value, clockdark_found, clockDarkMode)) {
        sendJsonMessage(400, "Invalid clockdark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "weatherdark", weatherdark_value, weatherdark_found, weatherDarkMode)) {
        sendJsonMessage(400, "Invalid weatherdark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "calendardark", calendardark_value, calendardark_found, calendarDarkMode)) {
        sendJsonMessage(400, "Invalid calendardark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "menudark", menudark_value, menudark_found, menuDarkMode)) {
        sendJsonMessage(400, "Invalid menudark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "historydark", historydark_value, historydark_found, historyDarkMode)) {
        sendJsonMessage(400, "Invalid historydark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "astrodark", astrodark_value, astrodark_found, astroDarkMode)) {
        sendJsonMessage(400, "Invalid astrodark value");
        return;
      }
      if (!parseJsonBoolKey(doc, "pixelshift", pixelshift_value, pixelshift_found, pixelShiftEnabled)) {
        sendJsonMessage(400, "Invalid pixelshift value");
        return;
      }
      if (!parseJsonBoolKey(doc, "touchenable", touchenable_value, touchenable_found, touchEnabled)) {
        sendJsonMessage(400, "Invalid touchenable value");
        return;
      }
      bool weathercycle_value; bool weathercycle_found = false;
      if (!parseJsonBoolKey(doc, "weathercycle", weathercycle_value, weathercycle_found, weatherCycleEnabled)) {
        sendJsonMessage(400, "Invalid weathercycle value");
        return;
      }
      bool calendarcycle_value; bool calendarcycle_found = false;
      if (!parseJsonBoolKey(doc, "calendarcycle", calendarcycle_value, calendarcycle_found, calendarCycleEnabled)) {
        sendJsonMessage(400, "Invalid calendarcycle value");
        return;
      }
      bool tempactual_value; bool tempactual_found = false;
      if (!parseJsonBoolKey(doc, "tempactual", tempactual_value, tempactual_found, tempActual)) {
        sendJsonMessage(400, "Invalid tempactual value");
        return;
      }

      // Parse local pressure pushed from Hubitat (int or float hPa)
      const char* localpressureKey = findKeyIgnoreCase(doc, "localpressure");
      if (localpressureKey) {
        if (!doc[localpressureKey].is<float>() && !doc[localpressureKey].is<int>()) {
          sendJsonMessage(400, "Invalid localpressure value");
          return;
        }

        localpressure_value = doc[localpressureKey].as<float>();

        if (localpressure_value < 800.0f || localpressure_value > 1200.0f) {
          sendJsonMessage(400, "Invalid localpressure range");
          return;
        }

        localpressure_found = true;
        DEBUG_PRINTF("  Local Pressure        : %.1f hPa\n", localpressure_value);
      }

      // ── Wind direction, local temperature, local humidity ──────────────
      const char* wdKey2 = findKeyIgnoreCase(doc, "winddir");
      if (wdKey2) {
        float wd = doc[wdKey2].as<float>();
        if (wd >= 0.0f && wd < 360.0f) {
          localWindDeg = wd;
          DEBUG_PRINTF("  Wind Dir              : %.0f deg\n", wd);
        }
      }
      const char* ltKey2 = findKeyIgnoreCase(doc, "localtemp");
      if (ltKey2) {
        localTemp = doc[ltKey2].as<float>();
        DEBUG_PRINTF("  Local Temp            : %.1f\n", localTemp);
      }
      const char* lhKey2 = findKeyIgnoreCase(doc, "localhumidity");
      if (lhKey2) {
        float lh = doc[lhKey2].as<float>();
        if (lh >= 0.0f && lh <= 100.0f) {
          localHumidity = lh;
          DEBUG_PRINTF("  Local Humidity        : %.0f%%\n", lh);
        }
      }

      // Apply found settings
      if (clockdark_found) {
        clockDarkMode = clockdark_value;
        if (!clockColorsCustomized) {
          clockTimeColor = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
          clockDateColor = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
          clockBgColor = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR : DEFAULT_CLOCK_BG_COLOR_L;
          clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;
        }
        settingsChanged = true;
      }
      if (weatherdark_found) {
        weatherDarkMode = weatherdark_value;
        settingsChanged = true;
      }
      if (calendardark_found) {
        calendarDarkMode = calendardark_value;
        settingsChanged = true;
      }
      if (menudark_found) {
        menuDarkMode = menudark_value;
        settingsChanged = true;
      }
      if (historydark_found) {
        historyDarkMode = historydark_value;
        settingsChanged = true;
      }
      if (astrodark_found) {
        astroDarkMode = astrodark_value;
        settingsChanged = true;
      }
      if (pixelshift_found) {
        pixelShiftEnabled = pixelshift_value;
        settingsChanged = true;
      }
      if (touchenable_found) {
        touchEnabled = touchenable_value;
        settingsChanged = true;
      }
      if (weathercycle_found) {
        weatherCycleEnabled = weathercycle_value;
        settingsChanged = true;
      }
      if (calendarcycle_found) {
        calendarCycleEnabled = calendarcycle_value;
        settingsChanged = true;
      }
      if (tempactual_found) {
        tempActual = tempactual_value;
        settingsChanged = true;
      }
      if (localpressure_found) {
        localPressureHpa = localpressure_value;
        localPressureValid = true;
        lastLocalPressureReceived = millis();
        localPressureUpdated = true;

        DEBUG_PRINTF("  Stored local pressure : %.1f hPa\n", localPressureHpa);
      }

      // Cycle timing / messaging behavior / pulse range
      ulong tempULong;
      if (getJSON_ULong(doc, "wxshowdur",   tempULong, 1, 3600, "  Wx Show Dur      ", " sec")) {
        weatherShowDuration = tempULong * 1000; settingsChanged = true;
      }
      if (getJSON_ULong(doc, "wxcycleint",  tempULong, 1, 86400, "  Wx Cycle Int     ", " sec")) {
        weatherCycleInterval = tempULong * 1000; settingsChanged = true;
      }
      if (getJSON_ULong(doc, "calshowdur",  tempULong, 1, 3600, "  Cal Show Dur     ", " sec")) {
        calendarShowDuration = tempULong * 1000; settingsChanged = true;
      }
      if (getJSON_ULong(doc, "calcycleint", tempULong, 1, 86400, "  Cal Cycle Int    ", " sec")) {
        calendarCycleInterval = tempULong * 1000; settingsChanged = true;
      }
      int tempInt2;
      if (getJSON_Int(doc, "hpalternate",    tempInt2, 1, 3600, "  HP Alternate     ", " sec")) {
        highPriorityAlternateInterval = tempInt2 * 1000; settingsChanged = true;
      }
      if (getJSON_Int(doc, "normoverridedur", tempInt2, 1, 3600, "  Norm Override Dur", " sec")) {
        normalOverrideDuration = tempInt2; settingsChanged = true;
      }
      uint8_t tempBri;
      if (getJSON_UInt(doc, "pulsemaxbri", tempBri, 0, 5, "  Pulse Max Bri    ")) {
        pulseMaxBrightness = tempBri; settingsChanged = true;
      }
      if (getJSON_UInt(doc, "pulseminbri", tempBri, 0, 5, "  Pulse Min Bri    ")) {
        pulseMinBrightness = tempBri; settingsChanged = true;
      }
      // Message history max age (0 = disabled, positive = hours)
      int tempMsgAge;
      if (getJSON_Int(doc, "maxmsgage", tempMsgAge, 0, 8760, "  Max Msg Age      ", " hr")) {
        maxMsgAge = tempMsgAge; settingsChanged = true;
        DEBUG_PRINTF("  maxMsgAge set to %d (%s)\n", maxMsgAge, maxMsgAge == 0 ? "disabled" : "enabled");
      }
      bool tempBool2;
      if (getJSON_Bool(doc, "normoverride", tempBool2, "  Norm Override En ")) {
        normalOverrideEnabled = tempBool2; settingsChanged = true;
      }

      // Handle clock palette reset (colors only)
      const char* clockresetcolorsKey = findKeyIgnoreCase(doc, "clockresetcolors");
      if (clockresetcolorsKey) {
        String v = String(doc[clockresetcolorsKey].as<const char*>());
        v.toLowerCase();
        if (v == "dark") clockDarkMode = true;
        else if (v == "light") clockDarkMode = false;
        clockColorsCustomized = false;
        clockTimeColor = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
        clockDateColor = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
        clockBgColor = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR : DEFAULT_CLOCK_BG_COLOR_L;
        clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;
        settingsChanged = true;
      }

      // Handle comprehensive clock reset (all settings, no reboot)
      const char* clockresetallKey = findKeyIgnoreCase(doc, "clockresetall");
      if (clockresetallKey) {
        bool doReset = false;
        String resetMode = "dark";  // Default to dark

        if (doc[clockresetallKey].is<bool>()) {
          doReset = doc[clockresetallKey].as<bool>();
        } else if (doc[clockresetallKey].is<const char*>()) {
          String v = String(doc[clockresetallKey].as<const char*>());
          v.toLowerCase();
          doReset = (v == "true" || v == "1" || v == "yes" || v == "dark" || v == "light");
          if (v == "dark" || v == "light") {
            resetMode = v;
          }
        }

        if (doReset) {
          DEBUG_PRINTLN("Comprehensive clock reset requested via /control");
          DEBUG_PRINTF("Reset mode: %s\n", resetMode.c_str());

          // Set dark mode based on reset mode
          clockDarkMode = (resetMode == "dark");

          // Reset all clock settings to defaults
          clockTimeFont = DEFAULT_TIME_FONT;
          clockDateFont = DEFAULT_DATE_FONT;
          clockTimeFormat = DEFAULT_CLOCK_TIME_FORMAT;
          clockDateFormat = DEFAULT_CLOCK_DATE_FORMAT;
          screenBrightness = DEFAULT_SCREEN_BRIGHTNESS;
          clockRotation = DEFAULT_CLOCK_ROTATION;
          currentRotation = DEFAULT_CLOCK_ROTATION;
          clockEnabled = DEFAULT_CLOCK_ENABLED;

          // Reset colors based on dark/light mode
          clockColorsCustomized = false;
          clockTimeColor = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
          clockDateColor = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
          clockBgColor = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR : DEFAULT_CLOCK_BG_COLOR_L;
          clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;

          // Reset screensaver settings
          screensaverDimValue = DEFAULT_SCREENSAVER_DIM;
          screensaverTimeout = DEFAULT_SCREENSAVER_TIMEOUT;

          // Reset suntimes settings
          clockSuntimesEnabled = DEFAULT_SUNTIMES_ENABLED;

          // Save all changes
          saveSettings();

          // Apply immediately if on clock screen
          if (currentScreen == SCREEN_CLOCK) {
            setBrightness(screenBrightness);
            drawClock();
          }

          sendJsonMessage(200, "Clock reset to defaults");
          return;
        }
      }

      // Handle full settings reset
      const char* resetsettingsKey = findKeyIgnoreCase(doc, "resetsettings");
      if (resetsettingsKey) {
        bool resetValue = false;
        if (doc[resetsettingsKey].is<bool>()) {
          resetValue = doc[resetsettingsKey].as<bool>();
        } else if (doc[resetsettingsKey].is<const char*>()) {
          String v = String(doc[resetsettingsKey].as<const char*>());
          v.toLowerCase();
          resetValue = (v == "true" || v == "1" || v == "yes");
        }

        if (resetValue) {
          DEBUG_PRINTLN("Reset settings requested via /control");

          // Clear preferences
          preferences.begin(PREFERENCES_NAMESPACE, false);
          preferences.clear();
          preferences.end();

          // Send response before rebooting
          sendJsonMessage(200, "Settings cleared; rebooting");
          delay(250);
          ESP.restart();
          return;  // Won't actually reach here
        }
      }

      // Handle full device reset (alias for resetsettings)
      const char* resetdeviceKey = findKeyIgnoreCase(doc, "resetdevice");
      if (resetdeviceKey) {
        bool resetValue = false;
        if (doc[resetdeviceKey].is<bool>()) {
          resetValue = doc[resetdeviceKey].as<bool>();
        } else if (doc[resetdeviceKey].is<const char*>()) {
          String v = String(doc[resetdeviceKey].as<const char*>());
          v.toLowerCase();
          resetValue = (v == "true" || v == "1" || v == "yes");
        }

        if (resetValue) {
          DEBUG_PRINTLN("Reset device requested via /control");

          // Clear preferences
          preferences.begin(PREFERENCES_NAMESPACE, false);
          preferences.clear();
          preferences.end();

          // Send response before rebooting
          sendJsonMessage(200, "Settings cleared; rebooting");
          delay(250);
          ESP.restart();
          return;  // Won't actually reach here
        }
      }

      // Handle reboot (no settings clear)
      const char* rebootKey = findKeyIgnoreCase(doc, "reboot");
      if (rebootKey) {
        bool rebootValue = false;
        if (doc[rebootKey].is<bool>()) {
          rebootValue = doc[rebootKey].as<bool>();
        } else if (doc[rebootKey].is<const char*>()) {
          String v = String(doc[rebootKey].as<const char*>());
          v.toLowerCase();
          rebootValue = (v == "true" || v == "1" || v == "yes");
        }

        if (rebootValue) {
          DEBUG_PRINTLN("Reboot requested via /control");
          sendJsonMessage(200, "Rebooting");
          delay(250);
          ESP.restart();
          return;
        }
      }

      // Handle clock enable/disable
      bool clockenable_found = false, clockenable_value = false;
      if (!parseJsonBoolKey(doc, "clockenable", clockenable_value, clockenable_found, clockEnabled)) {
        // parseJsonBoolKey returns false on error
      }
      if (clockenable_found) {
        clockEnabled = clockenable_value;
        settingsChanged = true;
        DEBUG_PRINTF("Clock enable set to: %s\n", clockEnabled ? "true" : "false");
      }

      // Handle screen navigation - weather
      const char* weatherKey = findKeyIgnoreCase(doc, "weather");
      if (weatherKey) {
        bool showWeather = false;
        if (doc[weatherKey].is<bool>()) {
          showWeather = doc[weatherKey].as<bool>();
        } else if (doc[weatherKey].is<const char*>()) {
          String v = String(doc[weatherKey].as<const char*>());
          v.toLowerCase();
          showWeather = (v == "true" || v == "1" || v == "yes");
        }

        if (showWeather) {
          DEBUG_PRINTLN("Navigate to weather screen via /control");
          changeScreen(SCREEN_WEATHER);
          sendJsonMessage(200, "Showing weather");
          return;
        }
      }

      // Handle screen navigation - calendar
      const char* calendarKey = findKeyIgnoreCase(doc, "calendar");
      if (calendarKey) {
        bool showCalendar = false;
        if (doc[calendarKey].is<bool>()) {
          showCalendar = doc[calendarKey].as<bool>();
        } else if (doc[calendarKey].is<const char*>()) {
          String v = String(doc[calendarKey].as<const char*>());
          v.toLowerCase();
          showCalendar = (v == "true" || v == "1" || v == "yes");
        }

        if (showCalendar) {
          DEBUG_PRINTLN("Navigate to calendar screen via /control");
          changeScreen(SCREEN_CALENDAR);
          sendJsonMessage(200, "Showing calendar");
          return;
        }
      }

      // Handle screen navigation - clock
      const char* clockKey = findKeyIgnoreCase(doc, "clock");
      if (clockKey) {
        bool showClock = false;
        if (doc[clockKey].is<bool>()) {
          showClock = doc[clockKey].as<bool>();
        } else if (doc[clockKey].is<const char*>()) {
          String v = String(doc[clockKey].as<const char*>());
          v.toLowerCase();
          showClock = (v == "true" || v == "1" || v == "yes");
        }

        if (showClock) {
          DEBUG_PRINTLN("Navigate to clock screen via /control");
          changeScreen(SCREEN_CLOCK);
          sendJsonMessage(200, "Showing clock");
          return;
        }
      }

      // Handle clear messages
      const char* clearKey = findKeyIgnoreCase(doc, "clear");
      if (clearKey) {
        bool doClear = false;
        if (doc[clearKey].is<bool>()) {
          doClear = doc[clearKey].as<bool>();
        } else if (doc[clearKey].is<const char*>()) {
          String v = String(doc[clearKey].as<const char*>());
          v.toLowerCase();
          doClear = (v == "true" || v == "1" || v == "yes");
        }

        if (doClear) {
          DEBUG_PRINTLN("Clear messages requested via /control");

          // Clear messages (handleClear logic)
          messageCount  = 0;
          unreadCount   = 0;
          messageActive = false;

          // Clear queued normal messages
          normalQueueHead  = 0;
          normalQueueTail  = 0;
          normalQueueCount = 0;

          // Navigate to appropriate screen
          if (currentScreen == SCREEN_MESSAGES) {
            drawMessagesScreen();
          } else if (currentScreen == SCREEN_MESSAGE) {
            changeScreen(SCREEN_CLOCK);  // Simplified - just go to clock
          } else {
            drawClock();  // Refresh current screen
          }

          sendJsonMessage(200, "Messages cleared");
          return;
        }
      }

      // Handle clear message history only (leaves active message/queue intact)
      const char* clearhistoryKey = findKeyIgnoreCase(doc, "clearhistory");
      if (clearhistoryKey) {
        bool doClear = false;
        if (doc[clearhistoryKey].is<bool>()) {
          doClear = doc[clearhistoryKey].as<bool>();
        } else if (doc[clearhistoryKey].is<const char*>()) {
          String v = String(doc[clearhistoryKey].as<const char*>());
          v.toLowerCase();
          doClear = (v == "true" || v == "1" || v == "yes");
        }

        if (doClear) {
          DEBUG_PRINTLN("Clear message history requested via /control");
          messageCount          = 0;
          unreadCount           = 0;
          currentHistoryIndex   = 0;

          if (currentScreen == SCREEN_MESSAGES) {
            drawMessagesScreen();
          }

          sendJsonMessage(200, "Message history cleared");
          return;
        }
      }

      if (settingsChanged) {
        saveSettings();

        // Redraw current screen
        switch (currentScreen) {
          case SCREEN_CLOCK     : drawClock();          break;
          case SCREEN_WEATHER   : displayWeather();     break;
          case SCREEN_CALENDAR  : displayCalendar();    break;
          case SCREEN_MENU      : drawMenu();           break;
          case SCREEN_MESSAGES  : drawMessagesScreen(); break;
          case SCREEN_ASTRO     : drawAstroScreen();    break;
        }

        sendJsonMessage(200, "Settings updated");
      } else if (localPressureUpdated) {
        sendJsonMessage(200, "Local pressure updated");
      } else {
        sendJsonMessage(200, "No changes");
      }
      return;

    } else {
      DEBUG_PRINTLN("JSON parsing failed");
      sendJsonMessage(400, "Invalid JSON");
      return;
    }
  }

  // Handle GET parameters (original logic)
  if (server.hasArg("return")) {
    String r = server.arg("return");
    if (r.length() > 0 && r.charAt(0) == '/') returnTo = r;
  }

  // Clock palette reset (also clears 'customized' flag)
  if (server.hasArg("clockresetcolors")) {
    String v = server.arg("clockresetcolors");
    v.toLowerCase();
    if (v == "dark") clockDarkMode = true;
    else if (v == "light") clockDarkMode = false;
    clockColorsCustomized = false;
    clockTimeColor = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
    clockDateColor = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
    clockBgColor = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR : DEFAULT_CLOCK_BG_COLOR_L;
    clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;
    settingsChanged = true;
  }

  if (server.hasArg("clockdark")) {
    String val = server.arg("clockdark");
    clockDarkMode = (val == "toggle") ? !clockDarkMode : (val == "true");
    if (!clockColorsCustomized) {
      clockTimeColor = clockDarkMode ? DEFAULT_CLOCK_TIME_COLOR : DEFAULT_CLOCK_TIME_COLOR_L;
      clockDateColor = clockDarkMode ? DEFAULT_CLOCK_DATE_COLOR : DEFAULT_CLOCK_DATE_COLOR_L;
      clockBgColor = clockDarkMode ? DEFAULT_CLOCK_BG_COLOR : DEFAULT_CLOCK_BG_COLOR_L;
      clockSuntimesColor = clockDarkMode ? DEFAULT_SUNTIMES_COLOR : DEFAULT_SUNTIMES_COLOR_L;
    }
    settingsChanged = true;
  }

  if (server.hasArg("weatherdark")) {
    String val = server.arg("weatherdark");
    weatherDarkMode = (val == "toggle") ? !weatherDarkMode : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("calendardark")) {
    String val = server.arg("calendardark");
    calendarDarkMode = (val == "toggle") ? !calendarDarkMode : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("menudark")) {
    String val = server.arg("menudark");
    menuDarkMode = (val == "toggle") ? !menuDarkMode : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("historydark")) {
    String val = server.arg("historydark");
    historyDarkMode = (val == "toggle") ? !historyDarkMode : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("astrodark")) {
    String val = server.arg("astrodark");
    astroDarkMode = (val == "toggle") ? !astroDarkMode : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("pixelshift")) {
    String val = server.arg("pixelshift");
    pixelShiftEnabled = (val == "toggle") ? !pixelShiftEnabled : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("touchenable")) {
    String val = server.arg("touchenable");
    touchEnabled = (val == "toggle") ? !touchEnabled : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("weathercycle")) {
    String val = server.arg("weathercycle");
    weatherCycleEnabled = (val == "toggle") ? !weatherCycleEnabled : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("calendarcycle")) {
    String val = server.arg("calendarcycle");
    calendarCycleEnabled = (val == "toggle") ? !calendarCycleEnabled : (val == "true");
    settingsChanged = true;
  }

  if (server.hasArg("tempactual")) {
    String val = server.arg("tempactual");
    if (val == "alternate") {
      tempAlternate = true;
      tempAlternateShowActual = true;    //start with actual when alternation begins
      lastTempAlternation = millis();
    } else {
      tempAlternate = false;
      tempActual = (val != "false");
    }
    settingsChanged = true;
  }

  if (server.hasArg("wxshowdur"))    { weatherShowDuration    = server.arg("wxshowdur").toInt()    * 1000; settingsChanged = true; }
  if (server.hasArg("wxcycleint"))   { weatherCycleInterval   = server.arg("wxcycleint").toInt()   * 1000; settingsChanged = true; }
  if (server.hasArg("calshowdur"))   { calendarShowDuration   = server.arg("calshowdur").toInt()   * 1000; settingsChanged = true; }
  if (server.hasArg("calcycleint"))  { calendarCycleInterval  = server.arg("calcycleint").toInt()  * 1000; settingsChanged = true; }
  if (server.hasArg("hpalternate"))  { highPriorityAlternateInterval = server.arg("hpalternate").toInt() * 1000; settingsChanged = true; }
  if (server.hasArg("normoverride")) { normalOverrideEnabled = server.arg("normoverride") != "false"; settingsChanged = true; }
  if (server.hasArg("normoverridedur")) { normalOverrideDuration = server.arg("normoverridedur").toInt(); settingsChanged = true; }
  if (server.hasArg("pulsemaxbri")) { pulseMaxBrightness = server.arg("pulsemaxbri").toInt(); settingsChanged = true; }
  if (server.hasArg("pulseminbri")) { pulseMinBrightness = server.arg("pulseminbri").toInt(); settingsChanged = true; }

  // Message history max age: 0 = disabled, positive integer = hours
  if (server.hasArg("maxmsgage")) {
    int v = server.arg("maxmsgage").toInt();
    if (v >= 0 && v <= 8760) { maxMsgAge = v; settingsChanged = true; }
  }

  // Handle clear message history only (leaves active message/queue intact)
  if (server.hasArg("clearhistory")) {
    String val = server.arg("clearhistory");
    val.toLowerCase();
    if (val == "true" || val == "1" || val == "yes") {
      DEBUG_PRINTLN("Clear message history requested via GET /control");
      messageCount        = 0;
      unreadCount         = 0;
      currentHistoryIndex = 0;
      if (currentScreen == SCREEN_MESSAGES) drawMessagesScreen();
    }
  }

  if (settingsChanged) {
    saveSettings();

    // Redraw current screen
    switch (currentScreen) {
      case SCREEN_CLOCK: drawClock(); break;
      case SCREEN_WEATHER: displayWeather(); break;
      case SCREEN_CALENDAR: displayCalendar(); break;
      case SCREEN_MENU: drawMenu(); break;
      case SCREEN_MESSAGES: drawMessagesScreen(); break;
      case SCREEN_ASTRO: drawAstroScreen(); break;
    }
  }

  server.sendHeader("Location", returnTo);
  server.send(303);
}

//=============================================================
// STATUS PAGE - Enhanced to match Display32 style
//=============================================================
void handleStatusPage() {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  // ===== Header (static blocks) =====
  server.sendContent(
    "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
    "<title>Device Status</title>"
    "<meta http-equiv='refresh' content='60'>"
  );

  server.sendContent(
    "<style>.nav-links{margin:10px 0 14px 0;display:flex;flex-direction:column;gap:10px;}.nav-row{display:grid;gap:10px;}"
    ".nav-row.row1{grid-template-columns:repeat(7,minmax(0,1fr));}.nav-row.row2{grid-template-columns:repeat(6,minmax(0,1fr));}"
    ".nav-links a{display:block;text-decoration:none;color:#1a73e8;padding:5px 8px;border-radius:6px;background:#fff;border:1px "
    "solid #ddd;text-align:center;font-size:12.5px;white-space:nowrap;}.nav-links a:hover{background:#e8f0fe;}.nav-links "
    "a.active{border-color:#4CAF50;color:#0b6b2a;background:#eef8f0;font-weight:bold;}"
    "*,*::before,*::after{box-sizing:border-box;}"
    "body{font-family:Arial,sans-serif;max-width:1000px;margin:20px auto;padding:0 20px;background:#f5f5f5;}"
    "h1{color:#333;border-bottom:3px solid #4CAF50;padding-bottom:10px;}"
    "h2{color:#555;margin-top:25px;border-left:4px solid #4CAF50;padding-left:10px;}"
    ".auto-refresh{background:#fff3cd;border-left:4px solid #ffc107;padding:10px;margin:15px 0;border-radius:4px;font-size:13px;"
    "color:#856404;}"
    ".nav-back{margin:20px 0;}"
    ".nav-back a{color:#2196F3;text-decoration:none;font-size:16px;}"
    ".nav-back a:hover{text-decoration:underline;}"
    ".status-section{background:white;padding:25px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin:20px 0;}"
    ".info-grid{display:grid;grid-template-columns:250px 1fr;gap:12px;margin:15px 0;}"
    ".info-label{font-weight:bold;color:#555;text-align:right;padding-right:15px;}"
    ".info-value{color:#333;}"
    ".status-badge{display:inline-block;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:bold;}"
    ".badge-active{background:#4CAF50;color:white;}"
    ".badge-inactive{background:#9e9e9e;color:white;}"
    ".badge-yes{background:#4CAF50;color:white;}"
    ".badge-no{background:#f44336;color:white;}"
    ".badge-enabled{background:#4CAF50;color:white;}"
    ".badge-disabled{background:#9e9e9e;color:white;}"
    ".message-history{margin:20px 0;}"
    ".message-item{background:#f9f9f9;border-left:4px solid #2196F3;padding:15px;margin:10px 0;border-radius:4px;"
    "font-family:monospace;word-wrap:break-word;}"
    ".message-number{font-weight:bold;color:#2196F3;margin-bottom:8px;}"
    ".no-messages{text-align:center;padding:30px;color:#999;font-style:italic;}"
    ".btn{background:#4CAF50;color:white;padding:10px 20px;border:none;border-radius:5px;cursor:pointer;font-size:14px;"
    "text-decoration:none;display:inline-block;margin:5px;}"
    ".btn:hover{background:#45a049;}.btn.disabled{opacity:0.45;pointer-events:none;filter:grayscale(0.6);}"
    ".btn-secondary{background:#2196F3;}"
    ".btn-secondary:hover{background:#0b7dda;}"
    "</style></head><body>"
  );
  sendNav("/status");

  server.sendContent(
    ""
    "<h1>📊 Device Status</h1>"
    "<div class='auto-refresh'>🔄 This page auto-refreshes every 60 seconds</div>"
  );

  // ==================================================================
  // DEVICE INFORMATION
  // ==================================================================
  server.sendContent(
    "<div class='status-section'>"
    "<h2>Device Information</h2>"
    "<div class='info-grid'>"

        "<div class='info-label'>Device Name:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(deviceName));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Firmware Version:</div><div class='info-value'>"
  );
  server.sendContent(String(Version));
    server.sendContent(
    "</div>"
        "<div class='info-label'>Compilation Timestamp       :</div><div class='info-value'>"
  );
  server.sendContent(String(Timestamp));
  server.sendContent(
    "</div>"

        "<div class='info-label'>IP Address:</div><div class='info-value'>"
  );
  server.sendContent(WiFi.localIP().toString());
  server.sendContent(
    "</div>"

        "<div class='info-label'>mDNS Name:</div><div class='info-value'>"
  );
  {
    String mdnsName = deviceName + ".local";
    server.sendContent("<a href='http://");
    server.sendContent(htmlEscape(mdnsName));
    server.sendContent("'>");
    server.sendContent(htmlEscape(mdnsName));
    server.sendContent("</a>");
  }
  server.sendContent(
    "</div>"

        "<div class='info-label'>WiFi SSID:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(WiFi.SSID()));
  {
    int rssi = WiFi.RSSI();
    int nf   = rom_check_noise_floor() / 4;
    if (nf > 0) nf = -nf;
    int snr  = rssi - nf;
    server.sendContent(
      "</div>"
      "<div class='info-label'>Signal / Noise:</div><div class='info-value'>" +
      String(rssi) + " dBm / " + String(nf) + " dBm</div>"
      "<div class='info-label'>SNR:</div><div class='info-value'>" +
      String(snr) + " dB (" + snrLabel(snr) + ")</div>"
    );
  }
  server.sendContent(
    "<div class='info-label'>MAC Address:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(WiFi.macAddress()));

    server.sendContent(
    "</div>"

        "<div class='info-label'>Device ID:</div><div class='info-value'>"
  );
  server.sendContent("0x" + htmlEscape(deviceID));
  server.sendContent(
        "</div>"
  );

  // Uptime (computed)
  ulong uptimeSeconds = millis() / 1000;
  ulong days = uptimeSeconds / 86400;
  ulong hours = (uptimeSeconds % 86400) / 3600;
  ulong minutes = (uptimeSeconds % 3600) / 60;
  ulong seconds = uptimeSeconds % 60;

  String uptime;
  if (days > 0) uptime += String(days) + "d ";
  if (hours > 0 || days > 0) uptime += String(hours) + "h ";
  if (minutes > 0 || hours > 0 || days > 0) uptime += String(minutes) + "m ";
  uptime += String(seconds) + "s";

  server.sendContent(
        "<div class='info-label'>Uptime:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(uptime));
  server.sendContent(" (");
  server.sendContent(String(millis() / 1000));
  server.sendContent(
    " seconds)</div>"

        "<div class='info-label'>Free Heap:</div><div class='info-value'>"
  );
  server.sendContent(String(ESP.getFreeHeap()));
  server.sendContent(
        " bytes</div>"
  );

  // Current time
  struct tm timeinfo;
  if (getLocalTime(&timeinfo)) {
    char timeStr[30];
    strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %I:%M:%S %p", &timeinfo);

    server.sendContent(
        "<div class='info-label'>Current Time:</div><div class='info-value'>"
    );
    server.sendContent(htmlEscape(String(timeStr)));
    server.sendContent("</div>");
  }

  server.sendContent(
    "</div>"  // info-grid
    "</div>"  // status-section
  );

  // ==================================================================
  // CURRENT DISPLAY STATUS
  // ==================================================================
  server.sendContent(
    "<div class='status-section'>"
    "<h2>Current Display Status</h2>"
    "<div class='info-grid'>"

        "<div class='info-label'>Total Messages Sent:</div><div class='info-value'>"
  );
  server.sendContent(String(messageCount));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Time Since Last Message:</div><div class='info-value'>"
  );
  server.sendContent(String((millis() - lastMessageTime) / 1000));
  server.sendContent(
    " seconds</div>"

        "<div class='info-label'>Currently Displayed Screen:</div><div class='info-value'>"
  );
  {
    struct { ScreenMode mode; const char* label; } screenNames[] = {
      { SCREEN_CLOCK,    "Clock"    },
      { SCREEN_WEATHER,  "Weather"  },
      { SCREEN_CALENDAR, "Calendar" },
      { SCREEN_MENU,     "Menu"     },
      { SCREEN_MESSAGE,  "Message"  },
      { SCREEN_MESSAGES, "Messages" },
      { SCREEN_ABOUT,    "About"    },
    };
    const char* screenLabel = "Unknown";
    for (auto& s : screenNames) {
      if (currentScreen == s.mode) { screenLabel = s.label; break; }
    }
    server.sendContent("<span class='status-badge badge-active'>");
    server.sendContent(screenLabel);
    server.sendContent("</span>");
  }
  server.sendContent(
    "</div>"
        "<div class='info-label'>Clock Display:</div><div class='info-value'>"
  );
  server.sendContent(clockEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent("&nbsp;");
  server.sendContent(showClock
                       ? "<span class='status-badge badge-active'>ACTIVE</span>"
                       : "<span class='status-badge badge-inactive'>INACTIVE</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Screensaver:</div><div class='info-value'>"
  );
  server.sendContent((clockEnabled && screensaverTimeout > 0)
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent("&nbsp;");
  server.sendContent(screensaverActive
                       ? "<span class='status-badge badge-active'>ACTIVE</span>"
                       : "<span class='status-badge badge-inactive'>INACTIVE</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Weather Cycle:</div><div class='info-value'>"
  );
  server.sendContent(weatherCycleEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"
        "<div class='info-label'>Calendar Cycle:</div><div class='info-value'>"
  );
  server.sendContent(calendarCycleEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Actual Brightness:</div><div class='info-value'>"
  );
  server.sendContent(String(actualCurrentBrightness));
  server.sendContent(
    " out of 5</div>"
    "</div>"
    "</div>"
  );

  // ==================================================================
  // CURRENT MESSAGE SETTINGS
  // ==================================================================
  server.sendContent(
    "<div class='status-section'>"
    "<h2>Current Message Display Settings</h2>"
    "<div class='info-grid'>"

        "<div class='info-label'>Background Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(currentBgColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Text Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(currentTextColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Font:</div><div class='info-value'>"
  );
  server.sendContent(String(currentFont));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Rotation:</div><div class='info-value'>"
  );
  server.sendContent(String(currentRotation));
  server.sendContent(
    "°</div>"

        "<div class='info-label'>Horizontal Align:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(currentHAlign));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Vertical Align:</div><div class='info-value'>"
  );
  server.sendContent(htmlEscape(currentVAlign));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Text Wrap:</div><div class='info-value'>"
  );
  server.sendContent(currentWrap
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Scroll Direction:</div><div class='info-value'>"
  );
  if (currentScrollDirection.length() > 0) {
    server.sendContent(htmlEscape(currentScrollDirection));
    server.sendContent(" (speed: ");
    server.sendContent(String(currentScrollSpeed));
    server.sendContent(")");
  } else {
    server.sendContent("None (static)");
  }
  server.sendContent(
    "</div>"

        "<div class='info-label'>Brightness:</div><div class='info-value'>"
  );
  server.sendContent(String(currentBrightness));
  server.sendContent(
    " out of 5</div>"

        "<div class='info-label'>Pulse Duration:</div><div class='info-value'>"
  );
  server.sendContent(String(currentFlashInterval));
  server.sendContent(
    " ms</div>"

        "<div class='info-label'>Flashing Effect:</div><div class='info-value'>"
  );
  server.sendContent(isFlashing
                       ? "<span class='status-badge badge-active'>ACTIVE</span>"
                       : "<span class='status-badge badge-inactive'>INACTIVE</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Pulsing Effect:</div><div class='info-value'>"
  );
  server.sendContent(isPulsing
                       ? "<span class='status-badge badge-active'>ACTIVE</span>"
                       : "<span class='status-badge badge-inactive'>INACTIVE</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Message Priority:</div><div class='info-value'>"
  );
  {
    bool isHigh = (messagePriority == "high");
    server.sendContent(isHigh
                       ? "<span class='status-badge' style='background:#f44336;'>HIGH</span>"
                       : "<span class='status-badge' style='background:#2196F3;'>NORMAL</span>");
  }
  server.sendContent(
    "</div>"

        "<div class='info-label'>Expiration Time:</div><div class='info-value'>"
  );
  if (messageExpirationTime > 0) {
    ulong elapsed = messageActive ? (millis() - messageDisplayStartTime) / 1000 : 0;
    ulong remaining = (elapsed < (ulong)messageExpirationTime) ? (ulong)messageExpirationTime - elapsed : 0;
    server.sendContent(String(messageExpirationTime) + " sec (");
    server.sendContent(remaining > 0 ? String(remaining) + " sec remaining" : "expired");
    server.sendContent(")");
  } else {
    server.sendContent("None (never expires)");
  }
  server.sendContent(
    "</div>"

    "</div>"
    "</div>"
  );

  // ==================================================================
  // MESSAGE PROFILES
  // ==================================================================
  {
    server.sendContent(
      "<div class='status-section'>"
      "<h2>Message Profiles</h2>"
      "<table style='width:100%;border-collapse:collapse;font-size:13px;'>"
      "<tr style='background:#4CAF50;color:white;'>"
      "<th style='padding:8px;border:1px solid #ddd;'>Profile</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>BG Color</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Text Color</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Font</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Rotation</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Align H/V</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Wrap</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Scroll</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Brightness</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Effects</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Priority</th>"
      "<th style='padding:8px;border:1px solid #ddd;'>Expiration</th>"
      "</tr>"
    );
    for (int pi = 0; pi < MAX_MSG_PROFILES; pi++) {
      String row = "<tr>";
      row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;font-weight:bold;'>" + String(pi) + "</td>";
      if (msgProfiles[pi].saved) {
        String bgHx = colorToHex(msgProfiles[pi].bgColor);
        String tcHx = colorToHex(msgProfiles[pi].textColor);
        row += "<td style='padding:6px;border:1px solid #ddd;'>"
               "<span style='display:inline-block;width:16px;height:16px;background:" + htmlEscape(bgHx) + ";border:1px solid #888;vertical-align:middle;'></span>"
               " " + htmlEscape(bgHx) + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;'>"
               "<span style='display:inline-block;width:16px;height:16px;background:" + htmlEscape(tcHx) + ";border:1px solid #888;vertical-align:middle;'></span>"
               " " + htmlEscape(tcHx) + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + String(msgProfiles[pi].font) + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + String(msgProfiles[pi].rotation) + "°</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + htmlEscape(msgProfiles[pi].hAlign) + "/" + htmlEscape(msgProfiles[pi].vAlign) + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + String(msgProfiles[pi].wrap ? "yes" : "no") + "</td>";
        String scrollInfo = msgProfiles[pi].scrollDir.length() == 0 || msgProfiles[pi].scrollDir == "none" ?
                            "none" : htmlEscape(msgProfiles[pi].scrollDir) + " spd:" + String(msgProfiles[pi].scrollSpeed);
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + scrollInfo + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + String(msgProfiles[pi].brightness) + "</td>";
        String efx = "";
        if (msgProfiles[pi].flash) efx += "flash(" + String(msgProfiles[pi].flashInterval) + "ms) ";
        if (msgProfiles[pi].pulse) efx += "pulse(" + String(msgProfiles[pi].pulseDuration) + "ms)";
        if (efx.length() == 0) efx = "none";
        row += "<td style='padding:6px;border:1px solid #ddd;'>" + htmlEscape(efx) + "</td>";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + htmlEscape(msgProfiles[pi].priority) + "</td>";
        String expStr = msgProfiles[pi].expirationTime > 0 ? String(msgProfiles[pi].expirationTime) + "s" : "none";
        row += "<td style='padding:6px;border:1px solid #ddd;text-align:center;'>" + expStr + "</td>";
      } else {
        row += "<td colspan='11' style='padding:6px;border:1px solid #ddd;color:#999;font-style:italic;text-align:center;'>(empty)</td>";
      }
      row += "</tr>";
      server.sendContent(row);
    }
    server.sendContent("</table></div>");
  }

  // ==================================================================
  // CLOCK CONFIGURATION (same style)
  // ==================================================================
  server.sendContent(
    "<div class='status-section'>"
    "<h2>Clock Configuration</h2>"
    "<div class='info-grid'>"

        "<div class='info-label'>Clock Enabled:</div><div class='info-value'>"
  );
  server.sendContent(clockEnabled
                       ? "<span class='status-badge badge-yes'>YES</span>"
                       : "<span class='status-badge badge-no'>NO</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Time Format:</div><div class='info-value'><span style='font-family:monospace;font-size:15px;'>"
  );
  server.sendContent(htmlEscape(clockTimeFormat));
  server.sendContent(
    "</span></div>"

        "<div class='info-label'>Date Format:</div><div class='info-value'><span style='font-family:monospace;font-size:15px;'>"
  );
  server.sendContent(htmlEscape(clockDateFormat));
  server.sendContent(
    "</span></div>"

        "<div class='info-label'>Time Font:</div><div class='info-value'>"
  );
  server.sendContent(String(clockTimeFont));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Date Font:</div><div class='info-value'>"
  );
  server.sendContent(String(clockDateFont));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Time Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(clockTimeColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Date Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(clockDateColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Background Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(clockBgColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Clock Brightness:</div><div class='info-value'>"
  );
  server.sendContent(String(screenBrightness));
  server.sendContent(
    " / 5</div>"

        "<div class='info-label'>Clock Rotation:</div><div class='info-value'>"
  );
  server.sendContent(String(clockRotation));
  server.sendContent(
    "°</div>"

        "<div class='info-label'>Screensaver Dim:</div><div class='info-value'>"
  );
  server.sendContent(String(screensaverDimValue));
  server.sendContent(
    " (0-5)</div>"

        "<div class='info-label'>Screensaver Timeout:</div><div class='info-value'>"
  );
  server.sendContent(String(screensaverTimeout / 1000));
  server.sendContent(
    " seconds</div>"

        "<div class='info-label'>Night Mode:</div><div class='info-value'>"
  );
  if (nightModeEnabled) {
    server.sendContent("<span class='status-badge badge-enabled'>ENABLED</span>");
    if (nightModeActive) {
      server.sendContent(" <span class='status-badge' style='background:#4a5568;'>ACTIVE</span>");
    }
  } else {
    server.sendContent("<span class='status-badge badge-disabled'>DISABLED</span>");
  }
  server.sendContent(
    "</div>"

        "<div class='info-label'>Night Brightness:</div><div class='info-value'>"
  );
  server.sendContent(String(nightModeBrightness));
  server.sendContent(
    " / 5</div>"

        "<div class='info-label'>Day Brightness:</div><div class='info-value'>"
  );
  server.sendContent(String(nightModeWakeBrightness));
  server.sendContent(
    " / 5</div>"

        "<div class='info-label'>Show Sun Times:</div><div class='info-value'>"
  );
  server.sendContent(clockSuntimesEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Sun Times Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(clockSuntimesColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Night Time Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(nightClockTimeColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Night Date Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(nightClockDateColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Night BG Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(nightClockBgColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Night Suntimes Color:</div><div class='info-value'>"
  );
  server.sendContent(colorToString(nightClockSuntimesColor));
  server.sendContent(
    "</div>"

        "<div class='info-label'>Sun Times Available:</div><div class='info-value'>"
  );
  if (sunTimesValid) {
    char sunriseStr[12], sunsetStr[12];
    snprintf(sunriseStr, sizeof(sunriseStr), "%02d:%02d", sunriseHour, sunriseMinute);
    snprintf(sunsetStr,  sizeof(sunsetStr),  "%02d:%02d", sunsetHour,  sunsetMinute);
    server.sendContent(
      "<span class='status-badge badge-yes'>YES</span>"
      " &nbsp; 🌅 Rise: <span style='font-family:monospace;font-size:15px;'>" + String(sunriseStr) + "</span>"
      " &nbsp; 🌇 Set: <span style='font-family:monospace;font-size:15px;'>"  + String(sunsetStr)  + "</span>"
    );
  } else {
    server.sendContent(
      "<span class='status-badge badge-no'>NO</span>"
      "<span style='color:#666;font-size:13px;margin-left:8px;'>"
      "Fetch weather to populate</span>"
    );
  }
  server.sendContent(
    "</div>"

        "<div class='info-label'>Sunrise Offset:</div><div class='info-value'>"
  );
  server.sendContent((sunriseOffset >= 0 ? "+" : "") + String(sunriseOffset) + " min");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Sunset Offset:</div><div class='info-value'>"
  );
  server.sendContent((sunsetOffset >= 0 ? "+" : "") + String(sunsetOffset) + " min");
  server.sendContent(
    "</div>"

    "</div>"
    "<a href='/clockconfig' class='btn btn-secondary'>⚙️ Edit Clock Settings</a>"
    "</div>"
  );

  // ==================================================================
  // DEVICE CONTROLS
  // ==================================================================
  server.sendContent(
    "<div class='status-section'>"
    "<h2>Device Control Settings</h2>"
    "<div class='info-grid'>"

        "<div class='info-label'>Pixel Shift:</div><div class='info-value'>"
  );
  server.sendContent(pixelShiftEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"

        "<div class='info-label'>Touch Control:</div><div class='info-value'>"
  );
  server.sendContent(touchEnabled
                       ? "<span class='status-badge badge-enabled'>ENABLED</span>"
                       : "<span class='status-badge badge-disabled'>DISABLED</span>");
  server.sendContent(
    "</div>"

    "</div>"
    "</div>"
  );

  // ==================================================================
  // MESSAGE HISTORY (leave per-message; rarely used and variable sized)
  // ==================================================================
  server.sendContent("<div class='status-section'><h2 style='display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;'>Message History"
    "<a href='/control?clearhistory=true&return=/status' "
    "onclick=\"return confirm('Clear all message history?')\" "
    "style='font-size:13px;font-weight:normal;background:#e53935;color:#fff;padding:5px 12px;border-radius:5px;"
    "text-decoration:none;white-space:nowrap;'>&#x1F5D1; Clear History</a></h2>");

  // Show maxMsgAge state
  if (maxMsgAge <= 0) {
    server.sendContent(
      "<p style='margin:0 0 10px 0;font-size:12px;color:#888;'>"
      "Age-based purging is <strong>disabled</strong> "
      "(<code>maxMsgAge = 0</code>). Messages are kept until history is full or manually cleared.</p>");
  } else {
    server.sendContent(
      "<p style='margin:0 0 10px 0;font-size:12px;color:#888;'>"
      "Messages older than " + String(maxMsgAge) + " hour" +
      (maxMsgAge == 1 ? "" : "s") +
      " are automatically purged (<code>maxMsgAge = " + String(maxMsgAge) + "</code>).</p>");
  }

  if (messageCount == 0) {
    server.sendContent("<div class='no-messages'>No messages in history</div>");
  } else {
    server.sendContent("<div class='message-history'>");

    for (int i = messageCount - 1; i >= 0; i--) {
      if (messages[i].text.length() > 0) {
        server.sendContent("<div class='message-item'><div class='message-number'>Message #");
        server.sendContent(String(i + 1));

        if (messages[i].time.length() > 0) {
          server.sendContent(" - ");
          server.sendContent(htmlEscape(messages[i].time));
        }

        if (messages[i].unread) {
          server.sendContent(" <span class='status-badge badge-yes'>NEW</span>");
        }

        server.sendContent("</div>");
        server.sendContent(htmlEscape(messages[i].text));
        server.sendContent("</div>");
      }
    }

    server.sendContent("</div>");
  }

  server.sendContent("</div>");  // end status-section

  // ===== Footer =====
  server.sendContent(
    ""
    "</body></html>"
  );
  server.sendContent("");
}

//=============================================================
// CLOCK CONFIGURATION PAGE
//=============================================================
void handleClockConfigPage() {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  server.sendContent(
    "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Clock Configuration</title><style>.nav-links{margin:10px 0 14px 0;"
    "display:flex;flex-direction:column;gap:10px;}.nav-row{display:grid;gap:10px;}.nav-row.row1{grid-template-columns:repeat(7,"
    "minmax(0,1fr));}.nav-row.row2{grid-template-columns:repeat(6,minmax(0,1fr));}.nav-links a{display:block;"
    "text-decoration:none;color:#1a73e8;padding:5px 8px;border-radius:6px;background:#fff;border:1px solid #ddd;"
    "text-align:center;font-size:12.5px;white-space:nowrap;}.nav-links a:hover{background:#e8f0fe;}.nav-links "
    "a.active{border-color:#4CAF50;color:#0b6b2a;background:#eef8f0;font-weight:bold;}"
    "*,*::before,*::after{box-sizing:border-box;}"
    "body{font-family:Arial,sans-serif;max-width:900px;margin:20px auto;padding:0 20px;background:#f5f5f5;}"
    "h1{color:#333;border-bottom:3px solid #4CAF50;padding-bottom:10px;}"
    "h2{color:#555;margin-top:25px;border-left:4px solid #4CAF50;padding-left:10px;}"
    ".info-bar{background:#fff;padding:12px;border-radius:6px;margin:12px 0;border:1px solid #ddd;}"
    ".info-box{background:#e3f2fd;border-left:4px solid #2196F3;padding:15px;margin:15px 0;border-radius:4px;}"
    ".config-section{background:white;padding:25px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin:20px 0;}"
    ".form-row{margin:15px 0;display:grid;grid-template-columns:200px 1fr;gap:15px;align-items:center;}"
    ".form-row label{font-weight:bold;text-align:right;}"
    ".form-row .input-group{display:flex;gap:10px;align-items:center;}"
    "input[type='text'],input[type='number'],select{padding:8px;border:1px solid #ccc;border-radius:4px;font-size:14px;}"
    "input[type='range']{width:200px;}"
    "input[type='checkbox']{width:20px;height:20px;}"
    ".btn{background:#4CAF50;color:white;padding:12px 30px;border:none;border-radius:5px;cursor:pointer;font-size:16px;"
    "margin:10px 5px;}"
    ".btn:hover{background:#45a049;}.btn.disabled{opacity:0.45;pointer-events:none;filter:grayscale(0.6);}"
    ".btn-secondary{background:#2196F3;padding:6px 12px;margin:2px;}"
    ".btn-secondary:hover{background:#0b7dda;}"
    ".format-examples{background:#f9f9f9;padding:15px;border-radius:4px;margin:10px 0;font-size:13px;border:1px solid #e0e0e0;}"
    ".format-examples h4{margin:0 0 10px 0;color:#666;}"
    ".format-examples ul{margin:5px 0;padding-left:20px;}"
    ".format-examples li{margin:5px 0;}"
    ".color-input-group{display:flex;gap:10px;align-items:center;}"
    ".color-input-group select{width:150px;}"
    ".color-input-group input[type='text']{width:100px;font-family:monospace;text-transform:uppercase;}"
    ".nav-back{margin:20px 0;}"
    ".nav-back a{color:#2196F3;text-decoration:none;font-size:16px;}"
    ".nav-back a:hover{text-decoration:underline;}"
    ".quick-actions{display:flex;flex-wrap:nowrap;gap:6px;align-items:center;overflow-x:auto;padding-bottom:2px;}"
    ".quick-actions .btn{margin:0;padding:10px 14px;white-space:nowrap;}"
    "details{margin:15px 0;background:#fff;border:1px solid #ddd;border-radius:8px;}"
    "summary{background:#e0e0e0;padding:12px;border-radius:8px 8px 0 0;cursor:pointer;font-weight:bold;user-select:none;}"
    "summary:hover{background:#d0d0d0;}"
    ".details-content{padding:16px;}"
    "</style>"
    "<script>"
    "function useTimePreset(f){document.getElementById('timeformat').value=f;}"
    "function useDatePreset(f){document.getElementById('dateformat').value=f;}"
    "</script></head><body>"
    ""
    "<h1>🕐 Clock Configuration</h1>"
  );
  sendNav("/clockconfig");
  server.sendContent("<div class='info-bar'><strong>Device:</strong> " + deviceName +
                     " &nbsp; <strong>Version:</strong> " + String(Version) +
                     " &nbsp; <strong>Built:</strong> " + String(Timestamp) +
                     " &nbsp; <strong>IP:</strong> " + WiFi.localIP().toString() +
                       wifiSignalHtml() + "</div>");

  // Quick Actions
  server.sendContent(
    "<div class='config-section'><h2>Quick Actions</h2>"
    "<button class='btn btn-secondary' style='padding:12px 50px;' onclick='location.href=\"/clock\"'>▶️ Show Clock</button> "
    "<button class='btn btn-secondary' style='padding:12px 50px;' onclick='location.href=\"/control?clockresetcolors=dark&return=/clockconfig\"'>🌙 Reset to Dark Mode</button> "
    "<button class='btn btn-secondary' style='padding:12px 50px;' onclick='location.href=\"/control?clockresetcolors=light&return=/clockconfig\"'>☀️ Reset to Light Mode</button>"
    "</div>");

  // Main Form
  server.sendContent("<div class='config-section'><h2>Clock Settings</h2><form action='/clockconfig' method='POST'>");

  // Enable Clock
  server.sendContent("<div class='form-row'><label>Enable Clock:</label><input type='checkbox' name='enabled' value='true'");
  if (clockEnabled) server.sendContent(" checked");
  server.sendContent("></div>");

  // Time Format
  server.sendContent(
    "<div class='form-row'><label>Time Format:</label>"
    "<input type='text' name='timeformat' id='timeformat' value='" + clockTimeFormat + "' style='width:200px;'>"
    "</div>"
    "<div class='form-row'><label></label><div>"
      "<div class='format-examples'><h4>Common Time Formats:</h4>"
        "<button type='button' class='btn btn-secondary' onclick='useTimePreset(\"%I:%M %p\")'>12-hour (3:45 PM)</button> "
        "<button type='button' class='btn btn-secondary' onclick='useTimePreset(\"%H:%M\")'>24-hour (15:45)</button> "
        "<button type='button' class='btn btn-secondary' onclick='useTimePreset(\"%I:%M:%S %p\")'>With seconds</button>"
        "<div class='help-text'>Use <code>strftime</code> format tokens. Examples:</div>"
        "<ul><li><code>%I</code>=Hour(12hr), <code>%H</code>=Hour(24hr), <code>%M</code>=Minutes, <code>%S</code>=Seconds, <code>%p</code>=AM/PM</li></ul>"
      "</div>"
    "</div></div>"
  );

  // Date Format
  server.sendContent(
    "<div class='form-row'><label>Date Format:</label>"
    "<input type='text' name='dateformat' id='dateformat' value='" + clockDateFormat + "' style='width:200px;'>"
    "</div>"
    "<div class='form-row'><label></label><div>"
      "<div class='format-examples'><h4>Common Date Formats:</h4>"
        "<button type='button' class='btn btn-secondary' onclick='useDatePreset(\"%a, %b %d\")'>Fri, Dec 23</button> "
        "<button type='button' class='btn btn-secondary' onclick='useDatePreset(\"%A, %B %d\")'>Friday, December 23</button> "
        "<button type='button' class='btn btn-secondary' onclick='useDatePreset(\"%m/%d/%Y\")'>12/23/2025</button> "
        "<button type='button' class='btn btn-secondary' onclick='useDatePreset(\"%Y-%m-%d\")'>2025-12-23</button>"
        "<div class='help-text'>Use <code>strftime</code> format tokens. Examples:</div>"
        "<ul><li><code>%a</code>=Day(abbrev), <code>%A</code>=Day(full), <code>%b</code>=Month(abbrev), <code>%B</code>=Month(full), <code>%d</code>=Day(01-31), <code>%m</code>=Month(01-12), <code>%Y</code>=Year</li></ul>"
      "</div>"
    "</div></div>"
  );

// Fonts
  server.sendContent(
    "<div class='form-row'><label>Time Font:</label><select name='timefont'>" +
    buildRobotoFontOptions(clockTimeFont, DEFAULT_TIME_FONT) + "</select></div>"
  );

  server.sendContent(
    "<div class='form-row'><label>Date Font:</label><select name='datefont'>" +
    buildRobotoFontOptions(clockDateFont, DEFAULT_DATE_FONT) + "</select></div>"
  );

  // Colors with named options + hex
  String tcHex = colorToHex(clockTimeColor);
  String dcHex = colorToHex(clockDateColor);
  String bgHex = colorToHex(clockBgColor);

  server.sendContent(
    "<div class=\'form-row\'><label>Time Color:</label><div class=\'color-input-group\' style=\'display:flex;gap:10px;align-items:center;flex-wrap:nowrap;\'>"
    "<span id=\'timecolor_swatch\' style=\'display:inline-block;width:22px;height:22px;flex:0 0 22px;align-self:center;"
    "background:" + htmlEscape(tcHex) + ";border:1px solid #888;border-radius:3px;\'></span>"
    "<select id=\'timecolor_select\' style=\'flex:1;min-width:0;\'>"
    + buildNamedColorOptions(clockTimeColor, false) + "</select><span>OR</span>"
                                                      "<input type=\'text\' id=\'timecolor_hex\' value=\'"
    + htmlEscape(tcHex) + "\' placeholder=\'#FFFFFF\' maxlength=\'7\' style=\'width:120px;flex:0 0 auto;\'>"
                          "<input type=\'hidden\' name=\'timecolor\' id=\'timecolor_val\' value=\'"
    + htmlEscape(tcHex) + "\'>"
                          "</div></div>");

  server.sendContent(
    "<div class=\'form-row\'><label>Date Color:</label><div class=\'color-input-group\' style=\'display:flex;gap:10px;align-items:center;flex-wrap:nowrap;\'>"
    "<span id=\'datecolor_swatch\' style=\'display:inline-block;width:22px;height:22px;flex:0 0 22px;align-self:center;"
    "background:" + htmlEscape(dcHex) + ";border:1px solid #888;border-radius:3px;\'></span>"
    "<select id=\'datecolor_select\' style=\'flex:1;min-width:0;\'>"
    + buildNamedColorOptions(clockDateColor, false) + "</select><span>OR</span>"
                                                      "<input type=\'text\' id=\'datecolor_hex\' value=\'"
    + htmlEscape(dcHex) + "\' placeholder=\'#D3D3D3\' maxlength=\'7\' style=\'width:120px;flex:0 0 auto;\'>"
                          "<input type=\'hidden\' name=\'datecolor\' id=\'datecolor_val\' value=\'"
    + htmlEscape(dcHex) + "\'>"
                          "</div></div>");

  server.sendContent(
    "<div class=\'form-row\'><label>Background Color:</label><div class=\'color-input-group\' style=\'display:flex;gap:10px;align-items:center;flex-wrap:nowrap;\'>"
    "<span id=\'clkbgcolor_swatch\' style=\'display:inline-block;width:22px;height:22px;flex:0 0 22px;align-self:center;"
    "background:" + htmlEscape(bgHex) + ";border:1px solid #888;border-radius:3px;\'></span>"
    "<select id=\'bgcolor_select\' style=\'flex:1;min-width:0;\'>"
    + buildNamedColorOptions(clockBgColor, true) + "</select><span>OR</span>"
                                                   "<input type=\'text\' id=\'bgcolor_hex\' value=\'"
    + htmlEscape(bgHex) + "\' placeholder=\'#000000\' maxlength=\'7\' style=\'width:120px;flex:0 0 auto;\'>"
                          "<input type=\'hidden\' name=\'bgcolor\' id=\'bgcolor_val\' value=\'"
    + htmlEscape(bgHex) + "\'>"
                          "</div></div>");

  // Display Settings
  server.sendContent(
    "<div class='form-row'><label>Screen Brightness:</label><div class='input-group'>"
    "<input type='range' name='brightness' min='0' max='5' value='" + String(screenBrightness) +
    "' oninput='this.nextElementSibling.textContent=this.value'>"
    "<span>" + String(screenBrightness) + "</span><span style='margin-left:10px;color:#666;'>(0-5)</span></div></div>"
  );

  server.sendContent(
    "<div class='form-row'><label>Rotation:</label><select name='rotation'>"
    "<option value='0'" + String(clockRotation==0?" selected":"") + ">0° (Portrait)</option>" +
    "<option value='90'" + String(clockRotation==90?" selected":"") + ">90° (Landscape)</option>" +
    "<option value='180'" + String(clockRotation==180?" selected":"") + ">180° (Portrait Flipped)</option>" +
    "<option value='270'" + String(clockRotation==270?" selected":"") + ">270° (Landscape Flipped)</option></select></div>"
  );

  // Screensaver
  server.sendContent(
    "<div class='form-row'><label>Screensaver Dim:</label><div class='input-group'>"
    "<input type='range' name='dimlevel' min='0' max='5' value='" + String(screensaverDimValue) +
    "' oninput='this.nextElementSibling.textContent=this.value'>"
    "<span>" + String(screensaverDimValue) + "</span></div></div>"
  );

  server.sendContent(
    "<div class='form-row'><label>Screensaver Timeout:</label><div class='input-group'>"
    "<input type='number' name='timeout' min='0' max='3600' value='"
    + String(screensaverTimeout / 1000) + "' style='width:120px;'>"

    "<span style='margin-left:10px;color:#666;'>seconds (0 = disabled)</span></div></div>"
  );

  // Sunrise/Sunset Display  (moved above Night Mode)
  server.sendContent(
    "<div class='form-row'><label>Show Sunrise/Sunset:</label><div>"
    "<input type='checkbox' name='clksuntimesenabled' value='true'" +
    String(clockSuntimesEnabled?" checked":"") + "> " +
    "<span style='color:#666;font-size:13px;margin-left:10px;'>Display sunrise or sunset time below date</span></div></div>"
  );

  {
    String scHex = colorToHex(clockSuntimesColor);
    server.sendContent(
      "<div class='form-row'><label>Sunrise/Sunset Color:</label>"
      "<div class='color-input-group' style='display:flex;gap:10px;align-items:center;flex-wrap:nowrap;'>"
      "<span id='clksuntimescolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;align-self:center;"
      "background:" + htmlEscape(scHex) + ";border:1px solid #888;border-radius:3px;'></span>"
      "<select id='clksuntimescolor_select' style='flex:1;min-width:0;'>"
      + buildNamedColorOptions(clockSuntimesColor, false) +
      "</select><span>OR</span>"
      "<input type='text' id='clksuntimescolor_hex' value='" + htmlEscape(scHex) + "' placeholder='#FFA500' maxlength='7' style='width:120px;flex:0 0 auto;'>"
      "<input type='hidden' name='clksuntimescolor' id='clksuntimescolor_val' value='" + htmlEscape(scHex) + "'>"
      "</div></div>"
    );
  }

  // Night Mode checkbox
  server.sendContent(
    "<div class='form-row'><label>Night Mode:</label><div>"
    "<input type='checkbox' name='nightmodeenable' value='true'" +
    String(nightModeEnabled?" checked":"") + "> " +
    "<span style='color:#666;font-size:13px;margin-left:10px;'>Auto-dim between sunset and sunrise</span></div></div>"
  );

  // Collapsible Night Mode section (brightness, offsets, and night colors)
  {
    String nightDisplay = "none";
    String ntcHex = colorToHex(nightClockTimeColor);
    String ndcHex = colorToHex(nightClockDateColor);
    String nbHex  = colorToHex(nightClockBgColor);
    String nscHex = colorToHex(nightClockSuntimesColor);

    server.sendContent(
      "<details id='nightModeSection' style='border-color:#9C27B0;'>"
      "<summary style='background:#e1bee7;color:#6a1b9a;border-radius:8px 8px 0 0;'>"
      "&#x1F319; Night Mode Settings</summary>"
      "<div class='details-content' style='background:#fdf5ff;border-radius:0 0 8px 8px;'>"
    );

    // Night Brightness
    server.sendContent(
      "<div class='form-row'><label>Night Brightness:</label><div class='input-group'>"
      "<input type='range' name='nightbrightness' min='0' max='5' value='" + String(nightModeBrightness) +
      "' oninput='this.nextElementSibling.textContent=this.value'>"
      "<span>" + String(nightModeBrightness) + "</span><span style='margin-left:10px;color:#666;'>(0-5)</span></div></div>"
    );

    // Day Brightness
    server.sendContent(
      "<div class='form-row'><label>Night Awake Brightness:</label><div class='input-group'>"
      "<input type='range' name='daybrightness' min='0' max='5' value='" + String(nightModeWakeBrightness) +
      "' oninput='this.nextElementSibling.textContent=this.value'>"
      "<span>" + String(nightModeWakeBrightness) + "</span><span style='margin-left:10px;color:#666;'>(0-5) &mdash; brightness when touched</span></div></div>"
    );

    // Sunset Offset
    server.sendContent(
      "<div class='form-row'><label>Sunset Offset:</label><div class='input-group'>"
      "<input type='number' name='sunsetoffset' min='-360' max='360' value='" + String(sunsetOffset) + "' style='width:100px;'>" +
      "<span style='margin-left:10px;color:#666;'>minutes (+ after sunset, - before)</span></div></div>"
    );

    // Sunrise Offset
    server.sendContent(
      "<div class='form-row'><label>Sunrise Offset:</label><div class='input-group'>"
      "<input type='number' name='sunriseoffset' min='-360' max='360' value='" + String(sunriseOffset) + "' style='width:100px;'>" +
      "<span style='margin-left:10px;color:#666;'>minutes (+ after sunrise, - before)</span></div></div>"
    );

    // Night clock color subheading
    server.sendContent(
      "<h4 style='color:#6a1b9a;margin:16px 0 8px 0;border-top:1px solid #d4a6e8;padding-top:12px;'>"
      "Night Clock Colors</h4>"
      "<p style='color:#666;font-size:13px;margin:0 0 12px 0;'>"
      "These colors override the main clock palette while Night Mode is active. "
      "Tip: red-on-black is easy on dark-adapted eyes.</p>"
    );

    // Night Time Color
    server.sendContent(
      "<div class='form-row'><label>Night Time Color:</label>"
      "<div class='color-input-group' style='display:flex;gap:10px;align-items:center;flex-wrap:nowrap;'>"
      "<span id='ntimecolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
      "align-self:center;background:" + htmlEscape(ntcHex) + ";border:1px solid #888;border-radius:3px;'></span>"
      "<select id='ntimecolor_select' style='flex:1;min-width:0;'>"
      + buildNamedColorOptions(nightClockTimeColor, false) +
      "</select><span>OR</span>"
      "<input type='text' id='ntimecolor_hex' value='" + htmlEscape(ntcHex) + "' placeholder='#FF0000' maxlength='7' style='width:120px;flex:0 0 auto;'>"
      "<input type='hidden' name='nighttimecolor' id='ntimecolor_val' value='" + htmlEscape(ntcHex) + "'>"
      "</div></div>"
    );

    // Night Date Color
    server.sendContent(
      "<div class='form-row'><label>Night Date Color:</label>"
      "<div class='color-input-group' style='display:flex;gap:10px;align-items:center;flex-wrap:nowrap;'>"
      "<span id='ndatecolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
      "align-self:center;background:" + htmlEscape(ndcHex) + ";border:1px solid #888;border-radius:3px;'></span>"
      "<select id='ndatecolor_select' style='flex:1;min-width:0;'>"
      + buildNamedColorOptions(nightClockDateColor, false) +
      "</select><span>OR</span>"
      "<input type='text' id='ndatecolor_hex' value='" + htmlEscape(ndcHex) + "' placeholder='#FF0000' maxlength='7' style='width:120px;flex:0 0 auto;'>"
      "<input type='hidden' name='nightdatecolor' id='ndatecolor_val' value='" + htmlEscape(ndcHex) + "'>"
      "</div></div>"
    );

    // Night Background Color
    server.sendContent(
      "<div class='form-row'><label>Night BG Color:</label>"
      "<div class='color-input-group' style='display:flex;gap:10px;align-items:center;flex-wrap:nowrap;'>"
      "<span id='nbgcolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
      "align-self:center;background:" + htmlEscape(nbHex) + ";border:1px solid #888;border-radius:3px;'></span>"
      "<select id='nbgcolor_select' style='flex:1;min-width:0;'>"
      + buildNamedColorOptions(nightClockBgColor, true) +
      "</select><span>OR</span>"
      "<input type='text' id='nbgcolor_hex' value='" + htmlEscape(nbHex) + "' placeholder='#000000' maxlength='7' style='width:120px;flex:0 0 auto;'>"
      "<input type='hidden' name='nightbgcolor' id='nbgcolor_val' value='" + htmlEscape(nbHex) + "'>"
      "</div></div>"
    );

    // Night Suntimes Color
    server.sendContent(
      "<div class='form-row'><label>Night Suntimes Color:</label>"
      "<div class='color-input-group' style='display:flex;gap:10px;align-items:center;flex-wrap:nowrap;'>"
      "<span id='nsuntimescolor_swatch' style='display:inline-block;width:22px;height:22px;flex:0 0 22px;"
      "align-self:center;background:" + htmlEscape(nscHex) + ";border:1px solid #888;border-radius:3px;'></span>"
      "<select id='nsuntimescolor_select' style='flex:1;min-width:0;'>"
      + buildNamedColorOptions(nightClockSuntimesColor, false) +
      "</select><span>OR</span>"
      "<input type='text' id='nsuntimescolor_hex' value='" + htmlEscape(nscHex) + "' placeholder='#FF0000' maxlength='7' style='width:120px;flex:0 0 auto;'>"
      "<input type='hidden' name='nightsuntimescolor' id='nsuntimescolor_val' value='" + htmlEscape(nscHex) + "'>"
      "</div></div>"
      "</div>" // end details-content
      "</details>" // end nightModeSection
    );
  }

  // Color dropdown ↔ hex field sync
  server.sendContent(
    "<script>"
    "function bindColorPair(selId, hexId, hiddenId, swatchId){"
    "var sel=document.getElementById(selId);var hex=document.getElementById(hexId);var hid=document.getElementById(hiddenId);"
    "var sw=swatchId?document.getElementById(swatchId):null;"
    "if(!sel||!hex||!hid) return;"
    "function updateSwatch(c){if(sw&&c)sw.style.background=c;}"
    "function applyFromSelect(){var opt=sel.options[sel.selectedIndex];if(!opt) return;var v=sel.value||'';"
    "if(v===''){hid.value=hex.value;updateSwatch(hid.value);return;}var hx=opt.getAttribute('data-hex');if(hx){hex.value=hx;}hid.value=v;updateSwatch(v);}"
    "function applyFromHex(){var v=(hex.value||'').trim();hid.value=v;if(v.length>0){sel.value='';}updateSwatch(v);}"
    "sel.addEventListener('change', applyFromSelect);hex.addEventListener('input', applyFromHex);applyFromSelect();"
    "}"
    "bindColorPair('timecolor_select','timecolor_hex','timecolor_val','timecolor_swatch');"
    "bindColorPair('datecolor_select','datecolor_hex','datecolor_val','datecolor_swatch');"
    "bindColorPair('bgcolor_select','bgcolor_hex','bgcolor_val','clkbgcolor_swatch');"
    "bindColorPair('clksuntimescolor_select','clksuntimescolor_hex','clksuntimescolor_val','clksuntimescolor_swatch');"
    "bindColorPair('ntimecolor_select','ntimecolor_hex','ntimecolor_val','ntimecolor_swatch');"
    "bindColorPair('ndatecolor_select','ndatecolor_hex','ndatecolor_val','ndatecolor_swatch');"
    "bindColorPair('nbgcolor_select','nbgcolor_hex','nbgcolor_val','nbgcolor_swatch');"
    "bindColorPair('nsuntimescolor_select','nsuntimescolor_hex','nsuntimescolor_val','nsuntimescolor_swatch');"
    "</script>");

  // Submit
  server.sendContent(
    "<div style='text-align:center;margin:30px 0;'>"
    "<input type='submit' class='btn' value='💾 Save Clock Configuration'></div>"
    "</form></div>"
  );

  // ========== API STRING PREVIEW ==========
  server.sendContent(
    "<details id='clkApiPreview'>"
    "<summary>📋 API String Preview</summary>"
    "<div class='details-content'>"
    "<p style='margin:0 0 12px;font-size:0.85em;color:#888;'>"
    "Updates live as you change settings above. Copy for use in Hubitat Rule Machine, HTTP requests, etc."
    "</p>"

    "<label style='font-weight:bold;display:block;margin-bottom:4px;'>JSON Body (POST /clockconfig)</label>"
    "<div style='display:flex;gap:8px;align-items:flex-start;margin-bottom:14px;'>"
    "<textarea id='clk_json_preview' readonly rows='5' "
    "style='flex:1;font-family:monospace;font-size:0.82em;resize:vertical;background:#f9f9f9;'></textarea>"
    "<button type='button' onclick='clkCopyPreview(\"clk_json_preview\",this)' class='btn' "
    "style='white-space:nowrap;align-self:flex-start;'>&#128203; Copy</button>"
    "</div>"

    "<label style='font-weight:bold;display:block;margin-bottom:4px;'>GET Query String</label>"
    "<div style='display:flex;gap:8px;align-items:flex-start;'>"
    "<textarea id='clk_get_preview' readonly rows='3' "
    "style='flex:1;font-family:monospace;font-size:0.82em;resize:vertical;background:#f9f9f9;'></textarea>"
    "<button type='button' onclick='clkCopyPreview(\"clk_get_preview\",this)' class='btn' "
    "style='white-space:nowrap;align-self:flex-start;'>&#128203; Copy</button>"
    "</div>"
    "</div>"  // end details-content
    "</details>"

    "<script>"
    "function clkPreviewUpdate(){"
      "var form=document.querySelector('form[action=\"/clockconfig\"]');"
      "if(!form)return;"
      "var fv=function(nm){var e=form.querySelector('[name='+nm+']');return e?e.value:'';};"
      "var fc=function(nm){var e=form.querySelector('[name='+nm+']');return !!(e&&e.checked);};"
      "var ni=function(v,d){var x=parseInt(v,10);return isNaN(x)?d:x;};"
      "var hv=function(id){var e=document.getElementById(id);return e?e.value:'';};"

      "var obj={"
        "enabled:fc('enabled'),"
        "timeformat:fv('timeformat'),"
        "dateformat:fv('dateformat'),"
        "timefont:ni(fv('timefont'),60),"
        "datefont:ni(fv('datefont'),20),"
        "timecolor:hv('timecolor_val'),"
        "datecolor:hv('datecolor_val'),"
        "bgcolor:hv('bgcolor_val'),"
        "clksuntimescolor:hv('clksuntimescolor_val'),"
        "brightness:ni(fv('brightness'),5),"
        "rotation:ni(fv('rotation'),0),"
        "dimlevel:ni(fv('dimlevel'),2),"
        "timeout:ni(fv('timeout'),0),"
        "clksuntimesenabled:fc('clksuntimesenabled'),"
        "nightmodeenable:fc('nightmodeenable'),"
        "nightbrightness:ni(fv('nightbrightness'),3),"
        "daybrightness:ni(fv('daybrightness'),4),"
        "sunsetoffset:ni(fv('sunsetoffset'),0),"
        "sunriseoffset:ni(fv('sunriseoffset'),0),"
        "nighttimecolor:hv('ntimecolor_val'),"
        "nightdatecolor:hv('ndatecolor_val'),"
        "nightbgcolor:hv('nbgcolor_val'),"
        "nightsuntimescolor:hv('nsuntimescolor_val')"
      "};"

      "var jp=document.getElementById('clk_json_preview');"
      "if(jp)jp.value=JSON.stringify(obj);"

      "var p=[];"
      "p.push('enabled='+obj.enabled);"
      "p.push('timeformat='+encodeURIComponent(obj.timeformat));"
      "p.push('dateformat='+encodeURIComponent(obj.dateformat));"
      "p.push('timefont='+obj.timefont);"
      "p.push('datefont='+obj.datefont);"
      "p.push('timecolor='+encodeURIComponent(obj.timecolor));"
      "p.push('datecolor='+encodeURIComponent(obj.datecolor));"
      "p.push('bgcolor='+encodeURIComponent(obj.bgcolor));"
      "p.push('clksuntimescolor='+encodeURIComponent(obj.clksuntimescolor));"
      "p.push('brightness='+obj.brightness);"
      "p.push('rotation='+obj.rotation);"
      "p.push('dimlevel='+obj.dimlevel);"
      "p.push('timeout='+obj.timeout);"
      "p.push('clksuntimesenabled='+obj.clksuntimesenabled);"
      "p.push('nightmodeenable='+obj.nightmodeenable);"
      "p.push('nightbrightness='+obj.nightbrightness);"
      "p.push('daybrightness='+obj.daybrightness);"
      "p.push('sunsetoffset='+obj.sunsetoffset);"
      "p.push('sunriseoffset='+obj.sunriseoffset);"
      "p.push('nighttimecolor='+encodeURIComponent(obj.nighttimecolor));"
      "p.push('nightdatecolor='+encodeURIComponent(obj.nightdatecolor));"
      "p.push('nightbgcolor='+encodeURIComponent(obj.nightbgcolor));"
      "p.push('nightsuntimescolor='+encodeURIComponent(obj.nightsuntimescolor));"
      "var gp=document.getElementById('clk_get_preview');"
      "if(gp)gp.value='/clockconfig?'+p.join('&');"
    "}"

    "function clkCopyPreview(id,btn){"
      "var ta=document.getElementById(id);"
      "if(!ta)return;"
      "var done=function(){"
        "var o=btn.textContent;"
        "btn.textContent='\\u2705 Copied!';"
        "setTimeout(function(){btn.textContent=o;},1500);"
      "};"
      "if(navigator.clipboard){navigator.clipboard.writeText(ta.value).then(done).catch(function(){"
        "ta.select();document.execCommand('copy');done();"
      "});}else{ta.select();document.execCommand('copy');done();}"
    "}"

    "(function(){"
      "var form=document.querySelector('form[action=\"/clockconfig\"]');"
      "if(!form)return;"
      "var upd=function(){setTimeout(clkPreviewUpdate,0);};"
      "form.addEventListener('input',upd);"
      "form.addEventListener('change',upd);"
      "clkPreviewUpdate();"
    "})();"
    "</script>"
    "<script>"
    "(function(){"
      "var d=document.getElementById('clkApiPreview');"
      "if(!d)return;"
      "try{if(localStorage.getItem('clkApiPreviewOpen')==='1')d.setAttribute('open','open');}catch(e){}"
      "d.addEventListener('toggle',function(){try{localStorage.setItem('clkApiPreviewOpen',d.open?'1':'0');}catch(e){}});"
    "})();"
    "</script>"
  );

  // Footer
  server.sendContent(
    ""
    "</body></html>"
  );
  server.sendContent("");
}


//=============================================================
// WEATHER PAGE - With back to home link
//=============================================================
void handleWeatherPage() {
  messageActive = false;
  messageExpirationTime = 0;
  currentScreen = SCREEN_WEATHER;
  displayWeather();
  beginHtmlPage("Weather", "/weather");
  server.sendContent("<p>Weather display page - redirect to weather screen on device</p>");
  server.sendContent("");
  endHtmlPage();
}

//=============================================================
// CALENDAR PAGE - With back-to-home link
//=============================================================
void handleCalendarPage() {
  messageActive = false;
  messageExpirationTime = 0;
  currentScreen = SCREEN_CALENDAR;
  displayCalendar();
  beginHtmlPage("Calendar", "/calendar");
  server.sendContent("<p>Calendar display page - redirect to calendar screen on device</p>");
  server.sendContent("");
  endHtmlPage();
}

//=============================================================
// ASTRO PAGE - Forces Sun page, resets to today
//=============================================================
void handleAstroPage() {
  messageActive = false;
  messageExpirationTime = 0;
  astroShowMoon = false;   // always open on Sun page
  changeScreen(SCREEN_ASTRO);
  beginHtmlPage("Astro Times", "/astro");
  server.sendContent("<p>Astro Times display page - showing Sun screen on device</p>");
  server.sendContent("");
  endHtmlPage();
}

//=============================================================
// CLOCK START PAGE - With back-to-home link
//=============================================handleOTAUpdateForm================
void handleClockPage() {
  messageActive = false;
  messageExpirationTime = 0;
  currentScreen = SCREEN_CLOCK;
  showClock = true;  // Enable clock mode
  screensaverActive = false;
  drawClock();  // Call the actual display function

  beginHtmlPage("Clock", "/clock");
  server.sendContent("<p>Clock started - display showing on device</p>");
  server.sendContent("");
  endHtmlPage();
}

// //=============================================================
// // SCHEDULES PAGE - With back to home link
// //=============================================================
void handleSchedulerConfigPage() {
  beginHtmlPage("Scheduler Configuration", "/schedules");

  if (!sunTimesValid) {
    server.sendContent(
      "<div style='background:#fff3cd;padding:15px;border:2px solid #ffc107;margin:10px 0;border-radius:4px;'>"
      "⚠️ <strong>Sun times not available.</strong> Fetch weather to enable sunrise/sunset schedules."
      "</div>"
    );
  }

  server.sendContent(
    "<form method='POST' action='/schedules'>"
    "<table style='width:100%;border-collapse:collapse;margin:20px 0;background:#fff;'>"
    "<tr style='background:#4CAF50;color:white;'>"
    "<th style='padding:12px;border:1px solid #ddd;'>Enabled</th>"
    "<th style='padding:12px;border:1px solid #ddd;'>Mode</th>"
    "<th style='padding:12px;border:1px solid #ddd;'>Time / Ref</th>"
    "<th style='padding:12px;border:1px solid #ddd;'>Offset (min)</th>"
    "<th style='padding:12px;border:1px solid #ddd;'>Action</th>"
    "<th style='padding:12px;border:1px solid #ddd;'>Details</th>"
      "</tr>"
  );

  for (int i = 0; i < MAX_SCHEDULES; i++) {
    const String prefix = "sched" + String(i) + "_";

    String row;
    row.reserve(1400);

    row += "<tr>";

    // Enabled
    row += "<td style='padding:8px;border:1px solid #ddd;text-align:center;'>";
    row += "<input type='checkbox' name='" + prefix + "enabled'";
    if (schedules[i].enabled) row += " checked";
    row += ">";
    row += "</td>";

    // Mode
    row += "<td style='padding:8px;border:1px solid #ddd;'>";
    row += "<select name='" + prefix + "mode'>";
    row += "<option value='absolute'";
    if (schedules[i].mode == "absolute") row += " selected";
    row += ">Absolute</option>";
    row += "<option value='relative'";
    if (schedules[i].mode == "relative") row += " selected";
    row += ">Relative</option>";
    row += "</select>";
    row += "</td>";

    // Time / Reference
    row += "<td style='padding:8px;border:1px solid #ddd;'>";
    row += "<input type='number' name='" + prefix + "hour' min='0' max='23' value='" + String(schedules[i].hour) +
    "' style='width:50px;'> : ";
    row += "<input type='number' name='" + prefix + "minute' min='0' max='59' value='" + String(schedules[i].minute) +
    "' style='width:50px;'><br>";
    row += "<select name='" + prefix + "reference'>";
    row += "<option value='sunrise'";
    if (schedules[i].reference == "sunrise") row += " selected";
    row += ">Sunrise</option>";
    row += "<option value='sunset'";
    if (schedules[i].reference == "sunset") row += " selected";
    row += ">Sunset</option>";
    row += "</select>";
    row += "</td>";

    // Offset
    row += "<td style='padding:8px;border:1px solid #ddd;text-align:center;'>";
    row += "<input type='number' name='" + prefix + "offset' min='-120' max='120' value='" + String(schedules[i].offset) +
    "' style='width:60px;'>";
    row += "</td>";

    // Action
    row += "<td style='padding:8px;border:1px solid #ddd;'>";
    row += "<select name='" + prefix + "action'>";
    row += "<option value='brightness'";
    if (schedules[i].action == "brightness") row += " selected";
    row += ">Brightness</option>";
    row += "<option value='clock'";
    if (schedules[i].action == "clock") row += " selected";
    row += ">Show Clock</option>";
    row += "<option value='weather'";
    if (schedules[i].action == "weather") row += " selected";
    row += ">Show Weather</option>";
    row += "<option value='calendar'";
    if (schedules[i].action == "calendar") row += " selected";
    row += ">Show Calendar</option>";
    row += "<option value='message'";
    if (schedules[i].action == "message") row += " selected";
    row += ">Message</option>";
    row += "<option value='reboot'";
    if (schedules[i].action == "reboot") row += " selected";
    row += ">Reboot</option>";
    row += "</select>";
    row += "</td>";

    // Details
    row += "<td style='padding:8px;border:1px solid #ddd;'>";
    row += "<span class='bright-detail-" + String(i) + "' style='display:" + String(schedules[i].action == "reboot" ? "none" : "inline") + ";'>";
    row += "Brightness: <input type='number' name='" + prefix + "brightness' min='0' max='5' value='" + String(schedules[i].brightness) +
    "' placeholder='Brightness' style='width:80px;'><br>";
    row += "</span>";

    // IMPORTANT: escape for attribute
    row += "<span class='msg-detail-" + String(i) + "' style='display:" + String(schedules[i].action == "message" ? "inline" : "none") + ";'>";
    row += "Message: <input type='text' name='" + prefix + "message' value='";
    row += htmlEscape(schedules[i].message);
    row += "' placeholder='Message' style='width:140px;'><br>";

    // Msg profile selector (only shown when action=message)
    row += "Profile: <select name='" + prefix + "msgprofile' style='width:120px;margin-top:4px;'>";
    row += "<option value='-1'" + String(schedules[i].msgProfileIdx == -1 ? " selected" : "") + ">None</option>";
    for (int pi = 0; pi < MAX_MSG_PROFILES; pi++) {
      row += "<option value='" + String(pi) + "'" + String(schedules[i].msgProfileIdx == pi ? " selected" : "") + ">";
      row += String(pi);
      if (msgProfiles[pi].saved) row += " ✔";
      row += "</option>";
    }
    row += "</select>";
    row += "</span>";

    row += "</td>";

    row += "</tr>";

    server.sendContent(row);
  }

  // JS to show/hide message details based on action select
  server.sendContent(
    "</table>"
    "<script>"
    "(function(){"
    "var rows=" + String(MAX_SCHEDULES) + ";"
    "for(var i=0;i<rows;i++){"
    "(function(idx){"
    "var sel=document.querySelector('[name=\"sched'+idx+'_action\"]');"
    "if(!sel)return;"
    "function toggle(){"
    "var isMsg=sel.value==='message';"
    "var isReboot=sel.value==='reboot';"
    "document.querySelectorAll('.msg-detail-'+idx).forEach(function(s){s.style.display=isMsg?'inline':'none';});"
    "document.querySelectorAll('.bright-detail-'+idx).forEach(function(s){s.style.display=isReboot?'none':'inline';});"
    "}"
    "sel.addEventListener('change',toggle);"
    "toggle();"
    "})(i);"
    "}"
    "})();"
    "</script>"
    "<button type='submit' class='btn'>💾 Save Schedules</button>"
    "</form>"
    ""
  );

  endHtmlPage();
}

//=============================================================
// WEB LOG PAGE - With back to home link
//=============================================================
// Note: The actual web log handler is in WebDebugLog.cpp
// This is just a placeholder for navigation consistency

//=============================================================
// OTA PASSWORD PAGE
//=============================================================
void handleOTAPasswordPage() {
  beginHtmlPage("OTA Password Configuration", "/otapassword");

  server.sendContent(
    "<div class='info-box' style='background:#fff3cd;border-left:4px solid #ffc107;'>"
    "⚠️ <strong>Security Note:</strong> Choose a strong password to protect against unauthorized firmware updates."
    "</div>"
  );

  server.sendContent(
    "<form method='POST' action='/otapassword'>"
    "<div class='status-section'>"
    "<h2>Change OTA Password</h2>"
  );

  server.sendContent(
    "<label>Current Password:</label>"
    "<input type='password' name='currentpassword' placeholder='Enter current password' required><br>"
  );

  server.sendContent(
    "<label>New Password:</label>"
    "<input type='password' name='newpassword' placeholder='Enter new password' required><br>"
  );

  server.sendContent(
    "<label>Confirm New Password:</label>"
    "<input type='password' name='confirmpassword' placeholder='Confirm new password' required><br>"
  );

  server.sendContent(
    "<button type='submit' class='btn'>🔐 Update Password</button>"
    "</div></form>"
  );

  server.sendContent(
    "<div class='status-section'>"
    "<h2>Current Security Status</h2>"
    "<p><strong>OTA Password Set:</strong> " + String(otaPassword.length() > 0 ? "Yes" : "No") + "</p>" +
    "<p><strong>Password Length:</strong> " + String(otaPassword.length()) + " characters</p>" +
    "<p><strong>Failed Attempts:</strong> " + String(failedOTAAttempts) + " / " + String(MAX_OTA_ATTEMPTS) + "</p>"
  );

  if (failedOTAAttempts >= MAX_OTA_ATTEMPTS) {
    ulong remaining = (OTA_LOCKOUT_TIME - (millis() - lastFailedOTAAttempt)) / 1000;
    if (remaining > 0) {
      server.sendContent(
        "<p style='color:#f44336;'><strong>⚠️ LOCKED OUT:</strong> " +
        String(remaining) + " seconds remaining</p>"
      );
    }
  }

  server.sendContent("</div>");
  server.sendContent("");

  endHtmlPage();
}

//=============================================================
// RESET SETTINGS PAGE - With back to home link
//=============================================================
void handleResetSettingsPage() {
  beginHtmlPage("Reset Settings", "/resetsettings");

  server.sendContent(
    "<div class='status-section'>"
    "<h2>Reset Device Settings</h2>"
    "<p>⚠️ <strong>WARNING:</strong> This action will:</p>"
    "<ul>"
    "<li>Erase all saved configuration</li>"
    "<li>Reset to factory defaults</li>"
    "<li>Reboot the device</li>"
    "</ul>"
    "<form method='POST' action='/resetsettings'>"
    "<label style='display:flex;align-items:center;gap:8px;margin:20px 0;'>"
    "<input type='checkbox' name='confirm' value='true' required style='width:auto;'>"
    "I understand this will erase all settings"
    "</label>"
    "<label style='display:flex;align-items:center;gap:8px;margin-bottom:20px;'>"
    "<input type='checkbox' name='keepprofiles' value='true' style='width:auto;'>"
    "Keep message profiles"
    "</label>"
    "<button type='submit' class='btn' style='background:#f44336;'>⚠️ Reset All Settings</button>"
    "</form>"
    "</div>"
  );

  server.sendContent(
    "<div class='status-section'>"
    "<h2>Reboot Device</h2>"
    "<p>This will reboot the device immediately <strong>without</strong> erasing settings or message profiles.</p>"
    "<form method='GET' action='/reboot'>"
    "<button type='submit' class='btn btn-secondary'>🔄 Reboot</button>"
    "</form>"
    "</div>"
  );
  server.sendContent("");

  endHtmlPage();
}

//=============================================================
// OTA UPDATE PAGE - With back to home link
// (The actual form handler is complex, this adds back navigation)
//=============================================================
// Note: The main OTA update handler (handleOTAUpload / handleOTAUpdateForm)
// is in AdminHandlers.ino, not HelpFunctions.cpp.
// This just ensures navigation consistency

//=============================================================
// Handle Time Info Endpoint
//=============================================================
void handleTimeInfo() {
  //System time
  struct tm timeinfo;
  bool sysOk = getLocalTime(&timeinfo);
  char sysBuf[32] = "unavailable";
  if (sysOk) strftime(sysBuf, sizeof(sysBuf), "%Y-%m-%d %H:%M:%S", &timeinfo);

  //RTC
  bool rtcPresent = RTC_IsPresent();
  bool rtcValid   = RTC_IsValid();
  char rtcBuf[32] = "unavailable";
  struct tm rtcTime = {};
  if (rtcPresent && RTC_Read(rtcTime))
    strftime(rtcBuf, sizeof(rtcBuf), "%Y-%m-%d %H:%M:%S", &rtcTime);

  const char* battStatus = !rtcPresent ? "unknown (chip not found)"
                         :  rtcValid   ? "OK  (time is valid)"
                                       : "MISSING or DEAD  (VL flag set — time was lost)";

  String resp;
  resp += "System time : " + String(sysBuf)    + "\n";
  resp += "RTC present : " + String(rtcPresent ? "yes" : "no") + "\n";
  resp += "RTC battery : " + String(battStatus) + "\n";
  resp += "RTC time    : " + String(rtcBuf)     + "\n";
  server.send(200, "text/plain", resp);
}

//=============================================================
// Handle Status JSON Endpoint
// Returns device status as JSON for API access
//=============================================================
void handleStatusJson() {
  String json = "{";
  json += "\"deviceName\":\"" + deviceName + "\",";
  json += "\"deviceID\":\"" + deviceID + "\",";
  json += "\"messageCount\":" + String(messageCount) + ",";
  json += "\"clockEnabled\":" + String(clockEnabled ? "true" : "false") + ",";
  json += "\"uptime\":" + String(millis() / 1000) + ",";
  json += "\"freeHeap\":" + String(ESP.getFreeHeap());
  json += "}";

  server.send(200, "application/json", json);
}

//=============================================================
// Handle OTA Update Form Display
//=============================================================
void handleOTAUpdateForm() {
  // Let the heap allocator use PSRAM for large Strings automatically
  // No code changes needed! Just ensure initPSRAM() was called in setup()
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset='UTF-8'>
    <title>OTA Update - )rawliteral" + deviceName + R"rawliteral(</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <style>.nav-links{margin:10px 0 14px
    0;display:flex;flex-direction:column;gap:10px;}.nav-row{display:grid;gap:10px;}.nav-row.row1{grid-template-columns:repeat(7,
    minmax(0,1fr));}.nav-row.row2{grid-template-columns:repeat(6,minmax(0,1fr));}.nav-links
    a{display:block;text-decoration:none;color:#1a73e8;padding:5px 8px;border-radius:6px;background:#fff;border:1px solid
    #ddd;text-align:center;font-size:12.5px;white-space:nowrap;}.nav-links a:hover{background:#e8f0fe;}.nav-links
    a.active{border-color:#4CAF50;color:#0b6b2a;background:#eef8f0;font-weight:bold;}
      * { box-sizing: border-box; }
      body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        max-width: 900px;
        margin: 0 auto;
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
      }
      .container {
        background: white;
        padding: 40px;
        border-radius: 8px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      }
      h1 {
        color: #333;
        margin-top: 0;
        font-size: 28px;
        border-bottom: 3px solid #667eea;
        padding-bottom: 15px;
      }
      .info-bar {
        background: #fff;
        padding: 12px;
        border-radius: 6px;
        margin: 12px 0;
        border: 1px solid #ddd;
      }
      input[type='password'], input[type='file'] {
        width: 100%;
        padding: 12px 15px;
        margin: 10px 0;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 15px;
        transition: border-color 0.3s;
      }
      input[type='password']:focus, input[type='file']:focus {
        outline: none;
        border-color: #667eea;
      }
      label {
        font-weight: 600;
        color: #333;
        display: block;
        margin-top: 15px;
      }
      button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px 30px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        width: 100%;
        margin-top: 20px;
        transition: transform 0.2s, box-shadow 0.2s;
      }
      button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
      }
      button:active {
        transform: translateY(0);
      }
      .warning {
        background: #fff3cd;
        border: 2px solid #ffc107;
        padding: 15px;
        border-radius: 8px;
        margin: 20px 0;
        color: #856404;
      }
      .warning strong {
        display: block;
        margin-bottom: 8px;
        font-size: 16px;
      }
      .info {
        background: #d1ecf1;
        border: 2px solid #17a2b8;
        padding: 15px;
        border-radius: 8px;
        margin: 20px 0;
        color: #0c5460;
      }
      .info strong {
        display: block;
        margin-bottom: 10px;
        font-size: 16px;
      }
      .info ol {
        margin: 10px 0;
        padding-left: 20px;
      }
      .info li {
        margin: 5px 0;
      }
      #progress {
        display: none;
        margin: 30px 0;
      }
      progress {
        width: 100%;
        height: 35px;
        border-radius: 8px;
        overflow: hidden;
      }
      progress::-webkit-progress-bar {
        background-color: #e9ecef;
        border-radius: 8px;
      }
      progress::-webkit-progress-value {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        border-radius: 8px;
        transition: width 0.3s;
      }
      progress::-moz-progress-bar {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        border-radius: 8px;
      }
      .status {
        margin-top: 15px;
        font-weight: bold;
        text-align: center;
        font-size: 18px;
        padding: 10px;
        border-radius: 8px;
        background: #f8f9fa;
      }
      .back-link {
        display: inline-block;
        margin-top: 20px;
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
      }
      .back-link:hover {
        text-decoration: underline;
      }
    </style>
  </head>
  <body>
<div class='nav-links'><div class='nav-row row1'><a href='/'>🏠 Home</a><a href='/status'>📊 Status</a><a href='/weather'>🌤️
Weather</a><a href='/calendar'>📅 Calendar</a><a href='/astro'>🌙 Astro</a><a href='/clock'>🕒 Clock</a><a href='/clockconfig'>🕐 Clock Config</a></div><div
class='nav-row row2'><a href='/schedules'>⏰ Schedules</a><a href='/logs'>📋 Web Log</a><a class='active' href='/update'>⬆️ OTA
Update</a><a href='/otapassword'>🔐 OTA Password</a><a href='/resetsettings'>⚠️ Reset Settings</a></div></div><hr>
    <div class='container'>
      <h1>🔄 OTA Firmware Update</h1>

      <div class='info-bar'><strong>Device:</strong> )rawliteral" + deviceName + R"rawliteral( &nbsp; <strong>Version:</strong> )rawliteral" + String(Version) + R"rawliteral( &nbsp; <strong>Built:</strong> )rawliteral" + String(Timestamp) + R"rawliteral( &nbsp; <strong>IP:</strong> )rawliteral" + WiFi.localIP().toString() + wifiSignalHtml() + R"rawliteral(</div>

      <div class='warning'>
        <strong>⚠️ Important Warning</strong>
        Do not power off or disconnect the device during the update process! This could brick your device and require USB
        recovery.
      </div>

      <div class='info'>
        <strong>ℹ️ Update Instructions</strong>
        <ol>
          <li>Compile your sketch in Arduino IDE</li>
          <li>Export compiled binary (Sketch → Export Compiled Binary)</li>
          <li>Enter the OTA password below</li>
          <li>Select the .bin file from your sketch folder or "drag and drop" the .bin file</li>
          <li>Click "Upload Firmware" and wait for completion</li>
        </ol>
      </div>

      <form id='uploadForm' enctype='multipart/form-data'>
        <label for='password'>🔐 OTA Password:</label>
        <input type='password' name='password' id='password' required placeholder='Enter your OTA password' autocomplete='off'>

        <label for='file'>📁 Firmware File (.bin) - browse or "drag and drop":</label>
        <input type='file' name='file' id='file' accept='.bin' required>

        <button type='submit'>⬆️ Upload Firmware</button>
      </form>

      <div id='progress'>
        <progress id='progressBar' value='0' max='100'></progress>
        <div class='status' id='status'>Initializing upload...</div>
        <div style='display:flex;gap:12px;margin-top:14px;'>
          <button id='retryBtn' type='button' style='display:none;flex:1;background:linear-gradient(135deg,#e67e22 0%,#c0392b 100%);'>🔄 Retry Upload</button>
          <button id='changeBtn' type='button' style='display:none;flex:1;background:linear-gradient(135deg,#636e72 0%,#2d3436 100%);'>✏️ Change File / Password</button>
        </div>
      </div>

    </div>

    <script>
      // Held across attempts so Retry can reuse them without re-selecting
      var _pendingFile     = null;
      var _pendingPassword = null;

      function showError(msg) {
        document.getElementById('status').textContent = msg;
        document.getElementById('status').style.background = '#f8d7da';
        document.getElementById('status').style.color = '#721c24';
        document.getElementById('retryBtn').style.display = 'inline-block';
        document.getElementById('changeBtn').style.display = 'inline-block';
      }

      function doUpload(file, password) {
        document.getElementById('progress').style.display = 'block';
        document.getElementById('uploadForm').style.display = 'none';
        document.getElementById('retryBtn').style.display = 'none';
        document.getElementById('changeBtn').style.display = 'none';
        document.getElementById('progressBar').value = 0;
        document.getElementById('status').textContent = 'Initializing upload...';
        document.getElementById('status').style.background = '#f8f9fa';
        document.getElementById('status').style.color = '#333';

        var formData = new FormData();
        formData.append('password', password);
        formData.append('file', file);

        var xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', function(e) {
          if (e.lengthComputable) {
            var percentComplete = Math.round((e.loaded / e.total) * 100);
            document.getElementById('progressBar').value = percentComplete;
            document.getElementById('status').textContent = 'Uploading firmware: ' + percentComplete + '%';
            document.getElementById('status').style.background = '#d1ecf1';
            document.getElementById('status').style.color = '#0c5460';
          }
        });

        xhr.addEventListener('load', function() {
          if (xhr.status === 200) {
            document.getElementById('progressBar').value = 100;
            document.getElementById('status').textContent = '✓ Update successful! Device is rebooting...';
            document.getElementById('status').style.background = '#d4edda';
            document.getElementById('status').style.color = '#155724';

            setTimeout(function() {
              document.getElementById('status').textContent = '⏳ Waiting for device to reboot...';
              checkConnection();
            }, 5000);
          } else {
            var errorMsg = xhr.responseText || 'Unknown error';
            showError('✗ ' + errorMsg);
          }
        });

        xhr.addEventListener('error', function() {
          // A network error after 100% upload most likely means the device rebooted
          // successfully mid-response (the ESP32 resets before the HTTP reply fully
          // arrives, causing the browser to flag a connection drop as a network error).
          var progress = parseInt(document.getElementById('progressBar').value, 10);
          if (progress >= 100) {
            document.getElementById('progressBar').value = 100;
            document.getElementById('status').textContent = '✓ Update successful! Device is rebooting...';
            document.getElementById('status').style.background = '#d4edda';
            document.getElementById('status').style.color = '#155724';
            setTimeout(function() {
              document.getElementById('status').textContent = '⏳ Waiting for device to reboot...';
              checkConnection();
            }, 5000);
          } else {
            showError('✗ Network error during upload (upload was ' + progress + '% complete)');
          }
        });

        xhr.open('POST', '/doupdate', true);
        xhr.send(formData);
      }

      document.getElementById('uploadForm').addEventListener('submit', function(e) {
        e.preventDefault();

        var password = document.getElementById('password').value;
        var fileInput = document.getElementById('file');
        var file = fileInput.files[0];

        if (!file) {
          alert('Please select a firmware file');
          return;
        }

        if (!file.name.toLowerCase().endsWith('.bin')) {
          alert('Please select a valid .bin firmware file');
          return;
        }

        // Store for potential retry
        _pendingFile     = file;
        _pendingPassword = password;

        doUpload(file, password);
      });

      document.getElementById('retryBtn').addEventListener('click', function() {
        if (_pendingFile && _pendingPassword) {
          doUpload(_pendingFile, _pendingPassword);
        }
      });

      document.getElementById('changeBtn').addEventListener('click', function() {
        _pendingFile     = null;
        _pendingPassword = null;
        document.getElementById('retryBtn').style.display = 'none';
        document.getElementById('changeBtn').style.display = 'none';
        document.getElementById('progress').style.display = 'none';
        document.getElementById('uploadForm').style.display = 'block';
      });

      function checkConnection() {
        fetch('/')
          .then(function() {
            document.getElementById('status').textContent = '✓ Device is back online!';
            document.getElementById('status').style.background = '#d4edda';
            document.getElementById('status').style.color = '#155724';
            setTimeout(function() {
              window.location.href = '/';
            }, 2000);
          })
          .catch(function() {
            setTimeout(checkConnection, 2000);
          });
      }

      // Drag and drop support
      var fileInput = document.getElementById('file');
      var dropArea = fileInput;

      ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
      });

      function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
      }

      ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, function() {
          dropArea.style.borderColor = '#667eea';
          dropArea.style.background = '#f8f9fa';
        }, false);
      });

      ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, function() {
          dropArea.style.borderColor = '#ddd';
          dropArea.style.background = 'white';
        }, false);
      });

      dropArea.addEventListener('drop', function(e) {
        var dt = e.dataTransfer;
        var files = dt.files;
        fileInput.files = files;
      }, false);
    </script>
  </body>
  </html>
  )rawliteral";

  server.send(200, "text/html", html);
}
//=============================================================
// Handle Clock Configuration POST
//=============================================================
void handleClockConfig() {
  DEBUG_PRINTLN("\n=== Clock Config POST ===");

  // If the user submits any clock color fields, we treat that as a customization override
  // (i.e., stop auto-applying the theme palette based on clockDarkMode).
  bool anyClockColorChanged = false;
  bool isJson = false;

  //Check for JSON POST
  if (server.method() == HTTP_POST && server.hasArg("plain")) {
    String body = server.arg("plain");
    DEBUG_PRINTLN(body);

    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, body);

    if (!error) {
      isJson = true;
      DEBUG_PRINTLN("JSON parsed successfully");

      //Extract clock configuration from JSON
      if (doc.containsKey("timeformat")) {
        clockTimeFormat = doc["timeformat"].as<String>();
        DEBUG_PRINTF("  Time Format      : %s\n", clockTimeFormat.c_str());
      }
      if (doc.containsKey("dateformat")) {
        clockDateFormat = doc["dateformat"].as<String>();
        DEBUG_PRINTF("  Date Format      : %s\n", clockDateFormat.c_str());
      }

      int tempInt;
      if (getJSON_Int(doc, "timefont", tempInt, 6, 60, "  Time Font        ")) {
        tempInt = validateRobotoFontCode(tempInt);
        clockTimeFont = tempInt;
      }
      if (getJSON_Int(doc, "datefont", tempInt, 6, 60, "  Date Font        ")) {
        tempInt = validateRobotoFontCode(tempInt);
        clockDateFont = tempInt;
      }

      uint16_t tempColor;
      if (getJSON_Color(doc, "timecolor", tempColor, "  Time Color       ")) {
        clockTimeColor = tempColor;
        anyClockColorChanged = true;
      }
      if (getJSON_Color(doc, "datecolor", tempColor, "  Date Color       ")) {
        clockDateColor = tempColor;
        anyClockColorChanged = true;
      }
      if (getJSON_Color(doc, "bgcolor", tempColor, "  BG Color         ")) {
        clockBgColor = tempColor;
        anyClockColorChanged = true;
      }
      if (getJSON_Color(doc, "clksuntimescolor", tempColor, "  Suntimes Color   ")) {
        clockSuntimesColor = tempColor;
        anyClockColorChanged = true;
      }
      if (getJSON_Color(doc, "nighttimecolor",     tempColor, "  Night Time Color ")) nightClockTimeColor     = tempColor;
      if (getJSON_Color(doc, "nightdatecolor",     tempColor, "  Night Date Color ")) nightClockDateColor     = tempColor;
      if (getJSON_Color(doc, "nightbgcolor",       tempColor, "  Night BG Color   ")) nightClockBgColor       = tempColor;
      if (getJSON_Color(doc, "nightsuntimescolor", tempColor, "  Night Sun Color  ")) nightClockSuntimesColor = tempColor;

      if (getJSON_Int(doc,   "labelfont",          tempInt, 6, 60, "  Label Font       ")) labelFont           = tempInt;
      if (getJSON_Int(doc,   "msgnoticefont",      tempInt, 6, 60, "  Notice Font      ")) msgNoticeFont       = tempInt;
      if (getJSON_Int(doc,   "weathertempfnt",     tempInt, 6, 60, "  Wx Temp Font     ")) weatherTempFont     = tempInt;
      if (getJSON_Int(doc,   "weatherhumfnt",      tempInt, 6, 60, "  Wx Humid Font    ")) weatherHumidFont    = tempInt;
      if (getJSON_Int(doc,   "weatherpresfnt",     tempInt, 6, 60, "  Wx Pres Font     ")) weatherPressureFont = tempInt;

      if (getJSON_Color(doc, "labelcolor",         tempColor, "  Label Color      ")) labelColor      = tempColor;
      if (getJSON_Color(doc, "msgnoticecolor",     tempColor, "  Notice Color     ")) msgNoticeColor  = tempColor;

      if (getJSON_Int(doc,    "rotation",          tempInt, 0, 270, "  Rotation         ", "°")) {
        clockRotation = tempInt;
      }

      if (doc.containsKey("screensaverdim")) {
        screensaverDimValue = (uint8_t)constrain(doc["screensaverdim"].as<int>(), 0, 5);
        DEBUG_PRINTF("  Screensaver Dim  : %d\n", screensaverDimValue);
      }

      ulong tempTimeout;
      if (getJSON_ULong(doc, "screensavertimeout", tempTimeout, 0, 3600000, "  Screensaver TO   ", " ms")) {
        screensaverTimeout = tempTimeout;
      }

      uint8_t tempBrightness;
      if (getJSON_UInt(doc, "brightness", tempBrightness, 0, 5, "  Brightness       ")) {
        screenBrightness = tempBrightness;
      }

      if (getJSON_UInt(doc, "nightbrightness", tempBrightness, 0, 5, "  Night Brightness ")) {
        nightModeBrightness = tempBrightness;
      }
      if (getJSON_UInt(doc, "daybrightness", tempBrightness, 0, 5, "  Day Brightness   ")) {
        nightModeWakeBrightness = tempBrightness;
      }

      if (getJSON_Int(doc, "sunsetoffset", tempInt, -360, 360, "  Sunset Offset    ", " min")) {
        sunsetOffset = tempInt;
      }
      if (getJSON_Int(doc, "sunriseoffset", tempInt, -360, 360, "  Sunrise Offset   ", " min")) {
        sunriseOffset = tempInt;
      }

      //Boolean settings
      bool tempBool;
      if (getJSON_Bool(doc, "clockenable", tempBool, "  Clock Enabled    ")) {
        clockEnabled = tempBool;
      }
      if (getJSON_Bool(doc, "nightmodeenable", tempBool, "  Night Mode       ")) {
        nightModeEnabled = tempBool;
      }
      if (getJSON_Bool(doc, "clksuntimesenabled", tempBool, "  Suntimes Enabled ")) {
        clockSuntimesEnabled = tempBool;
      }
      ulong tempWake;
      if (getJSON_ULong(doc, "nightwakedur", tempWake, 1, 3600, "  Night Wake Dur   ", " sec")) {
        nightModeWakeDuration = tempWake * 1000;
      }
      bool tempCels;
      if (getJSON_Bool(doc, "tempcelsius", tempCels, "  Temp Celsius     ")) {
        tempCelsius = tempCels;
      }
    } else {
      DEBUG_PRINTLN("JSON parsing failed");
    }
  }

  //If NOT JSON, parse query/form parameters (GET or form POST)
  if (!isJson) {
    if (server.hasArg("timeformat")) clockTimeFormat = server.arg("timeformat");
    if (server.hasArg("dateformat")) clockDateFormat = server.arg("dateformat");
    if (server.hasArg("timefont")) clockTimeFont = validateRobotoFontCode(server.arg("timefont").toInt());
    if (server.hasArg("datefont")) clockDateFont = validateRobotoFontCode(server.arg("datefont").toInt());
    if (server.hasArg("timecolor")) {
      clockTimeColor = parseColor(server.arg("timecolor"));
      anyClockColorChanged = true;
    }
    if (server.hasArg("datecolor")) {
      clockDateColor = parseColor(server.arg("datecolor"));
      anyClockColorChanged = true;
    }
    if (server.hasArg("bgcolor")) {
      clockBgColor = parseColor(server.arg("bgcolor"));
      anyClockColorChanged = true;
    }
    if (server.hasArg("brightness")) screenBrightness = server.arg("brightness").toInt();
    if (server.hasArg("rotation")) clockRotation = server.arg("rotation").toInt();
    if (server.hasArg("dimlevel")) screensaverDimValue = (uint8_t)constrain(server.arg("dimlevel").toInt(), 0, 5);
    if (server.hasArg("timeout")) screensaverTimeout = server.arg("timeout").toInt() * 1000;
    if (server.hasArg("clksuntimescolor")) {
      clockSuntimesColor = parseColor(server.arg("clksuntimescolor"));
      anyClockColorChanged = true;
    }
    if (server.hasArg("nighttimecolor"))     nightClockTimeColor     = parseColor(server.arg("nighttimecolor"));
    if (server.hasArg("nightdatecolor"))     nightClockDateColor     = parseColor(server.arg("nightdatecolor"));
    if (server.hasArg("nightbgcolor"))       nightClockBgColor       = parseColor(server.arg("nightbgcolor"));
    if (server.hasArg("nightsuntimescolor")) nightClockSuntimesColor = parseColor(server.arg("nightsuntimescolor"));
    if (server.hasArg("labelfont"))          labelFont               = validateRobotoFontCode(server.arg("labelfont").toInt());
    if (server.hasArg("msgnoticefont"))      msgNoticeFont           = validateRobotoFontCode(server.arg("msgnoticefont").toInt());
    if (server.hasArg("weathertempfnt"))     weatherTempFont         = validateRobotoFontCode(server.arg("weathertempfnt").toInt());
    if (server.hasArg("weatherhumfnt"))      weatherHumidFont        = validateRobotoFontCode(server.arg("weatherhumfnt").toInt());
    if (server.hasArg("weatherpresfnt"))     weatherPressureFont     = validateRobotoFontCode(server.arg("weatherpresfnt").toInt());
    if (server.hasArg("labelcolor"))         labelColor              = parseColor(server.arg("labelcolor"));
    if (server.hasArg("msgnoticecolor"))     msgNoticeColor          = parseColor(server.arg("msgnoticecolor"));
    if (server.hasArg("nightbrightness"))    nightModeBrightness     = server.arg("nightbrightness").toInt();
    if (server.hasArg("daybrightness"))      nightModeWakeBrightness = server.arg("daybrightness").toInt();
    if (server.hasArg("sunsetoffset"))       sunsetOffset            = server.arg("sunsetoffset").toInt();
    if (server.hasArg("sunriseoffset"))      sunriseOffset           = server.arg("sunriseoffset").toInt();

    clockEnabled         = server.hasArg("enabled");
    nightModeEnabled     = server.hasArg("nightmodeenable");
    clockSuntimesEnabled = server.hasArg("clksuntimesenabled");
    if (server.hasArg("nightwakedur"))  nightModeWakeDuration = server.arg("nightwakedur").toInt() * 1000;
    if (server.hasArg("tempcelsius"))   tempCelsius           = server.arg("tempcelsius") != "false";
  }

  if (anyClockColorChanged) {
    clockColorsCustomized = true;
  }

  saveSettings();

  //Force an immediate night-mode evaluation so brightness/colors snap to the
  //correct state without waiting up to 60 seconds for the next scheduled check.
  lastNightModeCheck = 0;
  updateNightMode();

  //Apply the new settings immediately if we're on the clock screen
  if (currentScreen == SCREEN_CLOCK) {
    currentRotation = clockRotation;
    setBrightness(screenBrightness);
    drawClock();
    DEBUG_PRINTLN("Clock display updated with new settings");
  } else {
    DEBUG_PRINTLN("Settings saved - will apply when clock screen is shown");
  }

  server.sendHeader("Location", "/clockconfig");
  server.send(303, "text/plain", "Settings saved");
}

//=============================================================
// Location & Timezone Configuration  (/locationconfig)
//=============================================================

void handleLocationConfigPage() {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  sendHtmlHeader("Location Configuration", "/locationconfig");

  server.sendContent(
    "<h1>📍 Location Configuration</h1>"
    "<p>Set your location and timezone. These values are used for weather fetching, "
    "sunrise/sunset calculations, and NTP time synchronization. Changes take effect "
    "immediately and are saved to persistent storage.</p>"
  );

  // Build current-values form
  server.sendContent("<form method='POST' action='/locationconfig'>");
  server.sendContent(
    "<label for='location'>Display Name</label>"
    "<input type='text' id='location' name='location' maxlength='64' placeholder='e.g. San Diego, CA' style='max-width:340px;' value='"
  );
  server.sendContent(weatherLocation);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>Shown on the weather screen.</small>"
    "<label for='latitude'>Latitude</label>"
    "<input type='text' id='latitude' name='latitude' maxlength='12' placeholder='e.g. 32.7157' style='max-width:280px;' value='"
  );
  server.sendContent(weatherLatitude);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>Decimal degrees, positive = North, negative = South.</small>"
    "<label for='longitude'>Longitude</label>"
    "<input type='text' id='longitude' name='longitude' maxlength='13' placeholder='e.g. -117.1611' style='max-width:280px;' value='"
  );
  server.sendContent(weatherLongitude);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>Decimal degrees, positive = East, negative = West.</small>"
    "<label for='altitude'>Altitude (metres)</label>"
    "<input type='text' id='altitude' name='altitude' maxlength='8' placeholder='e.g. 45' style='max-width:160px;' value='"
  );
  server.sendContent(weatherAltitude);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>Elevation above sea level. Used to correct barometric pressure for the Zambretti forecast.</small>"
    "<label for='timezone'>IANA Timezone</label>"
    "<input type='text' id='timezone' name='timezone' maxlength='48' placeholder='e.g. America/Los_Angeles' style='max-width:340px;' value='"
  );
  server.sendContent(weatherTimezone);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>IANA identifier used for weather API calls. "
    "See <a href='https://en.wikipedia.org/wiki/List_of_tz_database_time_zones' target='_blank'>tz database</a>.</small>"
    "<label for='tzstring'>POSIX TZ String</label>"
    "<input type='text' id='tzstring' name='tzstring' maxlength='64' placeholder='e.g. PST8PDT,M3.2.0,M11.1.0' style='max-width:380px;' value='"
  );
  server.sendContent(weatherTzString);
  server.sendContent(
    "'><small style='display:block;margin:2px 0 12px 0;color:#666;font-size:12px;'>POSIX specification used by the ESP32 NTP library for DST handling. "
    "Find yours at <a href='https://github.com/nayarsystems/posix_tz_db/blob/master/zones.csv' target='_blank'>posix_tz_db</a>.</small>"
  );

  server.sendContent(
    "<br><div style='display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;'>"
    "<button type='submit' class='btn'>💾 Save Location</button>"
    "<a class='btn' style='background:#2196F3;color:#fff;text-decoration:none;padding:8px 16px;border-radius:4px;' "
    "href='/locationconfig'>↺ Discard Changes</a>"
    "</div>"
    "</form>"

    "<div style='background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px;margin-top:16px;'>"
    "<b>⚠️ After saving:</b> The new timezone takes effect immediately for NTP and astro calculations. "
    "The weather data will refresh on its normal schedule (or visit "
    "<a href='/weather'>/weather</a> to trigger a manual refresh)."
    "</div>"
  );

  sendHtmlFooter();
}

void handleLocationConfig() {
  DEBUG_PRINTLN("\n=== Location Config POST ===");

  bool changed = false;

  if (server.hasArg("location") && server.arg("location").length() > 0) {
    weatherLocation = server.arg("location");
    DEBUG_PRINTF("  Location   : %s\n", weatherLocation.c_str());
    changed = true;
  }
  if (server.hasArg("latitude") && server.arg("latitude").length() > 0) {
    weatherLatitude = server.arg("latitude");
    DEBUG_PRINTF("  Latitude   : %s\n", weatherLatitude.c_str());
    changed = true;
  }
  if (server.hasArg("longitude") && server.arg("longitude").length() > 0) {
    weatherLongitude = server.arg("longitude");
    DEBUG_PRINTF("  Longitude  : %s\n", weatherLongitude.c_str());
    changed = true;
  }
  if (server.hasArg("altitude")) {
    weatherAltitude = server.arg("altitude");
    if (weatherAltitude.length() == 0) weatherAltitude = "0";
    DEBUG_PRINTF("  Altitude   : %s m\n", weatherAltitude.c_str());
    changed = true;
  }
  if (server.hasArg("timezone") && server.arg("timezone").length() > 0) {
    weatherTimezone = server.arg("timezone");
    DEBUG_PRINTF("  Timezone   : %s\n", weatherTimezone.c_str());
    changed = true;
  }
  if (server.hasArg("tzstring") && server.arg("tzstring").length() > 0) {
    weatherTzString = server.arg("tzstring");
    DEBUG_PRINTF("  TZ String  : %s\n", weatherTzString.c_str());
    changed = true;
  }

  if (changed) {
    // Apply new TZ string immediately so NTP/RTC conversions are correct right away
    setenv("TZ", weatherTzString.c_str(), 1);
    tzset();

    saveSettings();
    DEBUG_PRINTLN("Location settings saved.");
  }

  server.sendHeader("Location", "/locationconfig");
  server.send(303, "text/plain", "Location saved");
}
