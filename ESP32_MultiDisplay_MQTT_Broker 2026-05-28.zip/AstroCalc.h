#pragma once
/*
  AstroCalc.h  –  Sun & Moon astronomical calculations
  Ported from WeekCalendar's SunMoonInfo.js (John Land, 2003–2005)
  and DayInfo.js into C++ for ESP32.

  Algorithm sources:
    Solar calculations  – NOAA / Jean Meeus "Astronomical Algorithms"
    Lunar calculations  – Jean Meeus "Astronomical Algorithms" ch. 45–46
*/
#ifndef ASTROCALC_H
#define ASTROCALC_H

#include <Arduino.h>
#include <math.h>

// -----------------------------------------------------------------------
// AstroData: all computed values for one calendar day
// -----------------------------------------------------------------------
struct AstroData {
  // --- Sun (all times in LOCAL decimal minutes from midnight) ---
  float sunriseMin;         // Sunrise
  float sunsetMin;          // Sunset
  float solarNoonMin;       // Solar noon
  float dayLengthMin;       // Daylight duration (minutes)

  float civilDawnMin;       // Civil dawn (morning)  – sun 6° below horizon
  float civilDuskMin;       // Civil dusk (evening)

  float nauticalDawnMin;    // Nautical dawn  – 12°
  float nauticalDuskMin;    // Nautical dusk

  float astroDawnMin;       // Astronomical dawn  – 18°
  float astroDuskMin;       // Astronomical dusk

  bool sunriseValid;        // false at extreme latitudes
  bool sunsetValid;
  bool civilValid;
  bool nauticalValid;
  bool astroValid;

  // --- Moon ---
  float moonriseHour;       // Local decimal hours; invalid when moonriseCode < 0
  float moonsetHour;        // Local decimal hours; invalid when moonsetCode  < 0
  int   moonriseCode;       // >=0 valid; -1 = no rise, moon was below horizon at midnight;
  int   moonsetCode;        //            -2 = no rise, moon was above horizon at midnight
  float phaseAngle;         // 0° = New Moon, 180° = Full Moon
  int   illuminationPct;    // 0–100
  String phaseName;         // e.g. "Waxing Crescent"

  bool isValid;
};

// -----------------------------------------------------------------------
// Compute AstroData for the given date / location / UTC-offset.
//
//   year, month (1-12), day (1-31)
//   latitude   – decimal degrees, positive = North
//   longitude  – decimal degrees, positive = East  (western USA → negative)
//   utcOffsetHours – e.g. -8 for PST, -7 for PDT (already includes DST)
// -----------------------------------------------------------------------
AstroData computeAstro(int year, int month, int day,
                       float latitude, float longitude,
                       float utcOffsetHours);

// Human-readable moon-phase name from a phase angle (0–360°)
String getMoonPhaseName(float phaseAngle);

// Format decimal day-minutes as "Xh Ym"
String formatDayLength(float totalMinutes);

#endif // ASTROCALC_H
