//=============================================================
// WeatherCalendar.ino  —  weather fetch/display, calendar,
//                          astro screen, and About screen
//=============================================================

static String astroFmtMin(float localMinutes) {
  // Clamp / normalise
  while (localMinutes <    0) localMinutes += 1440.0f;
  while (localMinutes >= 1440) localMinutes -= 1440.0f;

  struct tm t = {};
  t.tm_year = 70; t.tm_mon = 0; t.tm_mday = 1;
  t.tm_hour = (int)(localMinutes / 60) % 24;
  t.tm_min  = (int)localMinutes % 60;
  t.tm_sec  = 0;
  char buf[32];
  strftime(buf, sizeof(buf), clockTimeFormat.c_str(), &t);
  return String(buf);
}

static String astroFmtHour(float decimalHour) {
  return astroFmtMin(decimalHour * 60.0f);
}

void ensureAstroData() {
  time_t now_t = time(nullptr);
  if (now_t < 1000000L) return;   // NTP not yet synced

  struct tm localNow;
  localtime_r(&now_t, &localNow);

  int y = localNow.tm_year + 1900;
  int m = localNow.tm_mon + 1;
  int d = localNow.tm_mday;

  // Compute UTC offset portably: subtract UTC hour:min from local hour:min.
  // Both structs come from the same time_t so the difference is exact.
  struct tm utcNow;
  gmtime_r(&now_t, &utcNow);
  int diffMins = (localNow.tm_hour * 60 + localNow.tm_min)
               - (utcNow.tm_hour   * 60 + utcNow.tm_min);
  if (diffMins >  720) diffMins -= 1440;
  if (diffMins < -720) diffMins += 1440;
  float utcOffsetHours = diffMins / 60.0f;

  float lat = atof(weatherLatitude.c_str());
  float lon = atof(weatherLongitude.c_str());

  // Compute today if stale
  if (y != astroDataYear || m != astroDataMonth || d != astroDataDay) {
    cachedAstro    = computeAstro(y, m, d, lat, lon, utcOffsetHours);
    astroDataYear  = y;
    astroDataMonth = m;
    astroDataDay   = d;
  }

  // Compute tomorrow if stale
  time_t tom_t = now_t + 86400L;
  struct tm tomLocal;
  localtime_r(&tom_t, &tomLocal);
  int ty  = tomLocal.tm_year + 1900;
  int tm_ = tomLocal.tm_mon + 1;
  int td  = tomLocal.tm_mday;
  if (ty != tomorrowAstroYear || tm_ != tomorrowAstroMonth || td != tomorrowAstroDay) {
    tomorrowAstro      = computeAstro(ty, tm_, td, lat, lon, utcOffsetHours);
    tomorrowAstroYear  = ty;
    tomorrowAstroMonth = tm_;
    tomorrowAstroDay   = td;
  }

  // Sync computed sun times → legacy variables used by shouldNightModeBeActive()
  // and checkScheduledActions() (relative sunrise/sunset schedules).
  // This replaces the data that was previously fetched from Open-Meteo.
  if (cachedAstro.isValid && cachedAstro.sunriseValid && cachedAstro.sunsetValid) {
    float riseMin  = cachedAstro.sunriseMin;
    float setMin   = cachedAstro.sunsetMin;
    while (riseMin <  0)    riseMin += 1440.0f;
    while (riseMin >= 1440) riseMin -= 1440.0f;
    while (setMin  <  0)    setMin  += 1440.0f;
    while (setMin  >= 1440) setMin  -= 1440.0f;
    sunriseHour    =  (int)(riseMin / 60) % 24;
    sunriseMinute  =  (int)riseMin % 60;
    sunsetHour     =  (int)(setMin  / 60) % 24;
    sunsetMinute   =  (int)setMin  % 60;
    sunTimesValid  =  true;
  }
  if (tomorrowAstro.isValid && tomorrowAstro.sunriseValid && tomorrowAstro.sunsetValid) {
    float tRiseMin  = tomorrowAstro.sunriseMin;
    float tSetMin   = tomorrowAstro.sunsetMin;
    while (tRiseMin <    0) tRiseMin  += 1440.0f;
    while (tRiseMin >= 1440) tRiseMin -= 1440.0f;
    while (tSetMin  <    0) tSetMin   += 1440.0f;
    while (tSetMin  >= 1440) tSetMin  -= 1440.0f;
    tomorrowSunriseHour   = (int)(tRiseMin / 60) % 24;
    tomorrowSunriseMinute = (int)tRiseMin % 60;
    tomorrowSunsetHour    = (int)(tSetMin  / 60) % 24;
    tomorrowSunsetMinute  = (int)tSetMin  % 60;
  }
}

static void ensureViewedAstroData() {
  time_t now_t = time(nullptr);
  if (now_t < 1000000L) return;   // NTP not yet synced

  struct tm localNow, utcNow;
  localtime_r(&now_t, &localNow);
  gmtime_r(&now_t, &utcNow);
  int diffMins = (localNow.tm_hour * 60 + localNow.tm_min)
               - (utcNow.tm_hour   * 60 + utcNow.tm_min);
  if (diffMins >  720) diffMins -= 1440;
  if (diffMins < -720) diffMins += 1440;
  float utcOffsetHours = diffMins / 60.0f;

  float lat = atof(weatherLatitude.c_str());
  float lon = atof(weatherLongitude.c_str());

  // Compute target date by adding offset days
  time_t view_t = now_t + (time_t)astroDateOffset * 86400L;
  struct tm viewLocal;
  localtime_r(&view_t, &viewLocal);
  int y = viewLocal.tm_year + 1900;
  int m = viewLocal.tm_mon  + 1;
  int d = viewLocal.tm_mday;

  if (y != viewedAstroYear || m != viewedAstroMonth || d != viewedAstroDay) {
    viewedAstro      = computeAstro(y, m, d, lat, lon, utcOffsetHours);
    viewedAstroYear  = y;
    viewedAstroMonth = m;
    viewedAstroDay   = d;
  }
}

// bgColor: optional row background color. Pass a color to paint a filled
// rectangle from the label start to the value end before drawing text.
// Omit (or pass the default 0xFFFF sentinel) to leave the background untouched.
static int astroRow(const char* label, const String& value,
                    uint16_t labelCol, uint16_t valueCol,
                    int labelX, int valueX, int y,
                    uint16_t bgColor = 0xFFFF) {
  int16_t x1, y1; uint16_t w, h;

  setSmartFont(DEFAULT_ASTRO_TEXT_FONT);

  // Draw row background when a color is explicitly requested
  if (bgColor != 0xFFFF) {
    getTextBoundsHF("Ag", 0, 0, &x1, &y1, &w, &h);  // sample ascent/descent
    gfx->fillRect(labelX, y + y1 - 2, valueX - labelX, (int16_t)h + 4, bgColor);
  }

  gfx->setTextColor(labelCol);
  gfx->setCursor(labelX, y);
  printHF(label);

  gfx->setTextColor(valueCol);
  getTextBoundsHF(value.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor(valueX - (int16_t)w, y);
  printHF(value.c_str());

  return y;
}

void drawAstroScreen() {
  const bool dark     = astroDarkMode;
  uint16_t bgColor    = dark ? DEFAULT_ASTRO_BG_COLOR       : DEFAULT_ASTRO_BG_COLOR_L;
  uint16_t labelColor = dark ? DEFAULT_ASTRO_LABEL_COLOR    : DEFAULT_ASTRO_LABEL_COLOR_L;
  uint16_t valueColor = dark ? DEFAULT_ASTRO_VALUE_COLOR    : DEFAULT_ASTRO_VALUE_COLOR_L;
  uint16_t arrowColor = dark ? DEFAULT_ASTRO_VALUE_COLOR    : DEFAULT_ASTRO_VALUE_COLOR_L;
  uint16_t dimColor   = dark ? DEFAULT_ASTRO_DIM_TEXT_COLOR : DEFAULT_ASTRO_DIM_TEXT_COLOR_L;

  gfx->fillScreen(bgColor);

  int16_t x1, y1; uint16_t w, h;
  const int16_t screenW = DISPLAY_LONG;

  if (!viewedAstro.isValid) {
    setSmartFont(22);  //22pt
    gfx->setTextColor(COLOR_RED);
    getTextBoundsHF("Calculating...", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - w) / 2, 220);
    printHF("Calculating...");
    flushDisplay();
    return;
  }

  const int ROW_H = 32;                 //Row pitch for astroTextFont
  const int LX    = 110;                //Left padding on 800px wide screen
  const int VX    = DISPLAY_LONG - LX;  //Right padding

  // -----------------------------------------------------------------------
  // Header: title centered, filled-triangle arrows at left/right edges.
  // Left  ◄ = decrement date  (ASTRO_LARROW_* from User_Setup.h)
  // Right ► = increment date  (mirrored from left constants)
  // Touch zones match ASTRO_ARROW_W (defined in touch handler below).
  // -----------------------------------------------------------------------
  auto drawHeader = [&](const char* title, uint16_t headingColor) {
    // Build date string: clockDateFormat + Julian day of year
    struct tm tm2 = {};
    tm2.tm_year = viewedAstroYear  - 1900;
    tm2.tm_mon  = viewedAstroMonth - 1;
    tm2.tm_mday = viewedAstroDay;
    mktime(&tm2);

    // Compute Julian day of year (1-based; tm_yday is 0-based)
    int julianDay = tm2.tm_yday + 1;

    // Format date using the user's clockDateFormat then append Julian day
    char datePart[48];
    strftime(datePart, sizeof(datePart), clockDateFormat.c_str(), &tm2);
    char dateBuf[72];
    snprintf(dateBuf, sizeof(dateBuf), "%s          Day %d", datePart, julianDay);

    const int16_t titleBaseline = 45 + SCREEN_LAYOUT_SHIFT_Y;

    // Title (centered, per-page heading color)
    setSmartFont(astroHeaderFont);
    gfx->setTextColor(headingColor);
    getTextBoundsHF(title, 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - (int16_t)w) / 2, titleBaseline);
    printHF(title);

    // Left ◄ arrow — coordinates from User_Setup.h
    gfx->fillTriangle(ASTRO_LARROW_TIP_X,   ASTRO_LARROW_TIP_Y,
                      ASTRO_LARROW_BASE_X,  ASTRO_LARROW_BASE_T,
                      ASTRO_LARROW_BASE_X,  ASTRO_LARROW_BASE_B, arrowColor);

    // Right ► arrow — mirror of left arrow
    gfx->fillTriangle(screenW - ASTRO_LARROW_TIP_X,  ASTRO_LARROW_TIP_Y,
                      screenW - ASTRO_LARROW_BASE_X, ASTRO_LARROW_BASE_T,
                      screenW - ASTRO_LARROW_BASE_X, ASTRO_LARROW_BASE_B, arrowColor);

    // Date subtitle (centered, with Julian day)
    setSmartFont(astroTextFont);
    gfx->setTextColor(labelColor);
    getTextBoundsHF(dateBuf, 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - (int16_t)w) / 2, 85 + SCREEN_LAYOUT_SHIFT_Y);
    printHF(dateBuf);

    // Separator
    gfx->drawFastHLine(LX, 94 + SCREEN_LAYOUT_SHIFT_Y, screenW - 2 * LX, dimColor);
  };

  // Footer text (centered, dim)
  auto drawFooter = [&](const char* txt) {
    setSmartFont(astroTextFont);
    gfx->setTextColor(dimColor);
    getTextBoundsHF(txt, 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - (int16_t)w) / 2, 475);
    printHF(txt);
  };

  // =====================================================================
  //  SUN PAGE  –  chronological order: dawn → dusk, then summary data
  // =====================================================================
  if (!astroShowMoon) {
    uint16_t sunHeadingColor = dark ? DEFAULT_ASTRO_SUN_HEADER_COLOR : DEFAULT_ASTRO_SUN_HEADER_COLOR_L;
    drawHeader("Sun", sunHeadingColor);

    int y = 132 + SCREEN_LAYOUT_SHIFT_Y;  //first data row baseline

    // --- Chronological twilight + rise/set sequence ---
    astroRow("Astronomical Dawn",
             viewedAstro.astroValid    ? astroFmtMin(viewedAstro.astroDawnMin)    : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Nautical Dawn",
             viewedAstro.nauticalValid ? astroFmtMin(viewedAstro.nauticalDawnMin) : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Civil Dawn",
             viewedAstro.civilValid    ? astroFmtMin(viewedAstro.civilDawnMin)    : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Sunrise",
             viewedAstro.sunriseValid  ? astroFmtMin(viewedAstro.sunriseMin)      : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Solar Noon",
             astroFmtMin(viewedAstro.solarNoonMin),
            COLOR_ORANGE, COLOR_ORANGE, LX, VX, y, COLOR_CHARCOAL);  y += ROW_H;

    astroRow("Sunset",
             viewedAstro.sunsetValid   ? astroFmtMin(viewedAstro.sunsetMin)       : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Civil Dusk",
             viewedAstro.civilValid    ? astroFmtMin(viewedAstro.civilDuskMin)    : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Nautical Dusk",
             viewedAstro.nauticalValid ? astroFmtMin(viewedAstro.nauticalDuskMin) : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Astronomical Dusk",
             viewedAstro.astroValid    ? astroFmtMin(viewedAstro.astroDuskMin)    : "--",
             labelColor, valueColor, LX, VX, y);  y += ROW_H;

    astroRow("Day Length",
             (viewedAstro.sunriseValid && viewedAstro.sunsetValid)
               ? formatDayLength(viewedAstro.dayLengthMin) : "--",
             COLOR_ORANGE, COLOR_ORANGE, LX, VX, y, COLOR_CHARCOAL);

    drawFooter("\xBB Moon");

  // =====================================================================
  //  MOON PAGE
  // =====================================================================
  } else {
    uint16_t moonHeadingColor = dark ? DEFAULT_ASTRO_MOON_HEADER_COLOR : DEFAULT_ASTRO_MOON_HEADER_COLOR_L;
    drawHeader("Moon", moonHeadingColor);

    int y = 130 + SCREEN_LAYOUT_SHIFT_Y;

    // --- Rise / Set (stacked, single column) ---
    String moonriseStr, moonsetStr;
    if      (viewedAstro.moonriseCode >= 0)  moonriseStr = astroFmtHour(viewedAstro.moonriseHour);
    else if (viewedAstro.moonriseCode == -2) moonriseStr = "Always up";
    else                                     moonriseStr = "No rise";

    if      (viewedAstro.moonsetCode  >= 0)  moonsetStr  = astroFmtHour(viewedAstro.moonsetHour);
    else if (viewedAstro.moonsetCode  == -2) moonsetStr  = "Always up";
    else                                     moonsetStr  = "No set";

    astroRow("Moonrise",     moonriseStr,      labelColor, valueColor, LX, VX, y);  y += ROW_H;
    astroRow("Moonset",      moonsetStr,       labelColor, valueColor, LX, VX, y);  y += ROW_H;

    // Illumination
    char illumBuf[8];
    snprintf(illumBuf, sizeof(illumBuf), "%d%%", viewedAstro.illuminationPct);
    astroRow("Illumination", String(illumBuf), labelColor, valueColor, LX, VX, y);  y += ROW_H;

    // Phase angle
    char paBuf[12];
    snprintf(paBuf, sizeof(paBuf), "%.0f\xB0", (float)viewedAstro.phaseAngle);
    astroRow("Phase Angle",  String(paBuf),    labelColor, valueColor, LX, VX, y);  y += ROW_H + 6;

    // --- Moon-phase graphic (centered) ---
    {
      const int16_t cxGfx  = screenW / 2;
      const int16_t cyGfx  = y + 30;
      const int16_t radius = 52;
      float pa = viewedAstro.phaseAngle;

      uint16_t litColor = dark ? COLOR_WHITE : COLOR_YELLOW;

      // Convert the Meeus phase angle to a normalized lunar-cycle fraction:
      //   0.00 = New Moon (pa=180°), 0.25 = First Quarter (pa=90°),
      //   0.50 = Full Moon (pa=0°),  0.75 = Last Quarter  (pa=270°).
      // Correct transform: phase01 = (180 - pa) mod 360 / 360
      float phase01 = fmodf(180.0f - pa + 360.0f, 360.0f) / 360.0f;
      if (phase01 < 0.0f) phase01 += 1.0f;

      // Base dark disc.
      gfx->fillCircle(cxGfx, cyGfx, radius, dimColor);

      // Projected terminator ellipse semi-minor axis.
      float a = fabsf(cosf(phase01 * 2.0f * (float)PI)) * (float)radius;

      for (int16_t dy = -radius; dy <= radius; dy++) {
        float yy = (float)dy;
        float halfWf = sqrtf(max(0.0f, (float)(radius * radius) - yy * yy));
        int16_t halfW = (int16_t)floorf(halfWf + 0.0001f);
        int16_t xStart = 1;
        int16_t xEnd   = 0;   // default: draw nothing

        float xTermF = (radius > 0) ? (a * halfWf / (float)radius) : 0.0f;
        int16_t xTerm = (int16_t)floorf(xTermF + 0.0001f);

        if (phase01 < 0.25f) {           // Waxing crescent: right-side crescent
          xStart = xTerm;
          xEnd   = halfW;
        } else if (phase01 < 0.50f) {    // Waxing gibbous: dark crescent on the left
          xStart = -xTerm;
          xEnd   = halfW;
        } else if (phase01 < 0.75f) {    // Waning gibbous: dark crescent on the right
          xStart = -halfW;
          xEnd   = xTerm;
        } else {                         // Waning crescent: left-side crescent
          xStart = -halfW;
          xEnd   = -xTerm;
        }

        if (xStart <= xEnd)
          gfx->drawFastHLine(cxGfx + xStart, cyGfx + dy, xEnd - xStart + 1, litColor);
      }  //end dy loop

      y = cyGfx + radius + 8;
    }

    // Phase name below graphic
    setSmartFont(astroTextFont);
    getTextBoundsHF(viewedAstro.phaseName.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(valueColor);
    gfx->setCursor((screenW - (int16_t)w) / 2, y + 40);
    printHF(viewedAstro.phaseName.c_str());

    drawFooter("\xBB Sun");
  }

  flushDisplay();
}

void displayAstro() {
  ensureAstroData();
  ensureViewedAstroData();
  drawAstroScreen();
}

void drawAboutScreen() {
  gfx->fillScreen(COLOR_BLACK);

  int16_t x1, y1; uint16_t w, h;
  const int16_t screenW = DISPLAY_LONG;

  // ── Shared header ────────────────────────────────────────────────────────
  setSmartFont(screenHeaderFont);     // Roboto 20pt
  gfx->setTextColor(COLOR_YELLOW);
  getTextBoundsHF("ABOUT", 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor((screenW - w) / 2, -y1 + 6 + SCREEN_LAYOUT_SHIFT_Y);
  printHF("ABOUT");

  setSmartFont(msgNoticeFont);        // set before measuring label widths

  // ── Page indicators (2 circles, bottom-center) ───────────────────────────
  // Active page: filled white circle.  Inactive: double outlined white circle.
  {
    const int16_t indY    = 461;
    const int16_t radius  = 7;
    const int16_t spacing = 22;
    const int16_t cx1     = screenW / 2 - spacing;  // page 1
    const int16_t cx2     = screenW / 2 + spacing;  // page 2

    if (!aboutSubPage) {
      gfx->fillCircle(cx1, indY, radius, COLOR_WHITE);
      gfx->fillCircle(cx2, indY, radius, COLOR_BLACK);
      gfx->drawCircle(cx2, indY, radius,     COLOR_WHITE);
      gfx->drawCircle(cx2, indY, radius - 1, COLOR_WHITE);
    } else {
      gfx->fillCircle(cx2, indY, radius, COLOR_WHITE);
      gfx->fillCircle(cx1, indY, radius, COLOR_BLACK);
      gfx->drawCircle(cx1, indY, radius,     COLOR_WHITE);
      gfx->drawCircle(cx1, indY, radius - 1, COLOR_WHITE);
    }
  }

  // ── Row helper ───────────────────────────────────────────────────────────
  const int16_t labelX   = 150;
  char buf[80];

  // Find the widest label across both pages to align value columns consistently
  const char* allLabels[] = {
    "Device Name: ", "Device ID: ", "FW Version: ",
    "Device Type: ", "Flash Size: ", "PSRAM Size: ",
    "Free Heap: ",   "WiFi IP: ",   "Signal/Noise: ", "WiFi SNR: ",
    "Location: ", "Latitude: ", "Longitude: ", "Altitude (m): ",
    "IANA Timezone: ", "POSIX TZ String: "
  };
  uint16_t maxLabelW = 0;
  for (const char* lbl : allLabels) {
    getTextBoundsHF(lbl, 0, 0, &x1, &y1, &w, &h);
    if (w > maxLabelW) maxLabelW = w;
  }
  const int16_t valueX = labelX + maxLabelW + 12;

  auto printRow = [&](int16_t y, const char* label, const char* value) {
    gfx->setCursor(labelX, y);
    gfx->setTextColor(COLOR_YELLOW);
    printHF(label);
    gfx->setCursor(valueX, y);
    gfx->setTextColor(COLOR_WHITE);
    printHF(value);
  };

  // ── Page 1: Device / System info ─────────────────────────────────────────
  if (!aboutSubPage) {
    const int startRow   = 90;
    const int rowSpacing = 33;
    auto ROW_Y = [&](int n) { return startRow + (rowSpacing * n) + SCREEN_LAYOUT_SHIFT_Y; };

    printRow(ROW_Y(0), "Device Name: ", deviceName.c_str());

    snprintf(buf, sizeof(buf), "0x%s", deviceID.c_str());
    printRow(ROW_Y(1), "Device ID: ", buf);

    snprintf(buf, sizeof(buf), "%s (%s)", Version, Timestamp);
    printRow(ROW_Y(2), "FW Version: ", buf);

    snprintf(buf, sizeof(buf), "%s @ %d MHz", ESP.getChipModel(), ESP.getCpuFreqMHz());
    printRow(ROW_Y(3), "Device Type: ", buf);

    snprintf(buf, sizeof(buf), "%d MB  (%d KB OTA free)",
             ESP.getFlashChipSize() / 1024 / 1024, ESP.getFreeSketchSpace() / 1024);
    printRow(ROW_Y(4), "Flash Size: ", buf);

    snprintf(buf, sizeof(buf), "%d MB  (%d KB free)",
             ESP.getPsramSize() / 1024 / 1024, ESP.getFreePsram() / 1024);
    printRow(ROW_Y(5), "PSRAM Size: ", buf);

    snprintf(buf, sizeof(buf), "%d KB", ESP.getFreeHeap() / 1024);
    printRow(ROW_Y(6), "Free Heap: ", buf);

    if (WiFi.status() == WL_CONNECTED) {
      int rssi = WiFi.RSSI();
      int nf   = rom_check_noise_floor() / 4;
      if (nf > 0) nf = -nf;
      int snr  = rssi - nf;
      printRow(ROW_Y(7), "WiFi IP: ", WiFi.localIP().toString().c_str());
      snprintf(buf, sizeof(buf), "%d dBm / %d dBm", rssi, nf);
      printRow(ROW_Y(8), "Signal/Noise: ", buf);
      snprintf(buf, sizeof(buf), "%d dB (%s)", snr, snrLabel(snr));
      printRow(ROW_Y(9), "WiFi SNR: ", buf);
    }

  // ── Page 2: Location / Timezone info ────────────────────────────────────
  } else {
    const int startRow   = 90;
    const int rowSpacing = 40;
    auto ROW_Y = [&](int n) { return startRow + (rowSpacing * n) + SCREEN_LAYOUT_SHIFT_Y; };

    printRow(ROW_Y(0), "Location: ",        weatherLocation.c_str());
    printRow(ROW_Y(1), "Latitude: ",        weatherLatitude.c_str());
    printRow(ROW_Y(2), "Longitude: ",       weatherLongitude.c_str());
    printRow(ROW_Y(3), "Altitude (m): ",    weatherAltitude.c_str());
    printRow(ROW_Y(4), "IANA Timezone: ",   weatherTimezone.c_str());
    printRow(ROW_Y(5), "POSIX TZ String: ", weatherTzString.c_str());
  }

  flushDisplay();
}

String getWeatherDescription(int weatherCode) {
  //All 27 weather codes from Open-Meteo API
  switch (weatherCode) {
    case  0: return "Clear sky";
    case  1: return "Mainly clear";
    case  2: return "Partly cloudy";
    case  3: return "Overcast";
    case 45: return "Fog";
    case 48: return "Depositing rime fog";
    case 51: return "Drizzle: Light";
    case 53: return "Drizzle: Moderate";
    case 55: return "Drizzle: Dense";
    case 56: return "Freezing drizzle: Light";
    case 57: return "Freezing drizzle: Dense";
    case 61: return "Rain: Slight";
    case 63: return "Rain: Moderate";
    case 65: return "Rain: Heavy";
    case 66: return "Freezing rain: Light";
    case 67: return "Freezing rain: Heavy";
    case 71: return "Snow: Slight";
    case 73: return "Snow: Moderate";
    case 75: return "Snow: Heavy";
    case 77: return "Snow grains";
    case 80: return "Rain showers: Slight";
    case 81: return "Rain showers: Moderate";
    case 82: return "Rain showers: Violent";
    case 85: return "Snow showers: Slight";
    case 86: return "Snow showers: Heavy";
    case 95: return "Thunderstorm";
    case 96: return "Thunderstorm: Slight hail";
    case 99: return "Thunderstorm: Heavy hail";
    default: return "Unknown";
  }
}

void getWeatherIconArrays(int weatherCode, bool isDay,
                          const uint16_t** rgb565, const uint8_t** alpha,
                          int16_t* w, int16_t* h) {
  //All icons are 128x128
  *w = 128;
  *h = 128;

  //Clear sky (0-1) - Sun or Moon
  if (weatherCode <= 1) {
    if (isDay) {
      *rgb565 = weather_sun_rgb565;
      *alpha = weather_sun_alpha;
    } else {
      *rgb565 = weather_night_rgb565;
      *alpha = weather_night_alpha;
    }
  }
  //Partly cloudy/Overcast (2-3)
  else if (weatherCode >= 2 && weatherCode <= 3) {
    *rgb565 = weather_cloud_rgb565;
    *alpha = weather_cloud_alpha;
  }
  //Fog (45-48)
  else if (weatherCode >= 45 && weatherCode <= 48) {
    *rgb565 = weather_cloud_rgb565;
    *alpha = weather_cloud_alpha;
  }
  //Drizzle or Rain (51-67, 80-82)
  else if ((weatherCode >= 51 && weatherCode <= 67) || (weatherCode >= 80 && weatherCode <= 82)) {
    *rgb565 = weather_rain_rgb565;
    *alpha = weather_rain_alpha;
  }
  //Snow (71-77, 85-86)
  else if ((weatherCode >= 71 && weatherCode <= 77) || (weatherCode >= 85 && weatherCode <= 86)) {
    *rgb565 = weather_snow_rgb565;
    *alpha = weather_snow_alpha;
  }
  //Thunderstorm (95-99)
  else if (weatherCode >= 95 && weatherCode <= 99) {
    *rgb565 = weather_thunder_rgb565;
    *alpha = weather_thunder_alpha;
  }
  //Default: cloud
  else {
    *rgb565 = weather_cloud_rgb565;
    *alpha = weather_cloud_alpha;
  }
}

void fetchWeather() {
  const uint8_t   MAX_ATTEMPTS     = 3;
  const uint16_t  RETRY_DELAY_MS   = 500;
  const uint16_t  HTTP_TIMEOUT_MS  = 3000;
  static uint32_t consecutiveFails = 0;
  static uint32_t cooldownUntil    = 0;

  uint32_t now = millis();

  //Check cooldown period after failures
  if (consecutiveFails >= 3 && now < cooldownUntil) {
    #if DEEP_DEBUG
      DEBUG_PRINTF("Weather: In cooldown, %d sec remaining\n", (cooldownUntil - now) / 1000);
    #endif
    return;
  }

  if (WiFi.status() != WL_CONNECTED) {
    DEBUG_PRINTLN("Weather: WiFi not connected");
    consecutiveFails++;
    cooldownUntil = now + 60000;  //1 minute cooldown
    return;
  }

  String tempUnit = tempCelsius ? "" : "&temperature_unit=fahrenheit";
  String url = String("http://api.open-meteo.com/v1/forecast?latitude=") + weatherLatitude + "&longitude=" + weatherLongitude
             + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,surface_pressure,is_day,weather_code"
             + "&daily=temperature_2m_max,apparent_temperature_max,temperature_2m_min,apparent_temperature_min,precipitation_sum,precipitation_probability_max"
             + tempUnit + "&timezone=" + weatherTimezone + "&forecast_days=1";

  DEBUG_PRINTLN("\n=== Fetching Weather ===");
  #if EXTENDED_DEBUG
    DEBUG_PRINTLN("URL: " + url);
  #endif

  bool success = false;

  //Try up to MAX_ATTEMPTS times
  for (uint8_t attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    if (attempt > 1) {
      DEBUG_PRINTF("Weather: Retry attempt %d/%d\n", attempt, MAX_ATTEMPTS);
      delay(RETRY_DELAY_MS);
    }

    HTTPClient http;
    http.setTimeout(HTTP_TIMEOUT_MS);

    if (!http.begin(url)) {
      DEBUG_PRINTLN("Weather: HTTP begin failed");
      continue;
    }

    int httpCode = http.GET();

    if (httpCode == HTTP_CODE_OK) {
      String payload = http.getString();
      http.end();

      JsonDocument doc;
      DeserializationError err = deserializeJson(doc, payload);

      if (err) {
        DEBUG_PRINT("Weather: JSON parse failed: ");
        DEBUG_PRINTLN(err.c_str());
        continue;
      }

      JsonObject current = doc["current"];
      if (current.isNull()) {
        DEBUG_PRINTLN("Weather: No current data");
        continue;
      }

      //SUCCESS - Extract data
      weatherTemp         = current["temperature_2m"] | 0.0f;
      weatherApparentTemp = current["apparent_temperature"] | 0.0f;
      weatherHumidity     = current["relative_humidity_2m"] | 0;
      weatherPressure     = current["surface_pressure"] | 0.0f;
      weatherIsDay        = current["is_day"] | 1;
      weatherCode         = current["weather_code"] | 0;
      weatherDescription  = getWeatherDescription(weatherCode);

      //Extract today's daily forecast (index 0 = today)
      JsonObject daily = doc["daily"];
      if (!daily.isNull()) {
        dailyTempMax            = daily["temperature_2m_max"][0]            | 0.0f;
        dailyApparentTempMax    = daily["apparent_temperature_max"][0]      | 0.0f;
        dailyTempMin            = daily["temperature_2m_min"][0]            | 0.0f;
        dailyApparentTempMin    = daily["apparent_temperature_min"][0]      | 0.0f;
        dailyPrecipitationSum   = daily["precipitation_sum"][0]             | 0.0f;
        dailyPrecipProbMax      = daily["precipitation_probability_max"][0] | 0;
        DEBUG_PRINTF("  Daily High / Low       : %.1f / %.1f %s\n",
                     dailyTempMax, dailyTempMin, tempCelsius ? "°C" : "°F");
        DEBUG_PRINTF("  Feels-like High / Low  : %.1f / %.1f %s\n",
                     dailyApparentTempMax, dailyApparentTempMin, tempCelsius ? "°C" : "°F");
        DEBUG_PRINTF("  Precipitation          : %.1f mm, %d%% probability\n",
                     dailyPrecipitationSum, dailyPrecipProbMax);
      }

      //Get local time for "last update" (use DEFAULT_CLOCK_TIME_FORMAT)
      struct tm timeinfo;
      if (getLocalTime(&timeinfo)) {
        char timeStr[32];
        strftime(timeStr, sizeof(timeStr), DEFAULT_CLOCK_TIME_FORMAT, &timeinfo);
        weatherLastUpdate = String(timeStr);
      }

      DEBUG_PRINTF("  Actual Temperature     : %.1f%s\n", weatherTemp, tempCelsius ? "°C" : "°F");
      DEBUG_PRINTF("  Apparent Temperature   : %.1f%s\n", weatherApparentTemp, tempCelsius ? "°C" : "°F");
      DEBUG_PRINTF("  Temperature Displayed  : %s\n", tempAlternate ? "Alternating actual & apparent" : (tempActual ? "Actual" : "Apparent (feels-like)"));
      DEBUG_PRINTF("  Relative Humidity      : %d%%\n", weatherHumidity);
      DEBUG_PRINTF("  Air Pressure           : %.1f hPa\n", weatherPressure);

      if (!localPressureValid) {
        DEBUG_PRINTLN("  Local Air Pressure     : null (no fetch yet)");
      } else {
        ulong localPressureAge = millis() - lastLocalPressureReceived;
        bool  fresh            = localPressureAge < LOCAL_PRESSURE_STALE_MS;
        DEBUG_PRINTF("  Local Air Pressure     : %.1f hPa (%s, %lu minutes old)\n",
                    localPressureHpa, fresh ? "fresh" : "STALE", localPressureAge / 60000UL);
      }
      DEBUG_PRINTF("  AP Display Mode        : %s\n",
                  !localPressureValid ? "open-meteo only (no local data)" :
                  !apAlternate        ? "local avg (fixed)" : "alternating local <-> open-meteo (~)");

      DEBUG_PRINTF("  Weather Condition code : %s (code %d)\n\n", weatherDescription.c_str(), weatherCode);

      lastWeatherFetch = millis();
      consecutiveFails = 0;  //Reset failure counter
      mqttPublishWeather();  //Broadcast updated weather to CYD subscribers
      success = true;
      break;  //Exit retry loop

    } else {
      DEBUG_PRINTF("Weather: HTTP error %d\n", httpCode);
      http.end();
    }
  }

  if (!success) {
    DEBUG_PRINTLN("Weather: All attempts failed");
    consecutiveFails++;
    if (consecutiveFails >= 3) {
      cooldownUntil = now + 300000;  //5 minute cooldown after 3 failures
      DEBUG_PRINTLN("Weather: Entering 5-minute cooldown");
    }
  }
}

void updateWeather() {                    //Only fetch if enough time has passed
  if (millis() - lastWeatherFetch >= WEATHER_FETCH_INTERVAL) {
    fetchWeather();
  }
}

static void drawWeatherPage1() {
  //Apply dark/light mode colors
  uint16_t bgColor       = weatherDarkMode ? DEFAULT_WEATHER_BG_COLOR       : DEFAULT_WEATHER_BG_COLOR_L;
  uint16_t forecastColor = weatherDarkMode ? DEFAULT_WEATHER_FORECAST_COLOR : DEFAULT_WEATHER_FORECAST_COLOR_L;
  uint16_t titleColor    = weatherDarkMode ? DEFAULT_WEATHER_TITLE_COLOR    : DEFAULT_WEATHER_TITLE_COLOR_L;
  uint16_t tempColor     = weatherDarkMode ? DEFAULT_WEATHER_TEMP_COLOR     : DEFAULT_WEATHER_TEMP_COLOR_L;
  uint16_t humidityColor = weatherDarkMode ? DEFAULT_WEATHER_HUMID_COLOR    : DEFAULT_WEATHER_HUMID_COLOR_L;
  uint16_t sunInfoColor  = weatherDarkMode ? DEFAULT_WEATHER_SUN_INFO_COLOR : DEFAULT_WEATHER_SUN_INFO_COLOR_L;
  uint16_t footerColor   = weatherDarkMode ? DEFAULT_WEATHER_FOOTER_COLOR   : DEFAULT_WEATHER_FOOTER_COLOR_L;

  gfx->fillScreen(bgColor);

  int16_t x1, y1;
  uint16_t w, h;

  const int16_t screenW = gfx->width();
  const int16_t pad = 50;

  //Location (top, centered)
  setSmartFont(weatherTitleFont);
  gfx->setTextColor(titleColor);
  getTextBoundsHF(weatherLocation.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor((screenW - w) / 2, -y1 + 8 + SCREEN_LAYOUT_SHIFT_Y);
  printHF(weatherLocation.c_str());

  //Weather description (below location)
  setSmartFont(weatherFont);
  gfx->setTextColor(forecastColor);
  getTextBoundsHF(weatherDescription.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor((screenW - w) / 2, 85 + SCREEN_LAYOUT_SHIFT_Y);
  printHF(weatherDescription.c_str());

  //Large weather icon (LEFT)
  const uint16_t* iconRGB;
  const uint8_t* iconAlpha;
  int16_t iconW, iconH;

  getWeatherIconArrays(weatherCode, weatherIsDay,
                       &iconRGB, &iconAlpha, &iconW, &iconH);

  int16_t iconX = pad + 50; //position the large weather icon on the left with some padding
  int16_t iconY = 135 + SCREEN_LAYOUT_SHIFT_Y;

  drawRGB565AlphaBitmap(gfx, iconX, iconY, iconRGB, iconAlpha,
                        iconW, iconH, bgColor);

  //RIGHT-SIDE METRICS (Temperature & Humidity)
  const int16_t rightX = screenW - pad;

  //---------- Temperature ----------
  char tempValStr[16];
  bool showActualTemp = (tempAlternate ? tempAlternateShowActual : tempActual);
  float displayTemp   = showActualTemp ? weatherTemp : weatherApparentTemp;
  bool showTildeTemp  = !showActualTemp;  // tilde drawn left of icon, not in value string
  const char* unitStr = (tempCelsius ? "\xB0""C" : "\xB0""F");
  snprintf(tempValStr, sizeof(tempValStr), "%.1f", displayTemp);

  // Combine value + unit into one string for clean right-alignment
  char tempFullStr[24];
  snprintf(tempFullStr, sizeof(tempFullStr), "%s%s", tempValStr, unitStr);

  setSmartFont(weatherTempFont);
  getTextBoundsHF(tempFullStr, 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(tempColor);
  int16_t tempY = 160 + SCREEN_LAYOUT_SHIFT_Y;
  int16_t tempTextX = rightX - (int16_t)w;

  //Small temperature icon (24x24, alpha mask)
  const int16_t tempIconW = 24;
  const int16_t tempIconH = 24;
  int16_t tempIconX = tempTextX - tempIconW - 6;
  int16_t textTopY  = tempY + y1;
  int16_t tempIconY = textTopY + ((int16_t)h - tempIconH) / 2;

  drawAlphaMaskIcon(gfx, tempIconX, tempIconY, weather_temperature_alpha,
                    24, 24, tempColor, bgColor);

  // Draw tilde to the LEFT of the icon so icon+value stay anchored (no layout jump)
  // Account for x1 (left bearing) so the right glyph-edge sits exactly 6px from the icon.
  if (showTildeTemp) {
    getTextBoundsHF("~", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor(tempIconX - (int16_t)w - x1 - 6, tempY);
    printHF("~");
  }

  gfx->setCursor(tempTextX, tempY);
  printHF(tempFullStr);

  //---------- Humidity ----------
  char humStr[12];
  snprintf(humStr, sizeof(humStr), "%d%%", weatherHumidity);

  setSmartFont(weatherHumidFont);
  gfx->setTextColor(humidityColor);

  //Measure humidity string bounds (capture y1 and h!)
  getTextBoundsHF(humStr, 0, 0, &x1, &y1, &w, &h);
  int16_t humW  = w;
  int16_t humY1 = y1;
  uint16_t humH = h;

  int16_t humY     = tempY + 68;
  int16_t humTextX = rightX - humW;

  //Small humidity icon (24x24, alpha mask) aligned to humidity text bounds
  const int16_t humIconW = 24;
  const int16_t humIconH = 24;
  int16_t humIconX       = humTextX - humIconW - 6;

  int16_t humTextTopY = humY + humY1;
  int16_t humIconY    = humTextTopY + ((int16_t)humH - humIconH) / 2;

  drawAlphaMaskIcon(gfx, humIconX, humIconY, weather_humidity_alpha,
                    24, 24, humidityColor, bgColor);

  //Draw humidity value
  gfx->setCursor(humTextX, humY);
  printHF(humStr);

  //---------- Air Pressure ----------
  //Integer value at weatherPressureFont; "hPa" label smaller font, shared baseline
  // Prefer a fresh local reading over the model value
  char pressValStr[10];
  bool localFresh = localPressureValid &&
                    (millis() - lastLocalPressureReceived < LOCAL_PRESSURE_STALE_MS);

  float displayPressure;
  bool  showingOpenMeteo = false;  // drives the ~ prefix

  if (!localFresh) {
    displayPressure    = weatherPressure;
    showingOpenMeteo   = true;           // ← was false, now always ~ for open-meteo
  } else if (!apAlternate) {
    displayPressure    = localPressureHpa;
    showingOpenMeteo   = false;
  } else {
    if (apAlternateShowLocal) {
      displayPressure  = localPressureHpa;
      showingOpenMeteo = false;
    } else {
      displayPressure  = weatherPressure;
      showingOpenMeteo = true;
    }
  }

  snprintf(pressValStr, sizeof(pressValStr), "%.1f", displayPressure);
 
  const char* pressUnitStr = "hPa";
  const int16_t pressGap   = 10;  //pixels between value and unit
  uint16_t pressureColor   = weatherDarkMode ? DEFAULT_AIR_PRESSURE_COLOR : DEFAULT_AIR_PRESSURE_COLOR_L;

  //Measure value at full pressure font
  setSmartFont(weatherPressureFont);
  getTextBoundsHF(pressValStr, 0, 0, &x1, &y1, &w, &h);
  int16_t pressValW  = w;
  int16_t pressValY1 = y1;
  uint16_t pressValH = h;

  //Make the pressure measurement unit a relatively smaller font
  setSmartFont(weatherPressureUnitsFont);
  getTextBoundsHF(pressUnitStr, 0, 0, &x1, &y1, &w, &h);
  int16_t pressUnitW = w;

  //Total width drives right-alignment and icon placement
  int16_t pressTotalW = pressValW + pressGap + pressUnitW;
  int16_t pressY      = humY + 68;
  int16_t pressTextX  = rightX - pressTotalW;

  //Icon: center vertically on the value bounds (tallest element)
  const int16_t presIconW = 24;
  const int16_t presIconH = 24;
  int16_t presIconX       = pressTextX - presIconW - 6;
  int16_t presTextTopY    = pressY + pressValY1;
  int16_t presIconY       = presTextTopY + ((int16_t)pressValH - presIconH) / 2;

  drawAlphaMaskIcon(gfx, presIconX, presIconY, weather_pressure_alpha,
                    24, 24, pressureColor, bgColor);

  //Draw integer value (full pressure font)
  setSmartFont(weatherPressureFont);
  gfx->setTextColor(pressureColor);

  // Draw tilde to the LEFT of the icon so icon+value stay anchored (no layout jump)
  // Account for x1 (left bearing) so the right glyph-edge sits exactly 6px from the icon.
  if (showingOpenMeteo) {
    getTextBoundsHF("~", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor(presIconX - (int16_t)w - x1 - 6, pressY);
    printHF("~");
  }

  gfx->setCursor(pressTextX, pressY);
  printHF(pressValStr);

  //Draw "hPa" unit (smaller font shares baseline with value)
  setSmartFont(weatherPressureUnitsFont);
  gfx->setTextColor(pressureColor);
  gfx->setCursor(pressTextX + pressValW + pressGap, pressY);
  printHF(pressUnitStr);

  // ── Daily Forecast — 2-row × 6-column grid ───────────────────────────────
  // Row 0:  High  72°F     Low  55°F     Wet 0.3
  // Row 1: ~High  69°F    ~Low  52°F     Chance 40%
  //
  //  • Tilde column: "~" on row 1 only — keeps H/L horizontally aligned.
  //  • Label column: "High" / "Low", left-aligned.
  //  • Value column: right-aligned so digits stack cleanly.
  //  Three groups centred as a block with GROUP_GAP between them.
  // ─────────────────────────────────────────────────────────────────────────
  {
    const char* unitStr = tempCelsius ? "\xB0""C" : "\xB0""F";

    char hiVal0[12], hiVal1[12], loVal0[12], loVal1[12];
    char wetStr[20], chanceStr[20];
    snprintf(hiVal0,    sizeof(hiVal0),    "%.0f%s",     dailyTempMax,          unitStr);
    snprintf(hiVal1,    sizeof(hiVal1),    "%.0f%s",     dailyApparentTempMax,  unitStr);
    snprintf(loVal0,    sizeof(loVal0),    "%.0f%s",     dailyTempMin,          unitStr);
    snprintf(loVal1,    sizeof(loVal1),    "%.0f%s",     dailyApparentTempMin,  unitStr);
    float  precipDisplay = tempCelsius ? dailyPrecipitationSum : dailyPrecipitationSum * 0.0393701f;
    snprintf(wetStr,    sizeof(wetStr),    "Wet %.1f %s", precipDisplay, tempCelsius ? "mm" : "in");
    snprintf(chanceStr, sizeof(chanceStr), "Chance %d%%",dailyPrecipProbMax);

    setSmartFont(clockSuntimesFont);
    gfx->setTextColor(sunInfoColor);

    int16_t  bx, by;
    uint16_t wTilde, wHiLbl, wLoLbl,
             wHiV0, wHiV1, wLoV0, wLoV1,
             wWet, wCh, th;

    getTextBoundsHF("~",       0, 0, &bx, &by, &wTilde, &th);
    getTextBoundsHF("High",    0, 0, &bx, &by, &wHiLbl, &th);
    getTextBoundsHF("Low",     0, 0, &bx, &by, &wLoLbl, &th);
    getTextBoundsHF(hiVal0,    0, 0, &bx, &by, &wHiV0,  &th);
    getTextBoundsHF(hiVal1,    0, 0, &bx, &by, &wHiV1,  &th);
    getTextBoundsHF(loVal0,    0, 0, &bx, &by, &wLoV0,  &th);
    getTextBoundsHF(loVal1,    0, 0, &bx, &by, &wLoV1,  &th);
    getTextBoundsHF(wetStr,    0, 0, &bx, &by, &wWet,   &th);
    getTextBoundsHF(chanceStr, 0, 0, &bx, &by, &wCh,    &th);

    int tildeW  = (int)wTilde;
    int hiLblW  = (int)wHiLbl;
    int hiValW  = (int)max(wHiV0, wHiV1);
    int loLblW  = (int)wLoLbl;
    int loValW  = (int)max(wLoV0, wLoV1);
    int wetW    = (int)max(wWet,  wCh);

    const int INNER = 6;    // tilde→label gap
    const int LGAP  = 14;   // label→value gap (wider for readability)
    const int GROUP = 20;   // gap between the three main groups

    int hiGroupW = tildeW + INNER + hiLblW + LGAP + hiValW;
    int loGroupW = tildeW + INNER + loLblW + LGAP + loValW;
    int totalW   = hiGroupW + GROUP + loGroupW + GROUP + wetW;

    int hiGX     = (screenW - totalW) / 2;
    int loGX     = hiGX + hiGroupW + GROUP;
    int wetGX    = loGX + loGroupW + GROUP;

    int hiLblX   = hiGX + tildeW + INNER;
    int hiValRX  = hiGX + hiGroupW;
    int loLblX   = loGX + tildeW + INNER;
    int loValRX  = loGX + loGroupW;

    const int ROW_Y0 = 355 + SCREEN_LAYOUT_SHIFT_Y;  // moved up to clear "Updated:" line
    const int ROW_DY = 30;

    // Row 0 — actuals (no tilde)
    gfx->setCursor(hiLblX,               ROW_Y0); printHF("High");
    gfx->setCursor(hiValRX - (int)wHiV0, ROW_Y0); printHF(hiVal0);
    gfx->setCursor(loLblX,               ROW_Y0); printHF("Low");
    gfx->setCursor(loValRX - (int)wLoV0, ROW_Y0); printHF(loVal0);
    gfx->setCursor(wetGX,                ROW_Y0); printHF(wetStr);

    // Row 1 — feels-like (tilde hangs left)
    gfx->setCursor(hiGX,                 ROW_Y0 + ROW_DY); printHF("~");
    gfx->setCursor(hiLblX,               ROW_Y0 + ROW_DY); printHF("High");
    gfx->setCursor(hiValRX - (int)wHiV1, ROW_Y0 + ROW_DY); printHF(hiVal1);
    gfx->setCursor(loGX,                 ROW_Y0 + ROW_DY); printHF("~");
    gfx->setCursor(loLblX,               ROW_Y0 + ROW_DY); printHF("Low");
    gfx->setCursor(loValRX - (int)wLoV1, ROW_Y0 + ROW_DY); printHF(loVal1);
    gfx->setCursor(wetGX,                ROW_Y0 + ROW_DY); printHF(chanceStr);
  }

  //Last update — always shown; "--:--" until first successful weather fetch
  {
    String updateStr = "Updated: " + (weatherLastUpdate.length() > 0 ? weatherLastUpdate : String("--:--"));
    setSmartFont(labelFont);
    getTextBoundsHF(updateStr.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(footerColor);
    gfx->setCursor((screenW - w) / 2, 440);
    printHF(updateStr.c_str());
  }

  // ── Page indicators (bottom-center) ──────────────────────────────────
  {
    const int16_t indY    = 465;
    const int16_t radius  = 6;
    const int16_t spacing = 18;
    uint16_t activeC   = weatherDarkMode ? COLOR_WHITE    : COLOR_DARKGRAY;
    uint16_t inactiveC = weatherDarkMode ? COLOR_DARKGRAY : COLOR_LIGHTGRAY;
    int16_t cx1 = screenW / 2 - spacing;
    int16_t cx2 = screenW / 2 + spacing;
    // Page 1 active
    gfx->fillCircle(cx1, indY, radius, activeC);
    gfx->fillCircle(cx2, indY, radius, bgColor);
    gfx->drawCircle(cx2, indY, radius,     inactiveC);
    gfx->drawCircle(cx2, indY, radius - 1, inactiveC);
  }

  flushDisplay();
}

static void drawWeatherPage2() {
  uint16_t bgColor     = weatherDarkMode ? DEFAULT_WEATHER_BG_COLOR       : DEFAULT_WEATHER_BG_COLOR_L;
  uint16_t titleColor  = weatherDarkMode ? DEFAULT_WEATHER_TITLE_COLOR    : DEFAULT_WEATHER_TITLE_COLOR_L;
  uint16_t lineColor   = weatherDarkMode ? COLOR_DARKGRAY                 : COLOR_LIGHTGRAY;
  uint16_t dotColor    = weatherDarkMode ? COLOR_CYAN                     : COLOR_BLUE;
  uint16_t axisColor   = weatherDarkMode ? COLOR_GRAY                     : COLOR_DARKGRAY;
  uint16_t textColor   = weatherDarkMode ? COLOR_WHITE                    : COLOR_BLACK;
  uint16_t foreColor   = weatherDarkMode ? DEFAULT_WEATHER_FORECAST_COLOR : DEFAULT_WEATHER_FORECAST_COLOR_L;
  uint16_t footerColor = weatherDarkMode ? DEFAULT_WEATHER_FOOTER_COLOR   : DEFAULT_WEATHER_FOOTER_COLOR_L;

  gfx->fillScreen(bgColor);

  int16_t x1, y1; uint16_t w, h;
  const int16_t screenW = gfx->width();

  // Title: location name (consistent with page 1)
  setSmartFont(weatherTitleFont);
  gfx->setTextColor(titleColor);
  getTextBoundsHF(weatherLocation.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor((screenW - w) / 2, -y1 + 8 + SCREEN_LAYOUT_SHIFT_Y);
  printHF(weatherLocation.c_str());

  // Subtitle + data counter
  // Shows: "Pressure Trend" centred, and a small reading count/span right-aligned
  setSmartFont(weatherFont);
  gfx->setTextColor(foreColor);
  getTextBoundsHF("Pressure Trend", 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor((screenW - w) / 2, 85 + SCREEN_LAYOUT_SHIFT_Y);
  printHF("Pressure Trend");

  // Data counter — right-aligned at the same baseline as the subtitle
  {
    int   nPts  = pressureBufSize();
    uint32_t spanSec = pressureBufSpanSec();
    char ctrStr[32];
    if (nPts < 2) {
      snprintf(ctrStr, sizeof(ctrStr), "%d pt%s", nPts, nPts == 1 ? "" : "s");
    } else if (spanSec < 3600) {
      snprintf(ctrStr, sizeof(ctrStr), "%d pts / %lum", nPts, (unsigned long)(spanSec / 60));
    } else {
      // show to one decimal hour, e.g. "24 pts / 3.5hr"
      snprintf(ctrStr, sizeof(ctrStr), "%d pts / %.1fhr",
               nPts, spanSec / 3600.0f);
    }
    setSmartFont(labelFont);
    gfx->setTextColor(footerColor);
    getTextBoundsHF(ctrStr, 0, 0, &x1, &y1, &w, &h);
    // Right-aligned with a small margin, same y baseline as subtitle
    gfx->setCursor(screenW - w - 20, 85 + SCREEN_LAYOUT_SHIFT_Y);
    printHF(ctrStr);
    setSmartFont(weatherFont);   // restore for graph code that follows
  }

  // ── Graph area ─────────────────────────────────────────────────────────
  // gX0/gX1 = left/right pixel bounds of plot area (excluding axis labels)
  // gY0/gY1 = top/bottom of plot area
  const int16_t gX0 = 85;
  const int16_t gX1 = 770;
  const int16_t gY0 = 96  + SCREEN_LAYOUT_SHIFT_Y;
  const int16_t gY1 = 266 + SCREEN_LAYOUT_SHIFT_Y;
  const int16_t gW  = gX1 - gX0;
  const int16_t gH  = gY1 - gY0;

  int n = pressureBufSize();

  if (n < 2) {
    // Not enough data yet — show a waiting message
    setSmartFont(22);
    gfx->setTextColor(COLOR_GRAY);
    getTextBoundsHF("Collecting data...", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - w) / 2, gY0 + gH / 2);
    printHF("Collecting data...");

  } else {
    // Collect min/max pressure for Y-axis range
    float pMin =  9999.0f, pMax = -9999.0f;
    uint32_t tsMin = 0, tsMax = 0;
    for (int i = 0; i < n; i++) {
      PressureReading r;
      pressureBufEntry(i, r);
      if (r.hpa < pMin) pMin = r.hpa;
      if (r.hpa > pMax) pMax = r.hpa;
      if (i == 0) tsMin = r.ts;
      tsMax = r.ts;
    }
    // Round Y range outward to nearest 0.5 hPa, add 1 hPa padding
    pMin = floorf((pMin - 1.0f) * 2.0f) / 2.0f;
    pMax = ceilf ((pMax + 1.0f) * 2.0f) / 2.0f;
    float pRange = pMax - pMin;
    uint32_t tsRange = (tsMax > tsMin) ? (tsMax - tsMin) : 1;

    // Coord helpers
    auto pxX = [&](uint32_t ts) -> int16_t {
      return gX0 + (int16_t)((float)(ts - tsMin) / tsRange * gW);
    };
    auto pxY = [&](float p) -> int16_t {
      return gY1 - (int16_t)((p - pMin) / pRange * gH);
    };

    // Background grid + Y-axis labels
    // Choose tick spacing: ~5 nice gridlines
    float tickStep = 0.5f;
    if (pRange > 15.0f) tickStep = 4.0f;
    else if (pRange > 8.0f) tickStep = 2.0f;
    else if (pRange > 4.0f) tickStep = 1.0f;

    setSmartFont(labelFont);
    gfx->setTextColor(axisColor);
    for (float p = ceilf(pMin / tickStep) * tickStep; p <= pMax; p += tickStep) {
      int16_t py = pxY(p);
      gfx->drawFastHLine(gX0, py, gW, lineColor);
      char lbl[10];
      snprintf(lbl, sizeof(lbl), "%.0f", p);
      getTextBoundsHF(lbl, 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor(gX0 - w - 4, py - h / 2 - y1);
      printHF(lbl);
    }

    // X-axis time labels (hours ago)
    uint32_t nowSec = (uint32_t)time(nullptr);
    for (int hAgo = 0; hAgo <= 3; hAgo++) {
      uint32_t targetTs = nowSec - (uint32_t)(hAgo) * 3600UL;
      if (targetTs < tsMin) break;
      int16_t px = pxX(targetTs);
      if (px < gX0 || px > gX1) continue;
      gfx->drawFastVLine(px, gY1, 6, axisColor);
      char lbl[8];
      snprintf(lbl, sizeof(lbl), hAgo == 0 ? "now" : "-%dh", hAgo);
      getTextBoundsHF(lbl, 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor(px - w / 2, gY1 + 8 - y1);
      printHF(lbl);
    }

    // Draw border
    gfx->drawRect(gX0, gY0, gW, gH, axisColor);

    // Plot: connected lines + dots
    int16_t prevPx = -1, prevPy = -1;
    for (int i = 0; i < n; i++) {
      PressureReading r;
      pressureBufEntry(i, r);
      int16_t px = pxX(r.ts);
      int16_t py = pxY(r.hpa);
      if (prevPx >= 0) {
        gfx->drawLine(prevPx, prevPy, px, py, dotColor);
      }
      gfx->fillCircle(px, py, 3, dotColor);
      prevPx = px;
      prevPy = py;
    }
  }

  // ── Trends + Matrix Forecast ────────────────────────────────────────────
  // All y-positions are offsets from gY1 so they track with the graph height.
  // Layout (gY1 = 266 + SHIFT = 286 on this device):
  //   gY1+ 55  3hr · 24hr       14pt  (combined, each half colour-coded)
  //   gY1+ 80  confidence       10pt  (colour-coded)
  //   gY1+105  base forecast    12pt
  //   gY1+125  modifier line 1  10pt  (humidity, if present; can be +135 if mod line 2 is absent)
  //   gY1+143  modifier line 2  10pt  (wind, if present)
  //   gY1+165  footer: SLP · Updated  14pt (always shown)
  float altM = atof(weatherAltitude.c_str());
  float slp  = localPressureValid ? seaLevelPressure(localPressureHpa, altM) : 0.0f;

  if (n >= 2) {
    int   trend3   = pressureTrend();
    float change3  = pressureChangeHpa();
    float change24 = pressureChange24Hpa();

    // Combined 3hr + 24hr trend — single line, 14pt, each half its own colour
    setSmartFont(labelFont);
    {
      char t3[48], t24[48];
      uint32_t spanH = pressureBufSpanSec() / 3600UL;
      int trend24 = (change24 >  PRESSURE_TREND_THRESHOLD) ?  1
                  : (change24 < -PRESSURE_TREND_THRESHOLD) ? -1 : 0;

      snprintf(t3, sizeof(t3), "3hr: %+.1f hPa (%s)",
               change3, trend3 > 0 ? "Rising" : trend3 < 0 ? "Falling" : "Steady");
      if (spanH >= 3)
        snprintf(t24, sizeof(t24), "24hr: %+.1f hPa (%s)",
                 change24, trend24 > 0 ? "Rising" : trend24 < 0 ? "Falling" : "Steady");
      else
        snprintf(t24, sizeof(t24), "24hr: building (%luhr)", (unsigned long)spanH);

      const char* sep = "  -  ";
      uint16_t w3, w_sep, w24, th;
      int16_t  bx, by;
      getTextBoundsHF(t3,  0, 0, &bx, &by, &w3,    &th);
      getTextBoundsHF(sep, 0, 0, &bx, &by, &w_sep, &th);
      getTextBoundsHF(t24, 0, 0, &bx, &by, &w24,   &th);
      int16_t startX = (screenW - (int16_t)(w3 + w_sep + w24)) / 2;

      gfx->setTextColor(trend3 > 0 ? COLOR_GREEN : trend3 < 0 ? COLOR_RED : COLOR_YELLOW);
      gfx->setCursor(startX, gY1 + 55);
      printHF(t3);

      gfx->setTextColor(footerColor);
      gfx->setCursor(startX + (int16_t)w3, gY1 + 55);
      printHF(sep);

      uint16_t t24Color = (spanH >= 3)
        ? (trend24 > 0 ? COLOR_GREEN : trend24 < 0 ? COLOR_RED : COLOR_YELLOW)
        : footerColor;
      gfx->setTextColor(t24Color);
      gfx->setCursor(startX + (int16_t)(w3 + w_sep), gY1 + 55);
      printHF(t24);
    }


    // Confidence badge  (10pt, colour-coded)
    LocalForecast fc = getLocalForecast();
    setSmartFont(10);
    uint16_t confColor = (strcmp(fc.confidence, "High")   == 0) ? COLOR_GREEN :
                         (strcmp(fc.confidence, "Medium") == 0) ? COLOR_ORANGE : COLOR_GRAY;
    char confStr[20];
    snprintf(confStr, sizeof(confStr), "%s confidence", fc.confidence);
    getTextBoundsHF(confStr, 0, 0, &x1, &y1, &w, &h);
    gfx->setTextColor(confColor);
    gfx->setCursor((screenW - w) / 2, gY1 + 80);
    printHF(confStr);

    // ── Forecast summary ─────────────────────────────────────────────────
    // Split full summary into:
    //   baseLine  — base forecast sentence(s), up to the first modifier keyword
    //   mod1      — humidity modifier sentence (if present)
    //   mod2      — wind modifier sentence (if present)
    //
    // Modifier keywords known from PressureBuffer.ino:
    //   " High humidity", " Low humidity",
    //   " Southerly winds", " Northerly winds", " Easterly winds"
    String full = String(fc.summary);
    int modStart = -1;
    const char* modKW[] = {
        " High humidity", " Low humidity",
        " Southerly winds", " Northerly winds", " Easterly winds"
    };
    for (const char* kw : modKW) {
        int idx = full.indexOf(kw);
        if (idx >= 0 && (modStart < 0 || idx < modStart))
            modStart = idx;
    }
    String baseLine = (modStart >= 0) ? full.substring(0, modStart)
                                      : full;
    String modsRem  = (modStart >= 0) ? full.substring(modStart + 1) // skip leading space
                                      : String("");

    // Split the modifiers at ". " to get up to two individual lines
    String mod1 = "", mod2 = "";
    if (modsRem.length() > 0) {
        int dot = modsRem.indexOf(". ");
        if (dot >= 0) {
            mod1 = modsRem.substring(0, dot + 1);
            mod2 = modsRem.substring(dot + 2);
        } else {
            mod1 = modsRem;
        }
    }

    // Base forecast  (12pt)
    setSmartFont(12);
    gfx->setTextColor(foreColor);
    getTextBoundsHF(baseLine.c_str(), 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - w) / 2, gY1 + 105);
    printHF(baseLine.c_str());

    //===========================================================================================================================
    //mod1 = "humidity modifier sentence (if present)"; //TEST LINE, comment out when not testing line spacing
    //===========================================================================================================================
    // Modifier line 1  (10pt or 12pt)
    if (mod1.length() > 0) {
        bool twoLines = (mod2.length() > 0);
        setSmartFont(twoLines ? 10 : 12);
        gfx->setTextColor(foreColor);
        getTextBoundsHF(mod1.c_str(), 0, 0, &x1, &y1, &w, &h);
        gfx->setCursor((screenW - w) / 2, gY1 + (twoLines ? 125 : 135));
        printHF(mod1.c_str());
    }
    
    //===========================================================================================================================
    //mod2 = "wind modifier sentence (if present)"; //TEST LINE, comment out when not testing line spacing
    //===========================================================================================================================
    // Modifier line 2  (10pt)
    if (mod2.length() > 0) {
      setSmartFont(10);
      gfx->setTextColor(foreColor);
      getTextBoundsHF(mod2.c_str(), 0, 0, &x1, &y1, &w, &h);
      gfx->setCursor((screenW - w) / 2, gY1 + 145);
      printHF(mod2.c_str());
    }

  }  // end n >= 2

  // ── Footer: SLP · Updated  (always shown, consolidated on one line) ──────
  {
    char footer[80];
    String updStr = weatherLastUpdate.length() > 0 ? weatherLastUpdate : String("--:--");
    if (slp > 0.0f)
      snprintf(footer, sizeof(footer), "SLP %.1f hPa                     Updated: %s",
               slp, updStr.c_str());
    else
      snprintf(footer, sizeof(footer), "Updated: %s", updStr.c_str());
    setSmartFont(labelFont);
    gfx->setTextColor(footerColor);
    getTextBoundsHF(footer, 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((screenW - w) / 2, gY1 + 165);
    printHF(footer);
  }

  // ── Page indicators ─────────────────────────────────────────────────────
  {
    const int16_t indY    = 465;
    const int16_t radius  = 6;
    const int16_t spacing = 18;
    uint16_t activeC      = weatherDarkMode ? COLOR_WHITE    : COLOR_DARKGRAY;
    uint16_t inactiveC    = weatherDarkMode ? COLOR_DARKGRAY : COLOR_LIGHTGRAY;
    int16_t cx1 = screenW / 2 - spacing;
    int16_t cx2 = screenW / 2 + spacing;
    // Page 2 active
    gfx->fillCircle(cx2, indY, radius, activeC);
    gfx->fillCircle(cx1, indY, radius, bgColor);
    gfx->drawCircle(cx1, indY, radius,     inactiveC);
    gfx->drawCircle(cx1, indY, radius - 1, inactiveC);
  }

  flushDisplay();
}

void displayWeather() {
  if (!weatherSubPage) {
    drawWeatherPage1();
  } else {
    drawWeatherPage2();
  }
}

void fetchLocalPressureViaMQTT() {    //Conditionally get first local pressure via a pending MQTT message
  if (!localPressureValid) {
    for (int i = 0; i < 30 && !localPressureValid; i++) {
      mqttBrokerUpdate();                 
      delay(100);
    }
    if (!localPressureValid) {
      DEBUG_PRINTLN("LocalPressure: local pressure unavailable — weather will use open-meteo");
    }
  }
}

void fetchLocalPressure() {
  const uint8_t   MAX_ATTEMPTS     = 3;
  const uint16_t  RETRY_DELAY_MS   = 500;
  const uint16_t  HTTP_TIMEOUT_MS  = 3000;
  static uint32_t consecutiveFails = 0;
  static uint32_t cooldownUntil    = 0;

  uint32_t now = millis();

  //Check cooldown period after sustained failures
  if (consecutiveFails >= 3 && now < cooldownUntil) {
    #if DEEP_DEBUG
      DEBUG_PRINTF("LocalPressure: In cooldown, %d sec remaining\n", (cooldownUntil - now) / 1000);
    #endif
    return;
  }

  if (WiFi.status() != WL_CONNECTED) {
    DEBUG_PRINTLN("LocalPressure: WiFi not connected");
    consecutiveFails++;
    cooldownUntil = now + 60000;        //1 minute cooldown on WiFi failure
    return;
  }

  String url = HUBITAT_PRESSURE_URL;    //from secrets.h

  DEBUG_PRINTLN("\n=== Fetching Local Air Pressure ===");
  #if EXTENDED_DEBUG
    DEBUG_PRINTLN("URL: " + url);
  #endif

  bool success = false;

  for (uint8_t attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    if (attempt > 1) {
      DEBUG_PRINTF("  Local Air Pressure: Retry attempt %d/%d\n", attempt, MAX_ATTEMPTS);
      delay(RETRY_DELAY_MS);
    }

    HTTPClient http;
    http.setTimeout(HTTP_TIMEOUT_MS);

    if (!http.begin(url)) {
      DEBUG_PRINTLN("LocalPressure: HTTP begin failed");
      continue;
    }

    int httpCode = http.GET();

    if (httpCode == HTTP_CODE_OK) {
      String payload = http.getString();
      http.end();

      JsonDocument doc;
      DeserializationError err = deserializeJson(doc, payload);
      if (err) {
        DEBUG_PRINTF("Local Air Pressure: JSON parse error: %s\n", err.c_str());
        continue;                   //was 'return' — retry on parse failure
      }

      float hpa = doc["hpa"] | 0.0f;
      if (hpa > 800.0f && hpa < 1100.0f) {
        localPressureHpa          = hpa;
        localPressureValid        = true;
        lastLocalPressureReceived = millis();

        DEBUG_PRINTF("  Local Air Pressure     : %.1f hPa (%d sensor(s), %ld seconds ago on hub)\n",
                     hpa, (int)(doc["sensors"] | 0), (long)(doc["age_seconds"] | -1));

        //If weather screen is showing the local-pressure turn, redraw immediately
        if (currentScreen == SCREEN_WEATHER &&
            (!apAlternate || apAlternateShowLocal)) {
          displayWeather();
        }

        lastLocalPressureFetch = millis();  //stamp on success, parallel to lastWeatherFetch
	
        consecutiveFails = 0;
        mqttPublishPressure();  //Broadcast updated pressure to CYD subscribers
        success = true;
      } else {
        DEBUG_PRINTF("  Local Air Pressure: out-of-range value %.1f hPa, retrying\n", hpa);
        continue;                   //was silent fall-through to return — retry on bad value
      }
      break;

    } else {
      DEBUG_PRINTF("  Local Air Pressure: HTTP %d (attempt %d)\n", httpCode, attempt);
      http.end();
    }
  }

  if (!success) {
    DEBUG_PRINTLN("  Local Air Pressure: all attempts failed");
    consecutiveFails++;
    if (consecutiveFails >= 3) {
      cooldownUntil = now + 300000;   //5-minute cooldown after 3 consecutive failures
      DEBUG_PRINTLN("LocalPressure: Entering 5-minute cooldown");
    }
  }
}

void updateLocalPressure() {
  // Select the polling interval dynamically:
  //   SHORT (LOCAL_PRESSURE_FETCH_INTERVAL, default 5 min) — normal HTTP backup rate.
  //   LONG  (LOCAL_PRESSURE_FETCH_INTERVAL_MQTT, 30 min)   — MQTT is actively pushing
  //          values so redundant HTTP fetches are unnecessary.
  // When MQTT goes quiet (broker offline, Hubitat disconnects), lastLocalPressureReceived
  // ages past the LONG window and the interval automatically reverts to SHORT — no flag
  // or manual intervention needed.
  ulong interval = (localPressureValid &&
                    (millis() - lastLocalPressureReceived) < LOCAL_PRESSURE_FETCH_INTERVAL_MQTT)
                   ? LOCAL_PRESSURE_FETCH_INTERVAL_MQTT
                   : LOCAL_PRESSURE_FETCH_INTERVAL;

  if (millis() - lastLocalPressureFetch >= interval) {
    fetchLocalPressure();           //lastLocalPressureFetch now managed inside on success
  }
}

void displayCalendar() {
  uint16_t dayColor     = calendarDarkMode ? DEFAULT_CALENDAR_DAY_COLOR      : DEFAULT_CALENDAR_DAY_COLOR_L;
  uint16_t textColor    = calendarDarkMode ? DEFAULT_CALENDAR_TEXT_COLOR     : DEFAULT_CALENDAR_TEXT_COLOR_L;
  uint16_t flagColor    = calendarDarkMode ? DEFAULT_CALENDAR_HI_LIGHT_COLOR : DEFAULT_CALENDAR_HI_LIGHT_COLOR_L;
  uint16_t bgColor      = calendarDarkMode ? DEFAULT_CALENDAR_BG_COLOR       : DEFAULT_CALENDAR_BG_COLOR_L;
  uint16_t todayColor   = calendarDarkMode ? DEFAULT_CALENDAR_TODAY_COLOR    : DEFAULT_CALENDAR_TODAY_COLOR_L;
  uint16_t daynameColor = calendarDarkMode ? DEFAULT_CALENDAR_DAYNAME_COLOR  : DEFAULT_CALENDAR_DAYNAME_COLOR_L;

  gfx->fillScreen(bgColor);

  //Get today's real date (for "today" highlight)
  struct tm timeinfo;
  int todayYear  = -1;
  int todayMonth = -1;
  int todayDay   = -1;
  if (getLocalTime(&timeinfo)) {
    todayYear  = timeinfo.tm_year + 1900;
    todayMonth = timeinfo.tm_mon;
    todayDay   = timeinfo.tm_mday;
    //If calendarViewYear/Month haven't been initialised yet, default to today
    if (calendarViewYear == 2000) {
      calendarViewMonth = todayMonth;
      calendarViewYear  = todayYear;
    }
  } else {
    setSmartFont(screenHeaderFont);
    gfx->setTextColor(COLOR_RED);
    int16_t x1, y1;
    uint16_t w, h;
    getTextBoundsHF("Time not synced", 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor((DISPLAY_LONG - w) / 2, 220 + SCREEN_LAYOUT_SHIFT_Y);
    printHF("Time not synced");
    flushDisplay();
    return;
  }

  int viewMonth = calendarViewMonth;
  int viewYear  = calendarViewYear;

  //--- Header: nav arrows + month/year label ---
  //Left ◄ and right ► arrows — coordinates defined in User_Setup.h
  gfx->fillTriangle(CAL_LARROW_TIP_X,  CAL_LARROW_TIP_Y,
                    CAL_LARROW_BASE_X, CAL_LARROW_BASE_T,
                    CAL_LARROW_BASE_X, CAL_LARROW_BASE_B, dayColor);

  //Right arrow (► = next month): triangle pointing right, right edge of screen
  gfx->fillTriangle(CAL_RARROW_TIP_X,  CAL_RARROW_TIP_Y,
                    CAL_RARROW_BASE_X, CAL_RARROW_BASE_T,
                    CAL_RARROW_BASE_X, CAL_RARROW_BASE_B, dayColor);

  //Month/Year label centered in header row
  String header = getMonthName(viewMonth) + " " + String(viewYear);
  setSmartFont(screenHeaderFont);

  int16_t x1, y1;
  uint16_t w, h;
  getTextBoundsHF(header.c_str(), 0, 0, &x1, &y1, &w, &h);
  gfx->setTextColor(dayColor);
  gfx->setCursor((DISPLAY_LONG - w) / 2, -y1 + 8 + SCREEN_LAYOUT_SHIFT_Y);
  printHF(header.c_str());

  //--- Day-name row ---
  setSmartFont(calendarDayFont);
  gfx->setTextColor(daynameColor);
  const char* dayNames[] = { "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa" };
  int dayNameX   = 100;
  int dayNameY   = 110 + SCREEN_LAYOUT_SHIFT_Y;
  int daySpacing = 100;

  for (int i = 0; i < 7; i++) {
    getTextBoundsHF(dayNames[i], 0, 0, &x1, &y1, &w, &h);
    gfx->setCursor(dayNameX + (i * daySpacing) - w / 2, dayNameY);
    printHF(dayNames[i]);
  }

  //--- Calculate dates for viewMonth/viewYear ---
  int daysInMonth     = getDaysInMonth(viewMonth, viewYear);
  int firstDayOfWeek  = getFirstDayOfMonth(viewMonth, viewYear);
  int prevMonth       = (viewMonth == 0) ? 11 : viewMonth - 1;
  int prevYear        = (viewMonth == 0) ? viewYear - 1 : viewYear;
  int daysInPrevMonth = getDaysInMonth(prevMonth, prevYear);

  //--- Draw 6×7 grid ---
  setSmartFont(calendarDayFont);
  uint16_t cellColor = dayColor;  //track color per cell
  int startX         = 100;
  int startY         = 155 + SCREEN_LAYOUT_SHIFT_Y;
  int cellWidth      = 100;
  int cellHeight     = 52;
  int dayNum         = 1;
  int nextMonthDay   = 1;

  for (int week = 0; week < 6; week++) {
    for (int day = 0; day < 7; day++) {
      int cellX  = startX + (day * cellWidth);
      int cellY  = startY + (week * cellHeight);

      String dayStr;

      if (week == 0 && day < firstDayOfWeek) {            //Previous-month overflow days
        int prevDayNum = daysInPrevMonth - (firstDayOfWeek - day - 1);
        dayStr = String(prevDayNum);
        cellColor = textColor;
      } 
      else if (dayNum > daysInMonth) {                    //Next-month overflow days
        dayStr = String(nextMonthDay);
        nextMonthDay++;
        cellColor = textColor;
      }
      else {                                               //Current view-month days
        dayStr = String(dayNum);
        //Highlight today only when viewing today's actual month/year
        if (dayNum == todayDay && viewMonth == todayMonth && viewYear == todayYear) {
          gfx->fillCircle(cellX + 4, cellY - 15, 27, flagColor); //Set circle X, Y, radius
          cellColor = todayColor;
        } else {
          cellColor = dayColor;
        }

        dayNum++;
      }

      getTextBoundsHF(dayStr.c_str(), 0, 0, &x1, &y1, &w, &h);
      gfx->setTextColor(cellColor);
      gfx->setCursor(cellX - w / 2, cellY);
      printHF(dayStr.c_str());
    }
  }

  flushDisplay();
}
