/*
  AstroCalc.cpp  –  Sun & Moon astronomical calculations
  Ported from WeekCalendar's SunMoonInfo.js (John Land, 2003–2005)
  and DayInfo.js into C++ for the ESP32.
*/
#include "AstroCalc.h"

// -----------------------------------------------------------------------
// Math helpers
// -----------------------------------------------------------------------
#ifndef PI
  #define PI 3.14159265358979323846
#endif
static inline double degToRad(double d) { return d * PI / 180.0; }
static inline double radToDeg(double r) { return r * 180.0 / PI; }
static inline double sinD(double d)     { return sin(degToRad(d)); }
static inline double cosD(double d)     { return cos(degToRad(d)); }
static inline double tanD(double d)     { return tan(degToRad(d)); }
static inline double arcSinD(double v)  { return radToDeg(asin(v)); }
static inline double arcCosD(double v)  { return radToDeg(acos(v)); }
static inline double rev(double a) {
  return a - floor(a / 360.0) * 360.0;
}

// -----------------------------------------------------------------------
// Julian-day / century helpers  (from DayInfo.js)
// -----------------------------------------------------------------------
static double jDayFromYMD(int year, int month, int day) {
  int y = year, m = month;
  if (m <= 2) { y--; m += 12; }
  int A = (int)(y / 100);
  int B = (y < 1583) ? 0 : 2 - A + (int)(A / 4);
  return (int)(365.25 * (y + 4716)) + (int)(30.6001 * (m + 1)) + day + B - 1524.5;
}

static inline double jCenturyFromJDay(double jday) {
  return (jday - 2451545.0) / 36525.0;
}

static inline double jDayFromJCentury(double jcent) {
  return jcent * 36525.0 + 2451545.0;
}

// -----------------------------------------------------------------------
// Solar calculations  (from SunMoonInfo.js)
// -----------------------------------------------------------------------
static double calcGeoMeanLongSun(double T) {
  double L = 280.4664567 + T * (36000.76982779 + 0.0003032028 * T);
  while (L > 360.0) L -= 360.0;
  while (L < 0.0)   L += 360.0;
  return L;
}

static double calcGeomMeanAnomalySun(double T) {
  return 357.52911 + T * (35999.05029 - 0.0001537 * T);
}

static double calcEccentricityEarthOrbit(double T) {
  return 0.016708634 - T * (0.000042037 + 0.0000001236 * T);
}

static double calcSunEqOfCenter(double T) {
  double M    = calcGeomMeanAnomalySun(T);
  double Mrad = degToRad(M);
  double s1   = sin(Mrad);
  double s2   = sin(2 * Mrad);
  double s3   = sin(3 * Mrad);
  return s1 * (1.914602 - T * (0.004817 + 0.000014 * T))
       + s2 * (0.019993 - 0.000101 * T)
       + s3 * 0.000289;
}

static double calcSunApparentLong(double T) {
  double o     = calcGeoMeanLongSun(T) + calcSunEqOfCenter(T);
  double omega = 125.04452 - 1934.136261 * T;
  return o - 0.00569 - 0.00478 * sinD(omega);
}

static double calcMeanObliquityOfEcliptic(double T) {
  double s = 21.448 - T * (46.8150 + T * (0.00059 - T * 0.001813));
  return 23.0 + (26.0 + s / 60.0) / 60.0;
}

static double calcObliquityCorrection(double T) {
  double eps   = calcMeanObliquityOfEcliptic(T);
  double omega = 125.04452 - 1934.136261 * T;
  return eps + 0.00256 * cosD(omega);
}

static double calcSunDeclination(double T) {
  double eps = calcObliquityCorrection(T);
  double lam = calcSunApparentLong(T);
  return arcSinD(sinD(eps) * sinD(lam));
}

static double calcEquationOfTime(double T) {
  double eps   = calcObliquityCorrection(T);
  double L0    = calcGeoMeanLongSun(T);
  double e     = calcEccentricityEarthOrbit(T);
  double M     = calcGeomMeanAnomalySun(T);
  double y     = tan(degToRad(eps) / 2.0);
  y *= y;
  double s2L0 = sin(2.0 * degToRad(L0));
  double sM   = sinD(M);
  double c2L0 = cos(2.0 * degToRad(L0));
  double s4L0 = sin(4.0 * degToRad(L0));
  double s2M  = sin(2.0 * degToRad(M));
  double eq   = y * s2L0 - 2.0 * e * sM + 4.0 * e * y * sM * c2L0
              - 0.5 * y * y * s4L0 - 1.25 * e * e * s2M;
  return radToDeg(eq) * 4.0;  // minutes
}

static double calcSolNoonUTC(double jcent, double longitude) {
  double noon  = jCenturyFromJDay(jDayFromJCentury(jcent) + longitude / 360.0);
  double eq    = calcEquationOfTime(noon);
  double sn    = 720 + longitude * 4 - eq;

  double newT  = jCenturyFromJDay(jDayFromJCentury(jcent) - 0.5 + sn / 1440.0);
  eq           = calcEquationOfTime(newT);
  return 720 + longitude * 4 - eq;   // UTC minutes from midnight
}

// Returns UTC minutes, or NAN if sun stays above/below horizon
static double sunRiseSetUTC(double jday, double lat, double lon,
                            double offset, bool rise) {
  double jcent = jCenturyFromJDay(jday);

  // First pass: use declination at solar noon
  double noonMin  = calcSolNoonUTC(jcent, lon);
  double noonTime = jCenturyFromJDay(jday + noonMin / 1440.0);
  double eq       = calcEquationOfTime(noonTime);
  double dec      = calcSunDeclination(noonTime);

  // Guard against polar extremes
  double cosArg = cosD(90.0 + offset)
                / (cosD(lat) * cosD(dec))
                - tanD(lat) * tanD(dec);
  if (cosArg < -1.0 || cosArg > 1.0) return NAN;

  double ha  = acos(cosArg);
  if (!rise) ha = -ha;

  double delta    = lon - radToDeg(ha);
  double timeDiff = 4.0 * delta;
  double timeUTC  = 720 + timeDiff - eq;

  // Second pass with refined Julian day
  double newTime = jCenturyFromJDay(jDayFromJCentury(jcent) + timeUTC / 1440.0);
  eq  = calcEquationOfTime(newTime);
  dec = calcSunDeclination(newTime);

  cosArg = cosD(90.0 + offset)
         / (cosD(lat) * cosD(dec))
         - tanD(lat) * tanD(dec);
  if (cosArg < -1.0 || cosArg > 1.0) return NAN;

  ha = acos(cosArg);
  if (!rise) ha = -ha;

  delta    = lon - radToDeg(ha);
  timeDiff = 4.0 * delta;
  return 720 + timeDiff - eq;    // UTC minutes
}

// -----------------------------------------------------------------------
// Lunar calculations  (from SunMoonInfo.js – Meeus ch.45)
// -----------------------------------------------------------------------

// Meeus Table 45.A  (60 rows, longitude & distance)
static const int8_t  T45AD[] = {0,2,2,0,0,0,2,2,2,2,0,1,0,2,0,0,4,0,4,2,2,1,1,2,2,4,2,0,2,2,1,2,0,0,2,2,2,4,0,3,2,4,0,2,2,2,4,0,4,1,2,0,1,3,4,2,0,1,2,2};
static const int8_t  T45AM[] = {0,0,0,0,1,0,0,-1,0,-1,1,0,1,0,0,0,0,0,0,1,1,0,1,-1,0,0,0,1,0,-1,0,-2,1,2,-2,0,0,-1,0,0,1,-1,2,2,1,-1,0,0,-1,0,1,0,1,0,0,-1,2,1,0,0};
static const int8_t  T45AMP[]= {1,-1,0,2,0,0,-2,-1,1,0,-1,0,1,0,1,1,-1,3,-2,-1,0,-1,0,1,2,0,-3,-2,-1,-2,1,0,2,0,-1,1,0,-1,2,-1,1,-2,-1,-1,-2,0,1,4,0,-2,0,2,1,-2,-3,2,1,-1,3,-1};
static const int8_t  T45AF[] = {0,0,0,0,0,2,0,0,0,0,0,0,0,-2,2,-2,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,-2,2,0,2,0,0,0,0,0,0,-2,0,0,0,0,-2,-2,0,0,0,0,0,0,0,-2};
static const long    T45AL[] = {6288774,1274027,658314,213618,-185116,-114332,58793,57066,53322,45758,-40923,-34720,-30383,15327,-12528,10980,10675,10034,8548,-7888,-6766,-5163,4987,4036,3994,3861,3665,-2689,-2602,2390,-2348,2236,-2120,-2069,2048,-1773,-1595,1215,-1110,-892,-810,759,-713,-700,691,596,549,537,520,-487,-399,-381,351,-340,330,327,-323,299,294,0};
static const long    T45AR[] = {-20905355,-3699111,-2955968,-569925,48888,-3149,246158,-152138,-170733,-204586,-129620,108743,104755,10321,0,79661,-34782,-23210,-21636,24208,30824,-8379,-16675,-12831,-10445,-11650,14403,-7003,0,10056,6322,-9884,5751,0,-4950,4130,0,-3958,0,3258,2616,-1897,-2117,2354,0,0,-1423,-1117,-1571,-1739,0,-4421,0,0,0,0,1165,0,0,8752};

// Meeus Table 45.B  (60 rows, latitude)
static const int8_t  T45BD[] = {0,0,0,2,2,2,2,0,2,0,2,2,2,2,2,2,2,0,4,0,0,0,1,0,0,0,1,0,4,4,0,4,2,2,2,2,0,2,2,2,2,4,2,2,0,2,1,1,0,2,1,2,0,4,4,1,4,1,4,2};
static const int8_t  T45BM[] = {0,0,0,0,0,0,0,0,0,0,-1,0,0,1,-1,-1,-1,1,0,1,0,1,0,1,1,1,0,0,0,0,0,0,0,0,-1,0,0,0,0,1,1,0,-1,-2,0,1,1,1,1,1,0,-1,1,0,-1,0,0,0,-1,-2};
static const int8_t  T45BMP[]= {0,1,1,0,-1,-1,0,2,1,2,0,-2,1,0,-1,0,-1,-1,-1,0,0,-1,0,1,1,0,0,3,0,-1,1,-2,0,2,1,-2,3,2,-3,-1,0,0,1,0,1,1,0,0,-2,-1,1,-2,2,-2,-1,1,1,-1,0,0};
static const int8_t  T45BF[] = {1,1,-1,-1,1,-1,1,1,-1,-1,-1,-1,1,-1,1,1,-1,-1,-1,1,3,1,1,1,-1,-1,-1,1,-1,1,-3,1,-3,-1,-1,1,-1,1,-1,1,1,1,1,-1,3,-1,-1,1,-1,-1,1,-1,1,-1,-1,-1,-1,-1,-1,1};
static const long    T45BL[] = {5128122,280602,277693,173237,55413,46271,32573,17198,9266,8822,8216,4324,4200,-3359,2463,2211,2065,-1870,1828,-1794,-1749,-1565,-1491,-1475,-1410,-1344,-1335,1107,1021,833,777,671,607,596,491,-451,439,422,421,-366,-351,331,315,302,-283,-229,223,223,-220,-220,-185,181,-177,176,166,-164,132,-119,115,107};

struct MoonPos {
  double elevation;
  double phaseAngle;
};

static double greenwichSidereal(int year, int month, int day) {
  double T   = (jDayFromYMD(year, month, day) - 2451545.0) / 36525.0;
  double GST = 100.46061837 + T * (36000.770053608 + T * (0.000387933 - T / 38710000.0));
  return rev(GST) / 15.0;   // hours
}

static double localSidereal(double lon, int year, int month, int day,
                            double hours, double minutes, double seconds,
                            double zoneAdjMin) {
  double LST = greenwichSidereal(year, month, day);
  LST += 1.00273790935 * (hours + ((minutes + zoneAdjMin) + seconds / 60.0) / 60.0);
  LST -= lon / 15.0;
  while (LST < 0)  LST += 24.0;
  while (LST > 24) LST -= 24.0;
  return LST;
}

static MoonPos moonPosition(double lat, double lon, int year, int month, int day,
                            double hours, double minutes, double seconds,
                            double zoneAdjMin) {
  double JD  = jDayFromYMD(year, month, day)
             + (hours + (minutes + zoneAdjMin) / 60.0 + seconds / 3600.0) / 24.0;
  double T   = (JD - 2451545.0) / 36525.0;
  double T2  = T * T, T3 = T2 * T, T4 = T3 * T;

  double LP  = 218.3164477 + 481267.88123421 * T - 0.0015786 * T2 + T3 / 538841.0   - T4 / 65194000.0;
  double D   = 297.8501921 + 445267.1114034  * T - 0.0018819 * T2 + T3 / 545868.0   - T4 / 113065000.0;
  double M   = 357.5291092 + 35999.0502909   * T - 0.0001536 * T2 + T3 / 24490000.0;
  double MP  = 134.9633964 + 477198.8675055  * T + 0.0087414 * T2 + T3 / 69699.0    - T4 / 14712000.0;
  double F   = 93.2720950  + 483202.0175233  * T - 0.0036539 * T2 - T3 / 3526000.0  + T4 / 863310000.0;

  double A1  = 119.75 + 131.849  * T;
  double A2  =  53.09 + 479264.290 * T;
  double A3  = 313.45 + 481266.484 * T;
  double E   = 1 - 0.002516 * T - 0.0000074 * T2;
  double E2  = E * E;

  double Sl = 0;
  for (int i = 0; i < 60; i++) {
    int  mAbs  = abs((int)T45AM[i]);
    double ET  = (mAbs == 1) ? E : (mAbs == 2) ? E2 : 1.0;
    Sl += T45AL[i] * ET * sinD(rev(T45AD[i]*D + T45AM[i]*M + T45AMP[i]*MP + T45AF[i]*F));
  }
  double Sb = 0;
  for (int i = 0; i < 60; i++) {
    int  mAbs  = abs((int)T45BM[i]);
    double ET  = (mAbs == 1) ? E : (mAbs == 2) ? E2 : 1.0;
    Sb += T45BL[i] * ET * sinD(rev(T45BD[i]*D + T45BM[i]*M + T45BMP[i]*MP + T45BF[i]*F));
  }

  Sl = Sl + 3958 * sinD(rev(A1))
          + 1962 * sinD(rev(LP - F))
          + 318  * sinD(rev(A2));
  Sb = Sb - 2235 * sinD(rev(LP))
          + 382  * sinD(rev(A3))
          + 175  * sinD(rev(A1 - F))
          + 175  * sinD(rev(A1 + F))
          + 127  * sinD(rev(LP - MP))
          - 115  * sinD(rev(LP + MP));

  double geoLong = rev(LP + Sl / 1000000.0);
  double geoLat  = rev(Sb / 1000000.0);
  if (geoLat > 180.0) geoLat -= 360.0;

  double Obl  = 23.4393 - 3.563e-7 * (JD - 2451543.5);

  // Right ascension (hours) and declination (degrees)
  double rtAsc = rev(radToDeg(atan2(sinD(geoLong) * cosD(Obl) - tanD(geoLat) * sinD(Obl),
                                     cosD(geoLong)))) / 15.0;
  double decl  = arcSinD(sinD(geoLat) * cosD(Obl) + cosD(geoLat) * sinD(Obl) * sinD(geoLong));
  if (decl > 180.0) decl -= 360.0;

  // Phase angle
  double pa = rev(180.0 - D - 6.289 * sinD(MP) + 2.1 * sinD(M)
                  - 1.274 * sinD(2*D - MP) - 0.658 * sinD(2*D)
                  - 0.214 * sinD(2*MP) - 0.11 * sinD(D));

  // Local Sidereal Time → elevation
  double LST  = localSidereal(lon, year, month, day, hours, minutes, seconds, zoneAdjMin);
  double X    = cosD(15.0 * (LST - rtAsc)) * cosD(decl);
  double Y    = sinD(15.0 * (LST - rtAsc)) * cosD(decl);
  double Z    = sinD(decl);
  double XHor = X * sinD(lat) - Z * cosD(lat);
  double YHor = Y;
  double ZHor = X * cosD(lat) + Z * sinD(lat);
  double elev = radToDeg(atan2(ZHor, sqrt(XHor*XHor + YHor*YHor)));

  MoonPos mp;
  mp.elevation  = elev;
  mp.phaseAngle = pa;
  return mp;
}

// Binary + linear search for moonrise/moonset (Meeus approach)
static void moonRiseSetCalc(double lat, double lon, int year, int month, int day,
                            double zoneAdjMin,
                            float &riseHour, float &setHour,
                            int   &riseCode, int   &setCode) {
  double ELH[25];
  bool   done[25];
  for (int i = 0; i <= 24; i++) done[i] = false;

  // Elevation at midnight (hour=0)
  MoonPos mp0 = moonPosition(lat, lon, year, month, day, 0, 0, 0, zoneAdjMin);
  ELH[0]  = mp0.elevation;
  done[0] = true;

  // Initial codes
  riseCode = (ELH[0] >= 0.0) ? -2 : -1;
  setCode  = riseCode;
  riseHour = (float)riseCode;
  setHour  = (float)setCode;

  // Elevation at end of day (hour=24)
  MoonPos mp24 = moonPosition(lat, lon, year, month, day, 24, 0, 0, zoneAdjMin);
  ELH[24]  = mp24.elevation;
  done[24] = true;

  for (int isRise = 0; isRise <= 1; isRise++) {
    bool found  = false;
    int  hFirst = 0, hLast = 24;

    // Binary search
    while ((int)ceil((hLast - hFirst) / 2.0) > 1) {
      int hMid = hFirst + (int)round((hLast - hFirst) / 2.0);
      if (!done[hMid]) {
        MoonPos mp = moonPosition(lat, lon, year, month, day, hMid, 0, 0, zoneAdjMin);
        ELH[hMid]  = mp.elevation;
        done[hMid] = true;
      }
      bool c1 = (isRise == 0) ? (ELH[hFirst] <= 0.0 && ELH[hMid] >= 0.0)
                               : (ELH[hFirst] >= 0.0 && ELH[hMid] <= 0.0);
      bool c2 = (isRise == 0) ? (ELH[hMid] <= 0.0 && ELH[hLast] >= 0.0)
                               : (ELH[hMid] >= 0.0 && ELH[hLast] <= 0.0);
      if      (c1) { hLast  = hMid; found = true; continue; }
      else if (c2) { hFirst = hMid; found = true; continue; }
      break;
    }

    // Linear scan if binary search left a gap > 1 hour
    if (hLast - hFirst > 1) {
      for (int idx = hFirst; idx < hLast; idx++) {
        found = false;
        if (!done[idx + 1]) {
          MoonPos mp = moonPosition(lat, lon, year, month, day, idx + 1, 0, 0, zoneAdjMin);
          ELH[idx + 1]  = mp.elevation;
          done[idx + 1] = true;
        }
        bool c = (isRise == 0) ? (ELH[idx] <= 0.0 && ELH[idx + 1] >= 0.0)
                                : (ELH[idx] >= 0.0 && ELH[idx + 1] <= 0.0);
        if (c) { hFirst = idx; hLast = idx + 1; found = true; break; }
      }
    }

    if (found) {
      double elF = ELH[hFirst], elL = ELH[hLast];
      // Refine with half-hour sample
      MoonPos mpH = moonPosition(lat, lon, year, month, day, hFirst, 30, 0, zoneAdjMin);
      double hF = (double)hFirst, hL = (double)hLast;
      if (isRise == 0) {
        if (mpH.elevation <= 0.0) { hF = hFirst + 0.5; elF = mpH.elevation; }
        else                      { hL = hFirst + 0.5; elL = mpH.elevation; }
      } else {
        if (mpH.elevation <= 0.0) { hL = hFirst + 0.5; elL = mpH.elevation; }
        else                      { hF = hFirst + 0.5; elF = mpH.elevation; }
      }
      double eld    = fabs(elF) + fabs(elL);
      double result = hF + (hL - hF) * fabs(elF) / eld;

      if (isRise == 0) { riseHour = (float)result; riseCode = 0; }
      else             { setHour  = (float)result; setCode  = 0; }
    }
  }
}

// -----------------------------------------------------------------------
// Public API
// -----------------------------------------------------------------------
String getMoonPhaseName(float pa) {
  // The Meeus-based phase-angle formula (pa = rev(180 - D - ...)) yields:
  //   0°   ≈ Full Moon       (D ≈ 180°)
  //   90°  ≈ First Quarter   (D ≈ 90°,  waxing)
  //   180° ≈ New Moon        (D ≈ 0°)
  //   270° ≈ Last Quarter    (D ≈ 270°, waning)
  // Waxing phases occupy pa 0–180 (D increasing toward Full).
  // Waning phases occupy pa 180–360 (D continuing past Full toward New).
  if (pa <  22.5 || pa >= 337.5)  return "Full Moon";
  if (pa <  67.5)                 return "Waxing Gibbous";
  if (pa < 112.5)                 return "First Quarter";
  if (pa < 157.5)                 return "Waxing Crescent";
  if (pa < 202.5)                 return "New Moon";
  if (pa < 247.5)                 return "Waning Crescent";
  if (pa < 292.5)                 return "Last Quarter";
                                  return "Waning Gibbous";
}

String formatDayLength(float totalMinutes) {
  if (totalMinutes <= 0) return "--";
  int h = (int)(totalMinutes / 60);
  int m = (int)totalMinutes % 60;
  char buf[16];
  snprintf(buf, sizeof(buf), "%dh %02dm", h, m);
  return String(buf);
}

AstroData computeAstro(int year, int month, int day,
                       float latitude, float longitude,
                       float utcOffsetHours) {
  AstroData d;
  memset(&d, 0, sizeof(d));
  d.isValid = false;

  // -----------------------------------------------------------------------
  // SIGN CONVENTION NOTE:
  // The solar/lunar formulas ported from SunMoonInfo.js use the same
  // convention as the original NOAA JavaScript: West longitude = POSITIVE.
  // (See fGetLocation() in DayInfo.js: case 0 = "North or West" = positive.)
  //
  // The LATITUDE / LONGITUDE defines in secrets.h use standard cartographic
  // convention: West longitude = NEGATIVE, North latitude = POSITIVE.
  //
  // Fix: negate longitude here so every formula below gets the sign it expects.
  // Latitude needs no change (N positive = correct in both conventions).
  // -----------------------------------------------------------------------
  double lat = (double)latitude;
  double lon = -(double)longitude;   // West-positive for all formulas below

  // zoneAdjMin: minutes to ADD to local hours to obtain UTC.
  // For UTC-8 (PST): zam = 480  (local + 480 min = UTC)
  double zam = -(double)utcOffsetHours * 60.0;

  double jday  = jDayFromYMD(year, month, day);
  double jcent = jCenturyFromJDay(jday);

  // --- Solar noon ---
  double noonUTC = calcSolNoonUTC(jcent, lon);
  d.solarNoonMin = (float)(noonUTC - zam);

  // --- Sunrise / Sunset  (offset = 0.833° for standard atmospheric refraction) ---
  const double OFF_SUN   = 0.833;
  const double OFF_CIV   = 6.0;
  const double OFF_NAUT  = 12.0;
  const double OFF_ASTRO = 18.0;

  double riseUTC = sunRiseSetUTC(jday, lat, lon, OFF_SUN,   true);
  double setUTC  = sunRiseSetUTC(jday, lat, lon, OFF_SUN,   false);
  double cDawnU  = sunRiseSetUTC(jday, lat, lon, OFF_CIV,   true);
  double cDuskU  = sunRiseSetUTC(jday, lat, lon, OFF_CIV,   false);
  double nDawnU  = sunRiseSetUTC(jday, lat, lon, OFF_NAUT,  true);
  double nDuskU  = sunRiseSetUTC(jday, lat, lon, OFF_NAUT,  false);
  double aDawnU  = sunRiseSetUTC(jday, lat, lon, OFF_ASTRO, true);
  double aDuskU  = sunRiseSetUTC(jday, lat, lon, OFF_ASTRO, false);

  d.sunriseValid  = !isnan(riseUTC);
  d.sunsetValid   = !isnan(setUTC);
  d.civilValid    = !isnan(cDawnU) && !isnan(cDuskU);
  d.nauticalValid = !isnan(nDawnU) && !isnan(nDuskU);
  d.astroValid    = !isnan(aDawnU) && !isnan(aDuskU);

  if (d.sunriseValid) d.sunriseMin = (float)(riseUTC - zam);
  if (d.sunsetValid)  d.sunsetMin  = (float)(setUTC  - zam);
  if (d.civilValid)   { d.civilDawnMin     = (float)(cDawnU - zam); d.civilDuskMin     = (float)(cDuskU - zam); }
  if (d.nauticalValid){ d.nauticalDawnMin  = (float)(nDawnU - zam); d.nauticalDuskMin  = (float)(nDuskU - zam); }
  if (d.astroValid)   { d.astroDawnMin     = (float)(aDawnU - zam); d.astroDuskMin     = (float)(aDuskU - zam); }

  d.dayLengthMin = (d.sunriseValid && d.sunsetValid)
                   ? d.sunsetMin - d.sunriseMin : 0;

  // --- Moon rise / set ---
  // Pass lon (west-positive) so localSidereal() works correctly
  moonRiseSetCalc(lat, lon, year, month, day, zam,
                  d.moonriseHour, d.moonsetHour, d.moonriseCode, d.moonsetCode);

  // --- Moon phase at solar noon (local) ---
  float localNoon = d.solarNoonMin;
  while (localNoon <    0) localNoon += 1440.0f;
  while (localNoon >= 1440) localNoon -= 1440.0f;
  int noonHr  = (int)(localNoon / 60.0f) % 24;
  int noonMin = (int)(localNoon) % 60;
  MoonPos mp = moonPosition(lat, lon, year, month, day,
                            noonHr, noonMin, 0, zam);
  d.phaseAngle      = (float)mp.phaseAngle;
  d.illuminationPct = (int)round(100.0 * (1.0 + cosD(mp.phaseAngle)) / 2.0);
  d.phaseName       = getMoonPhaseName(d.phaseAngle);

  d.isValid = true;
  return d;
}
