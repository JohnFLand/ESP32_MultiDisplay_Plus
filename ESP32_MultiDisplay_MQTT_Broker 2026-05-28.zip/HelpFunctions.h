/*
 * HelpFunctions.h
 *
 * Color definitions, font includes, and helper function declarations
 * PHASE 2: Enhanced Message System
 *
 * Requires: ArduinoJson v7 (tested with 7.4.2)
 */

#ifndef HELPFUNCTIONS_H
#define HELPFUNCTIONS_H
void flushDisplay();

//#include <Arduino_GFX_Library.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include "PSRAM_Helpers.h"      //PSRAM Support
#include "Colors.h"             //Named color definitions
#include "WebDebugLog.h"        //provides DEBUG_PRINT/PRINTLN/PRINTF globally
//Note: DEBUG_PRINT, DEBUG_PRINTLN, DEBUG_PRINTF macros are provided by WebDebugLog.h
//Include WebDebugLog.h directly in your .cpp files that need debug output.
//This avoids circular include dependencies.

//=============================================================
//External References
//=============================================================
//extern Arduino_Canvas *gfx;
extern PSRAMCanvas* gfx;
extern WebServer server;
extern String weatherLocation;
extern String weatherLatitude;
extern String weatherLongitude;
extern String weatherTimezone;
extern String weatherTzString;

//=============================================================
//Font Selection
//=============================================================
bool isSupportedRobotoFontCode(int fontNum);
int  validateRobotoFontCode(int fontNum);
void setSmartFont(int fontNum);
void getTextBoundsHF(const char* str, int16_t x, int16_t y,
                     int16_t* x1, int16_t* y1, uint16_t* w, uint16_t* h);
void printHF(const char* str);
String normalizeDisplayTextEncoding(String s);

//=============================================================
//Color Parsing
//=============================================================
uint16_t parseColor(String colorStr);    //Parse named or hex colors
String   colorToHex(uint16_t color);     //Convert RGB565 to hex
String   colorToString(uint16_t color);

//=============================================================
//NTP Time Functions
//=============================================================
void NTP_Init();        //Initialize NTP and sync time (falls back to RTC if NTP fails)
void NTP_CheckSync();   //Periodic background sync (call from loop)

//=============================================================
//RTC (PCF8563) Functions
//=============================================================
void RTC_Init();                      //Confirm chip presence (Wire already init'd by setup)
bool RTC_IsPresent();                 //True if chip responds on I2C
bool RTC_IsValid();                   //True if VL flag clear (battery OK, time intact)
bool RTC_Read(struct tm& t);          //Read local time from RTC into tm struct
bool RTC_Write(const struct tm& t);   //Write local time to RTC (clears VL flag)

//=============================================================
//Device Identification
//=============================================================
String getDeviceID();    //Get unique device ID from MAC
String getDeviceName();  //Get device name (Display-XXXX)

//=============================================================
//Time Formatting Helpers
//=============================================================
String getTimeString();                      //Get HH:MM:SS format
String getFormattedTime(const char* format); //Get custom format
bool isTimeSynced();                         //Check if time is synced

//=============================================================
//Sunrise/Sunset Management
//=============================================================
void updateSunTimes(int newSunriseHour, int newSunriseMinute,
                    int newSunsetHour, int newSunsetMinute);

//=============================================================
//Calendar Date Math (pure utilities)
//=============================================================
int    getDaysInMonth(int month, int year);      //month 0-11
int    getFirstDayOfMonth(int month, int year);  //returns 0=Sunday..6=Saturday
String getMonthName(int month);                  //month 0-11 -> "January" etc.

//=============================================================
//JSON/GET Parameter Parsing Helpers
//=============================================================
bool getJSON_String(const JsonDocument& doc, const char* key, String& outValue, const char* debugLabel = nullptr);
bool getJSON_Color(const JsonDocument& doc, const char* key, uint16_t& outValue, const char* debugLabel = nullptr);
bool getJSON_Int(const JsonDocument& doc, const char* key, int& outValue, int minVal, int maxVal,
                 const char* debugLabel = nullptr, const char* suffix = "");
bool getJSON_UInt(const JsonDocument& doc, const char* key, uint8_t& outValue, int minVal, int maxVal,
                  const char* debugLabel = nullptr, const char* suffix = "");
bool getJSON_ULong(const JsonDocument& doc, const char* key, unsigned long& outValue, unsigned long minVal, unsigned long maxVal,
                   const char* debugLabel = nullptr, const char* suffix = "");
bool getJSON_Bool(const JsonDocument& doc, const char* key, bool& outValue, const char* debugLabel = nullptr);
bool getJSON_Rotation(const JsonDocument& doc, const char* key, int& outValue, const char* debugLabel = nullptr);

bool getGET_String(const char* key, String& outValue, const char* debugLabel, bool& configChanged);
bool getGET_Color(const char* key, uint16_t& outValue, const char* debugLabel, bool& configChanged);
bool getGET_Int(const char* key, int& outValue, int minVal, int maxVal, const char* debugLabel,
                bool& configChanged, const char* suffix = "");
bool getGET_UInt(const char* key, uint8_t& outValue, int minVal, int maxVal,
                 const char* debugLabel, bool& configChanged);
bool getGET_Bool(const char* key, bool& outValue, const char* debugLabel, bool& configChanged);
bool getGET_Rotation(const char* key, int& outValue, const char* debugLabel, bool& configChanged);

//====================================================================
//Web page for Scheduler configuration (enhanced UI) — defined in HTML.cpp
//====================================================================
void handleSchedulerConfigPage();

//========================================================================================
//Web page not found handler — defined in HTML.cpp
//========================================================================================
void handleNotFound();

//=============================================================
//Text Positioning
//=============================================================
struct TextPosition {
  int16_t x;
  int16_t y;
};

TextPosition calculateTextPosition(
  int16_t screenW, int16_t screenH,
  uint16_t textW, uint16_t textH,
  int16_t textY1,   //y1 from getTextBounds (negative = above baseline)
  String hAlign, String vAlign,
  int16_t marginX = 10,
  int16_t marginY = 10
);

int getRotationIndex(int rotationDeg);  //Convert degrees to Arduino_GFX rotation index

//=============================================================
//JSON Case-Insensitive Key Finding & POST Helpers
//=============================================================
const char* findKeyIgnoreCase(const JsonDocument& doc, const char* key);
bool parseJsonBoolKey(JsonDocument &doc, const char * key, bool &outValue, bool &outFound, const bool currentValue);
void sendJsonMessage(int code, const String& message);

//=============================================================
//RF Signal Quality Helpers
//=============================================================
const char* snrLabel(int snr);  //Returns "Excellent", "Good", "Fair", or "Poor"

//=============================================================
//Build / Firmware Timestamp
//=============================================================
// Pass __DATE__ and __TIME__ from setup() so the macros are evaluated
// in the always-recompiled .ino translation unit, not in HelpFunctions.cpp
// (which is cached and only recompiled when its source changes).
void buildTimestamp(const char* date, const char* time);

#endif //HELPFUNCTIONS_H
