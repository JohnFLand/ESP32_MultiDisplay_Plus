/*
 * PSRAM_Helpers.h
 * Ready-to-use PSRAM optimization code for ESP32 Clock/Weather/Message Display
 *
 * Add this file to your project and include it in your main sketch.
 *
 * NOTE: The utilities below (isLowMemory, PSRAMStringBuffer, SpiRamAllocator,
 * WeatherIconCache, psram_alloc, psram_free, and related helpers) are not
 * currently called anywhere in the sketch.  They are intentionally retained
 * for future use — WeatherIconCache in particular is a natural fit if decoded
 * icon bitmaps are ever moved to PSRAM to reduce heap pressure.  Do not remove
 * without checking whether any of these have been wired in since this comment
 * was written.
 */

#ifndef PSRAM_HELPERS_H
#define PSRAM_HELPERS_H

#include <Arduino.h>
#include "driver/gpio.h"
#include <Arduino_GFX_Library.h>
#include "WebDebugLog.h"    //For DEBUG_PRINT/PRINTLN/PRINTF macros

//=============================================================
// RGBPanelGFXBridge
//  Wraps an Arduino_GFX output target (Arduino_RGB_Display here)
//  so PSRAMCanvas can keep using a stable Arduino_GFX surface while
//  optionally copying flushes through a dedicated transfer buffer and
//  driving the Elecrow backlight in coarse hardware steps.
//=============================================================
typedef void (*HardwareBrightnessCallback)(uint8_t);

class RGBPanelGFXBridge : public Arduino_GFX {
public:
  RGBPanelGFXBridge(Arduino_GFX* output, int16_t w, int16_t h,
                    HardwareBrightnessCallback hwCb = nullptr,
                    bool copyEachFlush = false)
    : Arduino_GFX(w, h), _output(output), _hwCb(hwCb), _brightness(5),
      _copyEachFlush(copyEachFlush) {}

  bool begin(int32_t speed = GFX_NOT_DEFINED) override {
    return _output ? _output->begin(speed) : false;
  }

  void draw16bitRGBBitmap(int16_t x, int16_t y,
                          uint16_t *bitmap, int16_t w, int16_t h) override {
    if (!_output || !bitmap || w <= 0 || h <= 0) return;

    int32_t totalPx = (int32_t)w * h;

    // For RGB panels on ESP32-S3, a dedicated transfer buffer often yields a
    // steadier image than handing the live canvas buffer directly to the panel
    // driver while the app continues drawing into it.
    bool needScratch = _copyEachFlush;

    if (!needScratch) {
      _output->draw16bitRGBBitmap(x, y, bitmap, w, h);
      return;
    }

    if (_dimBufPx < totalPx) {
      if (_dimBuf) heap_caps_free(_dimBuf);
      _dimBuf = (uint16_t*)heap_caps_malloc(totalPx * sizeof(uint16_t), MALLOC_CAP_SPIRAM);
      _dimBufPx = _dimBuf ? totalPx : 0;
    }
    if (!_dimBuf) return;
    memcpy(_dimBuf, bitmap, totalPx * sizeof(uint16_t));

    _output->draw16bitRGBBitmap(x, y, _dimBuf, w, h);
  }

  void setBrightness(uint8_t b) {
    _brightness = b;
    if (_hwCb) _hwCb(b);
  }

  //Called by the main loop drain after flushDisplay() has fully settled.
  //Updates the stored level AND fires the I2C write in one step, but only
  //ever called from a safe point (top of loop) where no DMA is in flight.
  void applyDeferredBrightness(uint8_t b) {
    _brightness = b;
    if (_hwCb) _hwCb(b);
  }

  uint8_t getBrightness() const { return _brightness; }

  // Keep the physical panel fixed in native landscape; only the canvas rotates.
  void setRotation(uint8_t r) override { (void)r; }

  //Arduino_GFX pure virtuals — not used (PSRAMCanvas overrides all drawing)
  void writePixelPreclipped(int16_t x, int16_t y, uint16_t color) override {}
  void writeFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) override {}
  void writeFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) override {}
  void writeFillRectPreclipped(int16_t x, int16_t y,
                               int16_t w, int16_t h, uint16_t color) override {}

private:
  Arduino_GFX* _output = nullptr;
  HardwareBrightnessCallback _hwCb = nullptr;
  uint8_t _brightness = 5;
  bool _copyEachFlush = false;
  uint16_t* _dimBuf = nullptr;
  int32_t _dimBufPx = 0;
};

//=============================================================
//PSRAM Detection and Configuration
//=============================================================
/*
 * Initialize PSRAM and configure malloc to prefer PSRAM for large allocations
 * Call this early in setup()
 */
inline bool initPSRAM(uint32_t threshold = 8192) {
  if (!psramFound()) {
    DEBUG_PRINTLN("[PSRAM] Not found or not enabled");
    return false;
  }
  
  DEBUG_PRINTF("\nPSRAM Found : %d bytes\n", ESP.getPsramSize());
  DEBUG_PRINTF("PSRAM Free  : %d bytes\n", ESP.getFreePsram());
  
  //Configure heap allocator to use PSRAM for allocations larger than threshold
  #if CONFIG_SPIRAM_USE_MALLOC || CONFIG_SPIRAM_USE_CAPS_ALLOC
    heap_caps_malloc_extmem_enable(threshold);
    DEBUG_PRINTF("PSRAM Configured: malloc will use PSRAM for allocations > %d bytes\n", threshold);
  #else
    DEBUG_PRINTLN("PSRAM Warning: SPIRAM malloc not configured in build flags");
  #endif
  
  return true;
}

//=============================================================
//Memory Diagnostics
//=============================================================
/*
 * Print detailed memory statistics to Serial & optionally to Web Log
 * Useful for debugging and monitoring
 */
inline void printMemoryStats() {
  DEBUG_PRINTLN("");
  DEBUG_PRINTLN("=== MEMORY STATISTICS === ");
  //Internal RAM (DRAM)
  DEBUG_PRINTF("  Heap Size             : %7d bytes\n", ESP.getHeapSize());
  DEBUG_PRINTF("  Free Heap             : %7d bytes\n", ESP.getFreeHeap());
  DEBUG_PRINTF("  Min Free Heap         : %7d bytes\n", ESP.getMinFreeHeap());
  DEBUG_PRINTF("  Max Alloc Heap        : %7d bytes\n", ESP.getMaxAllocHeap());
  
  multi_heap_info_t info;
  heap_caps_get_info(&info, MALLOC_CAP_INTERNAL);
  DEBUG_PRINTF("  Largest Free Block    : %7d bytes\n", info.largest_free_block);
  
  //PSRAM
  if (psramFound()) {
    DEBUG_PRINTF("  PSRAM Size            : %7d bytes\n", ESP.getPsramSize());
    DEBUG_PRINTF("  Free PSRAM            : %7d bytes\n", ESP.getFreePsram());
    DEBUG_PRINTF("  Min Free PSRAM        : %7d bytes\n", ESP.getMinFreePsram());
    DEBUG_PRINTF("  Max Alloc PSRAM       : %7d bytes\n", ESP.getMaxAllocPsram());
    
    heap_caps_get_info(&info, MALLOC_CAP_SPIRAM);
    DEBUG_PRINTF("  PSRAM Largest Block   : %6d bytes\n", info.largest_free_block);
  } else {
    DEBUG_PRINTLN("=== PSRAM: Not available ===");
  }
}

/**
 * Lightweight memory check - returns true if low on memory
 */
inline bool isLowMemory(uint32_t minFreeHeap = 50000, uint32_t minFreePsram = 1000000) {
  bool lowHeap = ESP.getFreeHeap() < minFreeHeap;
  bool lowPsram = psramFound() && (ESP.getFreePsram() < minFreePsram);
  return lowHeap || lowPsram;
}

//=============================================================
//PSRAM Canvas for Arduino_GFX
//=============================================================
/*
 * Custom Canvas class that allocates framebuffer in PSRAM
 * Drop-in replacement for Arduino_Canvas
 * 
 * Usage: PSRAMCanvas* gfx = new PSRAMCanvas(320, 480, g);
 */
class PSRAMCanvas : public Arduino_Canvas {
protected:
  bool _usedPSRAM = false;
  
public:
  PSRAMCanvas(int16_t w, int16_t h, Arduino_GFX *output, 
              int16_t output_x = 0, int16_t output_y = 0, uint8_t r = 0)
    : Arduino_Canvas(w, h, output, output_x, output_y, r) {
    
    //Calculate buffer size (RGB565 = 2 bytes per pixel)
    size_t bufferSize = w * h * 2;
    
    //Try to allocate in PSRAM first
    uint16_t* psramBuffer = nullptr;
    if (psramFound()) {
      psramBuffer = (uint16_t*)heap_caps_malloc(bufferSize, MALLOC_CAP_SPIRAM);
    }
    
    if (psramBuffer) {
      //Success - replace the default buffer with PSRAM buffer
      if (_framebuffer) {
        free(_framebuffer);  //Free the heap buffer that Arduino_Canvas allocated
      }
      _framebuffer = psramBuffer;
      _usedPSRAM = true;
      DEBUG_PRINTF("[PSRAMCanvas] Allocated %d bytes in PSRAM\n", bufferSize);
    } else {
      //Fall back to default heap allocation
      DEBUG_PRINTF("[PSRAMCanvas] PSRAM allocation failed, using heap (%d bytes)\n", bufferSize);
      //Arduino_Canvas already allocated buffer in heap, so just continue using it
      _usedPSRAM = false;
    }
  }
  
  ~PSRAMCanvas() {
    //Arduino_Canvas destructor will free the buffer
    //but we need to use the right free function
    if (_usedPSRAM && _framebuffer) {
      heap_caps_free(_framebuffer);
      _framebuffer = nullptr; //Prevent double-free
    }
  }
  
  bool isUsingPSRAM() const { return _usedPSRAM; }
};

//=============================================================
//PSRAM String Buffer for HTML Generation
//=============================================================
/*
 * String buffer that allocates in PSRAM
 * Useful for large HTML generation to avoid heap fragmentation
 * 
 * Usage:
 *   PSRAMStringBuffer html(32768); //32KB buffer
 *   html.append("<!DOCTYPE html>");
 *   html.append("<html><body>...");
 *   server.send(200, "text/html", html.c_str());
 */
class PSRAMStringBuffer {
private:
  char* _buffer;
  size_t _capacity;
  size_t _length;
  bool _usedPSRAM;
  
public:
  PSRAMStringBuffer(size_t initialCapacity = 16384) {
    _capacity = initialCapacity;
    _length = 0;
    _usedPSRAM = false;
    
    //Try PSRAM first
    if (psramFound()) {
      _buffer = (char*)heap_caps_malloc(_capacity, MALLOC_CAP_SPIRAM);
      if (_buffer) {
        _usedPSRAM = true;
      }
    }
    
    //Fallback to heap
    if (!_buffer) {
      _buffer = (char*)malloc(_capacity);
    }
    
    if (_buffer) {
      _buffer[0] = '\0';
      DEBUG_PRINTF("[PSRAMStringBuffer] Allocated %d bytes in %s\n", 
                    _capacity, _usedPSRAM ? "PSRAM" : "heap");
    } else {
      DEBUG_PRINTLN("[PSRAMStringBuffer] ALLOCATION FAILED!");
    }
  }
  
  ~PSRAMStringBuffer() {
    if (_buffer) {
      if (_usedPSRAM) {
        heap_caps_free(_buffer);
      } else {
        free(_buffer);
      }
    }
  }
  
  bool append(const char* str) {
    if (!_buffer || !str) return false;
    
    size_t len = strlen(str);
    
    //Check if we need to expand
    if (_length + len + 1 >= _capacity) {
      size_t newCapacity = (_length + len + 1) * 2;
      
      char* newBuf = nullptr;
      if (_usedPSRAM) {
        newBuf = (char*)heap_caps_realloc(_buffer, newCapacity, MALLOC_CAP_SPIRAM);
      } else {
        newBuf = (char*)realloc(_buffer, newCapacity);
      }
      
      if (!newBuf) {
        DEBUG_PRINTLN("[PSRAMStringBuffer] Realloc failed!");
        return false;
      }
      
      _buffer = newBuf;
      _capacity = newCapacity;
    }
    
    //Append the string
    strcpy(_buffer + _length, str);
    _length += len;
    return true;
  }
  
  bool append(const String& str) {
    return append(str.c_str());
  }
  
  void clear() {
    if (_buffer) {
      _buffer[0] = '\0';
      _length = 0;
    }
  }
  
  const char* c_str() const { return _buffer; }
  size_t length() const { return _length; }
  size_t capacity() const { return _capacity; }
  bool isUsingPSRAM() const { return _usedPSRAM; }
};

//=============================================================
//PSRAM Allocator for ArduinoJson v7
//=============================================================
/*
 * Custom allocator for ArduinoJson that uses PSRAM
 * 
 * Usage:
 *   JsonDocument doc(SpiRamAllocator::instance());
 *   //or
 *   BasicJsonDocument<SpiRamAllocator> doc(4096);
 */
struct SpiRamAllocator {
  void* allocate(size_t size) {
    void* ptr = nullptr;
    
    //Try PSRAM first if available
    if (psramFound()) {
      ptr = heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
    }
    
    //Fallback to regular heap
    if (!ptr) {
      ptr = malloc(size);
    }
    
    return ptr;
  }
  
  void deallocate(void* ptr) {
    heap_caps_free(ptr);  //Works for both PSRAM and heap
  }
  
  void* reallocate(void* ptr, size_t new_size) {
    //heap_caps_realloc works for both PSRAM and heap
    return heap_caps_realloc(ptr, new_size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  }
  
  static SpiRamAllocator& instance() {
    static SpiRamAllocator allocator;
    return allocator;
  }
};

//=============================================================
//Weather Icon Cache (Optional - for frequently redrawn icons)
//=============================================================
/*
 * Cache weather icons in PSRAM for faster access than PROGMEM
 * Only useful if icons are redrawn frequently
 * Uses ~400KB of PSRAM when all icons cached
 */
class WeatherIconCache {
public:
  enum IconType {
    ICON_SUN = 0,
    ICON_CLOUD,
    ICON_RAIN,
    ICON_THUNDER,
    ICON_SNOW,
    ICON_NIGHT,
    ICON_TEMPERATURE,
    ICON_HUMIDITY,
    ICON_COUNT
  };
  
private:
  struct CachedIcon {
    uint16_t* rgb565;
    uint8_t* alpha;
    int16_t width;
    int16_t height;
    bool valid;
  };
  
  CachedIcon cache[ICON_COUNT];
  
public:
  WeatherIconCache() {
    memset(cache, 0, sizeof(cache));
  }
  
  ~WeatherIconCache() {
    clearAll();
  }
  
  /*
   * Load an icon from PROGMEM into PSRAM cache
   */
  bool loadIcon(IconType type, const uint16_t* progmem_rgb, 
                const uint8_t* progmem_alpha, int16_t w, int16_t h) {
    if (type >= ICON_COUNT) return false;
    if (cache[type].valid) return true; //Already loaded
    
    size_t pixelCount = w * h;
    size_t rgbSize = pixelCount * sizeof(uint16_t);
    size_t alphaSize = pixelCount * sizeof(uint8_t);
    
    //Allocate in PSRAM
    uint16_t* rgb = nullptr;
    uint8_t* alpha = nullptr;
    
    if (psramFound()) {
      rgb = (uint16_t*)heap_caps_malloc(rgbSize, MALLOC_CAP_SPIRAM);
      alpha = (uint8_t*)heap_caps_malloc(alphaSize, MALLOC_CAP_SPIRAM);
    }
    
    if (!rgb || !alpha) {
      if (rgb) heap_caps_free(rgb);
      if (alpha) heap_caps_free(alpha);
      DEBUG_PRINTF("[IconCache] Failed to allocate %d bytes for icon %d\n", 
                    rgbSize + alphaSize, type);
      return false;
    }
    
    //Copy from PROGMEM to PSRAM
    memcpy_P(rgb, progmem_rgb, rgbSize);
    memcpy_P(alpha, progmem_alpha, alphaSize);
    
    cache[type].rgb565 = rgb;
    cache[type].alpha  = alpha;
    cache[type].width  = w;
    cache[type].height = h;
    cache[type].valid  = true;
    
    DEBUG_PRINTF("[IconCache] Loaded icon %d (%dx%d, %d bytes)\n", 
                  type, w, h, rgbSize + alphaSize);
    return true;
  }
  
  /**
   * Get cached icon data (or nullptr if not cached)
   */
  const uint16_t* getRGB(IconType type) const {
    return (type < ICON_COUNT && cache[type].valid) ? cache[type].rgb565 : nullptr;
  }
  
  const uint8_t* getAlpha(IconType type) const {
    return (type < ICON_COUNT && cache[type].valid) ? cache[type].alpha : nullptr;
  }
  
  int16_t getWidth(IconType type) const {
    return (type < ICON_COUNT && cache[type].valid) ? cache[type].width : 0;
  }
  
  int16_t getHeight(IconType type) const {
    return (type < ICON_COUNT && cache[type].valid) ? cache[type].height : 0;
  }
  
  bool isCached(IconType type) const {
    return type < ICON_COUNT && cache[type].valid;
  }
  
  /*
   * Clear a specific icon from cache
   */
  void clearIcon(IconType type) {
    if (type < ICON_COUNT && cache[type].valid) {
      heap_caps_free(cache[type].rgb565);
      heap_caps_free(cache[type].alpha);
      cache[type].valid = false;
    }
  }
  
  /**
   * Clear all cached icons
   */
  void clearAll() {
    for (int i = 0; i < ICON_COUNT; i++) {
      clearIcon((IconType)i);
    }
  }
  
  /*
   * Get total memory used by cache
   */
  size_t getMemoryUsage() const {
    size_t total = 0;
    for (int i = 0; i < ICON_COUNT; i++) {
      if (cache[i].valid) {
        size_t pixels = cache[i].width * cache[i].height;
        total += pixels * sizeof(uint16_t); //RGB565
        total += pixels * sizeof(uint8_t);  //Alpha
      }
    }
    return total;
  }
};

//=============================================================
//Helper: Allocate any data structure in PSRAM
//=============================================================
/*
 * Template function to allocate any type in PSRAM
 * 
 * Usage:
 *   Message* messages = psram_alloc<Message>(20);  //Array of 20 Messages
 *   free(messages);  //heap_caps_free works for PSRAM too
 */
template<typename T>
T* psram_alloc(size_t count = 1) {
  size_t size = sizeof(T) * count;
  T* ptr = nullptr;
  
  if (psramFound()) {
    ptr = (T*)heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
  }
  
  if (!ptr) {
    ptr = (T*)malloc(size);  //Fallback to heap
  }
  
  return ptr;
}

/*
 * Free memory allocated with psram_alloc or any heap_caps_malloc
 */
template<typename T>
void psram_free(T* ptr) {
  heap_caps_free((void*)ptr);
}

#endif //PSRAM_HELPERS_H
