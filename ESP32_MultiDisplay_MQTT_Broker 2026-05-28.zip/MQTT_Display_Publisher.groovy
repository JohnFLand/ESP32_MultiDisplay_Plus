/**
 * Hubitat MQTT Display Publisher
 * Replaces MultiPOST Sender for display message routing via MQTT.
 *
 * INSTALLATION:
 *   Drivers Code → New Driver → paste this file → Save
 *   Devices → Add Virtual Device → select "MQTT Display Publisher"
 *   Configure the device with your broker IP/port.
 *
 * USAGE IN RULE MACHINE:
 *   Action: Run Custom Action on device "MQTT Display Publisher"
 *     - publishMessage(body)          → display/message        (all displays)
 *     - publishClear()                → display/clear          (all displays)
 *     - publishToGroup(group, body)   → display/message/<group>
 *     - publishToDevice(name, body)   → display/message/device/<name>
 *     - publishControl(json)          → device/control
 *     - publishClockConfig(json)      → device/clockconfig
 *     - publishScreen(screen)         → display/screen
 *     - clearPublishCount()           → resets the publishCount counter to 0
 *
 * GROUP NAMES:
 *   The group parameter in publishToGroup() is a free-form string matching
 *   the MQTT topic suffix used in the broker sketch:
 *     "elecrow" → targets the Elecrow 5" display only
 *     "cyd"     → targets all CYD displays only
 *   Add new groups to the broker sketch and use the same names here.
 *   The "Available Groups" preference below is a reminder of configured groups.
 *
 * DEVICE NAMES:
 *   The name parameter in publishToDevice() must exactly match the "name"
 *   field in the broker's displays.json (case-sensitive, including underscores).
 *   Example: "CYD_Bookcase"
 *
 * DEPENDENCIES:
 *   Requires the MQTT built-in capability introduced in Hubitat firmware 2.3.x
 *   (uses hubitat.device.HubAction with MQTT protocol — no external app needed).
 */

metadata {
    definition(
        name:        "MQTT Display Publisher 1.1",
        namespace:   "John Land",
        author:      "John Land and Claude AI",
        description: "Publishes display messages and control commands to an MQTT broker"
    ) {
        capability "Actuator"
        capability "Initialize"

        command "publishMessage", [
            [name: "Body*", type: "STRING",
             description: "JSON message body (same format your displays already accept)"]
        ]

        command "sendPosts", [
            [name: "Body*", type: "STRING",
            description: "Compatibility alias for publishMessage() — drop-in replacement for MultiPOST Sender's sendPosts command"]
        ]

        command "publishClear"

        command "publishToGroup", [
            [name: "Group*", type: "STRING",
             description: "Group name (e.g. elecrow, cyd). See 'Available Groups' preference."],
            [name: "Body*",  type: "STRING",
             description: "JSON message body"]
        ]

        command "publishToDevice", [
            [name: "DeviceName*", type: "STRING",
             description: "Exact display name from displays.json (e.g. CYD_Bookcase)"],
            [name: "Body*",       type: "STRING",
             description: "JSON message body"]
        ]

        command "publishControl", [
            [name: "Json*", type: "STRING",
             description: "JSON matching /control endpoint (e.g. {\"reboot\":true}, {\"clockdark\":\"toggle\"})"]
        ]

        command "publishClockConfig", [
            [name: "Json*", type: "STRING",
             description: "JSON matching POST /clockconfig endpoint"]
        ]

        command "publishScreen", [
            [name: "Screen*", type: "ENUM", constraints: ["clock", "weather", "calendar"],
             description: "Screen to navigate to"]
        ]

        command "reconnect"
        command "clearPublishCount"

        attribute "connectionStatus",  "STRING"   // "connected" / "disconnected"
        attribute "lastTopic",         "STRING"
        attribute "lastPublishBody",   "STRING"
        attribute "lastPublishTime",   "STRING"
        attribute "publishCount",      "NUMBER"
        attribute "lastError",         "STRING"   // cleared on success; set on publish exception
    }

    preferences {
        input name:  "brokerIP",
              type:  "string",
              title: "MQTT Broker IP address",
              description: "IP of your Elecrow 5\" broker",
              required: true,
              defaultValue: "192.168.1.32"

        input name:  "brokerPort",
              type:  "number",
              title: "MQTT Broker port",
              required: true,
              defaultValue: 1883

        input name:  "clientId",
              type:  "string",
              title: "MQTT Client ID",
              description: "Unique ID for this Hubitat connection — must be unique across all MQTT clients",
              required: true,
              defaultValue: "hubitat-display"

        input name:  "defaultTopic",
              type:  "string",
              title: "Default topic for publishMessage()",
              description: "Topic used by publishMessage(). Change to 'display/message/elecrow' or 'display/message/cyd' to narrow the default target.",
              required: true,
              defaultValue: "display/message"

        input name:  "availableGroups",
              type:  "string",
              title: "Available Groups (reference only)",
              description: "Comma-separated list of group names configured in the broker sketch. " +
                           "Used as a reminder when calling publishToGroup() from Rule Machine. " +
                           "Does not affect behaviour — the group name is typed freely in each rule action.",
              required: false,
              defaultValue: "elecrow, cyd"

        input name:  "enableDebug",
              type:  "bool",
              title: "Enable debug logging",
              defaultValue: true
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// LIFECYCLE
// ─────────────────────────────────────────────────────────────────────────────

def installed() {
    log.info "${device.label}: installed"
    sendEvent(name: "publishCount", value: 0)
    sendEvent(name: "lastError",    value: "")
    initialize()
}

def updated() {
    log.info "${device.label}: updated — reconnecting"
    initialize()
}

def initialize() {
    try { mqttDisconnect() } catch (e) { /* ignore if not previously connected */ }
    mqttConnect()
}

// ─────────────────────────────────────────────────────────────────────────────
// MQTT CONNECTION
// ─────────────────────────────────────────────────────────────────────────────

def mqttConnect() {
    def broker = "tcp://${brokerIP}:${brokerPort}"
    if (enableDebug) log.debug "${device.label}: connecting to ${broker}"

    try {
        interfaces.mqtt.connect(broker, clientId, null, null)
        // Connection result arrives in mqttClientStatus() callback below
    } catch (e) {
        log.error "${device.label}: MQTT connect exception: ${e.message}"
        sendEvent(name: "connectionStatus", value: "disconnected")
        runIn(30, "initialize")
    }
}

def mqttDisconnect() {
    try { interfaces.mqtt.disconnect() } catch (e) { /* ignore */ }
}

void mqttClientStatus(String status) {
    if (enableDebug) log.debug "${device.label}: MQTT status: ${status}"

    if (status.startsWith("Status: Connection succeeded")) {
        sendEvent(name: "connectionStatus", value: "connected")
        log.info "${device.label}: MQTT connected to ${brokerIP}:${brokerPort}"
    } else {
        log.warn "${device.label}: MQTT disconnected — ${status} — retrying in 30s"
        sendEvent(name: "connectionStatus", value: "disconnected")
        runIn(30, "initialize")
    }
}

def reconnect() {
    log.info "${device.label}: Manual reconnect requested"
    initialize()
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLISH COMMANDS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Publish to the default topic (all displays by default).
 * Rule Machine: Run Custom Action → publishMessage → JSON body
 */
def publishMessage(String body) {
    publishToTopic(defaultTopic ?: "display/message", body)
}

/**
 * Compatibility alias for the old MultiPOST Sender 'sendPosts' command.
 * Delegates directly to publishMessage() so existing rules can be
 * migrated without modification.
 * Rule Machine: Run Custom Action → sendPosts → JSON body
 */
def sendPosts(String body) {
    if (enableDebug) log.debug "${device.label}: sendPosts() called — delegating to publishMessage()"
    publishMessage(body)
}

/**
 * Clear all displays.
 * Rule Machine: Run Custom Action → publishClear
 */
def publishClear() {
    publishToTopic("display/clear", "{}")
}

/**
 * Publish to a named group of displays.
 * Rule Machine: Run Custom Action → publishToGroup → group name → JSON body
 * Group names are free-form strings matching the broker sketch topic routing.
 * See 'Available Groups' preference for a reminder of configured names.
 */
def publishToGroup(String group, String body) {
    if (!group?.trim()) {
        log.warn "${device.label}: publishToGroup called with empty group name — ignored"
        return
    }
    publishToTopic("display/message/${group.trim()}", body)
}

/**
 * Publish to a single named display.
 * The name must exactly match the "name" field in the broker's displays.json.
 * Rule Machine: Run Custom Action → publishToDevice → device name → JSON body
 */
def publishToDevice(String deviceName, String body) {
    if (!deviceName?.trim()) {
        log.warn "${device.label}: publishToDevice called with empty device name — ignored"
        return
    }
    publishToTopic("display/message/device/${deviceName.trim()}", body)
}

/**
 * Publish a control command to device/control.
 * Accepts the same JSON keys as POST /control on the broker sketch.
 * Rule Machine: Run Custom Action → publishControl → JSON
 * Examples: {"reboot":true}  {"clockdark":"toggle"}  {"clear":true}
 */
def publishControl(String json) {
    publishToTopic("device/control", json)
}

/**
 * Publish a clock configuration command to device/clockconfig.
 * Accepts the same JSON keys as POST /clockconfig on the broker sketch.
 * Rule Machine: Run Custom Action → publishClockConfig → JSON
 * Example: {"timefont":60,"nightmodeenable":true}
 */
def publishClockConfig(String json) {
    publishToTopic("device/clockconfig", json)
}

/**
 * Navigate to a screen on the broker display.
 * Rule Machine: Run Custom Action → publishScreen → screen name
 */
def publishScreen(String screen) {
    publishToTopic("display/screen", screen)
}

/**
 * Reset the publishCount counter to zero.
 * Rule Machine: Run Custom Action → clearPublishCount
 */
def clearPublishCount() {
    sendEvent(name: "publishCount", value: 0)
    sendEvent(name: "lastError",    value: "")
    log.info "${device.label}: publishCount and lastError reset"
}

// Internal publish helper — used by all publish commands above
private publishToTopic(String topic, String body) {
    if (device.currentValue("connectionStatus") != "connected") {
        log.warn "${device.label}: Not connected — attempting reconnect before publish"
        initialize()
        pauseExecution(1000)
    }

    try {
        interfaces.mqtt.publish(topic, body, 1, false)
        // QoS 1 = at-least-once delivery; false = not retained

        int count = (device.currentValue("publishCount") ?: 0) as int
        sendEvent(name: "publishCount",    value: count + 1)
        sendEvent(name: "lastTopic",       value: topic)
        sendEvent(name: "lastPublishBody", value: body.take(200))
        sendEvent(name: "lastPublishTime", value: new Date().toString())
        sendEvent(name: "lastError",       value: "")

        if (enableDebug) log.debug "${device.label}: Published to ${topic}: ${body.take(80)}"

    } catch (e) {
        log.error "${device.label}: Publish failed: ${e.message}"
        sendEvent(name: "connectionStatus", value: "disconnected")
        sendEvent(name: "lastError",        value: e.message ?: "Publish exception")
        runIn(5, "initialize")
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// INCOMING MESSAGES
// ─────────────────────────────────────────────────────────────────────────────

def parse(String message) {
    // This driver only publishes; it does not subscribe to any topics.
    if (enableDebug) log.debug "${device.label}: Received: ${message}"
}
