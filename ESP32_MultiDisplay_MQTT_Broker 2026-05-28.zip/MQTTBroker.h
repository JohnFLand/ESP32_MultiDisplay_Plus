#pragma once
//=============================================================
// MQTTBroker.h  —  Public API for the MQTT broker module
//
// Include this in ESP32_MultiDisplay_MQTT_Broker.ino.
// The broker class lives in MQTTBroker.cpp (separate translation
// unit, never processed by Arduino's prototype generator).
// MQTTBroker.ino provides bridge wrappers that give MQTTBroker.cpp
// access to sketch-internal types without exposing them to the
// .cpp translation unit.
//=============================================================

// ── Called from setup() and loop() ──────────────────────────────────────
void startMqttBroker();    // init LittleFS, load CYD list, start broker
void mqttBrokerUpdate();   // call every loop() — keeps client I/O running

// ── Bridge wrappers defined in MQTTBroker.ino ───────────────────────────

// Switch to SCREEN_MESSAGE (deactivates screensaver, disables clock)
void mqttPushMessageScreen();

// Clear all pending/active messages and return to clock
void mqttClearDisplay();

// Trigger async screen change via pendingScreen; use MQTT_SCREEN_* below
void mqttShowScreen(int screen);

// Save settings to NVS, then redraw whatever screen is currently active
void mqttSaveSettingsAndRedraw();

// Apply clock config: optionally mark colors customized, save, update
// night mode, and redraw clock if on clock screen
void mqttClockConfigApply(bool anyColorChanged);

// Clear message history (not active messages/queue)
void mqttClearHistory();

// Clear all NVS settings and reboot  (used by resetsettings / resetdevice)
void mqttResetSettingsAndReboot();

// Redraw weather screen immediately if it is active and showing the
// local-pressure turn — called when MQTT delivers a fresh pressure value
void mqttRefreshWeatherIfShowing();

// ── MQTT retained-topic publishers ────────────────────────────────────────
// Low-level: publish any topic/payload pair with optional retain flag.
// Note: calls broker.publish() — adjust signature if sMQTTBroker version
//       uses const char* instead of std::string.
void mqttPublish(const char* topic, const char* payload, bool retain = true);
void mqttPublishPressureHistory();  // Called after every pressure reading and on new client connect

// Set true by ESP32_MultiDisplay_MQTT_Broker.ino after loadPressureBuffer() completes.
// Guards the NewClient handler from publishing an empty history snapshot before
// the buffer has been restored from LittleFS.
extern bool mqttHistoryReady;

// High-level bridge wrappers (defined in MQTTBroker.ino; have access to
// all sketch globals that .cpp cannot see directly).
void mqttPublishWeather();          // Called after successful Open-Meteo fetch
void mqttPublishPressure();         // Called after successful local-pressure fetch/receive
void mqttPublishTime();             // Called on 60-second timer from loop()
        
// ── Screen index constants (must match ScreenMode enum in main .ino) ────
// SCREEN_NONE=-1, SCREEN_CLOCK=0, SCREEN_MENU=1, SCREEN_MESSAGE=2,
// SCREEN_MESSAGES=3, SCREEN_WEATHER=4, SCREEN_CALENDAR=5, SCREEN_ASTRO=6
constexpr int MQTT_SCREEN_CLOCK    = 0;
constexpr int MQTT_SCREEN_WEATHER  = 4;
constexpr int MQTT_SCREEN_CALENDAR = 5;
